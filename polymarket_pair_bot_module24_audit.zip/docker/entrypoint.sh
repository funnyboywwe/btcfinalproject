#!/bin/sh
# Container entrypoint for the polymarket_pair_bot image.
#
# One minimal image serves several single-purpose roles. Every branch uses
# `exec` so the orchestrator's SIGTERM reaches the target process directly,
# enabling the application's graceful shutdown (bounded by SHUTDOWN_TIMEOUT).
#
# Safety:
#   * Trading stays OFF unless the operator explicitly sets PAPER_TRADING /
#     LIVE_TRADING via the protected env files. This script sets nothing.
#   * This script never echoes environment variables or secrets.
set -eu

cmd="${1:-bot}"

case "$cmd" in
  bot)
    # Long-running application lifecycle (leader election, feeds, execution).
    exec polymarket-pair-bot
    ;;
  migrate)
    # Idempotent Alembic upgrade to head, then exit 0. Run as a one-shot job
    # BEFORE starting the bot (see the compose `migrate` service).
    exec python -m polymarket_pair_bot.persistence.cli migrate
    ;;
  db-health)
    # Connectivity + current migration revision (exit non-zero if unhealthy).
    exec python -m polymarket_pair_bot.persistence.cli health
    ;;
  healthcheck)
    # Postgres + Redis reachability probe (used by Docker HEALTHCHECK).
    exec python /app/scripts/healthcheck.py
    ;;
  *)
    # Escape hatch for read-only diagnostics (e.g. `reconcile`, `db-health`).
    # Never the default; the operator must ask for it explicitly.
    exec "$@"
    ;;
esac
