"""initial persistence schema (Module 3)

Revision ID: 0001_initial
Revises:
Create Date: 2026-07-17

Creates all 15 persistence tables. Monetary/price/quantity columns use NUMERIC
(fixed-point) so values round-trip as Decimal -- never binary floats. Unique
constraints enforce idempotency for exchange order ids, fill ids, client
idempotency keys (intent / risk decision / CTF operation) and the blockchain
operation key.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0001_initial"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_PRICE = sa.Numeric(precision=12, scale=6)
_SHARES = sa.Numeric(precision=30, scale=6)
_USD = sa.Numeric(precision=30, scale=6)
_PROFIT = sa.Numeric(precision=30, scale=6)
_ID = sa.String(length=128)
_HASH = sa.String(length=128)
_ENUM = sa.String(length=32)


def _recorded_at() -> sa.Column:
    return sa.Column(
        "recorded_at",
        sa.DateTime(timezone=True),
        server_default=sa.func.now(),
        nullable=False,
    )


def upgrade() -> None:
    op.create_table(
        "markets",
        sa.Column("market_id", _ID, nullable=False),
        sa.Column("condition_id", _HASH, nullable=False),
        sa.Column("up_token_id", _ID, nullable=False),
        sa.Column("down_token_id", _ID, nullable=False),
        sa.Column("up_tick_size", _PRICE, nullable=False),
        sa.Column("down_tick_size", _PRICE, nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("market_id", name="pk_markets"),
        sa.UniqueConstraint("condition_id", name="uq_markets_condition_id"),
    )
    op.create_index("ix_markets_recorded_at", "markets", ["recorded_at"])

    op.create_table(
        "market_windows",
        sa.Column("market_id", _ID, nullable=False),
        sa.Column("condition_id", _HASH, nullable=False),
        sa.Column("open_time", sa.BigInteger(), nullable=False),
        sa.Column("close_time", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("market_id", name="pk_market_windows"),
        sa.ForeignKeyConstraint(
            ["market_id"],
            ["markets.market_id"],
            name="fk_market_windows_market_id_markets",
            ondelete="CASCADE",
        ),
    )
    op.create_index(
        "ix_market_windows_recorded_at", "market_windows", ["recorded_at"]
    )

    op.create_table(
        "order_intents",
        sa.Column("intent_id", _ID, nullable=False),
        sa.Column("market_id", _ID, nullable=False),
        sa.Column("token_id", _ID, nullable=False),
        sa.Column("side", _ENUM, nullable=False),
        sa.Column("limit_price", _PRICE, nullable=False),
        sa.Column("size", _SHARES, nullable=False),
        sa.Column("time_in_force", _ENUM, nullable=False),
        sa.Column("created_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("intent_id", name="pk_order_intents"),
    )
    op.create_index("ix_order_intents_market_id", "order_intents", ["market_id"])
    op.create_index(
        "ix_order_intents_recorded_at", "order_intents", ["recorded_at"]
    )

    op.create_table(
        "exchange_orders",
        sa.Column("order_id", _ID, nullable=False),
        sa.Column("intent_id", _ID, nullable=False),
        sa.Column("token_id", _ID, nullable=False),
        sa.Column("market_id", _ID, nullable=False),
        sa.Column("side", _ENUM, nullable=False),
        sa.Column("limit_price", _PRICE, nullable=False),
        sa.Column("original_size", _SHARES, nullable=False),
        sa.Column("filled_size", _SHARES, nullable=False),
        sa.Column("status", _ENUM, nullable=False),
        sa.Column("created_at", sa.BigInteger(), nullable=False),
        sa.Column("updated_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("order_id", name="pk_exchange_orders"),
    )
    op.create_index(
        "ix_exchange_orders_intent_id", "exchange_orders", ["intent_id"]
    )
    op.create_index(
        "ix_exchange_orders_market_id", "exchange_orders", ["market_id"]
    )
    op.create_index("ix_exchange_orders_status", "exchange_orders", ["status"])
    op.create_index(
        "ix_exchange_orders_recorded_at", "exchange_orders", ["recorded_at"]
    )

    op.create_table(
        "fills",
        sa.Column("fill_id", _ID, nullable=False),
        sa.Column("order_id", _ID, nullable=False),
        sa.Column("token_id", _ID, nullable=False),
        sa.Column("side", _ENUM, nullable=False),
        sa.Column("price", _PRICE, nullable=False),
        sa.Column("size", _SHARES, nullable=False),
        sa.Column("fee", _USD, nullable=False),
        sa.Column("filled_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("fill_id", name="pk_fills"),
        sa.ForeignKeyConstraint(
            ["order_id"],
            ["exchange_orders.order_id"],
            name="fk_fills_order_id_exchange_orders",
            ondelete="RESTRICT",
        ),
    )
    op.create_index("ix_fills_order_id", "fills", ["order_id"])
    op.create_index("ix_fills_recorded_at", "fills", ["recorded_at"])

    op.create_table(
        "inventory_snapshots",
        sa.Column(
            "id", sa.BigInteger(), autoincrement=True, nullable=False
        ),
        sa.Column("market_id", _ID, nullable=False),
        sa.Column("up_token_id", _ID, nullable=False),
        sa.Column("up_quantity", _SHARES, nullable=False),
        sa.Column("up_average_price", _PRICE, nullable=False),
        sa.Column("up_fees_paid", _USD, nullable=False),
        sa.Column("down_token_id", _ID, nullable=False),
        sa.Column("down_quantity", _SHARES, nullable=False),
        sa.Column("down_average_price", _PRICE, nullable=False),
        sa.Column("down_fees_paid", _USD, nullable=False),
        sa.Column("matched_pairs", _SHARES, nullable=False),
        sa.Column("as_of", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_inventory_snapshots"),
    )
    op.create_index(
        "ix_inventory_snapshots_market_id", "inventory_snapshots", ["market_id"]
    )
    op.create_index(
        "ix_inventory_snapshots_as_of", "inventory_snapshots", ["as_of"]
    )
    op.create_index(
        "ix_inventory_snapshots_recorded_at",
        "inventory_snapshots",
        ["recorded_at"],
    )
    op.create_index(
        "ix_inventory_snapshots_market_as_of",
        "inventory_snapshots",
        ["market_id", "as_of"],
    )

    op.create_table(
        "pair_opportunities",
        sa.Column(
            "id", sa.BigInteger(), autoincrement=True, nullable=False
        ),
        sa.Column("market_id", _ID, nullable=False),
        sa.Column("size", _SHARES, nullable=False),
        sa.Column("up_price", _PRICE, nullable=False),
        sa.Column("down_price", _PRICE, nullable=False),
        sa.Column("effective_pair_cost", _USD, nullable=False),
        sa.Column("max_pair_cost", _USD, nullable=False),
        sa.Column("within_threshold", sa.Boolean(), nullable=False),
        sa.Column("as_of", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_pair_opportunities"),
    )
    op.create_index(
        "ix_pair_opportunities_market_id", "pair_opportunities", ["market_id"]
    )
    op.create_index(
        "ix_pair_opportunities_as_of", "pair_opportunities", ["as_of"]
    )
    op.create_index(
        "ix_pair_opportunities_recorded_at",
        "pair_opportunities",
        ["recorded_at"],
    )

    op.create_table(
        "matched_pairs",
        sa.Column(
            "id", sa.BigInteger(), autoincrement=True, nullable=False
        ),
        sa.Column("market_id", _ID, nullable=False),
        sa.Column("condition_id", _HASH, nullable=False),
        sa.Column("quantity", _SHARES, nullable=False),
        sa.Column("up_cost", _USD, nullable=False),
        sa.Column("down_cost", _USD, nullable=False),
        sa.Column("fees", _USD, nullable=False),
        sa.Column("locked_value", _USD, nullable=False),
        sa.Column("net_profit", _PROFIT, nullable=False),
        sa.Column("created_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_matched_pairs"),
    )
    op.create_index("ix_matched_pairs_market_id", "matched_pairs", ["market_id"])
    op.create_index(
        "ix_matched_pairs_recorded_at", "matched_pairs", ["recorded_at"]
    )

    op.create_table(
        "ctf_operations",
        sa.Column("operation_id", _ID, nullable=False),
        sa.Column("operation_type", _ENUM, nullable=False),
        sa.Column("condition_id", _HASH, nullable=False),
        sa.Column("quantity", _SHARES, nullable=False),
        sa.Column("collateral", _USD, nullable=False),
        sa.Column("status", _ENUM, nullable=False),
        sa.Column("created_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("operation_id", name="pk_ctf_operations"),
    )
    op.create_index(
        "ix_ctf_operations_condition_id", "ctf_operations", ["condition_id"]
    )
    op.create_index(
        "ix_ctf_operations_recorded_at", "ctf_operations", ["recorded_at"]
    )

    op.create_table(
        "blockchain_transactions",
        sa.Column(
            "id", sa.BigInteger(), autoincrement=True, nullable=False
        ),
        sa.Column("operation_key", _ID, nullable=False),
        sa.Column("chain_id", sa.Integer(), nullable=False),
        sa.Column("status", _ENUM, nullable=False),
        sa.Column("operation_id", _ID, nullable=True),
        sa.Column("tx_hash", _HASH, nullable=True),
        sa.Column("created_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_blockchain_transactions"),
        sa.UniqueConstraint(
            "operation_key", name="uq_blockchain_transactions_operation_key"
        ),
        sa.ForeignKeyConstraint(
            ["operation_id"],
            ["ctf_operations.operation_id"],
            name="fk_blockchain_transactions_operation_id_ctf_operations",
            ondelete="SET NULL",
        ),
    )
    op.create_index(
        "ix_blockchain_transactions_recorded_at",
        "blockchain_transactions",
        ["recorded_at"],
    )

    op.create_table(
        "reconciliation_runs",
        sa.Column(
            "id", sa.BigInteger(), autoincrement=True, nullable=False
        ),
        sa.Column("status", _ENUM, nullable=False),
        sa.Column("as_of", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_reconciliation_runs"),
    )
    op.create_index(
        "ix_reconciliation_runs_status", "reconciliation_runs", ["status"]
    )
    op.create_index(
        "ix_reconciliation_runs_as_of", "reconciliation_runs", ["as_of"]
    )
    op.create_index(
        "ix_reconciliation_runs_recorded_at",
        "reconciliation_runs",
        ["recorded_at"],
    )

    op.create_table(
        "reconciliation_discrepancies",
        sa.Column(
            "id", sa.BigInteger(), autoincrement=True, nullable=False
        ),
        sa.Column("run_id", sa.BigInteger(), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("recommended_action", sa.Text(), nullable=True),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_reconciliation_discrepancies"),
        sa.ForeignKeyConstraint(
            ["run_id"],
            ["reconciliation_runs.id"],
            name="fk_reconciliation_discrepancies_run_id_reconciliation_runs",
            ondelete="CASCADE",
        ),
    )
    op.create_index(
        "ix_reconciliation_discrepancies_run_id",
        "reconciliation_discrepancies",
        ["run_id"],
    )
    op.create_index(
        "ix_reconciliation_discrepancies_recorded_at",
        "reconciliation_discrepancies",
        ["recorded_at"],
    )

    op.create_table(
        "risk_events",
        sa.Column("decision_id", _ID, nullable=False),
        sa.Column("verdict", _ENUM, nullable=False),
        sa.Column("reason", sa.Text(), nullable=False),
        sa.Column("approved_size", _SHARES, nullable=False),
        sa.Column("decided_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("decision_id", name="pk_risk_events"),
    )
    op.create_index("ix_risk_events_decided_at", "risk_events", ["decided_at"])
    op.create_index(
        "ix_risk_events_recorded_at", "risk_events", ["recorded_at"]
    )

    op.create_table(
        "kill_switch_events",
        sa.Column(
            "id", sa.BigInteger(), autoincrement=True, nullable=False
        ),
        sa.Column("key", _ID, nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("reason", sa.Text(), nullable=False),
        sa.Column("actor", _ID, nullable=True),
        sa.Column("created_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_kill_switch_events"),
    )
    op.create_index("ix_kill_switch_events_key", "kill_switch_events", ["key"])
    op.create_index(
        "ix_kill_switch_events_created_at", "kill_switch_events", ["created_at"]
    )
    op.create_index(
        "ix_kill_switch_events_recorded_at",
        "kill_switch_events",
        ["recorded_at"],
    )

    op.create_table(
        "system_events",
        sa.Column(
            "id", sa.BigInteger(), autoincrement=True, nullable=False
        ),
        sa.Column("event_type", _ID, nullable=False),
        sa.Column("severity", _ENUM, nullable=False),
        sa.Column(
            "payload",
            postgresql.JSONB(astext_type=sa.Text()),
            server_default=sa.text("'{}'"),
            nullable=False,
        ),
        sa.Column("created_at", sa.BigInteger(), nullable=False),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_system_events"),
    )
    op.create_index("ix_system_events_event_type", "system_events", ["event_type"])
    op.create_index("ix_system_events_severity", "system_events", ["severity"])
    op.create_index(
        "ix_system_events_created_at", "system_events", ["created_at"]
    )
    op.create_index(
        "ix_system_events_recorded_at", "system_events", ["recorded_at"]
    )


def downgrade() -> None:
    for table in (
        "system_events",
        "kill_switch_events",
        "risk_events",
        "reconciliation_discrepancies",
        "reconciliation_runs",
        "blockchain_transactions",
        "ctf_operations",
        "matched_pairs",
        "pair_opportunities",
        "inventory_snapshots",
        "fills",
        "exchange_orders",
        "order_intents",
        "market_windows",
        "markets",
    ):
        op.drop_table(table)
