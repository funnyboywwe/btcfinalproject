"""market-data snapshot summaries (Module 7)

Revision ID: 0002_market_data_snapshots
Revises: 0001_initial
Create Date: 2026-07-17

Additive migration: creates the ``market_data_snapshots`` table used by the
research-grade market-data recorder to store queryable snapshot summaries
(full-fidelity depth lives in compressed Parquet, not in PostgreSQL). Price and
cost columns are NUMERIC (fixed-point) so they round-trip as Decimal; no binary
floats are stored. ``(window_id, sequence)`` is unique so re-processing a
Parquet file is idempotent. This table stores market data only -- never an
order, fill or trading decision. No existing table is modified.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0002_market_data_snapshots"
down_revision: str | None = "0001_initial"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_PRICE = sa.Numeric(precision=12, scale=6)
_USD = sa.Numeric(precision=30, scale=6)
_ID = sa.String(length=128)
_ENUM = sa.String(length=32)


def _recorded_at() -> sa.Column:
    return sa.Column(
        "recorded_at",
        sa.DateTime(timezone=True),
        server_default=sa.func.now(),
        nullable=False,
    )


def upgrade() -> None:
    op.create_table(
        "market_data_snapshots",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("window_id", _ID, nullable=False),
        sa.Column("market_slug", _ID, nullable=True),
        sa.Column("sequence", sa.BigInteger(), nullable=False),
        sa.Column("capture_epoch", sa.BigInteger(), nullable=False),
        sa.Column("trigger_reasons", sa.Text(), nullable=False),
        sa.Column("up_token_id", _ID, nullable=False),
        sa.Column("down_token_id", _ID, nullable=False),
        sa.Column("up_status", _ENUM, nullable=False),
        sa.Column("down_status", _ENUM, nullable=False),
        sa.Column("up_best_bid", _PRICE, nullable=True),
        sa.Column("up_best_ask", _PRICE, nullable=True),
        sa.Column("up_spread", _PRICE, nullable=True),
        sa.Column("down_best_bid", _PRICE, nullable=True),
        sa.Column("down_best_ask", _PRICE, nullable=True),
        sa.Column("down_spread", _PRICE, nullable=True),
        sa.Column("executable_pair_cost", _USD, nullable=True),
        sa.Column("pair_cost_level", _USD, nullable=True),
        sa.Column("up_is_live", sa.Boolean(), nullable=False),
        sa.Column("down_is_live", sa.Boolean(), nullable=False),
        sa.Column("any_stale", sa.Boolean(), nullable=False),
        sa.Column("any_crossed", sa.Boolean(), nullable=False),
        sa.Column("up_exchange_timestamp_ms", sa.BigInteger(), nullable=True),
        sa.Column("down_exchange_timestamp_ms", sa.BigInteger(), nullable=True),
        _recorded_at(),
        sa.PrimaryKeyConstraint("id", name="pk_market_data_snapshots"),
        sa.UniqueConstraint(
            "window_id",
            "sequence",
            name="uq_market_data_snapshots_window_sequence",
        ),
    )
    op.create_index(
        "ix_market_data_snapshots_window_id",
        "market_data_snapshots",
        ["window_id"],
    )
    op.create_index(
        "ix_market_data_snapshots_capture_epoch",
        "market_data_snapshots",
        ["capture_epoch"],
    )
    op.create_index(
        "ix_market_data_snapshots_window_epoch",
        "market_data_snapshots",
        ["window_id", "capture_epoch"],
    )
    op.create_index(
        "ix_market_data_snapshots_recorded_at",
        "market_data_snapshots",
        ["recorded_at"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_market_data_snapshots_recorded_at",
        table_name="market_data_snapshots",
    )
    op.drop_index(
        "ix_market_data_snapshots_window_epoch",
        table_name="market_data_snapshots",
    )
    op.drop_index(
        "ix_market_data_snapshots_capture_epoch",
        table_name="market_data_snapshots",
    )
    op.drop_index(
        "ix_market_data_snapshots_window_id",
        table_name="market_data_snapshots",
    )
    op.drop_table("market_data_snapshots")
