# Alembic

Database migrations for **Module 3 (PostgreSQL persistence)**.

- `../alembic.ini` — Alembic config. `sqlalchemy.url` is intentionally blank;
  the DSN is injected programmatically from `PostgresSettings` (a `SecretStr`)
  so it never lives in a checked-in file.
- `env.py` — async migration environment. `target_metadata` is the shared ORM
  metadata (`persistence.models.Base.metadata`). Uses an async engine with
  `NullPool`.
- `versions/0001_initial_schema.py` — creates all 15 tables with fixed-point
  `NUMERIC` money columns, unique constraints (exchange order id, fill id,
  client idempotency keys, blockchain operation key) and indexes.

## Running migrations

Preferred (loads config, keeps the DSN secret):

```bash
python -m polymarket_pair_bot.persistence.cli migrate
# or
make db-migrate
```

Direct Alembic (requires `DATABASE_URL` exported):

```bash
DATABASE_URL=postgresql+asyncpg://bot:bot@localhost:5432/pair_bot \
  uv run alembic upgrade head
```

See `docs/persistence.md` for the full design.
