"""Shared pytest configuration.

``asyncio_mode = auto`` (configured in pyproject.toml) means ``async def`` tests
run without an explicit marker. No real orders or network calls are made in any
automated test; integration tests self-skip unless RUN_INFRA_TESTS is set.
"""

from __future__ import annotations
