"""End-to-end crash / recovery / shutdown scenarios (Module 24, part 2).

Scenario coverage in this file:
 11  Crash before acknowledgement
 12  Crash after partial fill
 13  Reconnect (fresh authoritative sync required)
 14  Unknown order status
 21  Kill switch
 22  Market close while unmatched
 23  Graceful shutdown

Uses the real state machine (rebuilding from an authoritative store) and the
real orchestrator (graceful shutdown ordering). No network, wallet or orders.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.config.enums import RunMode
from polymarket_pair_bot.domain.enums import OrderStatus, OutcomeSide
from polymarket_pair_bot.domain.market_data import FeedStatus
from polymarket_pair_bot.domain.value_objects import TokenId, UnixTimestamp
from polymarket_pair_bot.market_data.manager import OrderBookManager
from polymarket_pair_bot.market_data.messages import parse_frame
from polymarket_pair_bot.orchestrator import (
    ApplicationOrchestrator,
    OrchestratorComponents,
    OrchestratorConfig,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.shared.health import HealthState
from polymarket_pair_bot.strategy.session_events import (
    KillSwitchEvent,
    LimitCheckEvent,
    UncertainEvent,
    WindowClosingEvent,
)
from polymarket_pair_bot.strategy.session_states import SessionState
from tests.fixtures import market_data as md
from tests.fixtures.orchestrator import (
    FakeClock,
    FakeDiscovery,
    FakeKillSwitch,
    FakeMachine,
    FakeMetrics,
    RecordingExecutionControl,
    RecordingPersistence,
    RecordingReconciler,
    RecordingResource,
    ScriptedProducer,
)
from tests.fixtures.state_machine import (
    DOWN_TOKEN,
    UP_TOKEN,
    Harness,
    build_harness,
    make_book,
    make_fill,
    make_market,
)

from tests.e2e.test_e2e_lifecycle import (  # reuse the proven drivers
    _books,
    _fill_event,
    _first_leg_open,
    _to_ready,
)


async def _unmatched_after_first_leg(h: Harness, *, size: str = "5") -> None:
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(
            h.market, eid=f"fill-{size}", side=OutcomeSide.UP, price="0.48", size=size, at=120
        )
    )


# --------------------------------------------------------------------------- #
# Scenario 11: Crash before acknowledgement
# --------------------------------------------------------------------------- #
async def test_scenario_11_crash_before_acknowledgement() -> None:
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)  # order submitted; NO confirmed fill yet

    # Simulate a process crash and restart from the same authoritative store.
    restarted = build_harness(store=h.store)
    restored = await restarted.machine.restore(h.market.market_id)

    assert restored is not None
    assert restored.state is SessionState.FIRST_LEG_OPEN
    # No ack is ever treated as a fill: rebuilt inventory is flat.
    assert restored.is_flat is True
    assert restored.matched_pairs.value == Decimal("0")


# --------------------------------------------------------------------------- #
# Scenario 12: Crash after partial fill
# --------------------------------------------------------------------------- #
async def test_scenario_12_crash_after_partial_fill() -> None:
    h = build_harness()
    await _unmatched_after_first_leg(h, size="3")  # partial: 3 of 5 confirmed

    restarted = build_harness(store=h.store)
    restored = await restarted.machine.restore(h.market.market_id)

    assert restored is not None
    assert restored.state is SessionState.UNMATCHED_INVENTORY
    # Position rebuilt from authoritative records: exactly the confirmed 3.
    assert restored.unmatched_up.value == Decimal("3")
    assert restored.matched_pairs.value == Decimal("0")


# --------------------------------------------------------------------------- #
# Scenario 13: Reconnect
# --------------------------------------------------------------------------- #
async def test_scenario_13_reconnect_requires_fresh_sync() -> None:
    # Order-book manager: a reconnect discards stale levels and awaits a fresh
    # authoritative snapshot before it can be LIVE again.
    manager = OrderBookManager(
        TokenId(md.UP_TOKEN),
        TokenId(md.DOWN_TOKEN),
        stale_after_seconds=5.0,
        monotonic=md.ManualClock(start=1_000.0),
    )
    manager.mark_connected()
    frame = parse_frame(
        md.book_message(md.UP_TOKEN, bids=[("0.46", "100")], asks=[("0.48", "120")])
    )
    assert frame.message is not None
    manager.apply_message(frame.message)
    assert manager.is_fresh(OutcomeSide.UP) is True

    manager.mark_disconnected()
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.UNAVAILABLE
    manager.mark_connected()
    manager.note_reconnect()
    # Fail closed: after a reconnect the book must not be trusted until a fresh
    # snapshot arrives.
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.AWAITING_SNAPSHOT
    assert manager.reconnect_count == 1

    # State machine: a stale/disconnected feed while holding unmatched
    # inventory forces reconciliation (a reconnect => fresh authoritative sync).
    h = build_harness()
    await _unmatched_after_first_leg(h)
    outcome = await h.machine.process(_books(h.market, at=200, fresh=False))
    assert outcome.snapshot.state is SessionState.RECONCILIATION_REQUIRED
    assert ReconciliationTrigger.USER_STREAM_RECONNECT in h.reconciliation.triggers


# --------------------------------------------------------------------------- #
# Scenario 14: Unknown order status
# --------------------------------------------------------------------------- #
async def test_scenario_14_unknown_order_status() -> None:
    # Enum contract: UNKNOWN is never a confirmed complete (fill) status.
    assert OrderStatus.UNKNOWN.is_confirmed_complete is False
    assert OrderStatus.UNKNOWN.is_terminal is False

    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    outcome = await h.machine.process(
        UncertainEvent(
            event_id="unknown-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(210),
            reason="submission timed out; status unknown",
            trigger=ReconciliationTrigger.UNKNOWN_SUBMISSION,
        )
    )
    assert outcome.snapshot.state is SessionState.RECONCILIATION_REQUIRED
    assert ReconciliationTrigger.UNKNOWN_SUBMISSION in h.reconciliation.triggers


# --------------------------------------------------------------------------- #
# Scenario 21: Kill switch
# --------------------------------------------------------------------------- #
async def test_scenario_21_kill_switch() -> None:
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    outcome = await h.machine.process(
        KillSwitchEvent(
            event_id="kill-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(220),
            reason="operator engaged global kill switch",
        )
    )
    assert outcome.snapshot.state is SessionState.HALTED
    # Cancellation of resting orders remains possible under the kill switch.
    assert h.execution.cancel_market_calls >= 1


# --------------------------------------------------------------------------- #
# Scenario 22: Market close while unmatched
# --------------------------------------------------------------------------- #
async def test_scenario_22_market_close_while_unmatched() -> None:
    h = build_harness()
    await _unmatched_after_first_leg(h)
    outcome = await h.machine.process(
        WindowClosingEvent(
            event_id="closing-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(230),
            market=h.market,
            seconds_to_close=5,
        )
    )
    # Directional exposure at close must be unwound, never left dangling.
    assert outcome.snapshot.state is SessionState.UNWIND_REQUIRED


# --------------------------------------------------------------------------- #
# Scenario 23: Graceful shutdown
# --------------------------------------------------------------------------- #
def _limit_event(market: object, index: int) -> LimitCheckEvent:
    return LimitCheckEvent(
        event_id=f"limit-{index}",
        market_id=market.market_id,
        occurred_at=UnixTimestamp(1_000 + index),
        market=market,
    )


async def test_scenario_23_graceful_shutdown() -> None:
    call_log: list[str] = []
    market = make_market()
    machine = FakeMachine(market=market)
    execution = RecordingExecutionControl(call_log)
    reconciler = RecordingReconciler(call_log, consistent=True)
    persistence = RecordingPersistence(call_log)
    components = OrchestratorComponents(
        run_mode=RunMode.PAPER,
        discovery=FakeDiscovery(market),
        machine=machine,
        execution=execution,
        reconciler=reconciler,
        kill_switch=FakeKillSwitch(),
        persistence=persistence,
        producers=[
            ScriptedProducer(
                "md", [_limit_event(market, 1)], critical=True, call_log=call_log
            )
        ],
        websockets=[RecordingResource("ws:md", call_log)],
        datastores=[
            RecordingResource("db", call_log),
            RecordingResource("redis", call_log),
        ],
        metrics=FakeMetrics(),
        clock=FakeClock(),
    )
    config = OrchestratorConfig(
        run_until_producers_complete=True,
        authoritative_wait_seconds=0.0,
        cancel_grace_seconds=1.0,
    )
    orch = ApplicationOrchestrator(components, config=config)

    await orch.run()

    # Ordered graceful shutdown: block new orders, cancel resting orders,
    # reconcile, flush persistence, then close resources (DB before Redis).
    def _idx(entry: str) -> int:
        assert entry in call_log, f"{entry!r} not in {call_log!r}"
        return call_log.index(entry)

    assert _idx("block_new_orders") < _idx("cancel_open_orders")
    assert _idx("cancel_open_orders") < _idx("reconcile:shutdown")
    assert _idx("reconcile:shutdown") < _idx("flush")
    assert _idx("flush") < _idx("aclose:ws:md")
    assert _idx("aclose:db") < _idx("aclose:redis")
    assert reconciler.triggers == [ReconciliationTrigger.SHUTDOWN]
    assert execution.cancel_calls == 1
    assert persistence.flushes == 1
    assert orch.health.state is HealthState.STOPPING
