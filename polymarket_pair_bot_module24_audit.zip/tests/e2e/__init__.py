"""End-to-end crash and recovery tests (Module 26/24 verification).

These suites wire together the real, previously-implemented components
(market discovery, local order books, the pair-accumulation state machine and
the paper execution simulator) plus deterministic in-memory fakes for the few
external systems that cannot run offline. No test ever touches the network,
signs a transaction or places a real order.
"""
