"""End-to-end lifecycle scenarios (Module 24 verification, part 1).

Covers the happy-path pipeline and its inventory accounting using the *real*
components: market discovery, the local order-book manager, the paper
execution simulator and the pair-accumulation state machine. Deterministic
in-memory fakes stand in only for external I/O.

Scenario coverage in this file:
  1  Market discovery
  2  WebSocket snapshot
  3  Incremental updates
  4  Opportunity detection
  5  Passive first-leg paper order
  6  Partial fill
  7  Second-leg completion
  8  Inventory match
  9  Simulated merge
 10  P&L accounting
 19  Duplicate fill
 20  Stale data

No network, no wallet, no real orders.
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal

from polymarket_pair_bot.domain.enums import (
    OrderStatus,
    OutcomeSide,
    TimeInForce,
)
from polymarket_pair_bot.domain.market_data import FeedStatus
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    OrderId,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.execution import LatencyDistribution, PaperExecutionConfig
from polymarket_pair_bot.market_data.manager import OrderBookManager
from polymarket_pair_bot.market_data.messages import parse_frame
from polymarket_pair_bot.market_discovery.ports import RawMarket
from polymarket_pair_bot.market_discovery.service import MarketDiscoveryService
from polymarket_pair_bot.market_discovery.windows import FiveMinuteWindow
from polymarket_pair_bot.strategy.detector import DetectorAction, ExecutionRole
from polymarket_pair_bot.strategy.session_events import (
    BooksUpdatedEvent,
    FillConfirmedEvent,
    MarketValidatedEvent,
    MergeEvaluateEvent,
)
from polymarket_pair_bot.strategy.session_states import SessionState
from tests.fixtures import gamma
from tests.fixtures import market_data as md
from tests.fixtures.execution import (
    UP as PAPER_UP,
    make_adapter,
    make_event,
    make_intent,
)
from tests.fixtures.state_machine import (
    DOWN_TOKEN,
    UP_TOKEN,
    Harness,
    build_harness,
    make_book,
    make_fill,
    make_market,
)


# --------------------------------------------------------------------------- #
# Shared state-machine drivers (mirrors tests/unit/test_strategy_state_machine)
# --------------------------------------------------------------------------- #
def _books(
    market: object,
    *,
    at: int,
    fresh: bool = True,
    stc: int = 240,
) -> BooksUpdatedEvent:
    up = make_book(UP_TOKEN, as_of=at)
    down = make_book(DOWN_TOKEN, as_of=at)
    return BooksUpdatedEvent(
        event_id=f"books-{at}",
        market_id=market.market_id,
        occurred_at=UnixTimestamp(at),
        market=market,
        up_book=up,
        down_book=down,
        up_is_fresh=fresh,
        down_is_fresh=fresh,
        feed_live=fresh,
        seconds_to_close=stc,
    )


async def _to_ready(h: Harness, *, at: int = 100) -> None:
    await h.machine.process(
        MarketValidatedEvent(
            event_id="validated",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(at),
            market=h.market,
        )
    )


async def _first_leg_open(h: Harness, *, at: int = 110) -> None:
    h.detector.program(
        DetectorAction.PASSIVE_FIRST_LEG,
        [(OutcomeSide.UP, ExecutionRole.MAKER, "0.48", "5")],
    )
    await h.machine.process(_books(h.market, at=at))


def _fill_event(
    market: object,
    *,
    eid: str,
    side: OutcomeSide,
    price: str,
    size: str,
    at: int,
    fee: str = "0",
    fid: str | None = None,
) -> FillConfirmedEvent:
    fill = make_fill(
        fill_id=fid or eid,
        side=side,
        price=price,
        size=size,
        fee=fee,
        at=at,
    )
    return FillConfirmedEvent(
        event_id=eid,
        market_id=market.market_id,
        occurred_at=UnixTimestamp(at),
        market=market,
        fill=fill,
    )


# --------------------------------------------------------------------------- #
# Scenario 1: Market discovery
# --------------------------------------------------------------------------- #
class _FakeMetadataSource:
    """In-memory ``MarketMetadataSource``: returns pre-baked raw markets."""

    def __init__(self, by_slug: dict[str, Sequence[RawMarket]]) -> None:
        self._by_slug = by_slug
        self.slugs_requested: list[str] = []

    async def fetch_markets_by_slug(self, slug: str) -> Sequence[RawMarket]:
        self.slugs_requested.append(slug)
        return self._by_slug.get(slug, ())


class _FakeSlugStrategy:
    """Deterministic slug builder keyed on the window open epoch."""

    def build(self, window: FiveMinuteWindow) -> str:
        return f"btc-updown-{window.open_epoch}"


async def test_scenario_01_market_discovery() -> None:
    now = gamma.WINDOW_OPEN_EPOCH + 60
    slug_strategy = _FakeSlugStrategy()
    windows = MarketDiscoveryService(
        _FakeMetadataSource({}), slug_strategy
    ).windows(now)
    current = windows.current
    slug = slug_strategy.build(current)
    source = _FakeMetadataSource({slug: [gamma.valid_market()]})
    service = MarketDiscoveryService(source, slug_strategy, clock=lambda: now)

    discovered = await service.discover_window(current)

    assert discovered.up_token_id == gamma.UP_TOKEN_ID
    assert discovered.down_token_id == gamma.DOWN_TOKEN_ID
    assert discovered.condition_id == gamma.CONDITION_ID
    assert discovered.order_book_enabled is True
    assert discovered.closed is False
    assert discovered.open_time == gamma.WINDOW_OPEN_EPOCH
    assert discovered.close_time == gamma.WINDOW_CLOSE_EPOCH
    assert source.slugs_requested == [slug]


# --------------------------------------------------------------------------- #
# Scenario 2: WebSocket snapshot  |  Scenario 3: Incremental updates
# Scenario 20: Stale data
# --------------------------------------------------------------------------- #
def _fresh_manager() -> tuple[OrderBookManager, md.ManualClock]:
    clock = md.ManualClock(start=1_000.0)
    manager = OrderBookManager(
        TokenId(md.UP_TOKEN),
        TokenId(md.DOWN_TOKEN),
        stale_after_seconds=5.0,
        monotonic=clock,
    )
    manager.mark_connected()
    return manager, clock


def _apply(manager: OrderBookManager, payload: dict) -> None:
    frame = parse_frame(payload)
    assert frame.message is not None
    manager.apply_message(frame.message)


async def test_scenario_02_websocket_snapshot() -> None:
    manager, _clock = _fresh_manager()
    _apply(
        manager,
        md.book_message(
            md.UP_TOKEN,
            bids=[("0.46", "100"), ("0.45", "250")],
            asks=[("0.48", "120"), ("0.49", "300")],
        ),
    )
    quote = manager.quote(OutcomeSide.UP)
    assert quote.status is FeedStatus.LIVE
    assert quote.best_bid is not None and quote.best_bid.value == Decimal("0.46")
    assert quote.best_ask is not None and quote.best_ask.value == Decimal("0.48")
    # The other side has not received a snapshot yet -> fail closed.
    assert manager.feed_status(OutcomeSide.DOWN) is FeedStatus.AWAITING_SNAPSHOT


async def test_scenario_03_incremental_updates() -> None:
    manager, _clock = _fresh_manager()
    _apply(
        manager,
        md.book_message(
            md.UP_TOKEN,
            bids=[("0.46", "100")],
            asks=[("0.48", "120")],
        ),
    )
    # A new, better ask arrives incrementally (BUY=>bid, SELL=>ask on the wire).
    _apply(
        manager,
        md.price_change_message(md.UP_TOKEN, changes=[("0.47", "SELL", "50")]),
    )
    quote = manager.quote(OutcomeSide.UP)
    assert quote.best_ask is not None and quote.best_ask.value == Decimal("0.47")
    # A bid improvement.
    _apply(
        manager,
        md.price_change_message(md.UP_TOKEN, changes=[("0.465", "BUY", "30")]),
    )
    quote = manager.quote(OutcomeSide.UP)
    assert quote.best_bid is not None and quote.best_bid.value == Decimal("0.465")


async def test_scenario_20_stale_data() -> None:
    manager, clock = _fresh_manager()
    _apply(
        manager,
        md.book_message(md.UP_TOKEN, bids=[("0.46", "100")], asks=[("0.48", "120")]),
    )
    assert manager.is_fresh(OutcomeSide.UP) is True
    # No further updates; advance the monotonic clock past the freshness bound.
    clock.advance(10.0)
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.STALE
    assert manager.is_fresh(OutcomeSide.UP) is False

    # The state machine also fails closed on stale books: it must not advance
    # out of book-syncing when the feed is not fresh.
    h = build_harness()
    await _to_ready(h)
    outcome = await h.machine.process(_books(h.market, at=120, fresh=False))
    assert outcome.snapshot.state is not SessionState.WAITING_FOR_EDGE
    assert outcome.snapshot.state in {
        SessionState.BOOK_SYNCING,
        SessionState.READY,
    }


# --------------------------------------------------------------------------- #
# Scenario 4: Opportunity detection
# --------------------------------------------------------------------------- #
async def test_scenario_04_opportunity_detection() -> None:
    # No opportunity -> the machine waits and submits nothing (fail closed).
    idle = build_harness()
    await _to_ready(idle)
    idle.detector.program(DetectorAction.NO_TRADE, [])
    waiting = await idle.machine.process(_books(idle.market, at=110))
    assert waiting.snapshot.state is SessionState.WAITING_FOR_EDGE
    assert idle.execution.submitted == []

    # A detected opportunity drives a passive first-leg order.
    active = build_harness()
    await _to_ready(active)
    await _first_leg_open(active)
    assert len(active.execution.submitted) == 1


# --------------------------------------------------------------------------- #
# Scenario 5: Passive first-leg paper order (real paper simulator)
# --------------------------------------------------------------------------- #
def _deterministic_paper_config() -> PaperExecutionConfig:
    # Zero probabilistic maker fills: a resting order only fills from real trade
    # prints that reach it. This makes the passive-order scenario deterministic.
    return PaperExecutionConfig(
        seed=123,
        taker_fee_bps=BasisPoints(Decimal("0")),
        maker_fee_bps=BasisPoints(Decimal("0")),
        ack_latency=LatencyDistribution.constant(100),
        cancel_latency=LatencyDistribution.constant(100),
        maker_fill_probability=Decimal(0),
    )


async def test_scenario_05_passive_first_leg_paper_order() -> None:
    adapter, _persistence = make_adapter(config=_deterministic_paper_config())
    # Opening book: our 0.45 bid rests behind an 80-share queue -> stays maker.
    await adapter.apply_market_event(
        make_event(
            "open",
            ts_ms=0,
            bids=(("0.46", "40"), ("0.45", "80")),
            asks=(("0.48", "60"), ("0.49", "120")),
        )
    )
    await adapter.submit_order(
        make_intent("leg1", token=PAPER_UP, price="0.45", size="30", tif=TimeInForce.GTC)
    )
    await adapter.advance_to(500)
    order = await adapter.get_order(OrderId("paper-leg1"))
    assert order is not None
    # A resting passive order is open, not filled: never treated as a pair.
    assert order.status is OrderStatus.OPEN
    assert order.filled_size.value == Decimal(0)
    assert not await adapter.get_fills(order_id=OrderId("paper-leg1"))


# --------------------------------------------------------------------------- #
# Scenario 6: Partial fill
# --------------------------------------------------------------------------- #
async def test_scenario_06_partial_fill() -> None:
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)  # programs a 5-share UP first leg
    # Only 3 of 5 confirm: directional unmatched exposure, NOT a matched pair.
    outcome = await h.machine.process(
        _fill_event(h.market, eid="f-up-3", side=OutcomeSide.UP, price="0.48", size="3", at=120)
    )
    snap = outcome.snapshot
    assert snap.state is SessionState.UNMATCHED_INVENTORY
    assert snap.unmatched_up.value == Decimal("3")
    assert snap.matched_pairs.value == Decimal("0")


# --------------------------------------------------------------------------- #
# Scenario 7: Second-leg completion  |  Scenario 8: Inventory match
# Scenario 9: Simulated merge        |  Scenario 10: P&L accounting
# --------------------------------------------------------------------------- #
async def _full_pair(h: Harness) -> None:
    await _to_ready(h)
    await _first_leg_open(h)
    # First leg fully fills -> unmatched inventory.
    await h.machine.process(
        _fill_event(h.market, eid="f-up", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    # Program and open the passive second leg.
    h.detector.program(
        DetectorAction.PASSIVE_SECOND_LEG,
        [(OutcomeSide.DOWN, ExecutionRole.MAKER, "0.50", "5")],
    )
    await h.machine.process(_books(h.market, at=130))


async def test_scenario_07_and_08_second_leg_and_inventory_match() -> None:
    h = build_harness()
    await _full_pair(h)
    assert (await h.machine.restore(h.market.market_id)).state is SessionState.SECOND_LEG_OPEN
    # Second leg confirms equal quantity -> a matched (locked) pair.
    outcome = await h.machine.process(
        _fill_event(h.market, eid="f-down", side=OutcomeSide.DOWN, price="0.50", size="5", at=140)
    )
    snap = outcome.snapshot
    assert snap.state is SessionState.MATCHED_PAIR
    assert snap.matched_pairs.value == Decimal("5")
    assert snap.unmatched_up.value == Decimal("0")
    assert snap.unmatched_down.value == Decimal("0")


async def test_scenario_09_and_10_merge_and_pnl() -> None:
    h = build_harness()
    await _full_pair(h)
    matched = await h.machine.process(
        _fill_event(h.market, eid="f-down", side=OutcomeSide.DOWN, price="0.50", size="5", at=140)
    )
    # Scenario 10: a conservative locked-net-profit figure is recorded on the
    # matched pair. This is an accounting figure only -- NOT a profit claim.
    assert matched.snapshot.locked_net_profit is not None
    assert isinstance(matched.snapshot.locked_net_profit.value, Decimal)

    # Scenario 9: evaluate/perform the simulated CTF merge.
    await h.machine.process(
        MergeEvaluateEvent(
            event_id="merge-eval-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(150),
            market=h.market,
        )
    )
    final = await h.machine.process(
        MergeEvaluateEvent(
            event_id="merge-eval-2",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(160),
            market=h.market,
        )
    )
    assert final.snapshot.state is SessionState.CLOSED
    assert final.snapshot.matched_pairs.value == Decimal("0")
    assert h.merge.merge_calls == 1


# --------------------------------------------------------------------------- #
# Scenario 19: Duplicate fill (idempotency)
# --------------------------------------------------------------------------- #
async def test_scenario_19_duplicate_fill() -> None:
    # State-machine level: replaying the same confirmed fill id is a no-op.
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    first = await h.machine.process(
        _fill_event(
            h.market, eid="dup", side=OutcomeSide.UP, price="0.48", size="5", at=120, fid="fill-1"
        )
    )
    assert first.snapshot.unmatched_up.value == Decimal("5")
    replay = await h.machine.process(
        _fill_event(
            h.market, eid="dup", side=OutcomeSide.UP, price="0.48", size="5", at=121, fid="fill-1"
        )
    )
    assert replay.idempotent_replay is True
    assert replay.snapshot.unmatched_up.value == Decimal("5")  # unchanged

    # Adapter level: the fill repository rejects a duplicate fill id.
    adapter, persistence = make_adapter()
    await adapter.apply_market_event(
        make_event("o", ts_ms=0, bids=(("0.45", "80"),), asks=(("0.48", "60"), ("0.49", "120")))
    )
    await adapter.submit_order(
        make_intent("tk", token=PAPER_UP, price="0.49", size="60", tif=TimeInForce.IOC)
    )
    await adapter.advance_to(200)
    fills = await adapter.get_fills(order_id=OrderId("paper-tk"))
    assert len(fills) >= 1
    inserted_again = await persistence.fills.insert_idempotent(fills[0])
    assert inserted_again is False
