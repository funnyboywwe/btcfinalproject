"""End-to-end infrastructure-fault scenarios (Module 24, part 3).

Scenario coverage in this file:
 15  PostgreSQL outage
 16  Redis outage
 17  Primary RPC outage
 18  RPC disagreement

Every fault must make the system fail closed: readiness drops or the read
raises, and no untrusted value is ever silently accepted. No network is used.
"""

from __future__ import annotations

import pytest

from polymarket_pair_bot.blockchain.dual_rpc import (
    Conservative,
    DualRpcReader,
    Endpoint,
)
from polymarket_pair_bot.blockchain.errors import (
    ChainRpcUnavailableError,
    RpcDisagreementError,
)
from polymarket_pair_bot.blockchain.resilience import CircuitBreaker, RetryPolicy
from polymarket_pair_bot.orchestrator.readiness import ReadinessProbe
from polymarket_pair_bot.shared.health import HealthState, HealthTracker
from tests.fixtures.blockchain import FakeClock, FakeEthereumRpc, FakeSleep
from tests.fixtures.orchestrator import (
    FakeDependencyCheck,
    FakeKillSwitch,
    RecordingExecutionControl,
)


async def _ready_tracker() -> HealthTracker:
    tracker = HealthTracker()
    await tracker.set(HealthState.READY, "ready")
    return tracker


def _endpoint(rpc: FakeEthereumRpc, clock: FakeClock) -> Endpoint:
    breaker = CircuitBreaker(
        name=rpc.label, fail_threshold=5, reset_seconds=30, clock=clock
    )
    return Endpoint(
        rpc,
        breaker=breaker,
        policy=RetryPolicy(max_retries=2, backoff_base_seconds=0.1, backoff_max_seconds=1),
        sleep=FakeSleep(),
        rng=lambda: 0.0,
    )


# --------------------------------------------------------------------------- #
# Scenario 15: PostgreSQL outage
# --------------------------------------------------------------------------- #
async def test_scenario_15_postgres_outage() -> None:
    probe = ReadinessProbe(
        health=await _ready_tracker(),
        kill_switch=FakeKillSwitch(),
        execution=RecordingExecutionControl([]),
        dependency_checks=[FakeDependencyCheck("postgres", healthy=False)],
    )
    report = await probe.evaluate()
    # Fail closed: an unhealthy datastore means the bot is not ready to trade.
    assert report.ready is False
    assert report.checks["postgres"] is False
    # The outage is the *only* cause: the rest of the pipeline is healthy.
    assert report.checks["kill_switch_inactive"] is True
    assert report.checks["health"] is True


# --------------------------------------------------------------------------- #
# Scenario 16: Redis outage
# --------------------------------------------------------------------------- #
async def test_scenario_16_redis_outage() -> None:
    # Redis backs both the coordination datastore and the persistent kill
    # switch. If the kill switch cannot be read, readiness fails closed by
    # treating it as active.
    probe = ReadinessProbe(
        health=await _ready_tracker(),
        kill_switch=FakeKillSwitch(unreadable=True),
        execution=RecordingExecutionControl([]),
        dependency_checks=[FakeDependencyCheck("redis", healthy=False)],
    )
    report = await probe.evaluate()
    assert report.ready is False
    assert report.checks["redis"] is False
    # Unreadable kill switch => treated as active (fail closed).
    assert report.checks["kill_switch_inactive"] is False
    assert report.detail["kill_switch"].startswith("unreadable")


# --------------------------------------------------------------------------- #
# Scenario 17: Primary RPC outage
# --------------------------------------------------------------------------- #
async def test_scenario_17_primary_rpc_outage() -> None:
    clock = FakeClock()
    # The primary endpoint is down (exhausts retries); the secondary is fine.
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", fail_first=99), clock),
        _endpoint(FakeEthereumRpc(label="secondary", native_balance=1000), clock),
        tolerance_base_units=0,
    )
    # The primary is authoritative and read first; its outage is a hard,
    # fail-closed error rather than a silent fallback to an unverified value.
    with pytest.raises(ChainRpcUnavailableError):
        await reader.read_int(
            "native", lambda rpc: rpc.get_balance("0x0"), conservative=Conservative.MIN
        )


# --------------------------------------------------------------------------- #
# Scenario 18: RPC disagreement
# --------------------------------------------------------------------------- #
async def test_scenario_18_rpc_disagreement() -> None:
    clock = FakeClock()
    # Two reachable endpoints that disagree on the chain id.
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", chain_id=137), clock),
        _endpoint(FakeEthereumRpc(label="secondary", chain_id=80002), clock),
    )
    with pytest.raises(RpcDisagreementError):
        await reader.read_exact("chain_id", lambda rpc: rpc.chain_id())

    # Balances beyond tolerance also raise rather than pick a value.
    reader2 = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", native_balance=1000), clock),
        _endpoint(FakeEthereumRpc(label="secondary", native_balance=5000), clock),
        tolerance_base_units=5,
    )
    with pytest.raises(RpcDisagreementError):
        await reader2.read_int(
            "native", lambda rpc: rpc.get_balance("0x0"), conservative=Conservative.MIN
        )
