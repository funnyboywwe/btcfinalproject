"""Integration tests for the private operator FastAPI app (Module 20).

These exercise the real FastAPI request/response cycle via Starlette's
``TestClient``. They self-skip when FastAPI (and its test dependencies) are not
installed, so the rest of the suite still runs in a minimal environment. No
network socket is opened and no order is ever placed.
"""

from __future__ import annotations

import pytest

from polymarket_pair_bot.observability.health import OperatorHealth, ReadinessStatus
from polymarket_pair_bot.shared.health import HealthState, HealthTracker

pytestmark = pytest.mark.integration


class _Readiness:
    def __init__(self, ready: bool) -> None:
        self._ready = ready

    async def evaluate(self) -> ReadinessStatus:
        return ReadinessStatus(
            ready=self._ready,
            checks={"kill_switch_inactive": self._ready},
            detail={"kill_switch": "inactive" if self._ready else "active"},
        )


def _client(*, ready: bool):  # type: ignore[no-untyped-def]
    pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient

    from polymarket_pair_bot.observability.api import create_operator_app

    tracker = HealthTracker()
    # Drive to READY synchronously for the test.
    import asyncio

    asyncio.get_event_loop().run_until_complete(tracker.set(HealthState.READY))
    health = OperatorHealth(
        liveness=tracker,
        readiness=_Readiness(ready),
        config_view=lambda: {"run_mode": "paper", "api_secret": "leak"},
        version="test",
    )

    def _render() -> tuple[bytes, str]:
        return b"# HELP ppb_up 1\nppb_up 1.0\n", "text/plain; version=0.0.4"

    app = create_operator_app(health=health, metrics_renderer=_render)
    return TestClient(app)


def test_live_endpoint_is_ok() -> None:
    client = _client(ready=True)
    resp = client.get("/health/live")
    assert resp.status_code == 200
    assert resp.json()["status"] == "alive"


def test_ready_endpoint_returns_503_when_unsafe() -> None:
    client = _client(ready=False)
    resp = client.get("/health/ready")
    assert resp.status_code == 503
    assert resp.json()["ready"] is False


def test_ready_endpoint_returns_200_when_ready() -> None:
    client = _client(ready=True)
    resp = client.get("/health/ready")
    assert resp.status_code == 200
    assert resp.json()["ready"] is True


def test_details_endpoint_hides_secrets() -> None:
    client = _client(ready=True)
    resp = client.get("/health/details")
    assert resp.status_code == 200
    assert "leak" not in resp.text


def test_metrics_endpoint_serves_prometheus_text() -> None:
    client = _client(ready=True)
    resp = client.get("/metrics")
    assert resp.status_code == 200
    assert "text/plain" in resp.headers["content-type"]
    assert "ppb_up" in resp.text
