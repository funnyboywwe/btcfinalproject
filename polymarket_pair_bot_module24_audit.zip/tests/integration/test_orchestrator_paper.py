"""Deterministic paper-mode integration tests for the orchestrator (Module 19).

These exercise the real :class:`ApplicationOrchestrator` (real supervisor,
degraded controller, readiness probe, bounded queue) wired to in-memory fakes.
No network, wallet, orders or live trading are ever involved.
"""

from __future__ import annotations

import pytest

from polymarket_pair_bot.config.enums import RunMode
from polymarket_pair_bot.domain.value_objects import UnixTimestamp
from polymarket_pair_bot.orchestrator import (
    ApplicationOrchestrator,
    OrchestratorComponents,
    OrchestratorConfig,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.shared.health import HealthState
from polymarket_pair_bot.strategy.session_events import LimitCheckEvent
from polymarket_pair_bot.strategy.session_models import SessionState

from tests.fixtures.orchestrator import (
    FakeClock,
    FakeDiscovery,
    FakeFreshnessSource,
    FakeKillSwitch,
    FakeMachine,
    FakeMetrics,
    RecordingExecutionControl,
    RecordingPersistence,
    RecordingReconciler,
    RecordingResource,
    ScriptedProducer,
    make_market,
)


def _limit_event(market, index: int) -> LimitCheckEvent:
    return LimitCheckEvent(
        event_id=f"limit-{index}",
        market_id=market.market_id,
        occurred_at=UnixTimestamp(1_000 + index),
        market=market,
    )


def _build(
    *,
    call_log: list[str],
    producers,
    machine: FakeMachine,
    market,
    run_mode: RunMode = RunMode.PAPER,
    consistent: bool = True,
    freshness=(),
    dependency_checks=(),
    kill_switch=None,
    metrics=None,
    config: OrchestratorConfig | None = None,
):
    execution = RecordingExecutionControl(call_log)
    reconciler = RecordingReconciler(call_log, consistent=consistent)
    persistence = RecordingPersistence(call_log)
    components = OrchestratorComponents(
        run_mode=run_mode,
        discovery=FakeDiscovery(market),
        machine=machine,
        execution=execution,
        reconciler=reconciler,
        kill_switch=kill_switch or FakeKillSwitch(),
        persistence=persistence,
        producers=producers,
        freshness_sources=freshness,
        websockets=[RecordingResource("ws:md", call_log)],
        datastores=[
            RecordingResource("db", call_log),
            RecordingResource("redis", call_log),
        ],
        dependency_checks=dependency_checks,
        metrics=metrics or FakeMetrics(),
        clock=FakeClock(),
    )
    cfg = config or OrchestratorConfig(
        run_until_producers_complete=True,
        authoritative_wait_seconds=0.0,
        cancel_grace_seconds=1.0,
    )
    orch = ApplicationOrchestrator(components, config=cfg)
    return orch, components, execution, reconciler, persistence


@pytest.mark.asyncio
async def test_happy_path_runs_and_shuts_down_in_order() -> None:
    market = make_market()
    machine = FakeMachine(market=market)
    call_log: list[str] = []
    producer = ScriptedProducer(
        "md",
        [_limit_event(market, i) for i in range(3)],
        critical=True,
        call_log=call_log,
    )
    orch, _c, execution, reconciler, persistence = _build(
        call_log=call_log, producers=[producer], machine=machine, market=market
    )

    await orch.run()

    # Restart requirement: restore happens before processing.
    assert machine.restored == [market.market_id]
    # Seed MarketValidated + 3 producer events all processed.
    assert len(machine.processed) == 4
    # Graceful shutdown ordering (requirement 6).
    order = [
        call_log.index("block_new_orders"),
        call_log.index("cancel_open_orders"),
        call_log.index("reconcile:shutdown"),
        call_log.index("flush"),
        call_log.index("aclose:md"),
        call_log.index("aclose:ws:md"),
        call_log.index("aclose:db"),
        call_log.index("aclose:redis"),
    ]
    assert order == sorted(order)
    # db before redis (requirement 6: database then Redis).
    assert call_log.index("aclose:db") < call_log.index("aclose:redis")
    assert reconciler.triggers == [ReconciliationTrigger.SHUTDOWN]
    assert execution.cancel_calls == 1
    assert persistence.flushes == 1
    assert orch.health.state is HealthState.STOPPING


@pytest.mark.asyncio
async def test_bounded_queue_uses_configured_maxsize() -> None:
    market = make_market()
    machine = FakeMachine(market=market)
    call_log: list[str] = []
    cfg = OrchestratorConfig(
        event_queue_maxsize=8,
        run_until_producers_complete=True,
        authoritative_wait_seconds=0.0,
        cancel_grace_seconds=1.0,
    )
    orch, *_ = _build(
        call_log=call_log,
        producers=[ScriptedProducer("md", [], critical=True, call_log=call_log)],
        machine=machine,
        market=market,
        config=cfg,
    )
    assert orch._queue.maxsize == 8  # noqa: SLF001 - explicit bound assertion
    await orch.run()


@pytest.mark.asyncio
async def test_idempotent_events_processed_once() -> None:
    market = make_market()
    machine = FakeMachine(market=market)
    call_log: list[str] = []
    dup = _limit_event(market, 7)
    producer = ScriptedProducer("md", [dup, dup], critical=True, call_log=call_log)
    orch, *_ = _build(
        call_log=call_log, producers=[producer], machine=machine, market=market
    )
    await orch.run()
    # Seed + one unique limit event (the duplicate is an idempotent replay).
    assert len(machine.processed) == 2


@pytest.mark.asyncio
async def test_no_validated_market_fails_closed() -> None:
    market = make_market()
    machine = FakeMachine(market=market)
    call_log: list[str] = []
    orch, components, execution, reconciler, _p = _build(
        call_log=call_log,
        producers=[ScriptedProducer("md", [], critical=True, call_log=call_log)],
        machine=machine,
        market=None,
    )
    await orch.run()
    # No market => never restored, never traded, but still shuts down safely.
    assert machine.restored == []
    assert components.discovery.calls == 1
    assert execution.new_orders_blocked is True
    assert orch.health.state is HealthState.STOPPING


@pytest.mark.asyncio
async def test_critical_producer_failure_enters_degraded() -> None:
    market = make_market()
    machine = FakeMachine(market=market)
    call_log: list[str] = []
    metrics = FakeMetrics()
    producer = ScriptedProducer(
        "md", [], critical=True, fail_after=0, call_log=call_log
    )
    orch, _c, execution, reconciler, _p = _build(
        call_log=call_log,
        producers=[producer],
        machine=machine,
        market=market,
        metrics=metrics,
        consistent=True,
    )
    await orch.run()
    assert orch._degraded.active is True  # noqa: SLF001
    assert execution.new_orders_blocked is True
    assert ReconciliationTrigger.UNKNOWN_SUBMISSION in reconciler.triggers
    assert "orchestrator_degraded_total" in metrics.names()
    assert "orchestrator_critical_failure_total" in metrics.names()


@pytest.mark.asyncio
async def test_degraded_stops_when_reconcile_inconsistent() -> None:
    market = make_market()
    machine = FakeMachine(market=market)
    call_log: list[str] = []
    producer = ScriptedProducer(
        "md", [], critical=True, fail_after=0, call_log=call_log
    )
    orch, _c, execution, reconciler, _p = _build(
        call_log=call_log,
        producers=[producer],
        machine=machine,
        market=market,
        consistent=False,
    )
    await orch.run()
    # Uncertainty remains => still stops (fail closed) and reconciled on shutdown.
    assert orch._degraded.active is True  # noqa: SLF001
    assert ReconciliationTrigger.SHUTDOWN in reconciler.triggers
    assert orch.health.state is HealthState.STOPPING


@pytest.mark.asyncio
async def test_machine_halted_blocks_orders_and_degrades() -> None:
    market = make_market()
    machine = FakeMachine(
        market=market, script={"LimitCheckEvent": SessionState.HALTED}
    )
    call_log: list[str] = []
    producer = ScriptedProducer(
        "md", [_limit_event(market, 0)], critical=True, call_log=call_log
    )
    orch, _c, execution, reconciler, _p = _build(
        call_log=call_log, producers=[producer], machine=machine, market=market
    )
    await orch.run()
    assert execution.new_orders_blocked is True
    assert orch._degraded.active is True  # noqa: SLF001


@pytest.mark.asyncio
async def test_lockdown_state_blocks_without_degrading() -> None:
    market = make_market()
    machine = FakeMachine(
        market=market, script={"LimitCheckEvent": SessionState.UNWIND_REQUIRED}
    )
    call_log: list[str] = []
    producer = ScriptedProducer(
        "md", [_limit_event(market, 0)], critical=True, call_log=call_log
    )
    orch, _c, execution, _r, _p = _build(
        call_log=call_log, producers=[producer], machine=machine, market=market
    )
    await orch.run()
    assert execution.new_orders_blocked is True
    # UNWIND_REQUIRED locks down orders but is not a full degraded-mode trigger.
    assert orch._degraded.active is False  # noqa: SLF001


@pytest.mark.asyncio
async def test_freshness_watchdog_enters_degraded_on_stale_feed() -> None:
    market = make_market()
    machine = FakeMachine(market=market)
    call_log: list[str] = []
    stale = FakeFreshnessSource("market-data", age=99.0)
    # Continuous mode + a producer that never finishes, so only the watchdog
    # can end the run (by entering degraded mode and requesting stop).
    producer = ScriptedProducer(
        "md", [], critical=False, block_forever=True, call_log=call_log
    )
    cfg = OrchestratorConfig(
        run_until_producers_complete=False,
        authoritative_wait_seconds=0.0,
        cancel_grace_seconds=1.0,
        feed_staleness_seconds=0.01,
    )
    orch, _c, execution, reconciler, _p = _build(
        call_log=call_log,
        producers=[producer],
        machine=machine,
        market=market,
        freshness=[stale],
        config=cfg,
    )
    await orch.run()
    assert orch._degraded.active is True  # noqa: SLF001
    assert execution.new_orders_blocked is True
    assert ReconciliationTrigger.USER_STREAM_RECONNECT in reconciler.triggers


@pytest.mark.asyncio
async def test_live_mode_does_not_auto_enable_trading() -> None:
    market = make_market()
    machine = FakeMachine(market=market)
    call_log: list[str] = []
    producer = ScriptedProducer(
        "md", [_limit_event(market, 0)], critical=True, call_log=call_log
    )
    orch, components, execution, _r, _p = _build(
        call_log=call_log,
        producers=[producer],
        machine=machine,
        market=market,
        run_mode=RunMode.LIVE,
    )
    await orch.run()
    # Requirement 9: the orchestrator never flips mode; it only drives the
    # adapters it was given. run_mode is observed, not mutated.
    assert components.run_mode is RunMode.LIVE
    assert machine.restored == [market.market_id]
