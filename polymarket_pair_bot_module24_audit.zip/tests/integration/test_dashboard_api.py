"""Integration tests for the dashboard FastAPI app (Module 21).

Runs entirely in-process via ``fastapi.testclient.TestClient`` -- no server, no
network, no orders. Self-skips when FastAPI is not installed. Verifies:

* the surface is read-only (POST/PUT/DELETE are rejected; only GETs exist);
* auth is enforced when a token is configured (401 without it, 200 with it);
* served HTML escapes hostile external data (requirement 6);
* the JSON snapshot round-trips and contains no secret-like keys;
* the liveness endpoint needs no auth.

Uses a tiny in-test fake provider (a mock), never real infrastructure.
"""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

pytest.importorskip("fastapi")

from fastapi.testclient import TestClient  # noqa: E402

from polymarket_pair_bot.dashboard.api import create_dashboard_app  # noqa: E402
from polymarket_pair_bot.dashboard.auth import DashboardAuthenticator  # noqa: E402
from polymarket_pair_bot.dashboard.models import (  # noqa: E402
    DashboardSnapshot,
    MarketView,
)

_XSS = "<script>alert('x')</script>"


class _FakeProvider:
    """Deterministic read-only provider with a hostile market string."""

    def __init__(self, *, data_available: bool = True) -> None:
        self._data_available = data_available

    async def snapshot(self) -> DashboardSnapshot:
        return DashboardSnapshot(
            generated_at=datetime(2026, 7, 18, tzinfo=UTC),
            run_mode="PAPER",
            data_available=self._data_available,
            market=MarketView(slug="btc-5m", question=f"up? {_XSS}"),
        )


def _client(*, token: str | None = None) -> TestClient:
    app = create_dashboard_app(
        provider=_FakeProvider(),
        authenticator=DashboardAuthenticator(token),
    )
    return TestClient(app)


def test_healthz_is_open_and_ok() -> None:
    resp = _client().get("/healthz")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


def test_dashboard_html_escapes_external_data() -> None:
    resp = _client().get("/")
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]
    assert _XSS not in resp.text
    assert "&lt;script&gt;" in resp.text


def test_json_snapshot_shape_and_no_secrets() -> None:
    resp = _client().get("/api/snapshot")
    assert resp.status_code == 200
    body = resp.json()
    assert body["run_mode"] == "PAPER"
    assert body["market"]["slug"] == "btc-5m"
    flat = str(body).lower()
    for needle in ("secret", "private_key", "passphrase", "api_secret"):
        assert needle not in flat


def test_write_methods_are_rejected() -> None:
    client = _client()
    for method in ("post", "put", "patch", "delete"):
        resp = getattr(client, method)("/")
        # No write route exists -> method not allowed (or not found).
        assert resp.status_code in (404, 405)


def test_auth_enforced_when_token_configured() -> None:
    client = _client(token="s3cr3t")
    assert client.get("/").status_code == 401
    assert client.get("/api/snapshot").status_code == 401
    assert client.get("/", headers={"Authorization": "Bearer s3cr3t"}).status_code == 200
    assert client.get("/api/snapshot", params={"token": "s3cr3t"}).status_code == 200
    # The token itself is never echoed back in any response body.
    assert "s3cr3t" not in client.get(
        "/", headers={"Authorization": "Bearer s3cr3t"}
    ).text


def test_only_get_routes_are_registered() -> None:
    app = create_dashboard_app(
        provider=_FakeProvider(),
        authenticator=DashboardAuthenticator(None),
    )
    for route in app.routes:
        methods = getattr(route, "methods", set()) or set()
        # Ignore HEAD/OPTIONS which FastAPI adds automatically for GET routes.
        write_methods = methods & {"POST", "PUT", "PATCH", "DELETE"}
        assert not write_methods, f"unexpected write methods on {route}: {methods}"
