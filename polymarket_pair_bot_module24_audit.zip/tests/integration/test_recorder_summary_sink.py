"""Integration test for the PostgreSQL summary sink (Module 7).

Gated behind ``RUN_INFRA_TESTS=1`` and a running PostgreSQL 16 instance (see
``docker-compose.yml``). It exercises the idempotent ``ON CONFLICT DO NOTHING``
insert path end-to-end. It records market-data summaries only and never places
an order.
"""

from __future__ import annotations

import os
from decimal import Decimal

import pytest

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        os.environ.get("RUN_INFRA_TESTS") != "1",
        reason="requires PostgreSQL; set RUN_INFRA_TESTS=1 to enable",
    ),
]

sqlalchemy = pytest.importorskip("sqlalchemy")
pytest.importorskip("asyncpg")

from sqlalchemy.ext.asyncio import (  # noqa: E402
    async_sessionmaker,
    create_async_engine,
)

from polymarket_pair_bot.domain.recording import RecordedSnapshotSummary  # noqa: E402
from polymarket_pair_bot.persistence.models import (  # noqa: E402
    Base,
    MarketDataSnapshotRow,
)
from polymarket_pair_bot.recorder.summary_sink import PostgresSummarySink  # noqa: E402

_DSN = os.environ.get(
    "TEST_DATABASE_URL",
    "postgresql+asyncpg://bot:bot@localhost:5432/pair_bot",
)


def _summary(sequence: int) -> RecordedSnapshotSummary:
    return RecordedSnapshotSummary(
        window_id="btc-5m-window",
        market_slug="btc-updown",
        sequence=sequence,
        capture_epoch=1_700_000_000 + sequence,
        trigger_reasons="periodic",
        up_token_id="1",
        down_token_id="2",
        up_status="live",
        down_status="live",
        up_best_bid=Decimal("0.40"),
        up_best_ask=Decimal("0.60"),
        up_spread=Decimal("0.20"),
        down_best_bid=Decimal("0.41"),
        down_best_ask=Decimal("0.59"),
        down_spread=Decimal("0.18"),
        executable_pair_cost=Decimal("1.19"),
        pair_cost_level=None,
        up_is_live=True,
        down_is_live=True,
        any_stale=False,
        any_crossed=False,
        up_exchange_timestamp_ms=1_700_000_000_000,
        down_exchange_timestamp_ms=1_700_000_000_001,
    )


async def test_summary_sink_idempotent_insert() -> None:
    engine = create_async_engine(_DSN)
    try:
        async with engine.begin() as conn:
            await conn.run_sync(
                Base.metadata.create_all,
                tables=[MarketDataSnapshotRow.__table__],
            )
        session_factory = async_sessionmaker(engine, expire_on_commit=False)
        sink = PostgresSummarySink(session_factory)

        batch = [_summary(i) for i in range(3)]
        assert await sink.write_batch(batch) == 3
        # Re-writing the same batch inserts nothing (idempotent).
        assert await sink.write_batch(batch) == 0
    finally:
        async with engine.begin() as conn:
            await conn.run_sync(
                Base.metadata.drop_all,
                tables=[MarketDataSnapshotRow.__table__],
            )
        await engine.dispose()
