"""Optional integration tests against a local Polygon fork (Module 16).

These are SKIPPED unless ``POLYGON_FORK_RPC`` (and, optionally,
``POLYGON_FORK_WALLET``) are set in the environment and web3.py is installed.
They are read-only: they verify the chain id and read the wallet nonce/native
balance. They never submit a transaction and never touch a private key.

Run a local fork first, e.g.::

    anvil --fork-url "$POLYGON_ARCHIVE_RPC" --port 8545
    export POLYGON_FORK_RPC=http://127.0.0.1:8545
    export POLYGON_FORK_WALLET=0x0000000000000000000000000000000000000000
    uv run pytest tests/integration/test_blockchain_fork.py
"""

from __future__ import annotations

import os

import pytest

_FORK_RPC = os.getenv("POLYGON_FORK_RPC")
_FORK_WALLET = os.getenv(
    "POLYGON_FORK_WALLET", "0x0000000000000000000000000000000000000000"
)

pytestmark = pytest.mark.skipif(
    not _FORK_RPC, reason="POLYGON_FORK_RPC not set; local-fork test skipped"
)


async def test_fork_reads_are_read_only() -> None:
    web3 = pytest.importorskip("web3")  # noqa: F841
    from polymarket_pair_bot.blockchain.dual_rpc import DualRpcReader, Endpoint
    from polymarket_pair_bot.blockchain.resilience import CircuitBreaker, RetryPolicy
    from polymarket_pair_bot.blockchain.service import (
        ChainReadParams,
        WalletStateService,
    )
    from polymarket_pair_bot.blockchain.web3_rpc import Web3Rpc

    import time

    clock = time.monotonic
    rpc = Web3Rpc(_FORK_RPC, label="primary")  # type: ignore[arg-type]
    breaker = CircuitBreaker(name="primary", fail_threshold=5, reset_seconds=30, clock=clock)
    endpoint = Endpoint(rpc, breaker=breaker, policy=RetryPolicy())
    chain_id = await rpc.chain_id()
    params = ChainReadParams(chain_id=chain_id, wallet_address=_FORK_WALLET)
    svc = WalletStateService(DualRpcReader(endpoint), params, clock=clock)
    identity = await svc.verify_chain_id()
    assert identity.chain_id == chain_id
    nonce = await svc.get_nonce()
    assert nonce >= 0
    await svc.aclose()
