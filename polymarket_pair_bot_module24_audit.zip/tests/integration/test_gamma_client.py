"""Integration-style tests for the httpx Gamma adapter.

No real network access: an ``httpx.MockTransport`` serves canned responses and
``sleep``/``rng`` are injected so retry/backoff logic runs instantly and
deterministically. Gated on httpx so the suite still collects without it.
"""

from __future__ import annotations

from collections.abc import Callable

import pytest

httpx = pytest.importorskip("httpx")

from polymarket_pair_bot.market_discovery.errors import (  # noqa: E402
    InvalidMarketMetadataError,
    MarketMetadataUnavailableError,
    RateLimitedError,
)
from polymarket_pair_bot.market_discovery.gamma_client import (  # noqa: E402
    GammaMarketSource,
)
from tests.fixtures import gamma  # noqa: E402

BASE_URL = "https://gamma-api.example.invalid"


async def _no_sleep(_seconds: float) -> None:
    return None


def _source(
    handler: Callable[[httpx.Request], httpx.Response],
    *,
    max_retries: int = 3,
) -> GammaMarketSource:
    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(transport=transport)
    return GammaMarketSource(
        BASE_URL,
        client=client,
        max_retries=max_retries,
        backoff_base_seconds=0.01,
        backoff_max_seconds=0.02,
        sleep=_no_sleep,
        rng=lambda: 0.0,
    )


@pytest.mark.asyncio
async def test_success_returns_markets() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.params.get("slug") == "some-slug"
        return httpx.Response(200, json=[gamma.valid_market()])

    source = _source(handler)
    try:
        markets = await source.fetch_markets_by_slug("some-slug")
    finally:
        await source._client.aclose()  # type: ignore[union-attr]
    assert len(markets) == 1
    assert markets[0]["id"] == "512345"


@pytest.mark.asyncio
async def test_retries_then_succeeds_on_5xx() -> None:
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] < 3:
            return httpx.Response(503)
        return httpx.Response(200, json=[])

    source = _source(handler)
    try:
        markets = await source.fetch_markets_by_slug("s")
    finally:
        await source._client.aclose()  # type: ignore[union-attr]
    assert markets == []
    assert calls["n"] == 3


@pytest.mark.asyncio
async def test_rate_limit_then_success_honors_retry_after() -> None:
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(429, headers={"Retry-After": "0"})
        return httpx.Response(200, json=[])

    source = _source(handler)
    try:
        markets = await source.fetch_markets_by_slug("s")
    finally:
        await source._client.aclose()  # type: ignore[union-attr]
    assert markets == []
    assert calls["n"] == 2


@pytest.mark.asyncio
async def test_rate_limit_exhausted_raises() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(429)

    source = _source(handler, max_retries=2)
    try:
        with pytest.raises(RateLimitedError):
            await source.fetch_markets_by_slug("s")
    finally:
        await source._client.aclose()  # type: ignore[union-attr]


@pytest.mark.asyncio
async def test_client_error_fails_fast() -> None:
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(404)

    source = _source(handler)
    try:
        with pytest.raises(MarketMetadataUnavailableError):
            await source.fetch_markets_by_slug("s")
    finally:
        await source._client.aclose()  # type: ignore[union-attr]
    assert calls["n"] == 1  # no retries on 4xx


@pytest.mark.asyncio
async def test_transport_error_retries_then_raises() -> None:
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        raise httpx.ConnectError("boom", request=request)

    source = _source(handler, max_retries=2)
    try:
        with pytest.raises(MarketMetadataUnavailableError):
            await source.fetch_markets_by_slug("s")
    finally:
        await source._client.aclose()  # type: ignore[union-attr]
    assert calls["n"] == 3  # first try + 2 retries


@pytest.mark.asyncio
async def test_non_array_body_rejected() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"not": "a list"})

    source = _source(handler)
    try:
        with pytest.raises(InvalidMarketMetadataError):
            await source.fetch_markets_by_slug("s")
    finally:
        await source._client.aclose()  # type: ignore[union-attr]
