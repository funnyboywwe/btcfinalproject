"""Integration tests for infrastructure health checks.

These require a running PostgreSQL 16 and Redis 7 (see docker/docker-compose.yml)
and are skipped unless ``RUN_INFRA_TESTS=1`` is set, so the default ``pytest``
run never touches external services.
"""

from __future__ import annotations

import os

import pytest

from polymarket_pair_bot.config.settings import load_config
from polymarket_pair_bot.observability.health_checks import (
    PostgresHealthCheck,
    RedisHealthCheck,
)

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not os.getenv("RUN_INFRA_TESTS"),
        reason="set RUN_INFRA_TESTS=1 with Postgres+Redis running",
    ),
]


async def test_postgres_health_check_ok() -> None:
    config = load_config()
    check = PostgresHealthCheck(config.postgres.dsn)
    result = await check.check()
    assert result.healthy, result.detail


async def test_redis_health_check_ok() -> None:
    config = load_config()
    check = RedisHealthCheck(config.redis.url)
    result = await check.check()
    assert result.healthy, result.detail
