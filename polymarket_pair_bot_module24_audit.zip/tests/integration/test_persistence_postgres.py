"""Integration tests against a real PostgreSQL 16 container.

These self-skip unless ``RUN_INFRA_TESTS=1``. They exercise the acceptance
criteria: the schema applies to an empty database, duplicate fills do not alter
inventory twice, and order/fill/inventory changes commit atomically (or roll
back together). No real orders or network trading occur here.

Start infrastructure with ``make infra-up`` and point ``DATABASE_URL`` at it,
e.g. ``postgresql+asyncpg://bot:bot@localhost:5432/pair_bot``.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from decimal import Decimal

import pytest
import pytest_asyncio

from polymarket_pair_bot.config import load_config
from polymarket_pair_bot.domain.entities import (
    ExchangeOrder,
    Fill,
    InventorySnapshot,
    MarketWindow,
    Position,
)
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus, OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    ConditionId,
    FeeAmount,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.persistence import (
    create_engine_from_dsn,
    create_session_factory,
)
from polymarket_pair_bot.persistence.base import Base
from polymarket_pair_bot.persistence.models import InventorySnapshotRow
from polymarket_pair_bot.persistence.repositories import SqlAlchemyUnitOfWork

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        os.environ.get("RUN_INFRA_TESTS") != "1",
        reason="set RUN_INFRA_TESTS=1 and provide a PostgreSQL DATABASE_URL",
    ),
]

_MARKET = MarketId("btc-5m-2026-07-17T15:00")
_CONDITION = ConditionId("0x" + "ab" * 32)
_UP_TOKEN = TokenId("111")
_DOWN_TOKEN = TokenId("222")


def _order() -> ExchangeOrder:
    return ExchangeOrder(
        order_id=OrderId("order-1"),
        intent_id="intent-1",
        token_id=_UP_TOKEN,
        side=OrderSide.BUY,
        limit_price=ProbabilityPrice(Decimal("0.480000")),
        original_size=Shares(Decimal("5.000000")),
        filled_size=Shares(Decimal("5.000000")),
        status=OrderStatus.FILLED,
        created_at=UnixTimestamp(1_760_000_000),
        updated_at=UnixTimestamp(1_760_000_010),
    )


def _fill() -> Fill:
    return Fill(
        fill_id=FillId("fill-1"),
        order_id=OrderId("order-1"),
        token_id=_UP_TOKEN,
        side=OrderSide.BUY,
        price=ProbabilityPrice(Decimal("0.480000")),
        size=Shares(Decimal("5.000000")),
        fee=FeeAmount(Decimal("0.010000")),
        filled_at=UnixTimestamp(1_760_000_010),
    )


def _snapshot(as_of: int) -> InventorySnapshot:
    return InventorySnapshot(
        market_id=_MARKET,
        up_position=Position(
            token_id=_UP_TOKEN,
            side=OutcomeSide.UP,
            quantity=Shares(Decimal("5.000000")),
            average_price=ProbabilityPrice(Decimal("0.480000")),
            fees_paid=FeeAmount(Decimal("0.010000")),
        ),
        down_position=Position(
            token_id=_DOWN_TOKEN,
            side=OutcomeSide.DOWN,
            quantity=Shares(Decimal("0.000000")),
            average_price=ProbabilityPrice(Decimal("0.000000")),
            fees_paid=FeeAmount(Decimal("0.000000")),
        ),
        matched_pairs=Shares(Decimal("0.000000")),
        as_of=UnixTimestamp(as_of),
    )


@pytest_asyncio.fixture
async def uow_factory() -> AsyncIterator:
    from sqlalchemy import select

    dsn = load_config().postgres.dsn
    engine = create_engine_from_dsn(dsn, echo=False)
    # Acceptance: schema applies to an empty database.
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    session_factory = create_session_factory(engine)

    async def _count_snapshots() -> int:
        async with session_factory() as session:
            rows = (
                await session.execute(
                    select(InventorySnapshotRow).where(
                        InventorySnapshotRow.market_id == _MARKET.value
                    )
                )
            ).scalars().all()
            return len(rows)

    # Seed the parent market + order (fills FK requires the order to exist).
    async with SqlAlchemyUnitOfWork(session_factory) as uow:
        await uow.windows.upsert_window(
            MarketWindow(
                market_id=_MARKET,
                condition_id=_CONDITION,
                open_time=UnixTimestamp(1_760_000_000),
                close_time=UnixTimestamp(1_760_000_300),
            )
        )
        await uow.orders.upsert_for_market(_order(), _MARKET)
        await uow.commit()

    try:
        yield session_factory, _count_snapshots
    finally:
        await engine.dispose()


async def test_duplicate_fill_does_not_alter_inventory_twice(uow_factory) -> None:
    session_factory, count_snapshots = uow_factory

    async with SqlAlchemyUnitOfWork(session_factory) as uow:
        first = await uow.record_fill_and_update_inventory(_fill(), _snapshot(1))
        await uow.commit()
    assert first is True
    assert await count_snapshots() == 1

    # Replaying the same fill id must be a no-op for inventory.
    async with SqlAlchemyUnitOfWork(session_factory) as uow:
        second = await uow.record_fill_and_update_inventory(_fill(), _snapshot(2))
        await uow.commit()
    assert second is False
    assert await count_snapshots() == 1


async def test_rollback_is_atomic(uow_factory) -> None:
    session_factory, count_snapshots = uow_factory

    with pytest.raises(RuntimeError):
        async with SqlAlchemyUnitOfWork(session_factory) as uow:
            await uow.record_fill_and_update_inventory(_fill(), _snapshot(1))
            raise RuntimeError("boom before commit")

    # Nothing committed: neither the fill nor the inventory snapshot persisted.
    assert await count_snapshots() == 0
    async with SqlAlchemyUnitOfWork(session_factory) as uow:
        assert await uow.fills.get(FillId("fill-1")) is None


async def test_commit_persists_fill_and_inventory_together(uow_factory) -> None:
    session_factory, count_snapshots = uow_factory

    async with SqlAlchemyUnitOfWork(session_factory) as uow:
        await uow.record_fill_and_update_inventory(_fill(), _snapshot(1))
        await uow.commit()

    async with SqlAlchemyUnitOfWork(session_factory) as uow:
        stored_fill = await uow.fills.get(FillId("fill-1"))
        latest = await uow.inventory.get_latest(_MARKET)
    assert stored_fill is not None
    assert latest is not None
    assert latest.up_position.quantity.value == Decimal("5.000000")
    assert await count_snapshots() == 1
