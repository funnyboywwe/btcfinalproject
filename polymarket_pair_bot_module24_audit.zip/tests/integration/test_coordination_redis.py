"""Integration tests for the Redis coordination stack against a real Redis 7.

Gated behind RUN_INFRA_TESTS=1 so the default test run never touches external
services. Start Redis with ``make infra-up`` first.

Covers the mandated concurrency and lease-expiration behaviours plus the kill
switch, counters, idempotency, heartbeat and market-metadata caches.
"""

from __future__ import annotations

import asyncio
import os
import uuid
from collections.abc import AsyncIterator
from decimal import Decimal

import pytest

from polymarket_pair_bot.coordination.cache import RedisMarketMetadataCache
from polymarket_pair_bot.coordination.counters import RedisRiskCounters
from polymarket_pair_bot.coordination.heartbeat import RedisHeartbeatStore
from polymarket_pair_bot.coordination.idempotency import RedisIdempotencyStore
from polymarket_pair_bot.coordination.keys import RedisKeys
from polymarket_pair_bot.coordination.kill_switch import RedisKillSwitchCache
from polymarket_pair_bot.coordination.leader import RedisLeaderLease
from polymarket_pair_bot.coordination.redis_client import create_redis_client
from polymarket_pair_bot.domain.coordination import MarketMetadata

pytestmark = pytest.mark.integration

_RUN = os.getenv("RUN_INFRA_TESTS") == "1"
_REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

run_infra = pytest.mark.skipif(not _RUN, reason="set RUN_INFRA_TESTS=1 to run")


@pytest.fixture
async def keys() -> AsyncIterator[RedisKeys]:
    # Unique namespace per test so parallel runs never collide.
    yield RedisKeys(f"ppbtest:{uuid.uuid4().hex}")


@pytest.fixture
async def client() -> AsyncIterator[object]:
    c = create_redis_client(_REDIS_URL, operation_timeout_seconds=2.0)
    try:
        yield c
    finally:
        await c.aclose()


@run_infra
async def test_only_one_leader_can_acquire(client: object, keys: RedisKeys) -> None:
    a = RedisLeaderLease(client, keys, scope="w", token="A", ttl_seconds=5)
    b = RedisLeaderLease(client, keys, scope="w", token="B", ttl_seconds=5)
    assert await a.acquire() is True
    assert await b.acquire() is False
    assert await a.current_owner() == "A"
    # B cannot renew or release a lease it does not own.
    assert await b.renew() is False
    await b.release()
    assert await a.current_owner() == "A"
    # A can renew and release.
    assert await a.renew() is True
    await a.release()
    assert await a.current_owner() is None


@run_infra
async def test_lease_expires_and_can_be_taken_over(
    client: object, keys: RedisKeys
) -> None:
    a = RedisLeaderLease(client, keys, scope="w", token="A", ttl_seconds=1)
    b = RedisLeaderLease(client, keys, scope="w", token="B", ttl_seconds=5)
    assert await a.acquire() is True
    assert await b.acquire() is False
    # Wait for A's short lease to expire without renewal.
    await asyncio.sleep(1.3)
    assert await b.acquire() is True
    assert await b.current_owner() == "B"
    # A can no longer renew (it lost the lease).
    assert await a.renew() is False
    await b.release()


@run_infra
async def test_kill_switch_roundtrip(client: object) -> None:
    ks = RedisKillSwitchCache(client, key=f"ppbtest:ks:{uuid.uuid4().hex}")
    assert await ks.is_active() is False
    state = await ks.activate(reason="halt", actor="ops", at=1000)
    assert state.active is True
    assert await ks.is_active() is True
    fetched = await ks.get_state()
    assert fetched.reason == "halt"
    assert fetched.actor == "ops"
    assert fetched.updated_at == 1000
    await ks.deactivate(actor="ops", at=2000)
    assert await ks.is_active() is False


@run_infra
async def test_idempotency_first_writer_wins(
    client: object, keys: RedisKeys
) -> None:
    store = RedisIdempotencyStore(client, keys)
    key = uuid.uuid4().hex
    assert await store.claim(key, ttl_seconds=60) is True
    assert await store.claim(key, ttl_seconds=60) is False
    assert await store.is_claimed(key) is True


@run_infra
async def test_risk_counters(client: object, keys: RedisKeys) -> None:
    counters = RedisRiskCounters(client, keys)
    name = uuid.uuid4().hex
    assert await counters.increment(name, 3) == 3
    assert await counters.increment(name, 2, ttl_seconds=60) == 5
    assert await counters.get(name) == 5
    await counters.reset(name)
    assert await counters.get(name) == 0


@run_infra
async def test_heartbeat_expires(client: object, keys: RedisKeys) -> None:
    hb = RedisHeartbeatStore(client, keys)
    name = uuid.uuid4().hex
    await hb.beat(name, ttl_seconds=1, detail="ok")
    assert await hb.is_alive(name) is True
    assert await hb.get_detail(name) == "ok"
    await asyncio.sleep(1.3)
    assert await hb.is_alive(name) is False


@run_infra
async def test_market_metadata_cache(client: object, keys: RedisKeys) -> None:
    cache = RedisMarketMetadataCache(client, keys, default_ttl_seconds=30)
    meta = MarketMetadata(
        market_id="m1",
        condition_id="c1",
        up_token_id="u1",
        down_token_id="d1",
        up_tick_size=Decimal("0.001"),
        down_tick_size=Decimal("0.001"),
        close_time=1_700_000_000,
        fetched_at=1_699_999_000,
    )
    assert await cache.get("m1") is None
    await cache.put(meta)
    got = await cache.get("m1")
    assert got is not None
    assert got.up_tick_size == Decimal("0.001")
    assert got.condition_id == "c1"


@run_infra
async def test_market_metadata_corrupt_entry_is_miss(
    client: object, keys: RedisKeys
) -> None:
    cache = RedisMarketMetadataCache(client, keys, default_ttl_seconds=30)
    await client.set(keys.market_metadata("bad"), "{not valid json")
    assert await cache.get("bad") is None
