"""In-memory fixtures for reconciliation tests (Module 15).

No networking, no SQLAlchemy, no secrets. The fakes honour the reconciliation
Ports structurally so the service can be exercised deterministically, including
crash-recovery scenarios. Token ids are canonical base-10 uint strings.
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal

from polymarket_pair_bot.auth.models import (
    AllowanceView,
    OpenOrderView,
    TradeFillView,
)
from polymarket_pair_bot.domain.entities import (
    ExchangeOrder,
    Fill,
    InventorySnapshot,
    Position,
    ReconciliationResult,
)
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus, OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    FeeAmount,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.reconciliation.models import (
    ChainState,
    ChainTransactionRecord,
    FillImportOutcome,
    LocalState,
    RemoteAccountState,
)
from tests.fixtures.auth import make_balance  # asset is an arbitrary string

TOKEN = "2001"
UP_TOKEN = "1001"
DOWN_TOKEN = "1002"
MARKET = "market-1"


def make_order(
    *,
    order_id: str = "order-1",
    token: str = TOKEN,
    status: OrderStatus = OrderStatus.OPEN,
    original: str = "5",
    filled: str = "0",
    side: OrderSide = OrderSide.BUY,
    price: str = "0.40",
    created: int = 1000,
    updated: int = 1000,
    intent: str = "intent-1",
) -> ExchangeOrder:
    return ExchangeOrder(
        order_id=OrderId(order_id),
        intent_id=intent,
        token_id=TokenId(token),
        side=side,
        limit_price=ProbabilityPrice(Decimal(price)),
        original_size=Shares(Decimal(original)),
        filled_size=Shares(Decimal(filled)),
        status=status,
        created_at=UnixTimestamp(created),
        updated_at=UnixTimestamp(updated),
    )


def make_local_fill(
    *,
    fill_id: str = "fill-1",
    order_id: str = "order-1",
    token: str = TOKEN,
    side: OrderSide = OrderSide.BUY,
    price: str = "0.40",
    size: str = "2",
    fee: str = "0.01",
    filled_at: int = 1000,
) -> Fill:
    return Fill(
        fill_id=FillId(fill_id),
        order_id=OrderId(order_id),
        token_id=TokenId(token),
        side=side,
        price=ProbabilityPrice(Decimal(price)),
        size=Shares(Decimal(size)),
        fee=FeeAmount(Decimal(fee)),
        filled_at=UnixTimestamp(filled_at),
    )


def make_remote_order(
    *,
    order_id: str = "order-1",
    token: str = TOKEN,
    market: str | None = MARKET,
    status: OrderStatus = OrderStatus.OPEN,
    side: OrderSide = OrderSide.BUY,
    price: str = "0.40",
    original: str = "5",
    size_matched: str = "0",
) -> OpenOrderView:
    return OpenOrderView(
        order_id=order_id,
        token_id=token,
        market_id=market,
        side=side,
        status=status,
        price=price,
        original_size=original,
        size_matched=size_matched,
    )


def make_remote_fill(
    *,
    fill_id: str = "fill-1",
    order_id: str = "order-1",
    token: str = TOKEN,
    market: str | None = MARKET,
    side: OrderSide = OrderSide.BUY,
    price: str = "0.40",
    size: str = "2",
    fee: str = "0.01",
) -> TradeFillView:
    return TradeFillView(
        fill_id=fill_id,
        order_id=order_id,
        token_id=token,
        market_id=market,
        side=side,
        price=price,
        size=size,
        fee_paid=fee,
    )


def make_position(
    token: str,
    side: OutcomeSide,
    qty: str,
    *,
    price: str = "0.40",
    fees: str = "0",
) -> Position:
    return Position(
        token_id=TokenId(token),
        side=side,
        quantity=Shares(Decimal(qty)),
        average_price=ProbabilityPrice(Decimal(price)),
        fees_paid=FeeAmount(Decimal(fees)),
    )


def make_inventory(
    *,
    market: str = MARKET,
    up_token: str = UP_TOKEN,
    down_token: str = DOWN_TOKEN,
    up_qty: str = "0",
    down_qty: str = "0",
    matched: str = "0",
    as_of: int = 1000,
) -> InventorySnapshot:
    return InventorySnapshot(
        market_id=MarketId(market),
        up_position=make_position(up_token, OutcomeSide.UP, up_qty),
        down_position=make_position(down_token, OutcomeSide.DOWN, down_qty),
        matched_pairs=Shares(Decimal(matched)),
        as_of=UnixTimestamp(as_of),
    )


def make_allowance(
    *, token: str = TOKEN, spender: str = "0xspender", amount: str = "1000"
) -> AllowanceView:
    return AllowanceView(token=token, spender=spender, amount=amount)


def make_merge_tx(
    *, operation_key: str = "merge-1", status: str = "submitted"
) -> ChainTransactionRecord:
    return ChainTransactionRecord(
        operation_key=operation_key, kind="merge", status=status
    )


# --------------------------------------------------------------------------
# Fake ports
# --------------------------------------------------------------------------
class FakeLocalStateProvider:
    def __init__(self, state: LocalState | None = None) -> None:
        self.state = state or LocalState()
        self.calls = 0

    async def load(self, markets: Sequence[MarketId]) -> LocalState:
        self.calls += 1
        return self.state


class FakeRemoteAccountProvider:
    def __init__(
        self,
        state: RemoteAccountState | None = None,
        *,
        exc: BaseException | None = None,
    ) -> None:
        self.state = state if state is not None else RemoteAccountState()
        self.exc = exc
        self.calls = 0

    async def load(self, markets: Sequence[MarketId]) -> RemoteAccountState:
        self.calls += 1
        if self.exc is not None:
            raise self.exc
        return self.state


class FakeChainStateProvider:
    def __init__(
        self,
        state: ChainState | None = None,
        *,
        exc: BaseException | None = None,
    ) -> None:
        self.state = state if state is not None else ChainState(available=False)
        self.exc = exc
        self.calls = 0

    async def load(self, tokens: Sequence[TokenId]) -> ChainState:
        self.calls += 1
        if self.exc is not None:
            raise self.exc
        return self.state


class FakeFillImporter:
    """Idempotent by fill id, exactly like the real unit of work."""

    def __init__(self) -> None:
        self.seen: set[str] = set()
        self.received: list[Fill] = []
        self.batches = 0

    async def import_missing_fills(
        self, fills: Sequence[Fill]
    ) -> FillImportOutcome:
        self.batches += 1
        imported = 0
        duplicates = 0
        for fill in fills:
            self.received.append(fill)
            key = fill.fill_id.value
            if key in self.seen:
                duplicates += 1
            else:
                self.seen.add(key)
                imported += 1
        return FillImportOutcome(imported=imported, duplicates=duplicates)


class FakeCanceller:
    def __init__(self, *, fail: bool = False) -> None:
        self.cancelled: list[str] = []
        self.fail = fail

    async def cancel_order(self, order_id: OrderId) -> None:
        if self.fail:
            raise RuntimeError("cancel failed")
        self.cancelled.append(order_id.value)


class FakeTradingHalt:
    def __init__(self) -> None:
        self.halted = False
        self.reasons: list[str] = []

    async def halt_new_trading(self, *, reason: str) -> None:
        self.halted = True
        self.reasons.append(reason)


class FakeSink:
    def __init__(self) -> None:
        self.persisted: list[ReconciliationResult] = []

    async def persist(self, result: ReconciliationResult) -> int:
        self.persisted.append(result)
        return len(self.persisted)


class FakeMarketScope:
    def __init__(self, markets: Sequence[MarketId] = ()) -> None:
        self._markets = tuple(markets)

    async def markets(self) -> tuple[MarketId, ...]:
        return self._markets


class FixedClock:
    def __init__(self, value: int = 1000) -> None:
        self.value = value

    def __call__(self) -> int:
        return self.value


__all__ = [
    "DOWN_TOKEN",
    "MARKET",
    "TOKEN",
    "UP_TOKEN",
    "FakeCanceller",
    "FakeChainStateProvider",
    "FakeFillImporter",
    "FakeLocalStateProvider",
    "FakeMarketScope",
    "FakeRemoteAccountProvider",
    "FakeSink",
    "FakeTradingHalt",
    "FixedClock",
    "make_allowance",
    "make_balance",
    "make_inventory",
    "make_local_fill",
    "make_merge_tx",
    "make_order",
    "make_position",
    "make_remote_fill",
    "make_remote_order",
]
