"""Fixtures for live execution adapter tests (Module 14).

Every collaborator of :class:`LiveExecutionAdapter` is faked here so the full
order lifecycle can be exercised without networking, secrets or any real write
endpoint. The fake ``LiveOrderClient`` is programmable per order id so each
failure path (timeout, reject, partial fill, fill-before-ack, duplicate fill)
can be driven deterministically.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, field
from decimal import Decimal

from polymarket_pair_bot.config.models import LiveExecutionSettings
from polymarket_pair_bot.domain.entities import RiskDecision
from polymarket_pair_bot.domain.enums import OrderStatus, RiskVerdict
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    Shares,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.errors import ExchangeRejectedError
from polymarket_pair_bot.execution.lifecycle import OrderLifecycleManager
from polymarket_pair_bot.execution.live import LiveExecutionAdapter
from polymarket_pair_bot.execution.live_models import (
    CancelResult,
    FillRecord,
    OpenOrderRecord,
    OrderPlacement,
    OrderStateView,
)
from polymarket_pair_bot.execution.live_ports import (
    LiveOrderRequest,
    ReconciliationView,
)
from polymarket_pair_bot.execution.submission_gate import LiveSubmissionGate
from polymarket_pair_bot.execution.types import CancelOutcome

from tests.fixtures.execution import (  # noqa: F401 - re-exported builders
    CLOSE_S,
    DOWN,
    MARKET,
    OPEN_S,
    TICK,
    UP,
    InMemoryPersistence,
    make_intent,
    make_market,
)


# --------------------------------------------------------------------------- #
# Programmable fake exchange client
# --------------------------------------------------------------------------- #
@dataclass
class PlaceBehavior:
    """How the fake client should respond to a single place_order call."""

    placement: OrderPlacement | None = None
    error: ExchangeRejectedError | None = None
    sleep_s: float | None = None  # drives an asyncio.wait_for timeout


class FakeLiveOrderClient:
    """In-memory, programmable ``LiveOrderClient`` (no real endpoint)."""

    def __init__(self) -> None:
        self.place_queue: list[PlaceBehavior] = []
        self.default_place: PlaceBehavior | None = None
        self.fills_by_order: dict[str, list[FillRecord]] = {}
        self.order_states: dict[str, OrderStateView] = {}
        self.open_orders: list[OpenOrderRecord] = []
        self.cancel_results: dict[str, CancelResult] = {}
        self.cancel_error: ExchangeRejectedError | None = None
        self.market_cancel_results: list[CancelResult] = []
        self.place_calls: list[LiveOrderRequest] = []
        self.cancel_calls: list[str] = []

    async def place_order(self, request: LiveOrderRequest) -> OrderPlacement:
        self.place_calls.append(request)
        behavior = self.place_queue.pop(0) if self.place_queue else self.default_place
        if behavior is None:
            raise AssertionError("no place behavior configured")
        if behavior.sleep_s is not None:
            await asyncio.sleep(behavior.sleep_s)
        if behavior.error is not None:
            raise behavior.error
        assert behavior.placement is not None
        return behavior.placement

    async def cancel_order(self, order_id: str) -> CancelResult:
        self.cancel_calls.append(order_id)
        if self.cancel_error is not None:
            raise self.cancel_error
        return self.cancel_results.get(
            order_id,
            CancelResult(order_id=order_id, outcome=CancelOutcome.ACCEPTED),
        )

    async def cancel_market_orders(self, market_id: str) -> tuple[CancelResult, ...]:
        return tuple(self.market_cancel_results)

    async def cancel_all_orders(self) -> tuple[CancelResult, ...]:
        return tuple(self.market_cancel_results)

    async def get_open_orders(
        self, *, market_id: str | None = None
    ) -> tuple[OpenOrderRecord, ...]:
        return tuple(self.open_orders)

    async def get_order(self, order_id: str) -> OrderStateView | None:
        return self.order_states.get(order_id)

    async def get_fills(
        self, *, order_id: str | None = None, market_id: str | None = None
    ) -> tuple[FillRecord, ...]:
        if order_id is not None:
            return tuple(self.fills_by_order.get(order_id, ()))
        out: list[FillRecord] = []
        for records in self.fills_by_order.values():
            out.extend(records)
        return tuple(out)


# --------------------------------------------------------------------------- #
# Programmable fake signal providers (all healthy by default)
# --------------------------------------------------------------------------- #
@dataclass
class FakeAllowanceProvider:
    collateral: CollateralAmount | None = field(
        default_factory=lambda: CollateralAmount(Decimal("1000"))
    )
    allowance: CollateralAmount | None = field(
        default_factory=lambda: CollateralAmount(Decimal("1000"))
    )

    async def available_collateral(self) -> CollateralAmount | None:
        return self.collateral

    async def spender_allowance(self) -> CollateralAmount | None:
        return self.allowance


@dataclass
class FakeRiskProvider:
    decision: RiskDecision | None = None

    async def decision_for(self, intent: object) -> RiskDecision | None:
        return self.decision


@dataclass
class FakeFeedHealth:
    healthy: bool = True

    async def feeds_healthy(self) -> bool:
        return self.healthy


@dataclass
class FakeReconciliationStatus:
    view: ReconciliationView | None = field(
        default_factory=lambda: ReconciliationView(is_consistent=True, as_of_s=OPEN_S)
    )

    async def latest_reconciliation(self) -> ReconciliationView | None:
        return self.view


@dataclass
class FakeKillSwitch:
    active: bool = False

    async def is_active(self) -> bool:
        return self.active


@dataclass
class FakeExecutionGate:
    enabled: bool = True
    reason: str | None = None

    @property
    def is_enabled(self) -> bool:
        return self.enabled


class FakeIdempotencyStore:
    """First-writer-wins in-memory idempotency store."""

    def __init__(self) -> None:
        self.claimed: set[str] = set()

    async def claim(self, key: str, *, ttl_seconds: int) -> bool:
        if key in self.claimed:
            return False
        self.claimed.add(key)
        return True

    async def is_claimed(self, key: str) -> bool:
        return key in self.claimed


def approve_decision(*, size: str = "100") -> RiskDecision:
    return RiskDecision(
        decision_id="risk-approve",
        verdict=RiskVerdict.APPROVE,
        reason="approved",
        decided_at=UnixTimestamp(OPEN_S),
        approved_size=Shares(Decimal(size)),
    )


def reject_decision() -> RiskDecision:
    return RiskDecision(
        decision_id="risk-reject",
        verdict=RiskVerdict.REJECT,
        reason="exceeds pair budget",
        decided_at=UnixTimestamp(OPEN_S),
    )


def placement_ack(order_id: str, *, filled: str = "0") -> OrderPlacement:
    return OrderPlacement(
        order_id=order_id,
        status=OrderStatus.ACKNOWLEDGED,
        filled_size=Decimal(filled),
    )


def fill_record(
    fill_id: str,
    order_id: str,
    *,
    token: str = UP.value,
    price: str = "0.40",
    size: str = "100",
    fee: str = "0",
    at_s: int | None = OPEN_S,
) -> FillRecord:
    from polymarket_pair_bot.domain.enums import OrderSide

    return FillRecord(
        fill_id=fill_id,
        order_id=order_id,
        token_id=token,
        side=OrderSide.BUY,
        price=Decimal(price),
        size=Decimal(size),
        fee=Decimal(fee),
        filled_at_s=at_s,
    )


@dataclass
class LiveHarness:
    adapter: LiveExecutionAdapter
    client: FakeLiveOrderClient
    persistence: InMemoryPersistence
    allowance: FakeAllowanceProvider
    risk: FakeRiskProvider
    feeds: FakeFeedHealth
    reconciliation: FakeReconciliationStatus
    kill_switch: FakeKillSwitch
    execution_gate: FakeExecutionGate
    idempotency: FakeIdempotencyStore
    settings: LiveExecutionSettings


def make_live_harness(
    *,
    live_trading: bool = True,
    paper_trading: bool = False,
    settings: LiveExecutionSettings | None = None,
    now: int = OPEN_S + 10,
    now_s: Callable[[], int] | None = None,
    register: bool = True,
) -> LiveHarness:
    persistence = InMemoryPersistence()
    client = FakeLiveOrderClient()
    allowance = FakeAllowanceProvider()
    risk = FakeRiskProvider(decision=approve_decision())
    feeds = FakeFeedHealth()
    reconciliation = FakeReconciliationStatus()
    kill_switch = FakeKillSwitch()
    execution_gate = FakeExecutionGate()
    idempotency = FakeIdempotencyStore()
    live_settings = settings if settings is not None else LiveExecutionSettings()
    gate = LiveSubmissionGate(
        live_trading=live_trading,
        paper_trading=paper_trading,
        execution_gate=execution_gate,
        kill_switch=kill_switch,
        feeds=feeds,
        reconciliation=reconciliation,
        reconciliation_max_age_seconds=300,
    )
    clock: Callable[[], int] = now_s if now_s is not None else (lambda: now)
    lifecycle = OrderLifecycleManager(persistence=persistence, now_s=clock)
    adapter = LiveExecutionAdapter(
        client=client,
        persistence=persistence,
        submission_gate=gate,
        lifecycle=lifecycle,
        allowance_provider=allowance,
        risk_provider=risk,
        settings=live_settings,
        idempotency_store=idempotency,
        idempotency_ttl_seconds=300,
        now_s=clock,
    )
    if register:
        adapter.register_market(make_market())
    return LiveHarness(
        adapter=adapter,
        client=client,
        persistence=persistence,
        allowance=allowance,
        risk=risk,
        feeds=feeds,
        reconciliation=reconciliation,
        kill_switch=kill_switch,
        execution_gate=execution_gate,
        idempotency=idempotency,
        settings=live_settings,
    )
