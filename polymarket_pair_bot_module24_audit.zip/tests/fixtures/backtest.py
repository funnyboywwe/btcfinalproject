"""Reusable fixtures/builders for Module 22 backtest tests.

Everything here is in-memory and deterministic; no parquet, network or secret is
involved. Recorded snapshots are constructed by hand so tests do not depend on
``pyarrow`` (which may be absent).
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.backtest.ports import WindowRecording
from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    MarketWindow,
    OutcomeToken,
)
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.recording import (
    DataQualityFlags,
    RecordedBookSide,
    RecordedLevel,
    RecordedPairSnapshot,
    SnapshotTrigger,
)
from polymarket_pair_bot.domain.value_objects import (
    ConditionId,
    MarketId,
    TickSize,
    TokenId,
)

_UP_TOKEN = "100000000000000000000000000000000000000000000000000000000000000001"
_DOWN_TOKEN = "100000000000000000000000000000000000000000000000000000000000000002"
_CONDITION = "0x" + "ab" * 32


def make_market(
    *,
    market_id: str = "btc-5m-window",
    open_epoch: int = 1_000_000,
    close_epoch: int = 1_000_300,
    tick: str = "0.01",
) -> BinaryMarket:
    """Build a validated BTC five-minute BinaryMarket."""
    mid = MarketId(market_id)
    condition = ConditionId(_CONDITION)
    tick_size = TickSize(Decimal(tick))
    window = MarketWindow(
        market_id=mid,
        condition_id=condition,
        open_time=_ts(open_epoch),
        close_time=_ts(close_epoch),
    )
    up = OutcomeToken(
        token_id=TokenId(_UP_TOKEN),
        side=OutcomeSide.UP,
        market_id=mid,
        tick_size=tick_size,
    )
    down = OutcomeToken(
        token_id=TokenId(_DOWN_TOKEN),
        side=OutcomeSide.DOWN,
        market_id=mid,
        tick_size=tick_size,
    )
    return BinaryMarket(
        market_id=mid,
        condition_id=condition,
        window=window,
        up_token=up,
        down_token=down,
    )


def _ts(epoch: int):  # noqa: ANN202 - local helper returning UnixTimestamp
    from polymarket_pair_bot.domain.value_objects import UnixTimestamp

    return UnixTimestamp(epoch)


def fresh_flags() -> DataQualityFlags:
    """Data-quality flags for a clean, live, two-sided book."""
    return DataQualityFlags(
        has_snapshot=True,
        is_live=True,
        is_stale=False,
        is_unavailable=False,
        is_crossed=False,
        is_empty=False,
        missing_best_bid=False,
        missing_best_ask=False,
        missing_exchange_timestamp=False,
    )


def unavailable_flags() -> DataQualityFlags:
    """Flags for an outage (feed unavailable) on one side."""
    return DataQualityFlags(
        has_snapshot=False,
        is_live=False,
        is_stale=False,
        is_unavailable=True,
        is_crossed=False,
        is_empty=True,
        missing_best_bid=True,
        missing_best_ask=True,
        missing_exchange_timestamp=True,
    )


def make_side(
    *,
    side: str,
    token_id: str,
    best_bid: str,
    best_ask: str,
    depth: str = "500",
    live: bool = True,
    epoch: int = 1_000_000,
) -> RecordedBookSide:
    """Build one recorded book side with a single visible level per side."""
    if not live:
        return RecordedBookSide(
            side=side,
            token_id=token_id,
            status="UNAVAILABLE",
            best_bid=None,
            best_ask=None,
            best_bid_size=None,
            best_ask_size=None,
            spread=None,
            mid=None,
            bid_levels_count=0,
            ask_levels_count=0,
            bid_depth_total=Decimal(0),
            ask_depth_total=Decimal(0),
            bids=(),
            asks=(),
            exchange_timestamp_ms=None,
            local_receipt_epoch=None,
            processed_epoch=None,
            age_seconds=None,
            flags=unavailable_flags(),
        )
    bid = Decimal(best_bid)
    ask = Decimal(best_ask)
    size = Decimal(depth)
    return RecordedBookSide(
        side=side,
        token_id=token_id,
        status="LIVE",
        best_bid=bid,
        best_ask=ask,
        best_bid_size=size,
        best_ask_size=size,
        spread=ask - bid,
        mid=(ask + bid) / Decimal(2),
        bid_levels_count=1,
        ask_levels_count=1,
        bid_depth_total=size,
        ask_depth_total=size,
        bids=(RecordedLevel(price=bid, size=size),),
        asks=(RecordedLevel(price=ask, size=size),),
        exchange_timestamp_ms=epoch * 1000,
        local_receipt_epoch=epoch,
        processed_epoch=epoch,
        age_seconds=0.0,
        flags=fresh_flags(),
    )


def make_snapshot(
    *,
    sequence: int,
    epoch: int,
    up_ask: str = "0.45",
    down_ask: str = "0.45",
    up_bid: str = "0.44",
    down_bid: str = "0.44",
    up_live: bool = True,
    down_live: bool = True,
    market_id: str = "btc-5m-window",
    depth: str = "500",
) -> RecordedPairSnapshot:
    """Build a paired snapshot; default asks sum to 0.90 (< $1)."""
    up = make_side(
        side="UP",
        token_id=_UP_TOKEN,
        best_bid=up_bid,
        best_ask=up_ask,
        depth=depth,
        live=up_live,
        epoch=epoch,
    )
    down = make_side(
        side="DOWN",
        token_id=_DOWN_TOKEN,
        best_bid=down_bid,
        best_ask=down_ask,
        depth=depth,
        live=down_live,
        epoch=epoch,
    )
    pair_cost = (
        Decimal(up_ask) + Decimal(down_ask) if up_live and down_live else None
    )
    return RecordedPairSnapshot(
        window_id=market_id,
        market_slug=market_id,
        sequence=sequence,
        capture_epoch=epoch,
        triggers=(SnapshotTrigger.PERIODIC,),
        up=up,
        down=down,
        executable_pair_cost=pair_cost,
        pair_cost_level=None,
        top_depth=10,
    )


def make_recording(
    *,
    snapshots: tuple[RecordedPairSnapshot, ...],
    market: BinaryMarket | None = None,
) -> WindowRecording:
    """Wrap snapshots and a market into a WindowRecording."""
    return WindowRecording(market=market or make_market(), snapshots=snapshots)


class StubRecordingSource:
    """In-memory RecordingSource yielding pre-built recordings."""

    def __init__(self, recordings: tuple[WindowRecording, ...]) -> None:
        self._recordings = recordings

    def windows(self):  # noqa: ANN201 - Iterator[WindowRecording]
        yield from self._recordings


def default_snapshots(
    *, count: int = 6, start_epoch: int = 1_000_020, step: int = 1
) -> tuple[RecordedPairSnapshot, ...]:
    """A short chronological run of clean sub-$1 snapshots."""
    return tuple(
        make_snapshot(sequence=i, epoch=start_epoch + i * step)
        for i in range(count)
    )


__all__ = [
    "StubRecordingSource",
    "default_snapshots",
    "fresh_flags",
    "make_market",
    "make_recording",
    "make_side",
    "make_snapshot",
    "unavailable_flags",
]
