"""Shared fixtures/builders for auth-module tests (mocks only, no network)."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from pydantic import SecretStr

from polymarket_pair_bot.auth.addresses import build_account_identity
from polymarket_pair_bot.auth.credentials import ApiCredentials
from polymarket_pair_bot.auth.models import (
    AccountIdentity,
    BalanceView,
    OpenOrderView,
    TradeFillView,
)
from polymarket_pair_bot.auth.ports import UserStreamConnection
from polymarket_pair_bot.config.enums import SignatureType
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus

# Deterministic, obviously-fake test addresses (never real).
SIGNER_ADDRESS = "0x" + "1" * 40
FUNDER_ADDRESS = "0x" + "2" * 40


def make_identity(
    *,
    signature_type: SignatureType = SignatureType.POLY_GNOSIS_SAFE,
    chain_id: int = 137,
) -> AccountIdentity:
    return build_account_identity(
        signer_address=SIGNER_ADDRESS,
        funder_address=FUNDER_ADDRESS,
        signature_type=signature_type,
        chain_id=chain_id,
    )


def make_credentials() -> ApiCredentials:
    # Fake, non-secret placeholder values only.
    return ApiCredentials(
        api_key=SecretStr("test-key"),
        api_secret=SecretStr("test-secret"),
        api_passphrase=SecretStr("test-pass"),
    )


def make_open_order(
    *,
    order_id: str = "order-1",
    market_id: str | None = "market-1",
    status: OrderStatus = OrderStatus.OPEN,
    price: str = "0.40",
    original_size: str = "5",
    size_matched: str = "0",
) -> OpenOrderView:
    return OpenOrderView(
        order_id=order_id,
        token_id="token-1",
        market_id=market_id,
        side=OrderSide.BUY,
        status=status,
        price=price,
        original_size=original_size,
        size_matched=size_matched,
    )


def make_fill(
    *, fill_id: str = "fill-1", order_id: str = "order-1"
) -> TradeFillView:
    return TradeFillView(
        fill_id=fill_id,
        order_id=order_id,
        token_id="token-1",
        market_id="market-1",
        side=OrderSide.BUY,
        price="0.40",
        size="2",
        fee_paid="0.01",
    )


def make_balance(
    *, asset: str = "USDC", total: str = "100", available: str = "90"
) -> BalanceView:
    return BalanceView(asset=asset, total=total, available=available)


class FakeUserStreamConnection:
    """A scripted fake user-stream connection.

    Each script item is either a message mapping (yielded from ``receive``) or
    an ``Exception`` instance (raised from ``receive``).
    """

    def __init__(self, script: Sequence[Any]) -> None:
        self._script = list(script)
        self.closed = False

    async def receive(self) -> dict[str, Any]:
        if not self._script:
            raise ConnectionError("fake connection exhausted")
        item = self._script.pop(0)
        if isinstance(item, Exception):
            raise item
        return dict(item)

    async def aclose(self) -> None:
        self.closed = True


class FakeUserStreamConnectionFactory:
    """Yields the provided fake connections in order, one per connect()."""

    def __init__(self, connections: Sequence[UserStreamConnection]) -> None:
        self._connections = list(connections)
        self.connect_count = 0

    async def connect(self) -> UserStreamConnection:
        self.connect_count += 1
        if not self._connections:
            raise ConnectionError("no more fake connections")
        return self._connections.pop(0)


class SilentUserStreamConnection:
    """A connection that never delivers a message (to test freshness)."""

    def __init__(self, sleep_seconds: float = 10.0) -> None:
        self._sleep_seconds = sleep_seconds
        self.closed = False

    async def receive(self) -> dict[str, Any]:
        import asyncio

        await asyncio.sleep(self._sleep_seconds)
        return {"id": "never"}

    async def aclose(self) -> None:
        self.closed = True


class SilentUserStreamConnectionFactory:
    def __init__(self) -> None:
        self.connect_count = 0

    async def connect(self) -> UserStreamConnection:
        self.connect_count += 1
        return SilentUserStreamConnection()


__all__ = [
    "FUNDER_ADDRESS",
    "SIGNER_ADDRESS",
    "FakeUserStreamConnection",
    "FakeUserStreamConnectionFactory",
    "SilentUserStreamConnection",
    "SilentUserStreamConnectionFactory",
    "make_balance",
    "make_credentials",
    "make_fill",
    "make_identity",
    "make_open_order",
]
