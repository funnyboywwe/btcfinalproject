"""Fixtures for the paper execution adapter tests (Module 11).

Provides in-memory repository fakes that satisfy the domain repository
protocols and small deterministic builders for markets, books, trades, events
and intents. No real orders, no networking, no secrets.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    ExchangeOrder,
    Fill,
    MarketWindow,
    OrderBookSnapshot,
    OrderIntent,
    OutcomeToken,
    PriceLevel,
)
from polymarket_pair_bot.domain.enums import OrderSide, OutcomeSide, TimeInForce
from polymarket_pair_bot.domain.value_objects import (
    ConditionId,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.paper import PaperExecutionAdapter
from polymarket_pair_bot.execution.types import (
    MarketEvent,
    PaperExecutionConfig,
    TradeTick,
)

CONDITION = ConditionId("0x" + "ab" * 32)
MARKET = MarketId("btc-5m-paper")
UP = TokenId("1" * 64)
DOWN = TokenId("2" * 64)
TICK = TickSize(Decimal("0.01"))
OPEN_S = 1_700_000_000
CLOSE_S = OPEN_S + 300


def make_market() -> BinaryMarket:
    window = MarketWindow(
        market_id=MARKET,
        condition_id=CONDITION,
        open_time=UnixTimestamp(OPEN_S),
        close_time=UnixTimestamp(CLOSE_S),
    )
    up = OutcomeToken(token_id=UP, side=OutcomeSide.UP, market_id=MARKET, tick_size=TICK)
    down = OutcomeToken(
        token_id=DOWN, side=OutcomeSide.DOWN, market_id=MARKET, tick_size=TICK
    )
    return BinaryMarket(
        market_id=MARKET, condition_id=CONDITION, window=window, up_token=up, down_token=down
    )


def _levels(entries: tuple[tuple[str, str], ...]) -> tuple[PriceLevel, ...]:
    return tuple(
        PriceLevel(ProbabilityPrice(Decimal(p)), Shares(Decimal(s))) for p, s in entries
    )


def make_book(
    token: TokenId = UP,
    *,
    bids: tuple[tuple[str, str], ...] = (),
    asks: tuple[tuple[str, str], ...] = (),
    as_of: int = OPEN_S,
    sequence: int | None = None,
) -> OrderBookSnapshot:
    return OrderBookSnapshot(
        token_id=token,
        bids=_levels(bids),
        asks=_levels(asks),
        as_of=UnixTimestamp(as_of),
        sequence=sequence,
    )


def make_trade(
    trade_id: str,
    *,
    token: TokenId = UP,
    price: str,
    size: str,
    aggressor: OrderSide = OrderSide.SELL,
) -> TradeTick:
    return TradeTick(
        trade_id=trade_id,
        token_id=token,
        price=ProbabilityPrice(Decimal(price)),
        size=Shares(Decimal(size)),
        aggressor=aggressor,
    )


def make_event(
    event_id: str,
    *,
    token: TokenId = UP,
    ts_ms: int,
    bids: tuple[tuple[str, str], ...] = (),
    asks: tuple[tuple[str, str], ...] = (),
    trades: tuple[TradeTick, ...] = (),
    feed_live: bool = True,
    with_book: bool = True,
) -> MarketEvent:
    snapshot = (
        make_book(token, bids=bids, asks=asks, as_of=ts_ms // 1000) if with_book else None
    )
    return MarketEvent(
        event_id=event_id,
        token_id=token,
        timestamp_ms=ts_ms,
        snapshot=snapshot,
        trades=trades,
        feed_live=feed_live,
    )


def make_intent(
    intent_id: str,
    *,
    token: TokenId = UP,
    side: OrderSide = OrderSide.BUY,
    price: str,
    size: str,
    tif: TimeInForce = TimeInForce.GTC,
    created_s: int = OPEN_S,
) -> OrderIntent:
    return OrderIntent(
        intent_id=intent_id,
        market_id=MARKET,
        token_id=token,
        side=side,
        limit_price=ProbabilityPrice(Decimal(price)),
        size=Shares(Decimal(size)),
        time_in_force=tif,
        created_at=UnixTimestamp(created_s),
    )


class InMemoryIntentRepository:
    """Idempotent in-memory ``OrderIntentRepository``."""

    def __init__(self) -> None:
        self.items: dict[str, OrderIntent] = {}

    async def add(self, intent: OrderIntent) -> bool:
        if intent.intent_id in self.items:
            return False
        self.items[intent.intent_id] = intent
        return True

    async def get(self, intent_id: str) -> OrderIntent | None:
        return self.items.get(intent_id)


class InMemoryOrderRepository:
    """In-memory ``ExchangeOrderRepository``."""

    def __init__(self) -> None:
        self.items: dict[str, ExchangeOrder] = {}
        self.upsert_calls: int = 0

    async def upsert(self, order: ExchangeOrder) -> None:
        self.items[order.order_id.value] = order
        self.upsert_calls += 1

    async def get(self, order_id: OrderId) -> ExchangeOrder | None:
        return self.items.get(order_id.value)

    async def list_open(self, market_id: MarketId) -> list[ExchangeOrder]:
        # ExchangeOrder carries no market_id; the SQLAlchemy impl joins via the
        # intent. This fake returns every non-terminal order (sufficient for
        # single-market tests).
        return [o for o in self.items.values() if not o.status.is_terminal]


class InMemoryFillRepository:
    """Idempotent in-memory ``FillRepository``."""

    def __init__(self) -> None:
        self.items: dict[str, Fill] = {}
        self.insert_calls: int = 0

    async def insert_idempotent(self, fill: Fill) -> bool:
        self.insert_calls += 1
        if fill.fill_id.value in self.items:
            return False
        self.items[fill.fill_id.value] = fill
        return True

    async def get(self, fill_id: FillId) -> Fill | None:
        return self.items.get(fill_id.value)

    async def list_for_order(self, order_id: OrderId) -> list[Fill]:
        return [f for f in self.items.values() if f.order_id.value == order_id.value]


class InMemoryPersistence:
    """Bundle satisfying :class:`ExecutionPersistence`."""

    def __init__(self) -> None:
        self.intents = InMemoryIntentRepository()
        self.orders = InMemoryOrderRepository()
        self.fills = InMemoryFillRepository()


def make_adapter(
    *,
    config: PaperExecutionConfig | None = None,
    start_ms: int = 0,
    register: bool = True,
) -> tuple[PaperExecutionAdapter, InMemoryPersistence]:
    persistence = InMemoryPersistence()
    adapter = PaperExecutionAdapter(
        config=config if config is not None else PaperExecutionConfig(),
        persistence=persistence,
        start_ms=start_ms,
    )
    if register:
        adapter.register_market(make_market())
    return adapter, persistence
