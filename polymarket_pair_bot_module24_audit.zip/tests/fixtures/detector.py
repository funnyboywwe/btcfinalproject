"""Deterministic fixtures for the pair-opportunity detector tests (Module 10).

Reuses the engine fixtures for books/parameters and adds a synthetic binary
market, risk-input builders and in-memory observation sinks. All monetary
values use ``Decimal`` / domain value objects; no binary floats are used for
monetary quantities. No fixture ever submits an order or performs I/O.
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    MarketWindow,
    OutcomeToken,
)
from polymarket_pair_bot.domain.enums import OutcomeSide, RiskVerdict
from polymarket_pair_bot.domain.value_objects import (
    ConditionId,
    MarketId,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.strategy.detector import (
    DetectorConfig,
    PairDetector,
    RiskInput,
)
from polymarket_pair_bot.strategy.observations import DetectionObservation
from tests.fixtures.engine import TICK, UP_TOKEN, DOWN_TOKEN, NOW, make_params

CONDITION_ID = ConditionId("0x" + "ab" * 32)
MARKET_ID = MarketId("btc-5m-0001")


def make_market(
    *,
    now: UnixTimestamp = NOW,
    open_before: int = 60,
    close_after: int = 240,
    tick: TickSize = TICK,
) -> BinaryMarket:
    """Build a synthetic BTC 5-minute binary market around ``now``."""
    window = MarketWindow(
        market_id=MARKET_ID,
        condition_id=CONDITION_ID,
        open_time=UnixTimestamp(now.value - open_before),
        close_time=UnixTimestamp(now.value + close_after),
    )
    return BinaryMarket(
        market_id=MARKET_ID,
        condition_id=CONDITION_ID,
        window=window,
        up_token=OutcomeToken(
            token_id=TokenId(UP_TOKEN.value),
            side=OutcomeSide.UP,
            market_id=MARKET_ID,
            tick_size=tick,
        ),
        down_token=OutcomeToken(
            token_id=TokenId(DOWN_TOKEN.value),
            side=OutcomeSide.DOWN,
            market_id=MARKET_ID,
            tick_size=tick,
        ),
    )


def make_detector(
    *,
    passive_order_ttl_seconds: int = 30,
    taker_order_ttl_seconds: int = 5,
    **engine_overrides: object,
) -> PairDetector:
    """Build a detector with engine parameters from ``make_params`` overrides."""
    return PairDetector(
        DetectorConfig(
            engine_parameters=make_params(**engine_overrides),  # type: ignore[arg-type]
            passive_order_ttl_seconds=passive_order_ttl_seconds,
            taker_order_ttl_seconds=taker_order_ttl_seconds,
        )
    )


def approve(
    *,
    max_pair_size: str = "1000",
    reason: str = "within limits",
    as_of: UnixTimestamp = NOW,
) -> RiskInput:
    return RiskInput(
        verdict=RiskVerdict.APPROVE,
        max_pair_size=Shares(Decimal(max_pair_size)),
        reason=reason,
        as_of=as_of,
    )


def reject(*, reason: str = "limit breached", as_of: UnixTimestamp = NOW) -> RiskInput:
    return RiskInput(
        verdict=RiskVerdict.REJECT,
        max_pair_size=Shares(Decimal(0)),
        reason=reason,
        as_of=as_of,
    )


class InMemoryObservationSink:
    """Records observations in memory; used by consumer tests."""

    def __init__(self) -> None:
        self.written: list[DetectionObservation] = []
        self.flushed = 0
        self.closed = False

    async def write_batch(self, observations: Sequence[DetectionObservation]) -> int:
        self.written.extend(observations)
        return len(observations)

    async def flush(self) -> None:
        self.flushed += 1

    async def aclose(self) -> None:
        self.closed = True


class ExplodingObservationSink:
    """Raises on every write; used to prove the writer is best-effort."""

    def __init__(self) -> None:
        self.flushed = 0
        self.closed = False

    async def write_batch(self, observations: Sequence[DetectionObservation]) -> int:
        raise RuntimeError("sink on fire")

    async def flush(self) -> None:
        self.flushed += 1

    async def aclose(self) -> None:
        self.closed = True


__all__ = [
    "CONDITION_ID",
    "MARKET_ID",
    "ExplodingObservationSink",
    "InMemoryObservationSink",
    "approve",
    "make_detector",
    "make_market",
    "reject",
]
