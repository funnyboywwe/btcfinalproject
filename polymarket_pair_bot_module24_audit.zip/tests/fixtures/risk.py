"""Shared in-memory fakes and builders for risk-engine tests.

All fakes are infrastructure-free: they implement the abstract ports from
``polymarket_pair_bot.risk.ports`` and ``polymarket_pair_bot.domain`` so the
risk engine, kill switch and services can be exercised without PostgreSQL,
Redis or a network. No test ever places a real order.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

from polymarket_pair_bot.domain.coordination import KillSwitchState
from polymarket_pair_bot.domain.entities import RiskDecision
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ProfitAmount,
    Shares,
    UnixTimestamp,
)
from polymarket_pair_bot.risk.context import OperationKind, RiskContext
from polymarket_pair_bot.risk.kill_switch import KillSwitchSignal
from polymarket_pair_bot.risk.limits import RiskLimits
from polymarket_pair_bot.risk.ports import ReconciliationHealth


def make_limits(**overrides: Any) -> RiskLimits:
    """Construct a conservative but permissive-enough limit set for tests."""
    base: dict[str, Any] = dict(
        max_order_quantity=Shares(Decimal("50")),
        max_order_collateral=CollateralAmount(Decimal("25")),
        max_position_per_market=CollateralAmount(Decimal("100")),
        max_unmatched_shares=Shares(Decimal("50")),
        max_unmatched_collateral=CollateralAmount(Decimal("50")),
        max_unmatched_duration_seconds=120,
        max_deployed_capital=CollateralAmount(Decimal("200")),
        max_reserved_collateral=CollateralAmount(Decimal("100")),
        max_open_orders=10,
        max_loss_per_window=CollateralAmount(Decimal("10")),
        max_daily_loss=CollateralAmount(Decimal("25")),
        min_expected_pair_edge=CollateralAmount(Decimal("0.005")),
        min_hedge_depth=Shares(Decimal("1")),
        max_book_age_seconds=5,
        entry_min_seconds_before_close=60,
        mandatory_cancel_seconds_before_close=20,
        max_api_failures=5,
        max_ws_reconnects=10,
        min_wallet_collateral=CollateralAmount(Decimal("5")),
        min_polygon_gas_native=Decimal("0.5"),
        require_execution_leader=True,
    )
    base.update(overrides)
    return RiskLimits(**base)


def approving_context(**overrides: Any) -> RiskContext:
    """A context that passes every rule for :func:`make_limits`."""
    base: dict[str, Any] = dict(
        operation_id="op-1",
        kind=OperationKind.ORDER_INTENT,
        now=UnixTimestamp(1_000_000),
        is_execution_leader=True,
        order_quantity=Shares(Decimal("10")),
        order_collateral=CollateralAmount(Decimal("5")),
        market_position_notional=CollateralAmount(Decimal("10")),
        unmatched_shares=Shares(Decimal("5")),
        unmatched_collateral=CollateralAmount(Decimal("5")),
        oldest_unmatched_age_seconds=10,
        deployed_capital=CollateralAmount(Decimal("20")),
        reserved_collateral=CollateralAmount(Decimal("10")),
        open_orders=2,
        window_loss=CollateralAmount(Decimal("1")),
        daily_loss=CollateralAmount(Decimal("2")),
        expected_pair_edge=ProfitAmount(Decimal("0.02")),
        hedge_depth=Shares(Decimal("5")),
        book_age_seconds=1,
        seconds_to_close=120,
        api_failures=0,
        ws_reconnects=0,
        wallet_collateral=CollateralAmount(Decimal("50")),
        gas_balance_native=Decimal("1.0"),
        feed_live=True,
    )
    base.update(overrides)
    return RiskContext(**base)


@dataclass
class RecordedWrites:
    """Captures everything a fake unit of work persisted."""

    decisions: list[RiskDecision] = field(default_factory=list)
    audits: list[dict[str, Any]] = field(default_factory=list)
    kill_switch_rows: list[dict[str, Any]] = field(default_factory=list)
    commits: int = 0


class _FakeRiskEvents:
    def __init__(self, rec: RecordedWrites) -> None:
        self._rec = rec

    async def record(self, decision: RiskDecision) -> bool:
        self._rec.decisions.append(decision)
        return True

    async def get(self, decision_id: str) -> RiskDecision | None:
        for decision in self._rec.decisions:
            if decision.decision_id == decision_id:
                return decision
        return None


class _FakeAudit:
    def __init__(self, rec: RecordedWrites) -> None:
        self._rec = rec

    async def append_event(self, **kwargs: Any) -> int:
        self._rec.audits.append(kwargs)
        return len(self._rec.audits)


class _FakeKillSwitchRepo:
    def __init__(self, rec: RecordedWrites) -> None:
        self._rec = rec

    async def record(self, **kwargs: Any) -> int:
        self._rec.kill_switch_rows.append(kwargs)
        return len(self._rec.kill_switch_rows)


class FakeRiskUnitOfWork:
    """Async context-manager unit of work backed by in-memory lists."""

    def __init__(self, rec: RecordedWrites) -> None:
        self._rec = rec
        self.risk_events = _FakeRiskEvents(rec)
        self.audit = _FakeAudit(rec)
        self.kill_switch = _FakeKillSwitchRepo(rec)

    async def __aenter__(self) -> "FakeRiskUnitOfWork":
        return self

    async def __aexit__(self, *exc: object) -> None:
        return None

    async def commit(self) -> None:
        self._rec.commits += 1


class FakeRiskUnitOfWorkFactory:
    """Callable that returns fresh units of work sharing one record log."""

    def __init__(self) -> None:
        self.recorded = RecordedWrites()

    def __call__(self) -> FakeRiskUnitOfWork:
        return FakeRiskUnitOfWork(self.recorded)


class FakeKillSwitchStore:
    """In-memory :class:`KillSwitchStore`."""

    def __init__(self, *, active: bool = False, reason: str = "") -> None:
        self._active = active
        self._reason = reason
        self.calls: list[str] = []

    async def get_state(self) -> KillSwitchState:
        return KillSwitchState(active=self._active, reason=self._reason)

    async def is_active(self) -> bool:
        return self._active

    async def activate(self, *, reason: str, actor: str | None, at: int) -> None:
        self._active = True
        self._reason = reason
        self.calls.append("activate")

    async def deactivate(self, *, actor: str | None, at: int) -> None:
        self._active = False
        self._reason = ""
        self.calls.append("deactivate")


class FakeKillSwitchLatestReader:
    """In-memory :class:`KillSwitchLatestReader`."""

    def __init__(self, state: KillSwitchState | None = None) -> None:
        self._state = state

    async def read_latest(self, key: str) -> KillSwitchState | None:
        return self._state


class FakeReconciliationProvider:
    def __init__(self, health: ReconciliationHealth | None) -> None:
        self._health = health

    async def latest_reconciliation(self) -> ReconciliationHealth | None:
        return self._health


class FakeFeedProvider:
    def __init__(self, healthy: bool) -> None:
        self._healthy = healthy

    async def feeds_healthy(self) -> bool:
        return self._healthy


class StaticSource:
    """A :class:`KillSwitchSource` returning a fixed signal or raising."""

    def __init__(self, name: str, signal: KillSwitchSignal | Exception) -> None:
        self._name = name
        self._signal = signal

    @property
    def name(self) -> str:
        return self._name

    async def read(self) -> KillSwitchSignal:
        if isinstance(self._signal, Exception):
            raise self._signal
        return self._signal


__all__ = [
    "FakeFeedProvider",
    "FakeKillSwitchLatestReader",
    "FakeKillSwitchStore",
    "FakeReconciliationProvider",
    "FakeRiskUnitOfWork",
    "FakeRiskUnitOfWorkFactory",
    "RecordedWrites",
    "StaticSource",
    "approving_context",
    "make_limits",
]
