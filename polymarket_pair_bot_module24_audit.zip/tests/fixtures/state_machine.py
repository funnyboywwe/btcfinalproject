"""In-memory fakes and builders for the pair-accumulation state machine tests.

Everything here is infrastructure-free: no SQLAlchemy, no network, no real
adapters. The fakes implement the same ports the production adapters will, so
the SAME machine is exercised as in production (requirement 14). No fake ever
places a real order or handles a secret.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from decimal import Decimal

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    ExchangeOrder,
    Fill,
    MarketWindow,
    OrderBookSnapshot,
    OutcomeToken,
    ReconciliationResult,
    RiskDecision,
)
from polymarket_pair_bot.domain.enums import (
    CtfOperationStatus,
    OrderStatus,
    OutcomeSide,
    ReconciliationStatus,
    RiskVerdict,
)
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ConditionId,
    FeeAmount,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.types import (
    CancelBatchAck,
    SubmitAck,
    SubmitOutcome,
)
from polymarket_pair_bot.strategy.detector import DetectorAction, ExecutionRole
from polymarket_pair_bot.strategy.session_models import (
    PairSessionSnapshot,
    SessionLimits,
    SessionTransition,
)
from polymarket_pair_bot.strategy.session_ports import (
    MergeOutcome,
    RiskApprovalRequest,
    RiskApprovalResult,
)

MARKET_ID = "btc-5m-0001"
CONDITION_ID = "0x" + "ab" * 32
UP_TOKEN = "1001"
DOWN_TOKEN = "1002"
TICK = Decimal("0.001")


# --------------------------------------------------------------------------- #
# Builders
# --------------------------------------------------------------------------- #
def make_market(*, close_time: int = 10_000) -> BinaryMarket:
    market_id = MarketId(MARKET_ID)
    condition_id = ConditionId(CONDITION_ID)
    window = MarketWindow(
        market_id=market_id,
        condition_id=condition_id,
        open_time=UnixTimestamp(close_time - 300),
        close_time=UnixTimestamp(close_time),
    )
    up = OutcomeToken(
        token_id=TokenId(UP_TOKEN),
        side=OutcomeSide.UP,
        market_id=market_id,
        tick_size=TickSize(TICK),
    )
    down = OutcomeToken(
        token_id=TokenId(DOWN_TOKEN),
        side=OutcomeSide.DOWN,
        market_id=market_id,
        tick_size=TickSize(TICK),
    )
    return BinaryMarket(
        market_id=market_id,
        condition_id=condition_id,
        window=window,
        up_token=up,
        down_token=down,
    )


def make_book(token_id: str, *, as_of: int) -> OrderBookSnapshot:
    return OrderBookSnapshot(
        token_id=TokenId(token_id),
        bids=(),
        asks=(),
        as_of=UnixTimestamp(as_of),
    )


def make_fill(
    *,
    fill_id: str,
    side: OutcomeSide,
    price: str,
    size: str,
    fee: str = "0",
    at: int,
) -> Fill:
    token = UP_TOKEN if side is OutcomeSide.UP else DOWN_TOKEN
    return Fill(
        fill_id=FillId(fill_id),
        order_id=OrderId(f"ord-{fill_id}"),
        token_id=TokenId(token),
        side=side,
        price=ProbabilityPrice(Decimal(price)),
        size=Shares(Decimal(size)),
        fee=FeeAmount(Decimal(fee)),
        filled_at=UnixTimestamp(at),
    )


def make_limits(**overrides: object) -> SessionLimits:
    base: dict[str, object] = dict(
        target_pair_size=Shares(Decimal("5")),
        first_leg_cutoff_seconds=90,
        mandatory_cancel_seconds=20,
        max_unmatched_shares=Shares(Decimal("50")),
        max_unmatched_seconds=120,
        unmatched_warning_ratio=Decimal("0.8"),
        merge_min_net_value=CollateralAmount(Decimal("0")),
        max_effective_pair_cost=CollateralAmount(Decimal("0.99")),
        overhead=CollateralAmount(Decimal("0.01")),
        reconcile_on_uncertain=True,
        processed_id_history=64,
    )
    base.update(overrides)
    return SessionLimits(**base)  # type: ignore[arg-type]


# --------------------------------------------------------------------------- #
# Fake detector (duck-typed; the machine only reads action + approved_candidates)
# --------------------------------------------------------------------------- #
@dataclass
class _FakeCandidate:
    side: OutcomeSide
    role: ExecutionRole
    proposed_price: ProbabilityPrice
    proposed_quantity: Shares
    approved: bool


@dataclass
class _FakeDetection:
    action: DetectorAction
    candidates: tuple[_FakeCandidate, ...]

    @property
    def approved_candidates(self) -> tuple[_FakeCandidate, ...]:
        return tuple(c for c in self.candidates if c.approved)


class FakeDetector:
    """Programmable detector. Each ``evaluate`` consumes one scripted response.

    A response is ``(action, [(side, role, price, qty), ...])``. Candidates are
    marked approved ONLY when the passed ``risk_input`` verdict is APPROVE, so
    the risk gate is genuinely exercised. When the script is empty the detector
    returns NO_TRADE with no candidates.
    """

    def __init__(self) -> None:
        self.responses: deque[tuple[DetectorAction, list[tuple]]] = deque()
        self.calls = 0

    def program(self, action: DetectorAction, legs: list[tuple]) -> None:
        self.responses.append((action, legs))

    def evaluate(self, **kwargs: object) -> _FakeDetection:
        self.calls += 1
        risk_input = kwargs.get("risk_input")
        approved = bool(
            risk_input is not None
            and getattr(risk_input, "verdict", None) is RiskVerdict.APPROVE
        )
        if not self.responses:
            return _FakeDetection(DetectorAction.NO_TRADE, ())
        action, legs = self.responses.popleft()
        candidates = tuple(
            _FakeCandidate(
                side=side,
                role=role,
                proposed_price=ProbabilityPrice(Decimal(price)),
                proposed_quantity=Shares(Decimal(qty)),
                approved=approved,
            )
            for (side, role, price, qty) in legs
        )
        return _FakeDetection(action, candidates)


# --------------------------------------------------------------------------- #
# Fake ports
# --------------------------------------------------------------------------- #
class FakeSessionStore:
    """In-memory authoritative store recording every persisted transition."""

    def __init__(self) -> None:
        self.snapshots: dict[str, PairSessionSnapshot] = {}
        self.transitions: list[SessionTransition] = []

    async def load(self, market_id: MarketId) -> PairSessionSnapshot | None:
        return self.snapshots.get(market_id.value)

    async def save(
        self, snapshot: PairSessionSnapshot, transition: SessionTransition
    ) -> None:
        self.snapshots[snapshot.market_id.value] = snapshot
        self.transitions.append(transition)


class FakeExecutionAdapter:
    """In-memory execution adapter. Never places a real order."""

    def __init__(self, *, submit_outcome: SubmitOutcome = SubmitOutcome.ACCEPTED) -> None:
        self.submit_outcome = submit_outcome
        self.submitted: list = []
        self.cancel_market_calls = 0
        self._order_seq = 0
        # Each submit consumes one entry of fills the resulting order will show.
        self.fill_queue: deque[list[Fill]] = deque()

    def program_fills(self, fills: list[Fill]) -> None:
        self.fill_queue.append(fills)

    async def submit_order(self, intent) -> SubmitAck:
        self.submitted.append(intent)
        self._order_seq += 1
        order_id = OrderId(f"exch-{self._order_seq}")
        order = ExchangeOrder(
            order_id=order_id,
            intent_id=intent.intent_id,
            token_id=intent.token_id,
            side=intent.side,
            limit_price=intent.limit_price,
            original_size=intent.size,
            filled_size=Shares(Decimal(0)),
            status=OrderStatus.ACKNOWLEDGED,
            created_at=intent.created_at,
            updated_at=intent.created_at,
        )
        fills = self.fill_queue.popleft() if self.fill_queue else []
        self._fills_for_order = {order_id.value: fills}
        return SubmitAck(
            intent_id=intent.intent_id, outcome=self.submit_outcome, order=order
        )

    async def cancel_order(self, order_id):
        raise NotImplementedError

    async def cancel_market_orders(self, market_id) -> CancelBatchAck:
        self.cancel_market_calls += 1
        return CancelBatchAck(acks=())

    async def cancel_all_orders(self) -> CancelBatchAck:
        return CancelBatchAck(acks=())

    async def get_order(self, order_id):
        return None

    async def get_open_orders(self, market_id=None):
        return ()

    async def get_fills(self, *, order_id=None, market_id=None):
        if order_id is not None:
            return tuple(getattr(self, "_fills_for_order", {}).get(order_id.value, ()))
        return ()


def _decision(verdict: RiskVerdict, size: Shares, reason: str) -> RiskDecision:
    return RiskDecision(
        decision_id="decision-1",
        verdict=verdict,
        reason=reason,
        decided_at=UnixTimestamp(0),
        approved_size=size,
    )


class FakeRiskApprovalPort:
    def __init__(self, *, approved: bool = True, size: str = "5") -> None:
        self.approved = approved
        self.size = Shares(Decimal(size))
        self.requests: list[RiskApprovalRequest] = []

    async def evaluate(self, request: RiskApprovalRequest) -> RiskApprovalResult:
        self.requests.append(request)
        if self.approved:
            return RiskApprovalResult(
                approved=True,
                approved_size=self.size,
                reason="approved",
                decision=_decision(RiskVerdict.APPROVE, self.size, "approved"),
            )
        zero = Shares(Decimal(0))
        return RiskApprovalResult(
            approved=False,
            approved_size=zero,
            reason="rejected",
            decision=_decision(RiskVerdict.REJECT, zero, "rejected"),
        )


class FakeMergePort:
    def __init__(
        self,
        *,
        mergeable: str = "5",
        status: CtfOperationStatus = CtfOperationStatus.CONFIRMED,
    ) -> None:
        self.mergeable_qty = Shares(Decimal(mergeable))
        self.status = status
        self.merge_calls = 0

    async def mergeable(self, market) -> Shares:
        return self.mergeable_qty

    async def merge(self, *, market, quantity, risk_decision) -> MergeOutcome:
        self.merge_calls += 1
        return MergeOutcome(
            operation_id="merge-op-1",
            status=self.status,
            quantity=quantity,
            mergeable=self.mergeable_qty,
        )


class FakeReconciliationPort:
    def __init__(
        self, *, status: ReconciliationStatus = ReconciliationStatus.CONSISTENT
    ) -> None:
        self.status = status
        self.triggers: list = []

    async def reconcile(self, trigger) -> ReconciliationResult:
        self.triggers.append(trigger)
        return ReconciliationResult(status=self.status, as_of=UnixTimestamp(0))


class FakeKillSwitchPort:
    def __init__(self, *, active: bool = False) -> None:
        self.active = active

    async def is_active(self) -> bool:
        return self.active


@dataclass
class Harness:
    machine: object
    store: FakeSessionStore
    execution: FakeExecutionAdapter
    risk: FakeRiskApprovalPort
    merge: FakeMergePort
    reconciliation: FakeReconciliationPort
    kill_switch: FakeKillSwitchPort
    detector: FakeDetector
    market: BinaryMarket


def build_harness(*, limits: SessionLimits | None = None, **port_overrides) -> Harness:
    from polymarket_pair_bot.strategy.session_machine import (
        PairAccumulationStateMachine,
    )

    store = port_overrides.get("store") or FakeSessionStore()
    execution = port_overrides.get("execution") or FakeExecutionAdapter()
    risk = port_overrides.get("risk") or FakeRiskApprovalPort()
    merge = port_overrides.get("merge") or FakeMergePort()
    reconciliation = port_overrides.get("reconciliation") or FakeReconciliationPort()
    kill_switch = port_overrides.get("kill_switch") or FakeKillSwitchPort()
    detector = port_overrides.get("detector") or FakeDetector()
    machine = PairAccumulationStateMachine(
        store=store,
        execution=execution,
        risk=risk,
        merge=merge,
        reconciliation=reconciliation,
        kill_switch=kill_switch,
        detector=detector,  # type: ignore[arg-type]
        limits=limits or make_limits(),
    )
    return Harness(
        machine=machine,
        store=store,
        execution=execution,
        risk=risk,
        merge=merge,
        reconciliation=reconciliation,
        kill_switch=kill_switch,
        detector=detector,
        market=make_market(),
    )
