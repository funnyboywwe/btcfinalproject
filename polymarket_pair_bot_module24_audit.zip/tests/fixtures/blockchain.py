"""In-memory fakes for the Polygon wallet-state service tests (Module 16).

These let every branch of the service, dual-RPC reader, resilience primitives
and transaction classifier be exercised deterministically with no web3.py
install and no network. Nothing here ever holds a private key.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from polymarket_pair_bot.blockchain import abi

WALLET_ADDRESS = "0x" + "a" * 40
USDC_ADDRESS = "0x" + "b" * 40
CTF_ADDRESS = "0x" + "c" * 40
SPENDER_ADDRESS = "0x" + "d" * 40
UP_TOKEN = "1001"
DOWN_TOKEN = "1002"
POLYGON_CHAIN_ID = 137


class FakeClock:
    """A monotonic clock the tests advance explicitly."""

    def __init__(self, start: float = 1000.0) -> None:
        self.now = start

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


class FakeSleep:
    """An async sleep that records delays and advances a clock (no real wait)."""

    def __init__(self, clock: FakeClock | None = None) -> None:
        self.delays: list[float] = []
        self._clock = clock

    async def __call__(self, seconds: float) -> None:
        self.delays.append(seconds)
        if self._clock is not None:
            self._clock.advance(seconds)


def _encode_uint(value: int) -> str:
    return "0x" + format(value, "064x")


class FakeEthereumRpc:
    """Configurable in-memory :class:`EthereumRpc` implementation.

    * ``call_returns`` maps exact calldata -> uint256 result.
    * ``fail_first`` injects that many leading transient ``OSError`` failures
      into every method (to exercise retries / circuit breakers).
    """

    def __init__(
        self,
        *,
        label: str = "primary",
        chain_id: int = POLYGON_CHAIN_ID,
        native_balance: int = 5 * 10**18,
        gas_estimate: int = 21000,
        gas_price: int = 30 * 10**9,
        nonce_latest: int = 7,
        nonce_pending: int = 7,
        block_number: int = 1000,
        call_returns: Mapping[str, int] | None = None,
        transactions: Mapping[str, dict[str, Any] | None] | None = None,
        receipts: Mapping[str, dict[str, Any] | None] | None = None,
        call_error: Exception | None = None,
        fail_first: int = 0,
    ) -> None:
        self._label = label
        self.chain_id_value = chain_id
        self.native_balance = native_balance
        self.gas_estimate = gas_estimate
        self.gas_price_value = gas_price
        self.nonce_latest = nonce_latest
        self.nonce_pending = nonce_pending
        self.block_number_value = block_number
        self.call_returns = dict(call_returns or {})
        self.transactions = dict(transactions or {})
        self.receipts = dict(receipts or {})
        self.call_error = call_error
        self._fail_first = fail_first
        self.calls: list[str] = []

    @property
    def label(self) -> str:
        return self._label

    def _maybe_fail(self, op: str) -> None:
        self.calls.append(op)
        if self._fail_first > 0:
            self._fail_first -= 1
            raise OSError(f"injected transient failure on {op}")

    async def chain_id(self) -> int:
        self._maybe_fail("chain_id")
        return self.chain_id_value

    async def get_balance(self, address: str, *, block: str = "latest") -> int:
        self._maybe_fail("get_balance")
        return self.native_balance

    async def call(self, *, to: str, data: str, block: str = "latest") -> str:
        self._maybe_fail("call")
        if self.call_error is not None:
            raise self.call_error
        if data not in self.call_returns:
            raise ValueError(f"execution reverted: no stub for calldata {data}")
        return _encode_uint(self.call_returns[data])

    async def estimate_gas(
        self, *, to: str, data: str, value: int = 0, sender: str | None = None
    ) -> int:
        self._maybe_fail("estimate_gas")
        return self.gas_estimate

    async def gas_price(self) -> int:
        self._maybe_fail("gas_price")
        return self.gas_price_value

    async def get_transaction(self, tx_hash: str) -> Mapping[str, Any] | None:
        self._maybe_fail("get_transaction")
        return self.transactions.get(tx_hash)

    async def get_transaction_receipt(
        self, tx_hash: str
    ) -> Mapping[str, Any] | None:
        self._maybe_fail("get_transaction_receipt")
        return self.receipts.get(tx_hash)

    async def get_transaction_count(
        self, address: str, *, block: str = "latest"
    ) -> int:
        self._maybe_fail("get_transaction_count")
        return self.nonce_pending if block == "pending" else self.nonce_latest

    async def block_number(self) -> int:
        self._maybe_fail("block_number")
        return self.block_number_value

    async def aclose(self) -> None:
        return None


def collateral_calldata() -> str:
    return abi.encode_erc20_balance_of(WALLET_ADDRESS)


def token_calldata(token_id: str) -> str:
    return abi.encode_erc1155_balance_of(WALLET_ADDRESS, int(token_id))


def allowance_calldata(spender: str = SPENDER_ADDRESS) -> str:
    return abi.encode_erc20_allowance(WALLET_ADDRESS, spender)


def make_receipt(
    *, status: int = 1, block_number: int = 990, gas_used: int = 21000
) -> dict[str, Any]:
    return {
        "status": status,
        "blockNumber": block_number,
        "gasUsed": gas_used,
    }


__all__ = [
    "CTF_ADDRESS",
    "DOWN_TOKEN",
    "FakeClock",
    "FakeEthereumRpc",
    "FakeSleep",
    "POLYGON_CHAIN_ID",
    "SPENDER_ADDRESS",
    "UP_TOKEN",
    "USDC_ADDRESS",
    "WALLET_ADDRESS",
    "allowance_calldata",
    "collateral_calldata",
    "make_receipt",
    "token_calldata",
]
