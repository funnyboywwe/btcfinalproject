"""Deterministic fixtures/helpers for the Module 7 recorder tests.

Builders for :class:`BookQuote` / :class:`OrderBookSnapshot` and an in-memory
fake :class:`OrderBookProvider`, plus capturing fake sinks. No network, no
secrets, no pyarrow, no database.
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal

from polymarket_pair_bot.domain.entities import OrderBookSnapshot, PriceLevel
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.market_data import BookQuote, FeedStatus
from polymarket_pair_bot.domain.recording import (
    RecordedPairSnapshot,
    RecordedSnapshotSummary,
)
from polymarket_pair_bot.domain.value_objects import (
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)

UP_TOKEN = "1000000000000000000000000000000000000000000000000000000000000001"
DOWN_TOKEN = "2000000000000000000000000000000000000000000000000000000000000002"


def _price(value: str | None) -> ProbabilityPrice | None:
    return None if value is None else ProbabilityPrice(Decimal(value))


def _shares(value: str | None) -> Shares | None:
    return None if value is None else Shares(Decimal(value))


def make_quote(
    side: OutcomeSide,
    *,
    token_id: str,
    status: FeedStatus = FeedStatus.LIVE,
    best_bid: str | None = "0.40",
    best_ask: str | None = "0.60",
    best_bid_size: str | None = "100",
    best_ask_size: str | None = "100",
    bid_levels: int = 1,
    ask_levels: int = 1,
    bid_depth: str = "100",
    ask_depth: str = "100",
    exchange_timestamp_ms: int | None = 1_700_000_000_000,
    local_receipt_epoch: int | None = 1_700_000_000,
    processed_epoch: int | None = 1_700_000_000,
    age_seconds: float | None = 0.1,
) -> BookQuote:
    """Build a deterministic :class:`BookQuote`."""
    return BookQuote(
        side=side,
        token_id=TokenId(token_id),
        status=status,
        best_bid=_price(best_bid),
        best_ask=_price(best_ask),
        best_bid_size=_shares(best_bid_size),
        best_ask_size=_shares(best_ask_size),
        bid_levels=bid_levels,
        ask_levels=ask_levels,
        bid_depth=Shares(Decimal(bid_depth)),
        ask_depth=Shares(Decimal(ask_depth)),
        exchange_timestamp_ms=exchange_timestamp_ms,
        local_receipt_epoch=local_receipt_epoch,
        processed_epoch=processed_epoch,
        age_seconds=age_seconds,
    )


def make_snapshot(
    token_id: str,
    *,
    bids: Sequence[tuple[str, str]] = (("0.40", "100"),),
    asks: Sequence[tuple[str, str]] = (("0.60", "100"),),
    as_of: int = 1_700_000_000,
    sequence: int | None = 1,
) -> OrderBookSnapshot:
    """Build a deterministic full L2 :class:`OrderBookSnapshot`."""
    return OrderBookSnapshot(
        token_id=TokenId(token_id),
        bids=tuple(
            PriceLevel(price=ProbabilityPrice(Decimal(p)), size=Shares(Decimal(s)))
            for p, s in bids
        ),
        asks=tuple(
            PriceLevel(price=ProbabilityPrice(Decimal(p)), size=Shares(Decimal(s)))
            for p, s in asks
        ),
        as_of=UnixTimestamp(as_of),
        sequence=sequence,
    )


class FakeOrderBookProvider:
    """An in-memory, scriptable :class:`OrderBookProvider`.

    ``set_side`` replaces the current quote/snapshot for one side; the recorder
    poll loop reads whatever is currently set on each tick.
    """

    def __init__(self) -> None:
        self._quotes: dict[OutcomeSide, BookQuote] = {
            OutcomeSide.UP: make_quote(OutcomeSide.UP, token_id=UP_TOKEN),
            OutcomeSide.DOWN: make_quote(OutcomeSide.DOWN, token_id=DOWN_TOKEN),
        }
        self._snapshots: dict[OutcomeSide, OrderBookSnapshot | None] = {
            OutcomeSide.UP: make_snapshot(UP_TOKEN),
            OutcomeSide.DOWN: make_snapshot(DOWN_TOKEN),
        }
        self._reconnects = 0

    def set_side(
        self,
        side: OutcomeSide,
        quote: BookQuote,
        snapshot: OrderBookSnapshot | None,
    ) -> None:
        self._quotes[side] = quote
        self._snapshots[side] = snapshot

    def feed_status(self, side: OutcomeSide) -> FeedStatus:
        return self._quotes[side].status

    def quote(self, side: OutcomeSide) -> BookQuote:
        return self._quotes[side]

    def snapshot(self, side: OutcomeSide) -> OrderBookSnapshot | None:
        return self._snapshots[side]

    def is_fresh(self, side: OutcomeSide) -> bool:
        return self._quotes[side].status is FeedStatus.LIVE

    @property
    def reconnect_count(self) -> int:
        return self._reconnects


class FakeSnapshotSink:
    """Capturing bulk sink implementing the ``SnapshotSink`` protocol."""

    def __init__(self) -> None:
        self.batches: list[list[RecordedPairSnapshot]] = []
        self.flushed = 0
        self.closed = False

    async def write_batch(self, snapshots: Sequence[RecordedPairSnapshot]) -> int:
        self.batches.append(list(snapshots))
        return len(snapshots)

    async def flush(self) -> None:
        self.flushed += 1

    async def aclose(self) -> None:
        self.closed = True

    @property
    def written(self) -> list[RecordedPairSnapshot]:
        return [item for batch in self.batches for item in batch]


class FakeSummarySink:
    """Capturing summary sink implementing the ``SummarySink`` protocol."""

    def __init__(self) -> None:
        self.summaries: list[RecordedSnapshotSummary] = []
        self.closed = False

    async def write_batch(self, summaries: Sequence[RecordedSnapshotSummary]) -> int:
        self.summaries.extend(summaries)
        return len(summaries)

    async def flush(self) -> None:
        return None

    async def aclose(self) -> None:
        self.closed = True


__all__ = [
    "DOWN_TOKEN",
    "UP_TOKEN",
    "FakeOrderBookProvider",
    "FakeSnapshotSink",
    "FakeSummarySink",
    "make_quote",
    "make_snapshot",
]
