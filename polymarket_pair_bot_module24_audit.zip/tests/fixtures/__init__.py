"""Shared test fixtures and static sample payloads."""
