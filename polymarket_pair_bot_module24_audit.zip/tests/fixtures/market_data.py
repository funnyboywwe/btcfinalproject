"""Deterministic fixtures/helpers for Module 6 market-data tests.

Provides builders for the documented market-channel frames (as wire-shaped
dicts with string prices/sizes), an in-memory fake WebSocket connector, and a
manual monotonic clock so freshness/age can be asserted deterministically.

No network, no secrets.
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable, Sequence
from typing import Any

UP_TOKEN = "1000000000000000000000000000000000000000000000000000000000000001"
DOWN_TOKEN = "2000000000000000000000000000000000000000000000000000000000000002"


def book_message(
    asset_id: str,
    *,
    bids: Sequence[tuple[str, str]] = (),
    asks: Sequence[tuple[str, str]] = (),
    timestamp: str | None = "1700000000000",
) -> dict[str, Any]:
    """Build a documented ``book`` snapshot frame."""
    return {
        "event_type": "book",
        "asset_id": asset_id,
        "market": "0xmarket",
        "timestamp": timestamp,
        "hash": "0xhash",
        "bids": [{"price": p, "size": s} for p, s in bids],
        "asks": [{"price": p, "size": s} for p, s in asks],
    }


def price_change_message(
    asset_id: str,
    *,
    changes: Sequence[tuple[str, str, str]],
    timestamp: str | None = "1700000000001",
) -> dict[str, Any]:
    """Build a ``price_change`` frame. Each change is (price, side, size)."""
    return {
        "event_type": "price_change",
        "asset_id": asset_id,
        "market": "0xmarket",
        "timestamp": timestamp,
        "hash": "0xhash",
        "changes": [
            {"price": p, "side": side, "size": s} for p, side, s in changes
        ],
    }


def tick_size_message(
    asset_id: str, *, new: str, old: str | None = None
) -> dict[str, Any]:
    return {
        "event_type": "tick_size_change",
        "asset_id": asset_id,
        "market": "0xmarket",
        "timestamp": "1700000000002",
        "old_tick_size": old,
        "new_tick_size": new,
    }


def trade_message(
    asset_id: str, *, price: str, size: str, side: str = "BUY"
) -> dict[str, Any]:
    return {
        "event_type": "last_trade_price",
        "asset_id": asset_id,
        "market": "0xmarket",
        "timestamp": "1700000000003",
        "price": price,
        "size": size,
        "side": side,
    }


def dumps(payload: Any) -> str:
    """Serialize a frame (or batch) to a JSON text frame."""
    return json.dumps(payload)


class ManualClock:
    """A deterministic monotonic clock (seconds, float)."""

    def __init__(self, start: float = 1000.0) -> None:
        self._t = start

    def __call__(self) -> float:
        return self._t

    def advance(self, delta: float) -> None:
        self._t += delta


BLOCK = "__BLOCK_FOREVER__"


class FakeConnection:
    """Scripted in-memory WebSocket connection.

    ``frames`` items may be: a ``str`` (returned from ``recv``), a ``dict``
    (json-encoded then returned), a ``BaseException`` (raised from ``recv`` to
    simulate a drop), or the ``BLOCK`` sentinel (awaits forever to keep the
    session open until cancelled).
    """

    def __init__(self, frames: Sequence[Any]) -> None:
        self._frames: list[Any] = list(frames)
        self.sent: list[str] = []
        self.closed = False

    async def send(self, message: str) -> None:
        self.sent.append(message)

    async def recv(self) -> str:
        while self._frames:
            item = self._frames.pop(0)
            if isinstance(item, BaseException):
                raise item
            if item is BLOCK:
                await asyncio.Event().wait()  # blocks until cancelled
            if isinstance(item, (dict, list)):
                return json.dumps(item)
            return str(item)
        raise ConnectionError("fake connection exhausted")

    async def close(self) -> None:
        self.closed = True


class FakeConnector:
    """Yields pre-scripted :class:`FakeConnection` sessions in order."""

    def __init__(self, sessions: Sequence[FakeConnection]) -> None:
        self._sessions: list[FakeConnection] = list(sessions)
        self.connect_calls = 0
        self.urls: list[str] = []

    async def connect(self, url: str) -> FakeConnection:
        self.connect_calls += 1
        self.urls.append(url)
        if not self._sessions:
            raise ConnectionError("no more fake sessions")
        return self._sessions.pop(0)


async def wait_for(
    predicate: Callable[[], bool], *, timeout: float = 2.0
) -> None:
    """Poll ``predicate`` until true or raise ``TimeoutError``."""

    async def _spin() -> None:
        while not predicate():
            await asyncio.sleep(0)

    await asyncio.wait_for(_spin(), timeout=timeout)


async def immediate_sleep(_delay: float) -> Awaitable[None] | None:
    """A no-op sleep used to make reconnect backoff instant in tests."""
    await asyncio.sleep(0)
    return None


__all__ = [
    "BLOCK",
    "DOWN_TOKEN",
    "FakeConnection",
    "FakeConnector",
    "ManualClock",
    "UP_TOKEN",
    "book_message",
    "dumps",
    "immediate_sleep",
    "price_change_message",
    "tick_size_message",
    "trade_message",
    "wait_for",
]
