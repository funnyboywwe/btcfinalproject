"""Deterministic fixtures and helpers for Module 8 engine tests.

All prices, sizes and monetary values use ``Decimal`` / domain value objects.
No binary floats are used for monetary quantities.

Provides:
  * ``make_book`` — build an ``OrderBookSnapshot`` from plain tuples.
  * ``make_params`` — build ``EngineParameters`` with sensible defaults.
  * ``make_inventory`` — build ``InventorySummary``.
  * ``TICK`` — canonical 0.01 tick size used across tests.
  * ``UP_TOKEN`` / ``DOWN_TOKEN`` — synthetic token IDs.
  * Various pre-built book factories for common scenarios.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.entities import OrderBookSnapshot, PriceLevel
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.strategy.engine import (
    EngineParameters,
    FeeParameters,
    InventorySummary,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

UP_TOKEN = TokenId("1" * 64)
DOWN_TOKEN = TokenId("2" * 64)
TICK = TickSize(Decimal("0.01"))
NOW = UnixTimestamp(1_700_000_000)


# ---------------------------------------------------------------------------
# Book builder
# ---------------------------------------------------------------------------


def make_book(
    token: TokenId,
    *,
    bids: list[tuple[str, str]] | None = None,
    asks: list[tuple[str, str]] | None = None,
    as_of: UnixTimestamp | None = None,
) -> OrderBookSnapshot:
    """Build an OrderBookSnapshot from ``(price, size)`` tuples.

    Bids must be supplied in descending price order; asks in ascending order.
    Omit either to leave it empty.
    """
    def _lvl(p: str, s: str) -> PriceLevel:
        return PriceLevel(
            price=ProbabilityPrice(Decimal(p)),
            size=Shares(Decimal(s)),
        )

    return OrderBookSnapshot(
        token_id=token,
        bids=tuple(_lvl(p, s) for p, s in (bids or [])),
        asks=tuple(_lvl(p, s) for p, s in (asks or [])),
        as_of=as_of or NOW,
    )


# ---------------------------------------------------------------------------
# Pre-built books
# ---------------------------------------------------------------------------


def thin_book(token: TokenId, *, ask: str = "0.50", size: str = "1") -> OrderBookSnapshot:
    """Single-level book with one ask at `ask` price."""
    return make_book(
        token,
        bids=[(str(Decimal(ask) - Decimal("0.01")), "1")],
        asks=[(ask, size)],
    )


def deep_book(
    token: TokenId,
    *,
    best_ask: str = "0.50",
    levels: int = 5,
    size_per_level: str = "20",
    tick: str = "0.01",
) -> OrderBookSnapshot:
    """Multi-level book with uniform depth."""
    tick_d = Decimal(tick)
    base = Decimal(best_ask)
    asks = [
        (str(base + i * tick_d), size_per_level)
        for i in range(levels)
    ]
    base_bid = base - tick_d
    bids = [
        (str(base_bid - i * tick_d), size_per_level)
        for i in range(levels)
    ]
    return make_book(token, bids=bids, asks=asks)


def crossed_book(token: TokenId) -> OrderBookSnapshot:
    """Book where best bid >= best ask (crossed / invalid)."""
    # OrderBookSnapshot validates sort order but not crossing;
    # use separate-price levels that appear internally valid.
    return make_book(
        token,
        bids=[("0.60", "10")],
        asks=[("0.55", "10")],  # ask < bid → crossed
    )


# ---------------------------------------------------------------------------
# EngineParameters builder
# ---------------------------------------------------------------------------


def make_params(
    *,
    taker_fee_bps: str = "0",
    maker_fee_bps: str = "0",
    slippage_reserve: str = "0",
    merge_gas_overhead: str = "0.005",
    safety_reserve: str = "0.005",
    max_effective_pair_cost: str = "0.99",
    required_net_profit: str = "0",
    min_book_depth: str = "1",
    min_seconds_to_close: int = 30,
    tick_size: TickSize = TICK,
) -> EngineParameters:
    """Build EngineParameters with explicit overrides."""
    return EngineParameters(
        fee_parameters=FeeParameters(
            taker_fee_bps=BasisPoints(Decimal(taker_fee_bps)),
            maker_fee_bps=BasisPoints(Decimal(maker_fee_bps)),
        ),
        slippage_reserve=CollateralAmount(Decimal(slippage_reserve)),
        merge_gas_overhead=CollateralAmount(Decimal(merge_gas_overhead)),
        safety_reserve=CollateralAmount(Decimal(safety_reserve)),
        max_effective_pair_cost=CollateralAmount(Decimal(max_effective_pair_cost)),
        required_net_profit=ProfitAmount(Decimal(required_net_profit)),
        min_book_depth=Shares(Decimal(min_book_depth)),
        min_seconds_to_close=min_seconds_to_close,
        tick_size=tick_size,
    )


# ---------------------------------------------------------------------------
# InventorySummary builder
# ---------------------------------------------------------------------------


def make_inventory(
    unmatched_up: str = "0",
    unmatched_down: str = "0",
    matched_pairs: str = "0",
) -> InventorySummary:
    return InventorySummary(
        unmatched_up=Shares(Decimal(unmatched_up)),
        unmatched_down=Shares(Decimal(unmatched_down)),
        matched_pairs=Shares(Decimal(matched_pairs)),
    )
