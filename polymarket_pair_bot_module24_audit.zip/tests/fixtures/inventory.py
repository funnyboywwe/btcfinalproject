"""Fixtures for inventory accounting tests (architecture item 12).

Provides fill builders and in-memory fakes for the inventory service:

* :class:`FakeInventoryRepository` -- in-memory latest-snapshot store.
* :class:`FakeUnitOfWork` / :class:`FakeUnitOfWorkFactory` -- transactional
  fake that enforces fill-id idempotency exactly like the real unit of work.
* :class:`FakeMarketFillJournal` -- returns a fixed fill list for rebuilds.

No networking, no SQLAlchemy, no secrets. Markets and books reuse the shared
execution fixtures.
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal
from types import TracebackType

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    ExchangeOrder,
    Fill,
    InventorySnapshot,
)
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus
from polymarket_pair_bot.domain.value_objects import (
    FeeAmount,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)
from tests.fixtures.execution import (  # re-exported for convenience
    CONDITION,
    DOWN,
    MARKET,
    OPEN_S,
    TICK,
    UP,
    make_book,
    make_market,
)

__all__ = [
    "CONDITION",
    "DOWN",
    "FakeInventoryRepository",
    "FakeMarketFillJournal",
    "FakeUnitOfWork",
    "FakeUnitOfWorkFactory",
    "MARKET",
    "OPEN_S",
    "TICK",
    "UP",
    "make_book",
    "make_fill",
    "make_market",
    "make_order",
]


def make_fill(
    fill_id: str,
    token: TokenId,
    *,
    price: str,
    size: str,
    fee: str = "0",
    filled_at: int = OPEN_S,
    side: OrderSide = OrderSide.BUY,
    order_id: str | None = None,
) -> Fill:
    """Build a confirmed fill with Decimal-safe values."""
    return Fill(
        fill_id=FillId(fill_id),
        order_id=OrderId(order_id or f"o-{fill_id}"),
        token_id=token,
        side=side,
        price=ProbabilityPrice(Decimal(price)),
        size=Shares(Decimal(size)),
        fee=FeeAmount(Decimal(fee)),
        filled_at=UnixTimestamp(filled_at),
    )


def make_order(
    order_id: str,
    token: TokenId,
    *,
    side: OrderSide = OrderSide.BUY,
    limit_price: str,
    original_size: str,
    filled_size: str = "0",
    status: OrderStatus = OrderStatus.OPEN,
) -> ExchangeOrder:
    """Build an exchange order for pending-reserve tests."""
    return ExchangeOrder(
        order_id=OrderId(order_id),
        intent_id=f"i-{order_id}",
        token_id=token,
        side=side,
        limit_price=ProbabilityPrice(Decimal(limit_price)),
        original_size=Shares(Decimal(original_size)),
        filled_size=Shares(Decimal(filled_size)),
        status=status,
        created_at=UnixTimestamp(OPEN_S),
        updated_at=UnixTimestamp(OPEN_S),
    )


class FakeInventoryRepository:
    """In-memory latest-snapshot store keyed by market id."""

    def __init__(self) -> None:
        self._latest: dict[str, InventorySnapshot] = {}
        self.append_calls = 0

    async def append_snapshot(self, snapshot: InventorySnapshot) -> int:
        self.append_calls += 1
        self._latest[snapshot.market_id.value] = snapshot
        return self.append_calls

    async def get_latest(self, market_id: str) -> InventorySnapshot | None:
        return self._latest.get(market_id)


class _FakeMarketRepository:
    def __init__(self, market: BinaryMarket | None) -> None:
        self._market = market

    async def get_market(self, market_id: MarketId) -> BinaryMarket | None:
        if self._market is None:
            return None
        return self._market if self._market.market_id == market_id else None


class _FakeOrderRepository:
    def __init__(self, orders: Sequence[ExchangeOrder]) -> None:
        self._orders = list(orders)

    async def list_open(self, market_id: MarketId) -> Sequence[ExchangeOrder]:
        return [o for o in self._orders if not o.status.is_terminal]


class FakeUnitOfWork:
    """In-memory unit of work enforcing fill-id idempotency.

    Only the members the inventory service and CLI touch are implemented
    (``inventory``, ``markets``, ``orders``, ``record_fill_and_update_inventory``,
    ``commit``/``rollback`` and the async context protocol). Recording a
    previously-seen fill id returns ``False`` and leaves inventory untouched,
    mirroring the real transactional guarantee.
    """

    def __init__(
        self,
        inventory: FakeInventoryRepository,
        seen_fill_ids: set[str],
        market: BinaryMarket | None,
        orders: Sequence[ExchangeOrder],
    ) -> None:
        self.inventory = inventory
        self.markets = _FakeMarketRepository(market)
        self.orders = _FakeOrderRepository(orders)
        self._seen = seen_fill_ids
        self.commits = 0
        self.rollbacks = 0
        self._pending: InventorySnapshot | None = None

    async def __aenter__(self) -> FakeUnitOfWork:
        self._pending = None
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> bool | None:
        if exc_type is not None:
            await self.rollback()
        return None

    async def record_fill_and_update_inventory(
        self,
        fill: Fill,
        resulting_inventory: InventorySnapshot,
        order: ExchangeOrder | None = None,
    ) -> bool:
        if fill.fill_id.value in self._seen:
            return False
        self._seen.add(fill.fill_id.value)
        await self.inventory.append_snapshot(resulting_inventory)
        return True

    async def commit(self) -> None:
        self.commits += 1

    async def rollback(self) -> None:
        self.rollbacks += 1


class FakeUnitOfWorkFactory:
    """Opens fresh :class:`FakeUnitOfWork` instances sharing durable state."""

    def __init__(
        self,
        *,
        market: BinaryMarket | None = None,
        orders: Sequence[ExchangeOrder] = (),
    ) -> None:
        self.inventory = FakeInventoryRepository()
        self.seen_fill_ids: set[str] = set()
        self._market = market
        self._orders = list(orders)
        self.opened = 0

    def __call__(self) -> FakeUnitOfWork:
        self.opened += 1
        return FakeUnitOfWork(
            self.inventory, self.seen_fill_ids, self._market, self._orders
        )


class FakeMarketFillJournal:
    """Return a fixed list of fills for rebuild/verify tests."""

    def __init__(self, fills: Sequence[Fill]) -> None:
        self._fills = list(fills)

    async def list_market_fills(self, market: BinaryMarket) -> Sequence[Fill]:
        tokens = {market.up_token.token_id, market.down_token.token_id}
        return [f for f in self._fills if f.token_id in tokens]
