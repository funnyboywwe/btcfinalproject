"""Reusable Gamma ``/markets`` response fixtures for market-discovery tests.

Every value here is synthetic. No real market, token id, condition id, wallet,
or secret appears. Token ids are synthetic base-10 unsigned integers (matching
the domain ``TokenId`` shape); the condition id is a synthetic bytes32 hex.
"""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any

# Aligned 5-minute window used across tests: 2025-01-01T00:00:00Z .. 00:05:00Z.
WINDOW_OPEN_EPOCH = 1_735_689_600
WINDOW_CLOSE_EPOCH = 1_735_689_900
WINDOW_OPEN_ISO = "2025-01-01T00:00:00Z"
WINDOW_CLOSE_ISO = "2025-01-01T00:05:00Z"

NEXT_OPEN_EPOCH = 1_735_689_900
NEXT_CLOSE_EPOCH = 1_735_690_200
NEXT_OPEN_ISO = "2025-01-01T00:05:00Z"
NEXT_CLOSE_ISO = "2025-01-01T00:10:00Z"

CONDITION_ID = "0x" + "ab" * 32
UP_TOKEN_ID = "100000000000000000000000000000000000000000000000000000000000000001"
DOWN_TOKEN_ID = "200000000000000000000000000000000000000000000000000000000000000002"


def valid_market(
    *,
    encode_arrays: bool = True,
    start_iso: str = WINDOW_OPEN_ISO,
    end_iso: str = WINDOW_CLOSE_ISO,
    slug: str = "btc-updown-2025-01-01-0000",
    market_id: str = "512345",
) -> dict[str, Any]:
    """A well-formed BTC Up/Down market matching the standard test window.

    ``clobTokenIds`` / ``outcomes`` are JSON-encoded strings by default (as the
    live Gamma API returns them); pass ``encode_arrays=False`` for plain lists.
    """
    outcomes = ["Up", "Down"]
    tokens = [UP_TOKEN_ID, DOWN_TOKEN_ID]
    return {
        "id": market_id,
        "slug": slug,
        "conditionId": CONDITION_ID,
        "clobTokenIds": json.dumps(tokens) if encode_arrays else tokens,
        "outcomes": json.dumps(outcomes) if encode_arrays else outcomes,
        "active": True,
        "closed": False,
        "enableOrderBook": True,
        "negRisk": False,
        "startDate": start_iso,
        "endDate": end_iso,
        "orderPriceMinTickSize": "0.001",
        "orderMinSize": "5",
        "resolutionSource": "synthetic-test-source",
        # An undocumented/extra field must be ignored, never consumed.
        "someUndocumentedField": "ignore-me",
    }


def next_window_market() -> dict[str, Any]:
    """A valid market aligned to the *next* 5-minute window."""
    return valid_market(
        start_iso=NEXT_OPEN_ISO,
        end_iso=NEXT_CLOSE_ISO,
        slug="btc-updown-2025-01-01-0005",
        market_id="512346",
    )


def closed_market() -> dict[str, Any]:
    market = valid_market()
    market["active"] = False
    market["closed"] = True
    market["enableOrderBook"] = False
    return market


def reversed_outcomes_market() -> dict[str, Any]:
    """Outcomes/tokens listed Down-first to exercise name-based mapping."""
    market = valid_market(encode_arrays=False)
    market["outcomes"] = ["Down", "Up"]
    market["clobTokenIds"] = [DOWN_TOKEN_ID, UP_TOKEN_ID]
    return market


def missing_token_market() -> dict[str, Any]:
    market = valid_market(encode_arrays=False)
    market["clobTokenIds"] = [UP_TOKEN_ID]  # only one token id
    return market


def invalid_timestamps_market() -> dict[str, Any]:
    market = valid_market()
    # close before open
    market["startDate"] = WINDOW_CLOSE_ISO
    market["endDate"] = WINDOW_OPEN_ISO
    return market


def missing_condition_id_market() -> dict[str, Any]:
    market = valid_market()
    del market["conditionId"]
    return market


def contradictory_active_closed_market() -> dict[str, Any]:
    market = valid_market()
    market["active"] = True
    market["closed"] = True
    return market


def clone(market: dict[str, Any]) -> dict[str, Any]:
    return deepcopy(market)


__all__ = [
    "CONDITION_ID",
    "DOWN_TOKEN_ID",
    "NEXT_CLOSE_EPOCH",
    "NEXT_OPEN_EPOCH",
    "UP_TOKEN_ID",
    "WINDOW_CLOSE_EPOCH",
    "WINDOW_OPEN_EPOCH",
    "clone",
    "closed_market",
    "contradictory_active_closed_market",
    "invalid_timestamps_market",
    "missing_condition_id_market",
    "missing_token_market",
    "next_window_market",
    "reversed_outcomes_market",
    "valid_market",
]
