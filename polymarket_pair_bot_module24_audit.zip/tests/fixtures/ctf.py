"""In-memory fakes for CTF-operation tests (Module 17).

Every fake is infrastructure-free and implements the ctf ports / domain
protocols so the :class:`CtfOperationService` can be exercised without web3,
eth-account, PostgreSQL or a network. No test ever signs or broadcasts a real
transaction: the fake chain writer returns a deterministic fake hash.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

from polymarket_pair_bot.blockchain.errors import ReceiptTimeoutError
from polymarket_pair_bot.blockchain.models import (
    ChainIdentity,
    GasEstimate,
    SimulationResult,
    TokenAmount,
    TransactionOutcome,
    TransactionStatus,
)
from polymarket_pair_bot.ctf.errors import GaslessUnavailableError
from polymarket_pair_bot.ctf.models import (
    CtfContracts,
    OutcomeMapping,
    UnsignedCtfTransaction,
)
from polymarket_pair_bot.domain.entities import CtfOperation, RiskDecision
from polymarket_pair_bot.domain.enums import RiskVerdict
from polymarket_pair_bot.domain.value_objects import Shares, UnixTimestamp

WALLET = "0x" + "11" * 20
USDC = "0x" + "22" * 20
CTF = "0x" + "33" * 20
UP_TOKEN = "1001"
DOWN_TOKEN = "1002"
CONDITION_ID = "0x" + "ab" * 32
DECIMALS = 6


def make_contracts() -> CtfContracts:
    return CtfContracts(
        conditional_tokens=CTF, collateral=USDC, collateral_decimals=DECIMALS
    )


def make_mapping(**overrides: Any) -> OutcomeMapping:
    base: dict[str, Any] = dict(
        up_index_set=1, down_index_set=2, parent_collection="0x" + "00" * 32
    )
    base.update(overrides)
    return OutcomeMapping(**base)


def _token(amount: str) -> TokenAmount:
    dec = Decimal(amount)
    base_units = int(dec * (Decimal(10) ** DECIMALS))
    return TokenAmount(base_units=base_units, decimals=DECIMALS, amount=dec)


def make_risk_decision(operation_id: str, *, approve: bool = True) -> RiskDecision:
    verdict = RiskVerdict.APPROVE if approve else RiskVerdict.REJECT
    size = Shares(Decimal("5")) if approve else Shares(Decimal(0))
    return RiskDecision(
        decision_id=operation_id,
        verdict=verdict,
        reason="test",
        decided_at=UnixTimestamp(1_000_000),
        approved_size=size,
    )


class FakeChainStateReader:
    """An in-memory :class:`ChainStateReader`."""

    def __init__(
        self,
        *,
        chain_id: int = 137,
        balances: dict[str, str] | None = None,
        collateral: str = "100",
        allowance: str = "0",
        nonce: int = 7,
        simulate_ok: bool = True,
        revert_reason: str | None = None,
        receipt_status: TransactionStatus = TransactionStatus.SUCCESS,
        raise_receipt_timeout: bool = False,
    ) -> None:
        self._chain_id = chain_id
        self._balances = dict(balances or {})
        self._collateral = collateral
        self._allowance = allowance
        self._nonce = nonce
        self._simulate_ok = simulate_ok
        self._revert_reason = revert_reason
        self._receipt_status = receipt_status
        self._raise_receipt_timeout = raise_receipt_timeout
        self.calls: list[str] = []

    async def verify_chain_id(self) -> ChainIdentity:
        self.calls.append("verify_chain_id")
        return ChainIdentity(chain_id=self._chain_id, primary=self._chain_id)

    async def get_collateral_balance(self) -> TokenAmount:
        return _token(self._collateral)

    async def get_token_balance(self, token_id: str) -> TokenAmount:
        return _token(self._balances.get(token_id, "0"))

    async def get_allowance(
        self, *, spender: str, token_address: str | None = None
    ) -> TokenAmount:
        return _token(self._allowance)

    async def get_nonce(self, *, pending: bool = False) -> int:
        self.calls.append("get_nonce")
        return self._nonce

    async def simulate(
        self, *, to: str, data: str, block: str = "latest"
    ) -> SimulationResult:
        self.calls.append("simulate")
        return SimulationResult(
            success=self._simulate_ok, revert_reason=self._revert_reason
        )

    async def estimate_gas(
        self, *, to: str, data: str, value: int = 0, sender: str | None = None
    ) -> GasEstimate:
        return GasEstimate(
            gas_limit=100_000,
            buffered_gas_limit=120_000,
            gas_price_wei=1_000_000_000,
            max_cost_wei=120_000_000_000_000,
            max_cost_native=Decimal("0.00012"),
        )

    async def wait_for_receipt(
        self,
        tx_hash: str,
        *,
        expected_nonce: int | None = None,
        timeout_seconds: float | None = None,
        poll_interval_seconds: float | None = None,
    ) -> TransactionOutcome:
        self.calls.append("wait_for_receipt")
        if self._raise_receipt_timeout:
            raise ReceiptTimeoutError("receipt timed out")
        return TransactionOutcome(
            tx_hash=tx_hash,
            status=self._receipt_status,
            block_number=42,
            gas_used=90_000,
            confirmations=3,
            detail="ok",
        )

    async def get_transaction_status(
        self, tx_hash: str, *, expected_nonce: int | None = None
    ) -> TransactionOutcome:
        return TransactionOutcome(tx_hash=tx_hash, status=self._receipt_status)


class FakeCtfTransactionPreparer:
    """Returns deterministic unsigned calldata without touching keccak/web3."""

    def __init__(self) -> None:
        self.prepared: list[str] = []

    async def prepare_split(
        self, *, condition_id: str, partition: tuple[int, ...], amount_base_units: int
    ) -> UnsignedCtfTransaction:
        self.prepared.append("split")
        return UnsignedCtfTransaction(
            to=CTF, data="0xdead", value=0, description="split"
        )

    async def prepare_merge(
        self, *, condition_id: str, partition: tuple[int, ...], amount_base_units: int
    ) -> UnsignedCtfTransaction:
        self.prepared.append("merge")
        return UnsignedCtfTransaction(
            to=CTF, data="0xbeef", value=0, description="merge"
        )

    async def prepare_redeem(
        self, *, condition_id: str, index_sets: tuple[int, ...]
    ) -> UnsignedCtfTransaction:
        self.prepared.append("redeem")
        return UnsignedCtfTransaction(
            to=CTF, data="0xfeed", value=0, description="redeem"
        )

    async def prepare_erc20_approval(
        self, *, token_address: str, spender: str, amount_base_units: int
    ) -> UnsignedCtfTransaction:
        self.prepared.append("approve")
        return UnsignedCtfTransaction(
            to=token_address, data="0x0a", value=0, description="approve"
        )


class FakeCtfChainWriter:
    """Returns a deterministic fake tx hash; never signs/broadcasts anything."""

    def __init__(self, *, tx_hash: str | None = None) -> None:
        self._tx_hash = tx_hash or ("0x" + "cd" * 32)
        self.calls: list[dict[str, Any]] = []

    async def sign_and_broadcast(
        self,
        unsigned: UnsignedCtfTransaction,
        *,
        nonce: int,
        gas_limit: int,
        max_fee_per_gas_wei: int,
        max_priority_fee_per_gas_wei: int,
    ) -> str:
        self.calls.append(
            {"to": unsigned.to, "nonce": nonce, "gas_limit": gas_limit}
        )
        return self._tx_hash


class FakeGaslessRelayer:
    def __init__(self, *, available: bool = False, tx_hash: str | None = None) -> None:
        self._available = available
        self._tx_hash = tx_hash or ("0x" + "ef" * 32)
        self.calls: list[str] = []

    @property
    def available(self) -> bool:
        return self._available

    async def relay(
        self, unsigned: UnsignedCtfTransaction, *, operation_id: str
    ) -> str:
        if not self._available:
            raise GaslessUnavailableError("no gasless credentials")
        self.calls.append(operation_id)
        return self._tx_hash


class FakeKillSwitch:
    def __init__(self, *, active: bool = False) -> None:
        self._active = active

    async def is_active(self) -> bool:
        return self._active


@dataclass
class CtfRecord:
    operations: dict[str, CtfOperation] = field(default_factory=dict)
    tx_rows: dict[str, dict[str, Any]] = field(default_factory=dict)
    audits: list[dict[str, Any]] = field(default_factory=list)
    commits: int = 0


class _FakeCtfOps:
    def __init__(self, rec: CtfRecord) -> None:
        self._rec = rec

    async def upsert(self, operation: CtfOperation) -> None:
        self._rec.operations[operation.operation_id] = operation

    async def get(self, operation_id: str) -> CtfOperation | None:
        return self._rec.operations.get(operation_id)


class _FakeBlockchain:
    def __init__(self, rec: CtfRecord) -> None:
        self._rec = rec

    async def record(
        self,
        *,
        operation_key: str,
        chain_id: int,
        status: str,
        created_at: UnixTimestamp,
        operation_id: str | None = None,
        tx_hash: str | None = None,
    ) -> bool:
        if operation_key in self._rec.tx_rows:
            return False
        self._rec.tx_rows[operation_key] = {
            "operation_key": operation_key,
            "chain_id": chain_id,
            "status": status,
            "operation_id": operation_id,
            "tx_hash": tx_hash,
        }
        return True

    async def get(self, operation_key: str) -> dict[str, Any] | None:
        return self._rec.tx_rows.get(operation_key)


class _FakeAudit:
    def __init__(self, rec: CtfRecord) -> None:
        self._rec = rec

    async def append_event(self, **kwargs: Any) -> int:
        self._rec.audits.append(kwargs)
        return len(self._rec.audits)


class FakeCtfUnitOfWork:
    def __init__(self, rec: CtfRecord) -> None:
        self._rec = rec
        self.ctf_operations = _FakeCtfOps(rec)
        self.blockchain = _FakeBlockchain(rec)
        self.audit = _FakeAudit(rec)

    async def __aenter__(self) -> "FakeCtfUnitOfWork":
        return self

    async def __aexit__(self, *exc: object) -> None:
        return None

    async def commit(self) -> None:
        self._rec.commits += 1


class FakeCtfUnitOfWorkFactory:
    def __init__(self) -> None:
        self.recorded = CtfRecord()

    def __call__(self) -> FakeCtfUnitOfWork:
        return FakeCtfUnitOfWork(self.recorded)


__all__ = [
    "CONDITION_ID",
    "CTF",
    "DOWN_TOKEN",
    "UP_TOKEN",
    "USDC",
    "WALLET",
    "CtfRecord",
    "FakeChainStateReader",
    "FakeCtfChainWriter",
    "FakeCtfTransactionPreparer",
    "FakeCtfUnitOfWork",
    "FakeCtfUnitOfWorkFactory",
    "FakeGaslessRelayer",
    "FakeKillSwitch",
    "make_contracts",
    "make_mapping",
    "make_risk_decision",
]
