"""Deterministic fakes for orchestrator (Module 19) tests.

Everything here is in-memory and side-effect free (no network, no wallet, no
real orders). A single shared ordered ``call_log`` lets tests assert the exact
graceful-shutdown and degraded-mode sequencing.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from dataclasses import dataclass, field

from polymarket_pair_bot.domain.entities import BinaryMarket, ReconciliationResult
from polymarket_pair_bot.domain.enums import ReconciliationStatus
from polymarket_pair_bot.domain.value_objects import MarketId, UnixTimestamp
from polymarket_pair_bot.orchestrator.ports import EventSink
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.shared.health import HealthCheckResult
from polymarket_pair_bot.strategy.session_events import SessionEvent
from polymarket_pair_bot.strategy.session_models import (
    PairSessionSnapshot,
    SessionState,
    TransitionOutcome,
)

from tests.fixtures.state_machine import make_market


class FakeClock:
    """Deterministic monotonic clock."""

    def __init__(self, start: int = 1_000) -> None:
        self._value = start

    def now(self) -> UnixTimestamp:
        return UnixTimestamp(self._value)

    def advance(self, seconds: int) -> None:
        self._value += seconds


class FakeMetrics:
    """Records metric calls; never raises."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, str, float]] = []

    def incr(self, name: str, value: float = 1.0, **labels: str) -> None:
        self.calls.append(("incr", name, value))

    def gauge(self, name: str, value: float, **labels: str) -> None:
        self.calls.append(("gauge", name, value))

    def observe(self, name: str, value: float, **labels: str) -> None:
        self.calls.append(("observe", name, value))

    def names(self) -> list[str]:
        return [name for _kind, name, _v in self.calls]


class FakeDiscovery:
    """Returns a validated market, or ``None`` to simulate no market."""

    def __init__(self, market: BinaryMarket | None) -> None:
        self._market = market
        self.calls = 0

    async def discover(self) -> BinaryMarket | None:
        self.calls += 1
        return self._market


class RecordingExecutionControl:
    """Local execution gate + safe cancellation, fully recorded.

    ``cancel_open_orders`` is deliberately independent of any kill switch, per
    the safety rule that resting-order cancellation must always remain possible.
    """

    def __init__(self, call_log: list[str], *, open_orders: int = 2) -> None:
        self._log = call_log
        self._blocked = False
        self._open = open_orders
        self.block_reasons: list[str] = []
        self.cancel_calls = 0

    @property
    def new_orders_blocked(self) -> bool:
        return self._blocked

    async def block_new_orders(self, reason: str) -> None:
        self._blocked = True
        self.block_reasons.append(reason)
        self._log.append("block_new_orders")

    async def allow_new_orders(self) -> None:
        self._blocked = False
        self._log.append("allow_new_orders")

    async def cancel_open_orders(self, market_id: MarketId | None = None) -> int:
        self.cancel_calls += 1
        cancelled = self._open
        self._open = 0
        self._log.append("cancel_open_orders")
        return cancelled


class RecordingReconciler:
    """Returns a consistent/inconsistent result; records every trigger."""

    def __init__(
        self,
        call_log: list[str],
        *,
        consistent: bool = True,
        raises: bool = False,
    ) -> None:
        self._log = call_log
        self._consistent = consistent
        self._raises = raises
        self.triggers: list[ReconciliationTrigger] = []

    async def reconcile(self, trigger: ReconciliationTrigger) -> ReconciliationResult:
        self.triggers.append(trigger)
        self._log.append(f"reconcile:{trigger.value}")
        if self._raises:
            raise RuntimeError("reconcile boom")
        status = (
            ReconciliationStatus.CONSISTENT
            if self._consistent
            else ReconciliationStatus.DISCREPANCY
        )
        discrepancies = () if self._consistent else ("unmatched inventory",)
        return ReconciliationResult(
            status=status,
            as_of=UnixTimestamp(1_000),
            discrepancies=discrepancies,
        )


class FakeKillSwitch:
    """Read-only kill-switch view; can be toggled or made unreadable."""

    def __init__(self, *, active: bool = False, unreadable: bool = False) -> None:
        self._active = active
        self._unreadable = unreadable

    async def is_active(self) -> bool:
        if self._unreadable:
            raise RuntimeError("redis down")
        return self._active


class RecordingPersistence:
    def __init__(self, call_log: list[str]) -> None:
        self._log = call_log
        self.flushes = 0

    async def flush(self) -> None:
        self.flushes += 1
        self._log.append("flush")


class RecordingResource:
    """A named closable (stands in for a WebSocket, DB engine or Redis)."""

    def __init__(self, name: str, call_log: list[str]) -> None:
        self._name = name
        self._log = call_log
        self.closed = 0

    @property
    def name(self) -> str:
        return self._name

    async def aclose(self) -> None:
        self.closed += 1
        self._log.append(f"aclose:{self._name}")


class ScriptedProducer:
    """Emits a fixed event list then finishes, or fails, or runs forever.

    * ``fail_after`` > 0 raises after emitting that many events (failure test).
    * ``block_forever`` keeps running until cancelled (continuous producer).
    """

    def __init__(
        self,
        name: str,
        events: Sequence[SessionEvent],
        *,
        critical: bool = True,
        fail_after: int | None = None,
        block_forever: bool = False,
        call_log: list[str] | None = None,
    ) -> None:
        self._name = name
        self._events = list(events)
        self._critical = critical
        self._fail_after = fail_after
        self._block_forever = block_forever
        self._log = call_log if call_log is not None else []
        self.closed = 0

    @property
    def name(self) -> str:
        return self._name

    @property
    def critical(self) -> bool:
        return self._critical

    async def run(self, sink: EventSink) -> None:
        for index, event in enumerate(self._events):
            if self._fail_after is not None and index >= self._fail_after:
                raise RuntimeError(f"producer {self._name} failed")
            await sink.emit(event)
        if self._fail_after is not None and self._fail_after <= len(self._events):
            raise RuntimeError(f"producer {self._name} failed")
        if self._block_forever:
            await asyncio.Event().wait()

    async def aclose(self) -> None:
        self.closed += 1
        self._log.append(f"aclose:{self._name}")


class FakeFreshnessSource:
    """Reports staleness age; used by the freshness watchdog test."""

    def __init__(self, name: str, age: float | None) -> None:
        self._name = name
        self._age = age

    @property
    def name(self) -> str:
        return self._name

    def set_age(self, age: float | None) -> None:
        self._age = age

    def seconds_since_data(self, now: UnixTimestamp) -> float | None:
        return self._age


class FakeDependencyCheck:
    def __init__(self, name: str, *, healthy: bool) -> None:
        self._name = name
        self._healthy = healthy

    @property
    def name(self) -> str:
        return self._name

    async def check(self) -> HealthCheckResult:
        return HealthCheckResult(healthy=self._healthy, detail="probe")


@dataclass(slots=True)
class FakeMachine:
    """Records processed events; returns programmed states in order.

    ``restore`` records the restore call (restart requirement). ``process``
    de-duplicates by ``event_id`` to mirror the real machine's idempotency, and
    returns a :class:`TransitionOutcome` whose state comes from ``script`` (by
    event type) or ``default_state``.
    """

    market: BinaryMarket
    default_state: SessionState = SessionState.READY
    script: dict[str, SessionState] = field(default_factory=dict)
    processed: list[SessionEvent] = field(default_factory=list)
    seen_ids: set[str] = field(default_factory=set)
    restored: list[MarketId] = field(default_factory=list)

    async def restore(self, market_id: MarketId) -> PairSessionSnapshot | None:
        self.restored.append(market_id)
        return None

    async def process(self, event: SessionEvent) -> TransitionOutcome:
        replay = event.event_id in self.seen_ids
        if not replay:
            self.seen_ids.add(event.event_id)
            self.processed.append(event)
        state = self.script.get(type(event).__name__, self.default_state)
        snapshot = PairSessionSnapshot(
            market_id=self.market.market_id, state=state
        )
        return TransitionOutcome(
            market_id=self.market.market_id,
            previous_state=SessionState.DISCOVERED,
            snapshot=snapshot,
            transition=None,
            idempotent_replay=replay,
        )


__all__ = [
    "FakeClock",
    "FakeDependencyCheck",
    "FakeDiscovery",
    "FakeFreshnessSource",
    "FakeKillSwitch",
    "FakeMachine",
    "FakeMetrics",
    "RecordingExecutionControl",
    "RecordingPersistence",
    "RecordingReconciler",
    "RecordingResource",
    "ScriptedProducer",
    "make_market",
]
