"""Replay tests over recorded market data (added with the recorder module)."""
