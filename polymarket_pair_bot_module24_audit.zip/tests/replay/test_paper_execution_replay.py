"""Replay tests for the paper execution adapter (Module 11).

Drives the simulator with a recorded sequence of book snapshots and trade
prints and asserts a fully reproducible outcome. Recorded replays are the
closest deterministic proxy we have for realistic execution without touching
any network.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.enums import OrderStatus, TimeInForce
from polymarket_pair_bot.domain.value_objects import BasisPoints, OrderId
from polymarket_pair_bot.execution import (
    LatencyDistribution,
    MarketEvent,
    PaperExecutionConfig,
)
from tests.fixtures.execution import (
    UP,
    make_adapter,
    make_event,
    make_intent,
    make_trade,
)


def _recorded_up_book_session() -> tuple[MarketEvent, ...]:
    """A short recorded Up-token session: book drifts down with trade prints."""
    return (
        make_event(
            "r0",
            ts_ms=0,
            bids=(("0.46", "40"), ("0.45", "80")),
            asks=(("0.48", "60"), ("0.49", "120")),
        ),
        make_event(
            "r1",
            ts_ms=250,
            bids=(("0.46", "10"), ("0.45", "80")),
            asks=(("0.47", "30"), ("0.48", "60")),
            trades=(make_trade("rt1", price="0.46", size="30"),),
        ),
        make_event(
            "r2",
            ts_ms=500,
            bids=(("0.45", "50"),),
            asks=(("0.46", "40"), ("0.47", "30")),
            trades=(
                make_trade("rt2", price="0.45", size="20"),
                make_trade("rt3", price="0.45", size="25"),
            ),
        ),
    )


async def _replay(
    config: PaperExecutionConfig,
) -> tuple[OrderStatus, Decimal, list[tuple[Decimal, Decimal]]]:
    adapter, _ = make_adapter(config=config)
    session = _recorded_up_book_session()
    # Apply the opening snapshot, then rest a passive maker buy at 0.45.
    await adapter.apply_market_event(session[0])
    await adapter.submit_order(
        make_intent("m1", token=UP, price="0.45", size="30", tif=TimeInForce.GTC)
    )
    # Replay the remaining recorded events in order.
    for event in session[1:]:
        await adapter.apply_market_event(event)
    await adapter.advance_to(1000)
    order = await adapter.get_order(OrderId("paper-m1"))
    assert order is not None
    fills = await adapter.get_fills(order_id=OrderId("paper-m1"))
    return (
        order.status,
        order.filled_size.value,
        [(f.price.value, f.size.value) for f in fills],
    )


def _cfg() -> PaperExecutionConfig:
    return PaperExecutionConfig(
        seed=123,
        taker_fee_bps=BasisPoints(Decimal("0")),
        maker_fee_bps=BasisPoints(Decimal("0")),
        ack_latency=LatencyDistribution.constant(100),
        cancel_latency=LatencyDistribution.constant(100),
    )


async def test_replay_is_deterministic() -> None:
    first = await _replay(_cfg())
    second = await _replay(_cfg())
    assert first == second


async def test_replay_maker_fills_from_queue_and_trades() -> None:
    status, filled, fills = await _replay(_cfg())
    # Queue ahead at 0.45 on join = 80. Trades reaching <= 0.45 across the
    # session: rt2 (20) + rt3 (25) = 45, all consumed by the 80-share queue, so
    # nothing reaches our order -> no fill despite the price trading at 0.45.
    assert filled == Decimal(0)
    assert fills == []
    assert status is OrderStatus.OPEN


async def test_replay_taker_through_recorded_levels() -> None:
    # An IOC taker submitted at the opening book walks recorded ask levels.
    adapter, _ = make_adapter(config=_cfg())
    session = _recorded_up_book_session()
    await adapter.apply_market_event(session[0])
    await adapter.submit_order(
        make_intent("t1", token=UP, price="0.49", size="90", tif=TimeInForce.IOC)
    )
    await adapter.advance_to(100)  # taker executes against the opening book
    order = await adapter.get_order(OrderId("paper-t1"))
    assert order is not None and order.status is OrderStatus.FILLED
    fills = await adapter.get_fills(order_id=OrderId("paper-t1"))
    # 60 @ 0.48 then 30 @ 0.49.
    assert [(f.price.value, f.size.value) for f in fills] == [
        (Decimal("0.48"), Decimal("60")),
        (Decimal("0.49"), Decimal("30")),
    ]


async def test_replay_fills_when_queue_is_small() -> None:
    # Same recording, but rest at 0.46 where the join-queue is only 40; the
    # 30-share rt1 print at 0.46 consumes queue, and later movement leaves a
    # partial. This exercises real trade-driven maker fills deterministically.
    adapter, _ = make_adapter(config=_cfg())
    session = _recorded_up_book_session()
    await adapter.apply_market_event(session[0])
    await adapter.submit_order(
        make_intent("m2", token=UP, price="0.46", size="30", tif=TimeInForce.GTC)
    )
    for event in session[1:]:
        await adapter.apply_market_event(event)
    await adapter.advance_to(1000)
    order = await adapter.get_order(OrderId("paper-m2"))
    assert order is not None
    # Join queue at 0.46 = 40. rt1 = 30 (all queue). rt2+rt3 = 45 @ 0.45 (<=
    # 0.46) -> 10 finishes the queue, 35 available, order needs 30 -> FILLED.
    assert order.status is OrderStatus.FILLED
    assert order.filled_size.value == Decimal(30)
