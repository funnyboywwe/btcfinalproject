"""Deterministic replay tests for the market-data pipeline (Module 6).

A scripted, fixed sequence of frames is replayed through the manager (via the
same parse -> apply path the feed uses) and the resulting book state / quotes
are asserted exactly. No timing, no networking: fully deterministic.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.market_data import FeedStatus
from polymarket_pair_bot.domain.value_objects import TokenId
from polymarket_pair_bot.market_data.manager import OrderBookManager
from polymarket_pair_bot.market_data.messages import parse_frame
from tests.fixtures.market_data import (
    DOWN_TOKEN,
    UP_TOKEN,
    ManualClock,
    book_message,
    price_change_message,
    tick_size_message,
    trade_message,
)

# A fixed script exercised by the replay: snapshots for both sides, then a
# series of incremental changes, a tick-size event, and a trade print.
SCRIPT: list[dict] = [
    book_message(UP_TOKEN, bids=[("0.40", "100"), ("0.39", "50")], asks=[("0.60", "80")]),
    book_message(DOWN_TOKEN, bids=[("0.55", "70")], asks=[("0.61", "40")]),
    price_change_message(UP_TOKEN, changes=[("0.41", "BUY", "25")]),
    price_change_message(UP_TOKEN, changes=[("0.39", "BUY", "0")]),  # remove level
    price_change_message(UP_TOKEN, changes=[("0.60", "SELL", "90")]),  # resize ask
    tick_size_message(UP_TOKEN, new="0.001"),
    trade_message(UP_TOKEN, price="0.50", size="5"),
    price_change_message(DOWN_TOKEN, changes=[("0.56", "BUY", "10")]),
]


def _replay(manager: OrderBookManager, script: list[dict]) -> None:
    manager.mark_connected()
    for frame in script:
        parsed = parse_frame(frame)
        if parsed.message is not None:
            manager.apply_message(parsed.message)  # type: ignore[arg-type]


def test_deterministic_replay_final_state() -> None:
    clock = ManualClock(start=500.0)
    wall = iter(range(1, 1000))
    manager = OrderBookManager(
        TokenId(UP_TOKEN),
        TokenId(DOWN_TOKEN),
        stale_after_seconds=30.0,
        monotonic=clock,
        wall_clock=lambda: next(wall),
    )
    _replay(manager, SCRIPT)

    up = manager.quote(OutcomeSide.UP)
    assert up.status is FeedStatus.LIVE
    assert up.best_bid is not None and up.best_bid.value == Decimal("0.41")
    assert up.best_ask is not None and up.best_ask.value == Decimal("0.60")
    # 0.39 level removed; 0.40 and 0.41 remain.
    assert up.bid_levels == 2
    assert up.bid_depth.value == Decimal("125")  # 100 + 25
    assert up.ask_depth.value == Decimal("90")  # resized 80 -> 90
    assert manager.tick_size(OutcomeSide.UP) == Decimal("0.001")
    assert manager.last_trade_price(OutcomeSide.UP) == Decimal("0.50")

    down = manager.quote(OutcomeSide.DOWN)
    assert down.status is FeedStatus.LIVE
    assert down.best_bid is not None and down.best_bid.value == Decimal("0.56")
    assert down.bid_depth.value == Decimal("80")  # 70 + 10


def test_replay_is_repeatable() -> None:
    def run() -> tuple[Decimal, Decimal]:
        clock = ManualClock(start=500.0)
        wall = iter(range(1, 1000))
        manager = OrderBookManager(
            TokenId(UP_TOKEN),
            TokenId(DOWN_TOKEN),
            stale_after_seconds=30.0,
            monotonic=clock,
            wall_clock=lambda: next(wall),
        )
        _replay(manager, SCRIPT)
        up = manager.quote(OutcomeSide.UP)
        down = manager.quote(OutcomeSide.DOWN)
        assert up.best_bid is not None and down.best_bid is not None
        return up.best_bid.value, down.best_bid.value

    assert run() == run()
