"""Look-ahead and determinism proofs for the replay harness (Module 22).

Requirement 6/7: future events must not be able to influence earlier decisions,
and a seeded run must be exactly reproducible. These tests replay real
recordings through the SAME detector, risk engine, state machine, inventory
accounting and paper execution interface used in production. No orders or
network calls occur.
"""

from __future__ import annotations

from polymarket_pair_bot.backtest.harness import BacktestEngine
from polymarket_pair_bot.backtest.models import BacktestRunConfig
from polymarket_pair_bot.config.settings import AppConfig
from tests.fixtures.backtest import (
    default_snapshots,
    make_recording,
    make_snapshot,
)

_PREFIX = 4


def _engine(*, max_snapshots: int = 0, seed: int = 0) -> BacktestEngine:
    run_config = BacktestRunConfig(
        seed=seed,
        label="lookahead-test",
        max_snapshots_per_window=max_snapshots,
    )
    return BacktestEngine(config=AppConfig(), run_config=run_config)


async def test_future_snapshots_cannot_change_earlier_decisions() -> None:
    """Two recordings that share the first ``_PREFIX`` snapshots but diverge
    afterwards must produce identical results when only the shared prefix is
    replayed. If any later snapshot leaked backwards, the two capped runs would
    differ.
    """
    shared = default_snapshots(count=_PREFIX)
    # Adversarial, wildly different futures appended after the shared prefix.
    tail_a = tuple(
        make_snapshot(sequence=_PREFIX + i, epoch=1_000_100 + i, up_ask="0.10", down_ask="0.10")
        for i in range(4)
    )
    tail_b = tuple(
        make_snapshot(
            sequence=_PREFIX + i,
            epoch=1_000_100 + i,
            up_ask="0.99",
            down_ask="0.99",
            up_live=(i % 2 == 0),
        )
        for i in range(4)
    )
    recording_a = make_recording(snapshots=shared + tail_a)
    recording_b = make_recording(snapshots=shared + tail_b)

    result_a = await _engine(max_snapshots=_PREFIX).run_window(recording_a)
    result_b = await _engine(max_snapshots=_PREFIX).run_window(recording_b)

    assert result_a == result_b


async def test_same_seed_same_recording_is_reproducible() -> None:
    recording = make_recording(snapshots=default_snapshots(count=8))
    source_first = _StubOnce(recording)
    source_second = _StubOnce(recording)

    report_first = await _engine(seed=123).run(source_first)
    report_second = await _engine(seed=123).run(source_second)

    assert report_first.to_json_dict() == report_second.to_json_dict()


class _StubOnce:
    """RecordingSource yielding a single recording (fresh generator per run)."""

    def __init__(self, recording) -> None:  # noqa: ANN001 - WindowRecording
        self._recording = recording

    def windows(self):  # noqa: ANN201 - Iterator[WindowRecording]
        yield self._recording
