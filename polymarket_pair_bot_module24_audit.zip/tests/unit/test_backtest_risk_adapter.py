"""Unit tests for the backtest risk-approval adapter (Module 22).

Every order intent in a replay is gated by the SAME centralized RiskEngine used
in production (requirement 2 / global safety rule). These tests confirm the
adapter maps approval kinds and honors the engine verdict, using the real
configured limits. No orders or network calls occur.
"""

from __future__ import annotations

from polymarket_pair_bot.backtest.risk_adapter import BacktestRiskApprovalAdapter
from polymarket_pair_bot.config.settings import AppConfig
from polymarket_pair_bot.domain.value_objects import (
    MarketId,
    Shares,
    UnixTimestamp,
)
from polymarket_pair_bot.risk.engine import RiskEngine
from polymarket_pair_bot.risk.limits import RiskLimits
from polymarket_pair_bot.strategy.session_ports import (
    ApprovalKind,
    RiskApprovalRequest,
)


def _adapter() -> BacktestRiskApprovalAdapter:
    limits = RiskLimits.from_settings(AppConfig().risk)
    return BacktestRiskApprovalAdapter(RiskEngine(limits))


def _request(kind: ApprovalKind, *, size: str, seconds_to_close: int) -> RiskApprovalRequest:
    return RiskApprovalRequest(
        request_id=f"req-{kind.value}",
        kind=kind,
        market_id=MarketId("btc-5m-window"),
        desired_size=Shares(size),
        seconds_to_close=seconds_to_close,
        occurred_at=UnixTimestamp(1_000_000),
        opening_first_leg=kind is ApprovalKind.FIRST_LEG,
    )


async def test_first_leg_within_limits_is_approved() -> None:
    adapter = _adapter()
    result = await adapter.evaluate(
        _request(ApprovalKind.FIRST_LEG, size="1", seconds_to_close=200)
    )
    assert result.approved is True
    assert result.approved_size.is_positive


async def test_first_leg_blocked_inside_close_cutoff() -> None:
    adapter = _adapter()
    # Opening a new first leg with almost no time to close must fail closed.
    result = await adapter.evaluate(
        _request(ApprovalKind.FIRST_LEG, size="1", seconds_to_close=0)
    )
    assert result.approved is False
    assert result.approved_size == Shares(0)


async def test_merge_kind_maps_and_authorizes_requested_quantity() -> None:
    adapter = _adapter()
    result = await adapter.evaluate(
        _request(ApprovalKind.MERGE, size="5", seconds_to_close=10)
    )
    # Merge approvals carry no sizing; an approved verdict authorizes the ask.
    if result.approved:
        assert result.approved_size == Shares("5")
    else:
        assert result.approved_size == Shares(0)
