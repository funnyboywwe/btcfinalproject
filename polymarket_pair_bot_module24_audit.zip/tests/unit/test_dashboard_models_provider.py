"""Unit tests for dashboard view-models and the placeholder provider (Module 21).

Verifies Decimal precision survives JSON serialization (money is never coerced
to binary float), the snapshot forbids unknown fields, and the placeholder
provider returns a well-formed empty read-only snapshot with no secrets.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from decimal import Decimal

import pytest

from polymarket_pair_bot.dashboard.models import DashboardSnapshot, PairCostView
from polymarket_pair_bot.dashboard.provider import PlaceholderDashboardProvider


def test_decimal_serializes_as_lossless_string() -> None:
    pc = PairCostView(effective_pair_cost=Decimal("0.999999999999999999"))
    dumped = pc.model_dump(mode="json")
    # Pydantic v2 serializes Decimal to a string, preserving exact precision.
    assert dumped["effective_pair_cost"] == "0.999999999999999999"
    assert isinstance(dumped["effective_pair_cost"], str)


def test_snapshot_forbids_unknown_fields() -> None:
    with pytest.raises(ValueError):
        DashboardSnapshot(
            generated_at=datetime(2026, 7, 18, tzinfo=UTC),
            run_mode="PAPER",
            bogus_field="nope",  # type: ignore[call-arg]
        )


def test_placeholder_provider_returns_empty_readonly_snapshot() -> None:
    fixed = datetime(2026, 7, 18, 9, 0, tzinfo=UTC)
    provider = PlaceholderDashboardProvider(run_mode="PAPER", now=lambda: fixed)
    snap = asyncio.run(provider.snapshot())
    assert snap.data_available is False
    assert snap.run_mode == "PAPER"
    assert snap.generated_at == fixed
    assert snap.market is None
    assert snap.open_orders == ()
    assert snap.recent_fills == ()
    # Safe defaults fail closed: freshness stale, risk blocked, kill-switch on.
    assert snap.freshness.is_stale is True
    assert snap.risk.blocked is True
    assert snap.kill_switch.active is True


def test_placeholder_snapshot_json_has_no_secret_like_keys() -> None:
    provider = PlaceholderDashboardProvider(run_mode="PAPER")
    snap = asyncio.run(provider.snapshot())
    dumped = snap.model_dump(mode="json")
    flat = str(dumped).lower()
    for needle in ("token", "secret", "private_key", "passphrase", "api_secret"):
        assert needle not in flat
