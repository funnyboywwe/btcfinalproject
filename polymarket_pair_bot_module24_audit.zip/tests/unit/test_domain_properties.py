"""Property-based tests for the fixed-point arithmetic invariants.

These use Hypothesis with Decimal strategies built from integers so we never
construct a Decimal from a float.
"""

from __future__ import annotations

from decimal import Decimal

from hypothesis import given
from hypothesis import strategies as st

from polymarket_pair_bot.domain.arithmetic import (
    effective_pair_cost,
    executable_vwap,
    locked_net_profit,
    matched_quantity,
    residual_quantity,
    taker_fee,
)
from polymarket_pair_bot.domain.entities import PriceLevel
from polymarket_pair_bot.domain.precision import USD_QUANTUM
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    FeeAmount,
    ProbabilityPrice,
    Shares,
)

# Decimal strategies derived from ints (never from float).
price_decimals = st.integers(min_value=0, max_value=1_000_000).map(
    lambda micros: Decimal(micros) / Decimal(1_000_000)
)
usd_decimals = st.integers(min_value=0, max_value=10_000_000).map(
    lambda micros: Decimal(micros) / Decimal(1_000_000)
)
share_counts = st.integers(min_value=0, max_value=1_000_000).map(
    lambda micros: Decimal(micros) / Decimal(1_000)
)
bps_values = st.integers(min_value=0, max_value=1_000_000).map(
    lambda hundredths: Decimal(hundredths) / Decimal(100)
)


@given(price_decimals)
def test_probability_price_accepts_full_range(value: Decimal) -> None:
    assert ProbabilityPrice(value).value == value


@given(usd_decimals, bps_values)
def test_taker_fee_never_understates(notional: Decimal, bps: Decimal) -> None:
    fee = taker_fee(CollateralAmount(notional), BasisPoints(bps))
    exact = notional * (bps / Decimal(10000))
    # Conservative: rounded fee is >= exact fee, and within one quantum.
    assert fee.value >= exact
    assert fee.value - exact <= USD_QUANTUM


@given(share_counts, share_counts)
def test_matched_plus_residual_equals_max(up: Decimal, down: Decimal) -> None:
    matched = matched_quantity(Shares(up), Shares(down))
    residual = residual_quantity(Shares(up), Shares(down))
    assert matched.value == min(up, down)
    assert matched.value + residual.value == max(up, down)


@given(usd_decimals, usd_decimals, usd_decimals, usd_decimals, usd_decimals, usd_decimals)
def test_effective_pair_cost_is_monotone_and_conservative(
    a: Decimal, b: Decimal, c: Decimal, d: Decimal, e: Decimal, f: Decimal
) -> None:
    cost = effective_pair_cost(
        CollateralAmount(a),
        CollateralAmount(b),
        FeeAmount(c),
        CollateralAmount(d),
        CollateralAmount(e),
        CollateralAmount(f),
    )
    exact = a + b + c + d + e + f
    assert cost.value >= exact
    assert cost.value - exact <= USD_QUANTUM


@given(usd_decimals, usd_decimals)
def test_locked_net_profit_never_overstates(locked: Decimal, cost: Decimal) -> None:
    profit = locked_net_profit(CollateralAmount(locked), CollateralAmount(cost))
    exact = locked - cost
    assert profit.value <= exact
    assert exact - profit.value <= USD_QUANTUM


@given(price_decimals, share_counts, share_counts)
def test_vwap_never_exceeds_worst_level(
    price: Decimal, size_a: Decimal, size_b: Decimal
) -> None:
    if size_a <= 0 or size_b <= 0:
        return
    # Two levels at the same price -> VWAP equals that price.
    book = [
        PriceLevel(ProbabilityPrice(price), Shares(size_a)),
        PriceLevel(ProbabilityPrice(price), Shares(size_b)),
    ]
    result = executable_vwap(book, Shares(size_a))
    assert result.average_price is not None
    assert result.average_price.value == price
