"""Unit tests for secret redaction utilities."""

from __future__ import annotations

from hypothesis import given
from hypothesis import strategies as st

from polymarket_pair_bot.security.redaction import (
    REDACTED,
    is_secret_key,
    redact_mapping,
    redact_text,
    redact_value,
)


class _FakeSecret:
    """Stand-in for pydantic SecretStr (duck-typed via get_secret_value)."""

    def __init__(self, value: str) -> None:
        self._value = value

    def get_secret_value(self) -> str:
        return self._value


def test_is_secret_key_detects_sensitive_names() -> None:
    assert is_secret_key("POLYMARKET_API_SECRET")
    assert is_secret_key("private_key")
    assert is_secret_key("database_url")
    assert is_secret_key("polygon_rpc_primary")
    assert not is_secret_key("log_level")


def test_redact_text_scrubs_private_key_hex() -> None:
    secret = "0x" + "a" * 64
    assert secret not in redact_text(f"key={secret} tail")


def test_redact_value_redacts_secret_objects() -> None:
    assert redact_value(None, _FakeSecret("super-secret")) == REDACTED


def test_redact_mapping_is_recursive() -> None:
    payload = {
        "log_level": "INFO",
        "api_secret": "whatever",
        "nested": {
            "private_key": "0x" + "b" * 64,
            "list": [_FakeSecret("x"), "plain"],
        },
    }
    result = redact_mapping(payload)
    assert result["log_level"] == "INFO"
    assert result["api_secret"] == REDACTED
    assert result["nested"]["private_key"] == REDACTED
    assert result["nested"]["list"][0] == REDACTED
    assert result["nested"]["list"][1] == "plain"


@given(st.text())
def test_redact_text_never_leaves_32_byte_hex(fragment: str) -> None:
    secret = "0x" + "c" * 64
    redacted = redact_text(f"{fragment} {secret}")
    assert secret not in redacted
