"""Unit tests for the reconnecting user stream (reconnect/dedup/freshness)."""

from __future__ import annotations

import asyncio
from collections.abc import Mapping
from typing import Any

import pytest

from polymarket_pair_bot.auth.errors import StaleUserStreamError
from polymarket_pair_bot.auth.readiness import AuthReadinessState
from polymarket_pair_bot.auth.user_stream import ReconnectingUserStream
from tests.fixtures.auth import (
    FakeUserStreamConnection,
    FakeUserStreamConnectionFactory,
    SilentUserStreamConnectionFactory,
)


async def test_reconnect_dedup_and_resync() -> None:
    received: list[str] = []
    resync_count = 0

    async def handler(message: Mapping[str, Any]) -> None:
        received.append(str(message["id"]))

    async def resync() -> None:
        nonlocal resync_count
        resync_count += 1

    conn1 = FakeUserStreamConnection(
        [{"id": "1"}, {"id": "1"}, ConnectionError("drop")]
    )
    conn2 = FakeUserStreamConnection([{"id": "2"}])
    factory = FakeUserStreamConnectionFactory([conn1, conn2])
    stream = ReconnectingUserStream(
        factory=factory,
        handler=handler,
        resync=resync,
        max_reconnects=3,
        freshness_seconds=5,
        backoff_base_seconds=0.001,
        backoff_max_seconds=0.001,
    )

    async def stopper() -> None:
        for _ in range(1000):
            if received == ["1", "2"]:
                stream.stop()
                return
            await asyncio.sleep(0.001)
        stream.stop()

    await asyncio.gather(stream.run(), stopper())

    assert received == ["1", "2"]  # duplicate id "1" was deduped
    assert factory.connect_count == 2  # reconnected once after the drop
    assert resync_count == 2  # fresh resync on every (re)connect
    assert conn1.closed and conn2.closed  # cancellation-safe close


async def test_freshness_timeout_and_bounded_reconnects_fail_closed() -> None:
    async def handler(message: Mapping[str, Any]) -> None:
        return None

    factory = SilentUserStreamConnectionFactory()
    stream = ReconnectingUserStream(
        factory=factory,
        handler=handler,
        max_reconnects=1,
        freshness_seconds=0.01,
        backoff_base_seconds=0.001,
        backoff_max_seconds=0.001,
    )

    with pytest.raises(StaleUserStreamError):
        await stream.run()

    # 1 initial + 1 permitted reconnect, then fail closed.
    assert factory.connect_count == 2
    assert stream.readiness.state is AuthReadinessState.DEGRADED


async def test_stop_requests_graceful_shutdown() -> None:
    async def handler(message: Mapping[str, Any]) -> None:
        return None

    conn = FakeUserStreamConnection([{"id": "1"}])
    factory = FakeUserStreamConnectionFactory([conn])
    stream = ReconnectingUserStream(
        factory=factory,
        handler=handler,
        freshness_seconds=5,
    )
    stream.stop()
    await stream.run()  # returns promptly without connecting
    assert factory.connect_count == 0
