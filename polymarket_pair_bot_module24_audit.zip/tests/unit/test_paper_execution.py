"""Unit tests for the deterministic paper execution adapter (Module 11).

Each modeled behavior from the module brief has at least one test. Tests never
place a real order and use only in-memory fakes.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.enums import OrderStatus, OrderSide, TimeInForce
from polymarket_pair_bot.domain.value_objects import BasisPoints, OrderId, Shares
from polymarket_pair_bot.execution import (
    ExecutionAdapter,
    ExecutionPersistence,
    LatencyDistribution,
    PaperExecutionAdapter,
    PaperExecutionConfig,
    SubmitOutcome,
)
from polymarket_pair_bot.execution.types import CancelOutcome
from tests.fixtures.execution import (
    MARKET,
    UP,
    make_adapter,
    make_event,
    make_intent,
    make_trade,
)


def _cfg(**kwargs: object) -> PaperExecutionConfig:
    base: dict[str, object] = {
        "ack_latency": LatencyDistribution.constant(100),
        "cancel_latency": LatencyDistribution.constant(100),
    }
    base.update(kwargs)
    return PaperExecutionConfig(**base)  # type: ignore[arg-type]


async def _seed_book(adapter: PaperExecutionAdapter, **kwargs: object) -> None:
    await adapter.apply_market_event(make_event("seed", ts_ms=0, **kwargs))  # type: ignore[arg-type]


async def test_protocol_conformance() -> None:
    adapter, persistence = make_adapter()
    assert isinstance(adapter, ExecutionAdapter)
    assert isinstance(persistence, ExecutionPersistence)


async def test_post_only_rejection_when_crosses() -> None:
    # Item 1: a maker (GTC) buy at/above best ask is post-only rejected.
    adapter, persistence = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.40", "100"),), asks=(("0.50", "100"),))
    ack = await adapter.submit_order(make_intent("i1", price="0.51", size="10"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "post_only_would_cross"
    assert ack.order.status is OrderStatus.REJECTED
    # Persisted through repositories.
    assert persistence.intents.items["i1"] is not None
    assert persistence.orders.items["paper-i1"].status is OrderStatus.REJECTED


async def test_maker_rests_and_queue_position_blocks_touch() -> None:
    # Items 2 + "do not fill on touch": order rests behind queue; a mere quote
    # touch does not fill it.
    adapter, _ = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.45", "30"),), asks=(("0.55", "100"),))
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.advance_to(100)  # ack elapses -> OPEN, queue_ahead = 30
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.OPEN
    # A new book where price merely touches 0.45 (no trades) must not fill.
    await adapter.apply_market_event(
        make_event("e1", ts_ms=200, bids=(("0.45", "5"),), asks=(("0.46", "100"),))
    )
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.filled_size.value == Decimal(0)


async def test_maker_queue_then_partial_then_full_fill() -> None:
    # Items 2 + 3: queue ahead consumed first, then partial, then full fill.
    adapter, _ = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.45", "20"),), asks=(("0.55", "100"),))
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.advance_to(100)  # OPEN, queue_ahead = 20
    # Trade of 25 @ 0.45: 20 consumes queue, 5 fills us -> partial.
    await adapter.apply_market_event(
        make_event(
            "e1",
            ts_ms=200,
            bids=(("0.45", "20"),),
            asks=(("0.55", "100"),),
            trades=(make_trade("t1", price="0.45", size="25"),),
        )
    )
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None
    assert order.status is OrderStatus.PARTIALLY_FILLED
    assert order.filled_size.value == Decimal(5)
    # Another trade of 10 @ 0.44 (through our price) completes us.
    await adapter.apply_market_event(
        make_event(
            "e2",
            ts_ms=300,
            bids=(("0.45", "20"),),
            asks=(("0.55", "100"),),
            trades=(make_trade("t2", price="0.44", size="10"),),
        )
    )
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None
    assert order.status is OrderStatus.FILLED
    assert order.filled_size.value == Decimal(10)


async def test_acknowledgement_latency_pending_until_active() -> None:
    # Item 4: order stays PENDING_SUBMIT until ack latency elapses.
    adapter, _ = make_adapter(config=_cfg(ack_latency=LatencyDistribution.constant(250)))
    await _seed_book(adapter, bids=(("0.45", "10"),), asks=(("0.55", "10"),))
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.advance_to(100)
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.PENDING_SUBMIT
    await adapter.advance_to(250)
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.OPEN


async def test_cancellation_latency_and_cancel_takes_effect() -> None:
    # Item 5: cancel is SCHEDULED, then becomes effective after latency.
    adapter, _ = make_adapter(config=_cfg(cancel_latency=LatencyDistribution.constant(150)))
    await _seed_book(adapter, bids=(("0.45", "10"),), asks=(("0.55", "10"),))
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.advance_to(100)  # OPEN
    cancel = await adapter.cancel_order(OrderId("paper-i1"))
    assert cancel.outcome is CancelOutcome.SCHEDULED
    await adapter.advance_to(200)  # still before cancel effective (100+150=250)
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.OPEN
    await adapter.advance_to(260)
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.CANCELED


async def test_fill_before_cancel_race_fill_wins() -> None:
    # Item 6: a fill landing before the cancel effective time wins the race.
    adapter, _ = make_adapter(config=_cfg(cancel_latency=LatencyDistribution.constant(500)))
    # No queue ahead (empty bid book at our price) so a trade fills immediately.
    await _seed_book(adapter, asks=(("0.55", "10"),))
    await adapter.apply_market_event(
        make_event("seed2", ts_ms=0, bids=(), asks=(("0.55", "10"),))
    )
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.advance_to(100)  # OPEN, queue_ahead = 0
    cancel = await adapter.cancel_order(OrderId("paper-i1"))
    assert cancel.outcome is CancelOutcome.SCHEDULED
    # Fill at t=150, before cancel effective at 100+500=600.
    await adapter.apply_market_event(
        make_event(
            "e1",
            ts_ms=150,
            bids=(),
            asks=(("0.55", "10"),),
            trades=(make_trade("t1", price="0.45", size="10"),),
        )
    )
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.FILLED
    # A later cancel attempt reports the order already filled.
    late = await adapter.cancel_order(OrderId("paper-i1"))
    assert late.outcome is CancelOutcome.ALREADY_FILLED


async def test_taker_multi_level_execution_and_fees() -> None:
    # Items 7 + 12: IOC taker walks multiple ask levels; fees charged per fill.
    adapter, persistence = make_adapter(
        config=_cfg(taker_fee_bps=BasisPoints(Decimal("100")))  # 1%
    )
    await _seed_book(
        adapter,
        bids=(("0.40", "100"),),
        asks=(("0.50", "6"), ("0.51", "6")),
    )
    ack = await adapter.submit_order(
        make_intent("i1", price="0.52", size="10", tif=TimeInForce.IOC)
    )
    assert ack.outcome is SubmitOutcome.ACCEPTED
    await adapter.advance_to(100)  # ack elapses -> taker executes
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.FILLED
    fills = await adapter.get_fills(order_id=OrderId("paper-i1"))
    assert len(fills) == 2
    assert {f.price.value for f in fills} == {Decimal("0.50"), Decimal("0.51")}
    assert all(f.fee.value > Decimal(0) for f in fills)


async def test_fok_all_or_none_kills_when_insufficient() -> None:
    # Item 8: FOK with insufficient depth fills nothing and is canceled.
    adapter, _ = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.40", "100"),), asks=(("0.50", "4"),))
    await adapter.submit_order(
        make_intent("i1", price="0.52", size="10", tif=TimeInForce.FOK)
    )
    await adapter.advance_to(100)
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None
    assert order.status is OrderStatus.CANCELED
    assert order.filled_size.value == Decimal(0)


async def test_fok_fills_fully_when_depth_available() -> None:
    adapter, _ = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.40", "100"),), asks=(("0.50", "20"),))
    await adapter.submit_order(
        make_intent("i1", price="0.52", size="10", tif=TimeInForce.FOK)
    )
    await adapter.advance_to(100)
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.FILLED
    assert order.filled_size.value == Decimal(10)


async def test_fak_ioc_partial_then_kills_remainder() -> None:
    # Item 9: IOC/FAK fills what is available and cancels the rest.
    adapter, _ = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.40", "100"),), asks=(("0.50", "4"),))
    await adapter.submit_order(
        make_intent("i1", price="0.52", size="10", tif=TimeInForce.IOC)
    )
    await adapter.advance_to(100)
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None
    assert order.status is OrderStatus.CANCELED
    assert order.filled_size.value == Decimal(4)


async def test_tick_size_rejection() -> None:
    # Item 10: price not aligned to the token tick (0.01) is rejected.
    adapter, _ = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.40", "10"),), asks=(("0.60", "10"),))
    ack = await adapter.submit_order(make_intent("i1", price="0.455", size="10"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "tick_size"


async def test_minimum_size_rejection() -> None:
    # Item 11: size below the configured minimum is rejected.
    adapter, _ = make_adapter(config=_cfg(min_order_size=Shares(Decimal("5"))))
    await _seed_book(adapter, bids=(("0.40", "10"),), asks=(("0.60", "10"),))
    ack = await adapter.submit_order(make_intent("i1", price="0.45", size="2"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "min_size"


async def test_slippage_worsens_taker_price() -> None:
    # Item 13: configured slippage worsens the effective buy price (rounded up
    # to tick), so a fill occurs at a higher price than the raw quote.
    adapter, _ = make_adapter(
        config=_cfg(expected_slippage_bps=BasisPoints(Decimal("200")))  # 2%
    )
    await _seed_book(adapter, bids=(("0.40", "100"),), asks=(("0.50", "10"),))
    await adapter.submit_order(
        make_intent("i1", price="0.55", size="10", tif=TimeInForce.IOC)
    )
    await adapter.advance_to(100)
    fills = await adapter.get_fills(order_id=OrderId("paper-i1"))
    assert len(fills) == 1
    # 0.50 * 1.02 = 0.51 exactly, tick-aligned.
    assert fills[0].price.value == Decimal("0.51")


async def test_stale_book_rejection() -> None:
    # Item 14: submitting against a stale book is rejected (fail closed).
    adapter, _ = make_adapter(config=_cfg(stale_after_ms=1000))
    await _seed_book(adapter, bids=(("0.40", "10"),), asks=(("0.60", "10"),))
    await adapter.advance_to(5000)  # book now far older than stale_after_ms
    ack = await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "stale_book"


async def test_websocket_outage_prevents_fills_and_submits() -> None:
    # Item 15: a non-live feed marks the book stale; no matching, and new
    # submissions are rejected.
    adapter, _ = make_adapter(config=_cfg())
    await _seed_book(adapter, asks=(("0.55", "10"),))
    await adapter.apply_market_event(
        make_event("seed2", ts_ms=0, bids=(), asks=(("0.55", "10"),))
    )
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.advance_to(100)  # OPEN
    # Outage event carrying a trade: must NOT fill (feed not live).
    await adapter.apply_market_event(
        make_event(
            "e1",
            ts_ms=200,
            trades=(make_trade("t1", price="0.45", size="10"),),
            feed_live=False,
            with_book=False,
        )
    )
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.filled_size.value == Decimal(0)
    ack = await adapter.submit_order(make_intent("i2", price="0.45", size="10"))
    assert ack.reason == "stale_book"


async def test_missed_fills_during_fast_movement() -> None:
    # Item 16: with maker_fill_probability = 0, qualifying trades are missed.
    adapter, _ = make_adapter(
        config=_cfg(maker_fill_probability=Decimal(0))
    )
    await adapter.apply_market_event(
        make_event("seed2", ts_ms=0, bids=(), asks=(("0.55", "10"),))
    )
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.advance_to(100)
    await adapter.apply_market_event(
        make_event(
            "e1",
            ts_ms=200,
            bids=(),
            asks=(("0.55", "10"),),
            trades=(make_trade("t1", price="0.45", size="50"),),
        )
    )
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.filled_size.value == Decimal(0)


async def test_duplicate_event_delivery_is_idempotent() -> None:
    # Item 17: re-delivering the same event (and trade) does not double-fill.
    adapter, persistence = make_adapter(config=_cfg())
    await adapter.apply_market_event(
        make_event("seed2", ts_ms=0, bids=(), asks=(("0.55", "10"),))
    )
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.advance_to(100)
    fill_event = make_event(
        "e1",
        ts_ms=200,
        bids=(),
        asks=(("0.55", "10"),),
        trades=(make_trade("t1", price="0.45", size="10"),),
    )
    await adapter.apply_market_event(fill_event)
    await adapter.apply_market_event(fill_event)  # duplicate
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.filled_size.value == Decimal(10)
    fills = await adapter.get_fills(order_id=OrderId("paper-i1"))
    assert len(fills) == 1


async def test_unknown_submission_outcome_requires_reconciliation() -> None:
    # Item 18: an unknown submission stays UNKNOWN and is not cancelable.
    adapter, _ = make_adapter(
        config=_cfg(unknown_submission_probability=Decimal(1))
    )
    await _seed_book(adapter, bids=(("0.40", "10"),), asks=(("0.60", "10"),))
    ack = await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    assert ack.outcome is SubmitOutcome.UNKNOWN
    assert ack.order.status is OrderStatus.UNKNOWN
    await adapter.advance_to(10_000)
    order = await adapter.get_order(OrderId("paper-i1"))
    assert order is not None and order.status is OrderStatus.UNKNOWN
    cancel = await adapter.cancel_order(OrderId("paper-i1"))
    assert cancel.outcome is CancelOutcome.ALREADY_TERMINAL
    assert cancel.reason == "unknown_requires_reconciliation"


async def test_configurable_latency_distribution_uniform_is_deterministic() -> None:
    # Item 19: uniform latency is drawn deterministically from the seed.
    cfg = _cfg(
        seed=7,
        ack_latency=LatencyDistribution.uniform(10, 200),
    )
    latencies: list[int] = []
    for _ in range(2):
        adapter, _ = make_adapter(config=cfg)
        await _seed_book(adapter, bids=(("0.40", "10"),), asks=(("0.60", "10"),))
        await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
        # Bisect for the activation time by probing statuses.
        active_at = None
        for t in range(0, 201):
            adapter2, _ = make_adapter(config=cfg)
            await adapter2.apply_market_event(
                make_event("s", ts_ms=0, bids=(("0.40", "10"),), asks=(("0.60", "10"),))
            )
            await adapter2.submit_order(make_intent("i1", price="0.45", size="10"))
            await adapter2.advance_to(t)
            o = await adapter2.get_order(OrderId("paper-i1"))
            if o is not None and o.status is OrderStatus.OPEN:
                active_at = t
                break
        latencies.append(active_at if active_at is not None else -1)
    assert latencies[0] == latencies[1]
    assert 10 <= latencies[0] <= 200


async def test_submit_is_idempotent_by_intent_id() -> None:
    # Every state-changing op is idempotent: resubmit returns the same order.
    adapter, persistence = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.40", "10"),), asks=(("0.60", "10"),))
    first = await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    second = await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    assert first.order.order_id.value == second.order.order_id.value
    assert persistence.intents.items and len(persistence.intents.items) == 1


async def test_unknown_order_cancel_and_queries() -> None:
    adapter, _ = make_adapter(config=_cfg())
    cancel = await adapter.cancel_order(OrderId("paper-does-not-exist"))
    assert cancel.outcome is CancelOutcome.UNKNOWN_ORDER
    assert await adapter.get_order(OrderId("paper-does-not-exist")) is None
    assert await adapter.get_open_orders() == ()
    assert await adapter.get_fills() == ()


async def test_cancel_all_and_by_market() -> None:
    adapter, _ = make_adapter(config=_cfg())
    await _seed_book(adapter, bids=(("0.40", "10"),), asks=(("0.60", "10"),))
    await adapter.submit_order(make_intent("i1", price="0.45", size="10"))
    await adapter.submit_order(make_intent("i2", price="0.44", size="10"))
    await adapter.advance_to(100)
    batch = await adapter.cancel_market_orders(MARKET)
    assert batch.scheduled_count == 2
    all_batch = await adapter.cancel_all_orders()
    # Already scheduled orders are not re-scheduled to a new outcome.
    assert len(all_batch.acks) == 2


async def test_reproducible_across_seeded_runs() -> None:
    # Deterministic seed => identical fills across independent runs.
    async def scenario() -> list[tuple[Decimal, Decimal]]:
        adapter, _ = make_adapter(
            config=_cfg(
                seed=42,
                taker_fee_bps=BasisPoints(Decimal("30")),
                expected_slippage_bps=BasisPoints(Decimal("50")),
            )
        )
        await adapter.apply_market_event(
            make_event(
                "s", ts_ms=0, bids=(("0.40", "100"),), asks=(("0.50", "6"), ("0.51", "20"))
            )
        )
        await adapter.submit_order(
            make_intent("i1", price="0.55", size="10", tif=TimeInForce.IOC)
        )
        await adapter.advance_to(100)
        fills = await adapter.get_fills(order_id=OrderId("paper-i1"))
        return [(f.price.value, f.size.value) for f in fills]

    assert await scenario() == await scenario()


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(pytest.main([__file__, "-q"]))
