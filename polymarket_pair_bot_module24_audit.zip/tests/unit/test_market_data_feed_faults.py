"""Fault tests for the async market-data feed runner (Module 6).

Exercise the failure/recovery behaviour end-to-end with an in-memory fake
connector (no network): subscription, bounded-queue overflow (slow consumer
must not block reading -> fail closed + resync), disconnect -> unavailable,
reconnect -> increment count + require a fresh authoritative snapshot per
token, and graceful cancellation.
"""

from __future__ import annotations

import asyncio
import json

import pytest

from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.market_data import FeedStatus
from polymarket_pair_bot.domain.value_objects import TokenId
from polymarket_pair_bot.market_data.errors import MarketDataError
from polymarket_pair_bot.market_data.feed import (
    MarketDataFeed,
    MarketDataFeedConfig,
    _RawFrame,
    build_subscribe_message,
)
from polymarket_pair_bot.market_data.manager import OrderBookManager
from tests.fixtures.market_data import (
    BLOCK,
    DOWN_TOKEN,
    UP_TOKEN,
    FakeConnection,
    FakeConnector,
    ManualClock,
    book_message,
    immediate_sleep,
    wait_for,
)


def _manager(clock: ManualClock | None = None) -> OrderBookManager:
    clock = clock or ManualClock(start=100.0)
    wall = iter(range(1, 1_000_000))
    return OrderBookManager(
        TokenId(UP_TOKEN),
        TokenId(DOWN_TOKEN),
        stale_after_seconds=30.0,
        monotonic=clock,
        wall_clock=lambda: next(wall),
    )


def _config(**overrides: object) -> MarketDataFeedConfig:
    params: dict[str, object] = {
        "url": "wss://example.invalid/ws/market",
        "max_queue_size": 100,
        "reconnect_base_seconds": 0.01,
        "reconnect_max_seconds": 0.02,
    }
    params.update(overrides)
    return MarketDataFeedConfig(**params)  # type: ignore[arg-type]


def test_subscribe_message_includes_both_tokens() -> None:
    text = build_subscribe_message("market", [UP_TOKEN, DOWN_TOKEN])
    payload = json.loads(text)
    assert payload["type"] == "market"
    assert payload["assets_ids"] == [UP_TOKEN, DOWN_TOKEN]


async def test_snapshots_bring_both_books_live() -> None:
    session = FakeConnection(
        [
            book_message(UP_TOKEN, bids=[("0.40", "10")], asks=[("0.60", "5")]),
            book_message(DOWN_TOKEN, bids=[("0.45", "7")], asks=[("0.55", "9")]),
            BLOCK,
        ]
    )
    connector = FakeConnector([session])
    manager = _manager()
    feed = MarketDataFeed(connector, manager, _config(), sleep=immediate_sleep)
    runner = asyncio.create_task(feed.run())
    try:
        await wait_for(
            lambda: manager.feed_status(OutcomeSide.UP) is FeedStatus.LIVE
            and manager.feed_status(OutcomeSide.DOWN) is FeedStatus.LIVE
        )
        # The subscription frame was sent with both token ids.
        assert session.sent, "expected a subscription frame"
        assert UP_TOKEN in session.sent[0] and DOWN_TOKEN in session.sent[0]
    finally:
        feed.request_stop()
        runner.cancel()
        with pytest.raises(asyncio.CancelledError):
            await runner
    assert session.closed


async def test_reconnect_requires_fresh_snapshot_per_token() -> None:
    # Session 1 snapshots both sides then drops; session 2 only snapshots Up.
    session1 = FakeConnection(
        [
            book_message(UP_TOKEN, bids=[("0.40", "10")], asks=[("0.60", "5")]),
            book_message(DOWN_TOKEN, bids=[("0.45", "7")], asks=[("0.55", "9")]),
            ConnectionError("dropped"),
        ]
    )
    session2 = FakeConnection(
        [
            book_message(UP_TOKEN, bids=[("0.41", "11")], asks=[("0.59", "6")]),
            BLOCK,
        ]
    )
    connector = FakeConnector([session1, session2])
    manager = _manager()
    feed = MarketDataFeed(connector, manager, _config(), sleep=immediate_sleep)
    runner = asyncio.create_task(feed.run())
    try:
        await wait_for(lambda: manager.reconnect_count == 1)
        # After reconnect, Up gets a fresh snapshot; Down must NOT survive the
        # reconnect and remains awaiting its own fresh authoritative snapshot.
        await wait_for(
            lambda: manager.feed_status(OutcomeSide.UP) is FeedStatus.LIVE
        )
        assert manager.feed_status(OutcomeSide.DOWN) is FeedStatus.AWAITING_SNAPSHOT
        assert manager.snapshot(OutcomeSide.DOWN) is None
        up = manager.quote(OutcomeSide.UP)
        assert up.best_bid is not None and str(up.best_bid) == "0.41"
    finally:
        feed.request_stop()
        runner.cancel()
        with pytest.raises(asyncio.CancelledError):
            await runner


async def test_queue_overflow_fails_closed() -> None:
    # A full bounded queue must never block the reader: it raises to force a
    # reconnect + resync instead of silently dropping deltas.
    manager = _manager()
    feed = MarketDataFeed(
        FakeConnector([]), manager, _config(max_queue_size=1), sleep=immediate_sleep
    )
    # Pre-fill the bounded queue to capacity so the next enqueue overflows.
    feed._queue.put_nowait(_RawFrame("prefilled"))  # type: ignore[attr-defined]
    conn = FakeConnection(
        [book_message(UP_TOKEN, bids=[("0.4", "1")], asks=[("0.6", "1")])]
    )
    with pytest.raises(MarketDataError):
        await feed._reader_loop(conn)  # type: ignore[attr-defined]
    assert feed.metrics.queue_overflows == 1


async def test_malformed_frame_does_not_crash_processor() -> None:
    session = FakeConnection(
        [
            "{ this is not json",
            {"event_type": "made_up", "asset_id": UP_TOKEN},
            book_message(UP_TOKEN, bids=[("0.40", "10")], asks=[("0.60", "5")]),
            BLOCK,
        ]
    )
    connector = FakeConnector([session])
    manager = _manager()
    feed = MarketDataFeed(connector, manager, _config(), sleep=immediate_sleep)
    runner = asyncio.create_task(feed.run())
    try:
        # Despite the bad frames, the good snapshot is still applied.
        await wait_for(
            lambda: manager.feed_status(OutcomeSide.UP) is FeedStatus.LIVE
        )
        assert feed.metrics.malformed >= 1
    finally:
        feed.request_stop()
        runner.cancel()
        with pytest.raises(asyncio.CancelledError):
            await runner


async def test_crossed_book_forces_resync() -> None:
    # A crossed incremental update is a fault: the runner must resync (end the
    # session so a fresh snapshot is required).
    session1 = FakeConnection(
        [
            book_message(UP_TOKEN, bids=[("0.40", "10")], asks=[("0.60", "5")]),
            # Incremental bid above the best ask -> crossed.
            {
                "event_type": "price_change",
                "asset_id": UP_TOKEN,
                "changes": [{"price": "0.70", "side": "BUY", "size": "1"}],
            },
            BLOCK,
        ]
    )
    session2 = FakeConnection([BLOCK])
    connector = FakeConnector([session1, session2])
    manager = _manager()
    feed = MarketDataFeed(connector, manager, _config(), sleep=immediate_sleep)
    runner = asyncio.create_task(feed.run())
    try:
        await wait_for(lambda: feed.metrics.faults >= 1)
        # The resync tears down the session and reconnects (fresh snapshot).
        await wait_for(lambda: connector.connect_calls >= 2)
    finally:
        feed.request_stop()
        runner.cancel()
        with pytest.raises(asyncio.CancelledError):
            await runner
