"""Unit tests ensuring config summaries never leak secrets.

Requires pydantic-settings (run via `uv run pytest`).
"""

from __future__ import annotations

import json

import pytest

from polymarket_pair_bot.config.settings import load_config
from polymarket_pair_bot.security.redaction import REDACTED

_SECRETS = {
    "POLYMARKET_API_KEY": "key-abcdef-please-redact",
    "POLYMARKET_API_SECRET": "secret-abcdef-please-redact",
    "POLYMARKET_API_PASSPHRASE": "pass-abcdef-please-redact",
    "POLYGON_RPC_PRIMARY": "https://rpc.example/abcdefabcdefabcdef",
    "DATABASE_URL": "postgresql+asyncpg://bot:supersecret@localhost:5432/pair_bot",
}


def _apply(monkeypatch: pytest.MonkeyPatch) -> None:
    for key, value in _SECRETS.items():
        monkeypatch.setenv(key, value)


def test_redacted_summary_hides_secret_values(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _apply(monkeypatch)
    config = load_config()
    blob = json.dumps(config.redacted_summary(), default=str)
    assert "supersecret" not in blob
    assert "please-redact" not in blob
    assert REDACTED in blob


def test_health_public_view_has_no_secrets(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _apply(monkeypatch)
    config = load_config()
    view = config.health_public_view()
    blob = json.dumps(view, default=str)
    assert "supersecret" not in blob
    assert "please-redact" not in blob
    # Only coarse flags are present.
    assert view["run_mode"] in {"recorder", "paper", "live"}
    assert "database_url" not in view
    assert "polygon_rpc_primary" not in view
