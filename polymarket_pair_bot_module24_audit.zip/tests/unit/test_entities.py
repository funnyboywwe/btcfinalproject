"""Boundary tests for domain entities."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    ExchangeOrder,
    InventorySnapshot,
    MarketWindow,
    OrderBookSnapshot,
    OutcomeToken,
    PairOpportunity,
    Position,
    PriceLevel,
)
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus, OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ConditionId,
    FeeAmount,
    MarketId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)

CONDITION = "0x" + "a" * 64


def _window() -> MarketWindow:
    return MarketWindow(
        market_id=MarketId("m1"),
        condition_id=ConditionId(CONDITION),
        open_time=UnixTimestamp(1_700_000_000),
        close_time=UnixTimestamp(1_700_000_300),
    )


def test_market_window_duration_and_ordering() -> None:
    assert _window().duration_seconds == 300
    with pytest.raises(ValueError):
        MarketWindow(
            market_id=MarketId("m1"),
            condition_id=ConditionId(CONDITION),
            open_time=UnixTimestamp(100),
            close_time=UnixTimestamp(100),
        )


def _token(side: OutcomeSide, tid: str) -> OutcomeToken:
    return OutcomeToken(TokenId(tid), side, MarketId("m1"), TickSize(Decimal("0.01")))


def test_binary_market_side_validation() -> None:
    up = _token(OutcomeSide.UP, "1")
    down = _token(OutcomeSide.DOWN, "2")
    market = BinaryMarket(MarketId("m1"), ConditionId(CONDITION), _window(), up, down)
    assert market.token_for(OutcomeSide.UP) is up
    with pytest.raises(ValueError):
        BinaryMarket(MarketId("m1"), ConditionId(CONDITION), _window(), down, up)


def test_binary_market_tokens_must_differ() -> None:
    up = _token(OutcomeSide.UP, "1")
    down = _token(OutcomeSide.DOWN, "1")
    with pytest.raises(ValueError):
        BinaryMarket(MarketId("m1"), ConditionId(CONDITION), _window(), up, down)


def test_price_level_requires_positive_size() -> None:
    with pytest.raises(ValueError):
        PriceLevel(ProbabilityPrice(Decimal("0.5")), Shares(Decimal(0)))


def test_orderbook_sorting_enforced() -> None:
    bids = (
        PriceLevel(ProbabilityPrice(Decimal("0.50")), Shares(Decimal("1"))),
        PriceLevel(ProbabilityPrice(Decimal("0.49")), Shares(Decimal("1"))),
    )
    asks = (
        PriceLevel(ProbabilityPrice(Decimal("0.51")), Shares(Decimal("1"))),
        PriceLevel(ProbabilityPrice(Decimal("0.52")), Shares(Decimal("1"))),
    )
    book = OrderBookSnapshot(TokenId("1"), bids, asks, UnixTimestamp(1))
    assert book.best_bid is not None and book.best_bid.value == Decimal("0.50")
    assert book.best_ask is not None and book.best_ask.value == Decimal("0.51")
    with pytest.raises(ValueError):
        OrderBookSnapshot(TokenId("1"), asks, asks, UnixTimestamp(1))


def test_exchange_order_fill_bounds_and_completion() -> None:
    order = ExchangeOrder(
        order_id=OrderId("o1"),
        intent_id="i1",
        token_id=TokenId("1"),
        side=OrderSide.BUY,
        limit_price=ProbabilityPrice(Decimal("0.5")),
        original_size=Shares(Decimal("10")),
        filled_size=Shares(Decimal("10")),
        status=OrderStatus.FILLED,
        created_at=UnixTimestamp(1),
        updated_at=UnixTimestamp(2),
    )
    assert order.is_confirmed_complete
    assert order.remaining_size.value == 0


@pytest.mark.parametrize(
    "status",
    [
        OrderStatus.SUBMITTED,
        OrderStatus.ACKNOWLEDGED,
        OrderStatus.OPEN,
        OrderStatus.PARTIALLY_FILLED,
        OrderStatus.UNKNOWN,
    ],
)
def test_non_filled_status_never_complete(status: OrderStatus) -> None:
    order = ExchangeOrder(
        order_id=OrderId("o1"),
        intent_id="i1",
        token_id=TokenId("1"),
        side=OrderSide.BUY,
        limit_price=ProbabilityPrice(Decimal("0.5")),
        original_size=Shares(Decimal("10")),
        filled_size=Shares(Decimal("10")),
        status=status,
        created_at=UnixTimestamp(1),
        updated_at=UnixTimestamp(2),
    )
    assert not order.is_confirmed_complete


def test_exchange_order_filled_cannot_exceed_original() -> None:
    with pytest.raises(ValueError):
        ExchangeOrder(
            order_id=OrderId("o1"),
            intent_id="i1",
            token_id=TokenId("1"),
            side=OrderSide.BUY,
            limit_price=ProbabilityPrice(Decimal("0.5")),
            original_size=Shares(Decimal("10")),
            filled_size=Shares(Decimal("11")),
            status=OrderStatus.PARTIALLY_FILLED,
            created_at=UnixTimestamp(1),
            updated_at=UnixTimestamp(2),
        )


def test_position_cost_basis() -> None:
    pos = Position(
        token_id=TokenId("1"),
        side=OutcomeSide.UP,
        quantity=Shares(Decimal("10")),
        average_price=ProbabilityPrice(Decimal("0.40")),
        fees_paid=FeeAmount(Decimal("0.05")),
    )
    assert pos.cost_basis.value == Decimal("4.05")


def test_inventory_snapshot_unmatched_math() -> None:
    up = Position(TokenId("1"), OutcomeSide.UP, Shares(Decimal("7")), ProbabilityPrice(Decimal("0.4")), FeeAmount(Decimal(0)))
    down = Position(TokenId("2"), OutcomeSide.DOWN, Shares(Decimal("5")), ProbabilityPrice(Decimal("0.5")), FeeAmount(Decimal(0)))
    snap = InventorySnapshot(MarketId("m1"), up, down, Shares(Decimal("5")), UnixTimestamp(1))
    assert snap.unmatched_up.value == Decimal("2")
    assert snap.unmatched_down.value == Decimal("0")
    with pytest.raises(ValueError):
        InventorySnapshot(MarketId("m1"), up, down, Shares(Decimal("6")), UnixTimestamp(1))


def test_pair_opportunity_threshold_no_profit_claim() -> None:
    opp = PairOpportunity(
        market_id=MarketId("m1"),
        size=Shares(Decimal("10")),
        up_price=ProbabilityPrice(Decimal("0.45")),
        down_price=ProbabilityPrice(Decimal("0.50")),
        effective_pair_cost=CollateralAmount(Decimal("0.97")),
        max_pair_cost=CollateralAmount(Decimal("0.99")),
        as_of=UnixTimestamp(1),
    )
    assert opp.is_within_threshold
