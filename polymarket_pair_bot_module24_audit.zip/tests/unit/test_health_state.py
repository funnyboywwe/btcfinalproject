"""Unit tests for health state primitives."""

from __future__ import annotations

from polymarket_pair_bot.shared.health import (
    HealthCheckResult,
    HealthState,
    HealthTracker,
)


def test_health_state_values() -> None:
    assert {s.value for s in HealthState} == {
        "starting",
        "ready",
        "degraded",
        "stopping",
    }


def test_tracker_starts_in_starting() -> None:
    tracker = HealthTracker()
    assert tracker.state is HealthState.STARTING


async def test_tracker_transitions_are_atomic() -> None:
    tracker = HealthTracker()
    snapshot = await tracker.set(HealthState.READY, "ok")
    assert tracker.state is HealthState.READY
    assert snapshot.state is HealthState.READY
    assert snapshot.detail == "ok"
    assert tracker.snapshot().state is HealthState.READY


def test_health_check_result_defaults() -> None:
    result = HealthCheckResult(healthy=True)
    assert result.healthy is True
    assert result.detail == ""
