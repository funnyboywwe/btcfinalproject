"""Unit tests for pure fixed-point strategy arithmetic."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.arithmetic import (
    average_acquisition_price,
    effective_pair_cost,
    executable_vwap,
    locked_net_profit,
    locked_pair_value,
    mark_to_executable_bid_pnl,
    matched_quantity,
    residual_quantity,
    taker_fee,
)
from polymarket_pair_bot.domain.entities import Fill, PriceLevel
from polymarket_pair_bot.domain.enums import OrderSide
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    FeeAmount,
    FillId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)


def _level(price: str, size: str) -> PriceLevel:
    return PriceLevel(ProbabilityPrice(Decimal(price)), Shares(Decimal(size)))


def test_executable_vwap_full_fill_across_levels() -> None:
    book = [_level("0.40", "10"), _level("0.45", "10")]
    result = executable_vwap(book, Shares(Decimal("15")))
    assert result.is_complete
    assert result.filled.value == Decimal("15")
    # (10*0.40 + 5*0.45) / 15 = 6.25/15 = 0.416667 (rounded 1e-6)
    assert result.average_price is not None
    assert result.average_price.value == Decimal("0.416667")


def test_executable_vwap_insufficient_liquidity() -> None:
    book = [_level("0.40", "5")]
    result = executable_vwap(book, Shares(Decimal("10")))
    assert not result.is_complete
    assert result.filled.value == Decimal("5")


def test_executable_vwap_empty_book() -> None:
    result = executable_vwap([], Shares(Decimal("1")))
    assert result.average_price is None
    assert result.filled.value == 0


def test_executable_vwap_requires_positive_quantity() -> None:
    with pytest.raises(ValueError):
        executable_vwap([_level("0.4", "1")], Shares(Decimal(0)))


def _fill(price: str, size: str) -> Fill:
    return Fill(
        fill_id=FillId("f-" + price + "-" + size),
        order_id=OrderId("o1"),
        token_id=TokenId("1"),
        side=OrderSide.BUY,
        price=ProbabilityPrice(Decimal(price)),
        size=Shares(Decimal(size)),
        fee=FeeAmount(Decimal(0)),
        filled_at=UnixTimestamp(1_700_000_000),
    )


def test_average_acquisition_price() -> None:
    fills = [_fill("0.40", "10"), _fill("0.50", "30")]
    # (0.40*10 + 0.50*30)/40 = 19/40 = 0.475
    assert average_acquisition_price(fills).value == Decimal("0.475000")


def test_average_acquisition_price_empty() -> None:
    with pytest.raises(ValueError):
        average_acquisition_price([])


def test_taker_fee_rounds_up() -> None:
    # notional 10 USD @ 12 bps = 0.012 exactly
    fee = taker_fee(CollateralAmount(Decimal("10")), BasisPoints(Decimal("12")))
    assert fee.value == Decimal("0.012000")
    # a value needing rounding rounds UP
    fee2 = taker_fee(CollateralAmount(Decimal("1")), BasisPoints(Decimal("0.00011")))
    assert fee2.value == Decimal("0.000001")


def test_matched_and_residual_quantity() -> None:
    up = Shares(Decimal("7"))
    down = Shares(Decimal("5"))
    assert matched_quantity(up, down).value == Decimal("5")
    assert residual_quantity(up, down).value == Decimal("2")
    assert residual_quantity(down, up).value == Decimal("2")


def test_effective_pair_cost_sums_and_rounds_up() -> None:
    cost = effective_pair_cost(
        up_acquisition_cost=CollateralAmount(Decimal("0.40")),
        down_acquisition_cost=CollateralAmount(Decimal("0.55")),
        taker_fees=FeeAmount(Decimal("0.001")),
        expected_slippage=CollateralAmount(Decimal("0.002")),
        merge_or_gas_overhead=CollateralAmount(Decimal("0.01")),
        safety_reserve=CollateralAmount(Decimal("0.005")),
    )
    assert cost.value == Decimal("0.968000")


def test_locked_pair_value_is_dollar_per_pair() -> None:
    assert locked_pair_value(Shares(Decimal("3"))).value == Decimal("3")


def test_locked_net_profit_rounds_down_and_allows_loss() -> None:
    profit = locked_net_profit(
        CollateralAmount(Decimal("3")), CollateralAmount(Decimal("2.9040009"))
    )
    # 3 - 2.9040009 = 0.0959991 -> ROUND_FLOOR at 1e-6 = 0.095999
    assert profit.value == Decimal("0.095999")
    loss = locked_net_profit(
        CollateralAmount(Decimal("1")), CollateralAmount(Decimal("1.25"))
    )
    assert loss.value == Decimal("-0.250000")
    assert loss.is_loss


def test_mark_to_executable_bid_pnl_rounds_down() -> None:
    pnl = mark_to_executable_bid_pnl(
        Shares(Decimal("10")),
        ProbabilityPrice(Decimal("0.50")),
        ProbabilityPrice(Decimal("0.48")),
    )
    # 10 * (0.48 - 0.50) = -0.2
    assert pnl.value == Decimal("-0.200000")
