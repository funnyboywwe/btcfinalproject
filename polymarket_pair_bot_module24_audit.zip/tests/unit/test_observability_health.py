"""Unit tests for Module 20 operator health/readiness transitions.

These tests exercise the required health-state transitions and the fail-closed
readiness contract using only the standard library plus the project's own
stdlib-only primitives (no FastAPI, Prometheus, or pydantic-settings needed).
"""

from __future__ import annotations

from polymarket_pair_bot.observability.health import (
    OperatorHealth,
    ReadinessEvaluator,
    ReadinessOutcome,
    ReadinessStatus,
)
from polymarket_pair_bot.shared.health import HealthState, HealthTracker


class _FlagReadiness:
    """Readiness evaluator whose result is controlled by a mutable flag."""

    def __init__(self, ready: bool = False) -> None:
        self.ready = ready
        self.calls = 0

    async def evaluate(self) -> ReadinessOutcome:
        self.calls += 1
        return ReadinessStatus(
            ready=self.ready,
            checks={"kill_switch_inactive": self.ready},
            detail={"kill_switch": "inactive" if self.ready else "active"},
        )


class _BoomReadiness:
    async def evaluate(self) -> ReadinessOutcome:
        raise RuntimeError("probe exploded")


def test_readiness_evaluator_protocol_is_structural() -> None:
    assert isinstance(_FlagReadiness(), ReadinessEvaluator)


async def test_liveness_is_always_200_across_all_states() -> None:
    tracker = HealthTracker()
    health = OperatorHealth(liveness=tracker)
    for state in HealthState:
        await tracker.set(state)
        result = health.live()
        assert result.status_code == 200
        assert result.body["status"] == "alive"
        assert result.body["state"] == state.value


async def test_liveness_only_readiness_tracks_health_state() -> None:
    tracker = HealthTracker()
    health = OperatorHealth(liveness=tracker)

    # STARTING -> not ready (503), fail closed.
    assert tracker.state is HealthState.STARTING
    assert (await health.ready()).status_code == 503

    # READY -> ready (200).
    await tracker.set(HealthState.READY)
    ready = await health.ready()
    assert ready.status_code == 200
    assert ready.body["ready"] is True

    # DEGRADED -> not ready (503).
    await tracker.set(HealthState.DEGRADED)
    assert (await health.ready()).status_code == 503

    # STOPPING -> not ready (503) but still alive.
    await tracker.set(HealthState.STOPPING)
    assert (await health.ready()).status_code == 503
    assert health.live().status_code == 200


async def test_injected_readiness_controls_status_code() -> None:
    tracker = HealthTracker()
    await tracker.set(HealthState.READY)
    probe = _FlagReadiness(ready=False)
    health = OperatorHealth(liveness=tracker, readiness=probe)

    # Even though health is READY, an unsafe readiness probe => 503.
    not_ready = await health.ready()
    assert not_ready.status_code == 503
    assert not_ready.body["ready"] is False
    assert probe.calls == 1

    probe.ready = True
    ok = await health.ready()
    assert ok.status_code == 200
    assert ok.body["ready"] is True


async def test_readiness_fails_closed_on_probe_error() -> None:
    tracker = HealthTracker()
    await tracker.set(HealthState.READY)
    health = OperatorHealth(liveness=tracker, readiness=_BoomReadiness())
    result = await health.ready()
    assert result.status_code == 503
    assert result.body["ready"] is False
    assert result.body["checks"] == {"readiness_probe": False}


async def test_details_contains_non_secret_config_and_uptime() -> None:
    tracker = HealthTracker()
    await tracker.set(HealthState.READY, detail="all good")
    health = OperatorHealth(
        liveness=tracker,
        readiness=_FlagReadiness(ready=True),
        config_view=lambda: {"run_mode": "paper", "live_trading": False},
        version="1.2.3",
    )
    result = await health.details()
    assert result.status_code == 200
    body = result.body
    assert body["version"] == "1.2.3"
    assert body["state"] == "ready"
    assert body["ready"] is True
    assert body["config"]["run_mode"] == "paper"
    assert "uptime_seconds" in body


async def test_details_redacts_any_secret_like_config_value() -> None:
    tracker = HealthTracker()
    await tracker.set(HealthState.READY)
    # Defence in depth: even if a secret-looking key leaks into the view, the
    # details body must redact it.
    health = OperatorHealth(
        liveness=tracker,
        readiness=_FlagReadiness(ready=True),
        config_view=lambda: {"api_secret": "super-secret-value"},
    )
    result = await health.details()
    assert "super-secret-value" not in str(result.body)


async def test_details_can_be_disabled() -> None:
    tracker = HealthTracker()
    health = OperatorHealth(liveness=tracker, expose_details=False)
    assert health.expose_details is False
