"""Unit tests for pure snapshot <-> Parquet-row serialization (no pyarrow)."""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.recording import (
    DataQualityFlags,
    RecordedBookSide,
    RecordedLevel,
    RecordedPairSnapshot,
    SnapshotTrigger,
)
from polymarket_pair_bot.recorder.serialization import (
    COLUMN_NAMES,
    row_to_snapshot,
    snapshot_to_row,
)


def _flags() -> DataQualityFlags:
    return DataQualityFlags(
        has_snapshot=True,
        is_live=True,
        is_stale=False,
        is_unavailable=False,
        is_crossed=False,
        is_empty=False,
        missing_best_bid=False,
        missing_best_ask=False,
        missing_exchange_timestamp=False,
    )


def _side(side: str, token: str) -> RecordedBookSide:
    return RecordedBookSide(
        side=side,
        token_id=token,
        status="live",
        best_bid=Decimal("0.401234"),
        best_ask=Decimal("0.598766"),
        best_bid_size=Decimal("100.5"),
        best_ask_size=Decimal("250.25"),
        spread=Decimal("0.197532"),
        mid=Decimal("0.5"),
        bid_levels_count=3,
        ask_levels_count=2,
        bid_depth_total=Decimal("1000.75"),
        ask_depth_total=Decimal("900.5"),
        bids=(
            RecordedLevel(price=Decimal("0.401234"), size=Decimal("100.5")),
            RecordedLevel(price=Decimal("0.40"), size=Decimal("200")),
        ),
        asks=(RecordedLevel(price=Decimal("0.598766"), size=Decimal("250.25")),),
        exchange_timestamp_ms=1_700_000_000_000,
        local_receipt_epoch=1_700_000_000,
        processed_epoch=1_700_000_001,
        age_seconds=0.125,
        flags=_flags(),
    )


def _snapshot() -> RecordedPairSnapshot:
    return RecordedPairSnapshot(
        window_id="btc-5m-window",
        market_slug="btc-updown",
        sequence=42,
        capture_epoch=1_700_000_005,
        triggers=(SnapshotTrigger.PERIODIC, SnapshotTrigger.BEST_BID_CHANGE),
        up=_side("up", "1"),
        down=_side("down", "2"),
        executable_pair_cost=Decimal("0.997532"),
        pair_cost_level=Decimal("0.99"),
        top_depth=10,
    )


def test_row_has_all_declared_columns() -> None:
    row = snapshot_to_row(_snapshot())
    assert set(row) == set(COLUMN_NAMES)


def test_round_trip_is_exact() -> None:
    original = _snapshot()
    restored = row_to_snapshot(snapshot_to_row(original))
    assert restored == original
    # Prices survive as exact Decimals (never binary floats).
    assert restored.up.best_bid == Decimal("0.401234")
    assert restored.executable_pair_cost == Decimal("0.997532")
    assert restored.up.bids == original.up.bids


def test_none_monetary_fields_round_trip() -> None:
    snap = _snapshot()
    empty_up = RecordedBookSide(
        side="up",
        token_id="1",
        status="unavailable",
        best_bid=None,
        best_ask=None,
        best_bid_size=None,
        best_ask_size=None,
        spread=None,
        mid=None,
        bid_levels_count=0,
        ask_levels_count=0,
        bid_depth_total=Decimal("0"),
        ask_depth_total=Decimal("0"),
        bids=(),
        asks=(),
        exchange_timestamp_ms=None,
        local_receipt_epoch=None,
        processed_epoch=None,
        age_seconds=None,
        flags=_flags(),
    )
    snap = RecordedPairSnapshot(
        window_id=snap.window_id,
        market_slug=None,
        sequence=snap.sequence,
        capture_epoch=snap.capture_epoch,
        triggers=snap.triggers,
        up=empty_up,
        down=snap.down,
        executable_pair_cost=None,
        pair_cost_level=None,
        top_depth=snap.top_depth,
    )
    restored = row_to_snapshot(snapshot_to_row(snap))
    assert restored == snap
