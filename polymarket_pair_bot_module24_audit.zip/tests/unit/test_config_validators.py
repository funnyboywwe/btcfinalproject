"""Unit tests for the pure (dependency-free) config validators.

These run without pydantic-settings and cover the malformed-value handling
required by the module spec (chain id, wallet address, private key, URLs).
"""

from __future__ import annotations

import pytest

from polymarket_pair_bot.config.validators import (
    ensure_supported_chain_id,
    ensure_valid_evm_address,
    normalize_http_url,
    normalize_private_key,
    normalize_ws_url,
)


@pytest.mark.parametrize("chain_id", [137, 80002])
def test_supported_chain_ids_pass(chain_id: int) -> None:
    assert ensure_supported_chain_id(chain_id) == chain_id


@pytest.mark.parametrize("chain_id", [1, 0, 42161, -137])
def test_unsupported_chain_ids_rejected(chain_id: int) -> None:
    with pytest.raises(ValueError):
        ensure_supported_chain_id(chain_id)


def test_valid_evm_address() -> None:
    addr = "0x" + "a" * 40
    assert ensure_valid_evm_address(addr) == addr


@pytest.mark.parametrize(
    "addr",
    [
        "0x123",
        "a" * 40,
        "0x" + "g" * 40,
        "0x" + "a" * 39,
        "0x" + "a" * 41,
        "",
    ],
)
def test_invalid_evm_address_rejected(addr: str) -> None:
    with pytest.raises(ValueError):
        ensure_valid_evm_address(addr)


def test_private_key_normalizes_and_adds_prefix() -> None:
    body = "b" * 64
    assert normalize_private_key(body) == "0x" + body
    assert normalize_private_key("0x" + body) == "0x" + body


@pytest.mark.parametrize("raw", ["0x" + "b" * 63, "0x" + "z" * 64, "deadbeef"])
def test_malformed_private_key_rejected_without_leaking(raw: str) -> None:
    with pytest.raises(ValueError) as excinfo:
        normalize_private_key(raw)
    # The key material must never appear in the error message.
    assert raw not in str(excinfo.value)


@pytest.mark.parametrize(
    "url",
    ["https://gamma-api.polymarket.com", "http://localhost:8000/"],
)
def test_http_url_ok(url: str) -> None:
    assert normalize_http_url(url).startswith(("http://", "https://"))


@pytest.mark.parametrize("url", ["wss://x.example/ws", "ws://localhost:9000"])
def test_ws_url_ok(url: str) -> None:
    assert normalize_ws_url(url).startswith(("ws://", "wss://"))


@pytest.mark.parametrize("url", ["ftp://x", "not-a-url", "wss://x"])
def test_http_url_rejects_bad_scheme(url: str) -> None:
    with pytest.raises(ValueError):
        normalize_http_url(url)


@pytest.mark.parametrize("url", ["https://x", "tcp://x", ""])
def test_ws_url_rejects_bad_scheme(url: str) -> None:
    with pytest.raises(ValueError):
        normalize_ws_url(url)
