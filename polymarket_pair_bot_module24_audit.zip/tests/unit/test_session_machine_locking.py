"""Regression tests for per-market serialization in the pair-accumulation
state machine.

The machine drives many markets on one event loop. A per-market
:class:`asyncio.Lock` must serialize the cache read-modify-write for a single
market (so concurrent same-market events can never lose an update) while
leaving different markets free to run concurrently. This is defense-in-depth on
top of the upstream single-writer (one execution leader) guarantee.
"""

from __future__ import annotations

import asyncio

from polymarket_pair_bot.domain.value_objects import MarketId, UnixTimestamp
from polymarket_pair_bot.strategy.session_events import (
    BooksUpdatedEvent,
    MarketValidatedEvent,
)
from tests.fixtures.state_machine import FakeSessionStore, build_harness


def test_lock_for_is_per_market_and_stable() -> None:
    machine = build_harness().machine
    a1 = machine._lock_for(MarketId("mkt-a"))
    a2 = machine._lock_for(MarketId("mkt-a"))
    b = machine._lock_for(MarketId("mkt-b"))
    assert a1 is a2  # same market -> same lock instance
    assert a1 is not b  # different markets -> independent locks


def test_same_market_is_blocked_while_lock_held_but_other_market_proceeds() -> None:
    async def scenario() -> None:
        machine = build_harness().machine
        held = MarketId("btc-5m-0001")
        other = MarketId("eth-5m-0002")

        lock = machine._lock_for(held)
        await lock.acquire()
        try:
            blocked = asyncio.create_task(machine.restore(held))
            free = asyncio.create_task(machine.restore(other))
            await asyncio.sleep(0.05)
            # Same-market call must wait for the held lock.
            assert not blocked.done()
            # A different market is never blocked by an unrelated lock.
            assert free.done()
            assert await free is None
        finally:
            lock.release()

        assert await blocked is None  # proceeds once the lock is released

    asyncio.run(scenario())


def test_concurrent_same_market_process_is_serialized() -> None:
    """Two concurrent same-market events must not overlap their critical section.

    The store load is instrumented to detect overlap. Without the per-market
    lock both events would cache-miss and load concurrently (overlap == 2);
    with the lock the first populates the cache before the second runs, so the
    authoritative load happens exactly once and overlap never exceeds one.
    """

    async def scenario() -> None:
        store = FakeSessionStore()
        real_load = store.load
        gauge = {"active": 0, "max": 0, "calls": 0}

        async def instrumented_load(market_id: MarketId):
            gauge["calls"] += 1
            gauge["active"] += 1
            gauge["max"] = max(gauge["max"], gauge["active"])
            try:
                await asyncio.sleep(0.02)
                return await real_load(market_id)
            finally:
                gauge["active"] -= 1

        store.load = instrumented_load  # type: ignore[method-assign]
        harness = build_harness(store=store)
        market = harness.market

        ev1 = MarketValidatedEvent(
            event_id="e1",
            market_id=market.market_id,
            occurred_at=UnixTimestamp(1),
            market=market,
        )
        ev2 = BooksUpdatedEvent(
            event_id="e2",
            market_id=market.market_id,
            occurred_at=UnixTimestamp(2),
            market=market,
            up_book=None,
            down_book=None,
            up_is_fresh=False,
            down_is_fresh=False,
            feed_live=False,
            seconds_to_close=100,
        )

        await asyncio.gather(
            harness.machine.process(ev1),
            harness.machine.process(ev2),
        )

        assert gauge["max"] == 1  # critical section never overlapped
        assert gauge["calls"] == 1  # cache hit for the second event

    asyncio.run(scenario())
