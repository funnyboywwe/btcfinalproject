"""Unit tests for the async risk services (Modules 13-14 orchestration)."""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.entities import ReconciliationResult
from polymarket_pair_bot.domain.enums import ReconciliationStatus, RiskVerdict
from polymarket_pair_bot.domain.value_objects import UnixTimestamp
from polymarket_pair_bot.risk.engine import RiskEngine
from polymarket_pair_bot.risk.kill_switch import (
    CompositeKillSwitch,
    EnvKillSwitch,
    KillSwitchSignal,
    ProcessKillSwitch,
)
from polymarket_pair_bot.risk.ports import ReconciliationHealth
from polymarket_pair_bot.risk.service import KillSwitchService, RiskEngineService
from tests.fixtures.risk import (
    FakeFeedProvider,
    FakeKillSwitchStore,
    FakeReconciliationProvider,
    FakeRiskUnitOfWorkFactory,
    StaticSource,
    approving_context,
    make_limits,
)


def _inactive_composite() -> CompositeKillSwitch:
    return CompositeKillSwitch([StaticSource("p", KillSwitchSignal("p", False))])


async def test_service_approves_and_persists_decision() -> None:
    factory = FakeRiskUnitOfWorkFactory()
    service = RiskEngineService(
        RiskEngine(make_limits()),
        _inactive_composite(),
        factory,
        clock=lambda: 1234,
    )
    evaluation = await service.evaluate(approving_context())
    assert evaluation.verdict is RiskVerdict.APPROVE
    assert len(factory.recorded.decisions) == 1
    assert len(factory.recorded.audits) == 1
    assert factory.recorded.commits == 1
    audit = factory.recorded.audits[0]
    assert audit["event_type"] == "risk.decision"
    assert audit["severity"] == "info"


async def test_service_persists_rejections_with_warning_severity() -> None:
    factory = FakeRiskUnitOfWorkFactory()
    service = RiskEngineService(
        RiskEngine(make_limits()), _inactive_composite(), factory
    )
    evaluation = await service.evaluate(
        approving_context(is_execution_leader=None)
    )
    assert evaluation.verdict is RiskVerdict.REJECT
    assert factory.recorded.audits[0]["severity"] == "warning"
    assert len(factory.recorded.decisions) == 1


async def test_service_injects_kill_switch_state() -> None:
    factory = FakeRiskUnitOfWorkFactory()
    composite = CompositeKillSwitch(
        [StaticSource("p", KillSwitchSignal("p", True, "halt"))]
    )
    service = RiskEngineService(RiskEngine(make_limits()), composite, factory)
    evaluation = await service.evaluate(approving_context())
    assert evaluation.verdict is RiskVerdict.REJECT
    assert "kill_switch" in {o.rule for o in evaluation.failures()}


def _kill_switch_service(
    *,
    store: FakeKillSwitchStore,
    process: ProcessKillSwitch,
    factory: FakeRiskUnitOfWorkFactory,
    reconciliation: ReconciliationHealth | None,
    feeds_healthy: bool,
    env_active: bool = False,
    clock_value: int = 1_000,
) -> KillSwitchService:
    env = EnvKillSwitch(
        "PPB_KILL", env_reader=lambda key: "on" if env_active else None
    )
    composite = CompositeKillSwitch(
        [process, env, StaticSource("redis", KillSwitchSignal("redis", False))]
    )
    return KillSwitchService(
        key="ppb:kill_switch",
        redis_store=store,
        uow_factory=factory,
        process_switch=process,
        composite=composite,
        env_switch=env,
        reconciliation_provider=FakeReconciliationProvider(reconciliation),
        feed_provider=FakeFeedProvider(feeds_healthy),
        max_reconciliation_age_seconds=300,
        clock=lambda: clock_value,
    )


async def test_activate_writes_all_levels() -> None:
    store = FakeKillSwitchStore()
    process = ProcessKillSwitch()
    factory = FakeRiskUnitOfWorkFactory()
    service = _kill_switch_service(
        store=store,
        process=process,
        factory=factory,
        reconciliation=ReconciliationHealth(ReconciliationStatus.CONSISTENT, 1000),
        feeds_healthy=True,
    )
    snapshot = await service.activate(reason="manual halt", actor="ops")
    assert snapshot.active is True
    assert process.is_active() is True
    assert store.calls == ["activate"]
    row = factory.recorded.kill_switch_rows[-1]
    assert row["active"] is True
    assert row["reason"] == "manual halt"
    assert isinstance(row["created_at"], UnixTimestamp)


async def test_clear_succeeds_when_preconditions_met() -> None:
    store = FakeKillSwitchStore(active=True)
    process = ProcessKillSwitch()
    process.trip("halt")
    factory = FakeRiskUnitOfWorkFactory()
    service = _kill_switch_service(
        store=store,
        process=process,
        factory=factory,
        reconciliation=ReconciliationHealth(ReconciliationStatus.CONSISTENT, 1000),
        feeds_healthy=True,
    )
    result = await service.clear(reason="resolved", actor="ops")
    assert result.cleared is True
    assert process.is_active() is False
    assert store.calls[-1] == "deactivate"
    assert factory.recorded.kill_switch_rows[-1]["active"] is False


async def test_clear_denied_keeps_switch_active() -> None:
    store = FakeKillSwitchStore(active=True)
    process = ProcessKillSwitch()
    process.trip("halt")
    factory = FakeRiskUnitOfWorkFactory()
    service = _kill_switch_service(
        store=store,
        process=process,
        factory=factory,
        reconciliation=None,
        feeds_healthy=False,
    )
    result = await service.clear(reason="", actor="ops")
    assert result.cleared is False
    assert len(result.reasons) >= 1
    # nothing was written and the switch stays active
    assert process.is_active() is True
    assert factory.recorded.kill_switch_rows == []
    assert "deactivate" not in store.calls


async def test_clear_denied_when_env_switch_set() -> None:
    store = FakeKillSwitchStore(active=True)
    process = ProcessKillSwitch()
    factory = FakeRiskUnitOfWorkFactory()
    service = _kill_switch_service(
        store=store,
        process=process,
        factory=factory,
        reconciliation=ReconciliationHealth(ReconciliationStatus.CONSISTENT, 1000),
        feeds_healthy=True,
        env_active=True,
    )
    result = await service.clear(reason="resolved", actor="ops")
    assert result.cleared is False
    assert any("environment" in reason for reason in result.reasons)


async def test_trip_on_reconciliation_ignores_consistent() -> None:
    store = FakeKillSwitchStore()
    process = ProcessKillSwitch()
    factory = FakeRiskUnitOfWorkFactory()
    service = _kill_switch_service(
        store=store,
        process=process,
        factory=factory,
        reconciliation=None,
        feeds_healthy=True,
    )
    consistent = ReconciliationResult(
        status=ReconciliationStatus.CONSISTENT, as_of=UnixTimestamp(999)
    )
    assert await service.trip_on_reconciliation(consistent) is None
    assert process.is_active() is False


async def test_trip_on_reconciliation_activates_on_discrepancy() -> None:
    store = FakeKillSwitchStore()
    process = ProcessKillSwitch()
    factory = FakeRiskUnitOfWorkFactory()
    service = _kill_switch_service(
        store=store,
        process=process,
        factory=factory,
        reconciliation=None,
        feeds_healthy=True,
    )
    discrepancy = ReconciliationResult(
        status=ReconciliationStatus.DISCREPANCY,
        as_of=UnixTimestamp(999),
        discrepancies=("position mismatch on UP leg",),
    )
    snapshot = await service.trip_on_reconciliation(discrepancy)
    assert snapshot is not None
    assert process.is_active() is True
    row = factory.recorded.kill_switch_rows[-1]
    assert row["active"] is True
    assert "position mismatch" in row["reason"]
    assert Decimal(0) == Decimal(0)  # sanity: no float arithmetic used
