"""Unit tests for the asynchronous observation consumer (Module 10).

These tests use fully in-memory fake sinks and never touch a database, network
or disk, and never place an order. ``asyncio_mode = auto`` (pyproject) runs the
``async def`` tests without an explicit marker.
"""

from __future__ import annotations

import asyncio

from polymarket_pair_bot.strategy.observations import (
    CandidateObservation,
    DetectionObservation,
    ObservationConsumer,
    ObservationOverflowPolicy,
)
from tests.fixtures.detector import ExplodingObservationSink, InMemoryObservationSink


def _observation(seq: int, *, approved: bool = False) -> DetectionObservation:
    return DetectionObservation(
        market_id=f"btc-5m-{seq:04d}",
        window_open_epoch=1_700_000_000,
        window_close_epoch=1_700_000_300,
        evaluated_at_epoch=1_700_000_100 + seq,
        action="immediate_two_leg",
        engine_result="immediate_two_leg",
        matched_inventory="0",
        unmatched_up="0",
        unmatched_down="0",
        effective_pair_cost="0.97",
        effective_pair_cost_maker=None,
        expected_net_edge="0.03",
        seconds_to_close=200,
        up_book_age_seconds=0,
        down_book_age_seconds=0,
        risk_input_available=True,
        approved=approved,
        candidate_count=1,
        candidates=(
            CandidateObservation(
                side="up",
                role="taker",
                proposed_price="0.48",
                proposed_quantity="10",
                required_hedge_depth="10",
                effective_pair_cost="0.97",
                expected_net_edge="0.03",
                cancel_deadline_epoch=1_700_000_105,
                approved=approved,
            ),
        ),
        rejection_reasons=(),
    )


async def test_consumer_persists_all_submitted_then_closes() -> None:
    sink = InMemoryObservationSink()
    consumer = ObservationConsumer(sink=sink, drain_timeout_seconds=0.01)
    task = asyncio.create_task(consumer.run())
    for i in range(5):
        assert await consumer.submit(_observation(i)) is True
    consumer.request_stop()
    await asyncio.wait_for(task, timeout=5.0)

    assert len(sink.written) == 5
    assert sink.closed is True
    assert sink.flushed >= 1
    assert consumer.metrics.written == 5
    assert consumer.metrics.write_errors == 0


async def test_drop_oldest_overflow_policy_counts_drops() -> None:
    sink = InMemoryObservationSink()
    consumer = ObservationConsumer(
        sink=sink,
        max_queue_size=2,
        drain_timeout_seconds=0.01,
        policy=ObservationOverflowPolicy.DROP_OLDEST,
    )
    # Fill beyond capacity BEFORE the writer runs so overflow is exercised.
    for i in range(5):
        await consumer.submit(_observation(i))
    assert consumer.metrics.overflows == 3
    assert consumer.metrics.dropped == 3
    assert consumer.qsize() == 2

    task = asyncio.create_task(consumer.run())
    consumer.request_stop()
    await asyncio.wait_for(task, timeout=5.0)
    # Only the two most-recent survivors are written.
    assert len(sink.written) == 2
    assert consumer.metrics.written == 2


async def test_drop_newest_overflow_policy() -> None:
    sink = InMemoryObservationSink()
    consumer = ObservationConsumer(
        sink=sink,
        max_queue_size=2,
        drain_timeout_seconds=0.01,
        policy=ObservationOverflowPolicy.DROP_NEWEST,
    )
    results = [await consumer.submit(_observation(i)) for i in range(4)]
    assert results == [True, True, False, False]
    assert consumer.metrics.dropped == 2
    assert consumer.qsize() == 2

    task = asyncio.create_task(consumer.run())
    consumer.request_stop()
    await asyncio.wait_for(task, timeout=5.0)
    assert len(sink.written) == 2


async def test_writer_is_best_effort_on_sink_errors() -> None:
    sink = ExplodingObservationSink()
    consumer = ObservationConsumer(sink=sink, drain_timeout_seconds=0.01)
    task = asyncio.create_task(consumer.run())
    for i in range(3):
        await consumer.submit(_observation(i))
    consumer.request_stop()
    await asyncio.wait_for(task, timeout=5.0)

    assert consumer.metrics.write_errors >= 1
    assert consumer.metrics.written == 0
    # Graceful shutdown still closes the sink.
    assert sink.closed is True


async def test_block_policy_applies_backpressure() -> None:
    sink = InMemoryObservationSink()
    consumer = ObservationConsumer(
        sink=sink,
        max_queue_size=1,
        drain_timeout_seconds=0.01,
        policy=ObservationOverflowPolicy.BLOCK,
    )
    task = asyncio.create_task(consumer.run())
    # With the writer draining, BLOCK submits all eventually succeed.
    for i in range(4):
        assert await consumer.submit(_observation(i)) is True
    consumer.request_stop()
    await asyncio.wait_for(task, timeout=5.0)
    assert len(sink.written) == 4
    assert consumer.metrics.dropped == 0


def test_invalid_consumer_config_rejected() -> None:
    sink = InMemoryObservationSink()
    for kwargs in (
        {"max_queue_size": 0},
        {"batch_size": 0},
        {"drain_timeout_seconds": 0.0},
    ):
        try:
            ObservationConsumer(sink=sink, **kwargs)  # type: ignore[arg-type]
        except ValueError:
            continue
        raise AssertionError(f"expected ValueError for {kwargs}")
