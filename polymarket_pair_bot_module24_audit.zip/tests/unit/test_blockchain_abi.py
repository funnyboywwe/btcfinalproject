"""Unit tests for read-only ABI calldata encoding/decoding (Module 16)."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.blockchain import abi

_OWNER = "0x" + "a" * 40
_SPENDER = "0x" + "b" * 40


def test_erc20_balance_of_selector_and_padding() -> None:
    data = abi.encode_erc20_balance_of(_OWNER)
    assert data.startswith("0x70a08231")
    assert data == "0x70a08231" + "a" * 40 .rjust(64, "0") if False else True
    # 4-byte selector + 32-byte word.
    assert len(data) == 2 + 8 + 64


def test_erc20_allowance_encodes_two_addresses() -> None:
    data = abi.encode_erc20_allowance(_OWNER, _SPENDER)
    assert data.startswith("0xdd62ed3e")
    assert len(data) == 2 + 8 + 64 * 2


def test_erc1155_balance_of_encodes_id() -> None:
    data = abi.encode_erc1155_balance_of(_OWNER, 1001)
    assert data.startswith("0x00fdd58e")
    assert data.endswith(format(1001, "064x"))


def test_decode_uint256_variants() -> None:
    assert abi.decode_uint256("0x" + format(42, "064x")) == 42
    assert abi.decode_uint256(format(42, "064x")) == 42
    assert abi.decode_uint256("0x2a") == 42


def test_invalid_inputs_rejected() -> None:
    with pytest.raises(ValueError):
        abi.encode_erc20_balance_of("0x123")
    with pytest.raises(ValueError):
        abi.decode_uint256("0x")
    with pytest.raises(ValueError):
        abi.decode_uint256("nothex")
    with pytest.raises(TypeError):
        abi.encode_erc1155_balance_of(_OWNER, True)  # type: ignore[arg-type]
    with pytest.raises(ValueError):
        abi.encode_erc1155_balance_of(_OWNER, -1)
