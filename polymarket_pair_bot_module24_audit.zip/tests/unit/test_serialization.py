"""Unit tests for domain serialization helpers."""

from __future__ import annotations

import json
from decimal import Decimal

from polymarket_pair_bot.domain.entities import PriceLevel, Position
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.serialization import (
    collateral_from_str,
    dumps,
    probability_price_from_str,
    shares_from_str,
    to_jsonable,
)
from polymarket_pair_bot.domain.value_objects import (
    FeeAmount,
    ProbabilityPrice,
    Shares,
    TokenId,
)


def test_decimal_serialized_as_string() -> None:
    level = PriceLevel(ProbabilityPrice(Decimal("0.416667")), Shares(Decimal("3")))
    payload = to_jsonable(level)
    assert payload == {"price": {"value": "0.416667"}, "size": {"value": "3"}}
    assert isinstance(payload["price"]["value"], str)


def test_enum_serialized_as_value() -> None:
    pos = Position(
        token_id=TokenId("1"),
        side=OutcomeSide.UP,
        quantity=Shares(Decimal("10")),
        average_price=ProbabilityPrice(Decimal("0.4")),
        fees_paid=FeeAmount(Decimal("0.05")),
    )
    payload = to_jsonable(pos)
    assert payload["side"] == "up"


def test_dumps_is_deterministic_json() -> None:
    level = PriceLevel(ProbabilityPrice(Decimal("0.5")), Shares(Decimal("1")))
    text = dumps(level)
    assert json.loads(text) == {"price": {"value": "0.5"}, "size": {"value": "1"}}


def test_roundtrip_constructors_preserve_value() -> None:
    assert probability_price_from_str("0.5").value == Decimal("0.5")
    assert shares_from_str("12.5").value == Decimal("12.5")
    assert collateral_from_str("3.25").value == Decimal("3.25")
