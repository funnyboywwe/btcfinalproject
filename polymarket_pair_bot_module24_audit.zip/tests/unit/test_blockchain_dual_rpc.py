"""Unit tests for the dual-RPC comparison reader (Module 16)."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.blockchain.dual_rpc import (
    Conservative,
    DualRpcReader,
    Endpoint,
)
from polymarket_pair_bot.blockchain.errors import RpcDisagreementError
from polymarket_pair_bot.blockchain.resilience import CircuitBreaker, RetryPolicy
from tests.fixtures.blockchain import FakeClock, FakeEthereumRpc, FakeSleep


def _endpoint(rpc: FakeEthereumRpc, clock: FakeClock) -> Endpoint:
    breaker = CircuitBreaker(name=rpc.label, fail_threshold=5, reset_seconds=30, clock=clock)
    return Endpoint(
        rpc,
        breaker=breaker,
        policy=RetryPolicy(max_retries=2, backoff_base_seconds=0.1, backoff_max_seconds=1),
        sleep=FakeSleep(),
        rng=lambda: 0.0,
    )


async def test_read_exact_agreement() -> None:
    clock = FakeClock()
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", chain_id=137), clock),
        _endpoint(FakeEthereumRpc(label="secondary", chain_id=137), clock),
    )
    out = await reader.read_exact("chain_id", lambda rpc: rpc.chain_id())
    assert out.value == 137
    assert out.degraded is False


async def test_read_exact_disagreement_raises() -> None:
    clock = FakeClock()
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", chain_id=137), clock),
        _endpoint(FakeEthereumRpc(label="secondary", chain_id=80002), clock),
    )
    with pytest.raises(RpcDisagreementError):
        await reader.read_exact("chain_id", lambda rpc: rpc.chain_id())


async def test_read_int_conservative_min_within_tolerance() -> None:
    clock = FakeClock()
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", native_balance=1000), clock),
        _endpoint(FakeEthereumRpc(label="secondary", native_balance=1002), clock),
        tolerance_base_units=5,
    )
    out = await reader.read_int(
        "native", lambda rpc: rpc.get_balance("0x0"), conservative=Conservative.MIN
    )
    assert out.value == 1000  # min chosen
    assert out.degraded is False


async def test_read_int_conservative_max_for_nonce() -> None:
    clock = FakeClock()
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", nonce_latest=7), clock),
        _endpoint(FakeEthereumRpc(label="secondary", nonce_latest=8), clock),
        tolerance_base_units=2,
    )
    out = await reader.read_int(
        "nonce",
        lambda rpc: rpc.get_transaction_count("0x0"),
        conservative=Conservative.MAX,
    )
    assert out.value == 8  # max chosen


async def test_read_int_beyond_tolerance_raises() -> None:
    clock = FakeClock()
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", native_balance=1000), clock),
        _endpoint(FakeEthereumRpc(label="secondary", native_balance=2000), clock),
        tolerance_base_units=5,
    )
    with pytest.raises(RpcDisagreementError):
        await reader.read_int(
            "native", lambda rpc: rpc.get_balance("0x0"), conservative=Conservative.MIN
        )


async def test_single_endpoint_is_degraded() -> None:
    clock = FakeClock()
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", native_balance=1000), clock),
    )
    out = await reader.read_int(
        "native", lambda rpc: rpc.get_balance("0x0"), conservative=Conservative.MIN
    )
    assert out.value == 1000
    assert out.degraded is True


async def test_require_secondary_without_secondary_raises() -> None:
    clock = FakeClock()
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary"), clock),
        require_secondary=True,
    )
    with pytest.raises(RpcDisagreementError):
        await reader.read_exact("chain_id", lambda rpc: rpc.chain_id())


async def test_secondary_unavailable_degrades() -> None:
    clock = FakeClock()
    reader = DualRpcReader(
        _endpoint(FakeEthereumRpc(label="primary", native_balance=1000), clock),
        _endpoint(FakeEthereumRpc(label="secondary", fail_first=99), clock),
        tolerance_base_units=0,
    )
    out = await reader.read_int(
        "native", lambda rpc: rpc.get_balance("0x0"), conservative=Conservative.MIN
    )
    assert out.value == 1000
    assert out.degraded is True
    assert out.note == "secondary unavailable"
