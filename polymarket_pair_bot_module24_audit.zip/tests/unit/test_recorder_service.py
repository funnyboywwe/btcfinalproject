"""Unit tests for the recorder service orchestration (Module 7).

These tests use fully in-memory fakes (provider + sinks) and injected clocks /
sleep so they run deterministically without any network, disk, database or
pyarrow dependency, and without ever placing an order.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from decimal import Decimal
from pathlib import Path

import pytest

from polymarket_pair_bot.config.enums import RecorderOverflowPolicy
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.market_data import FeedStatus
from polymarket_pair_bot.domain.recording import RecordedPairSnapshot, SnapshotTrigger
from polymarket_pair_bot.recorder.buffer import BoundedSnapshotBuffer
from polymarket_pair_bot.recorder.config import RecorderRuntimeConfig
from polymarket_pair_bot.recorder.metrics import RecorderMetrics
from polymarket_pair_bot.recorder.sampler import SnapshotSampler
from polymarket_pair_bot.recorder.service import (
    MarketDataRecorder,
    executable_pair_cost,
)
from tests.fixtures.recorder import (
    DOWN_TOKEN,
    UP_TOKEN,
    FakeOrderBookProvider,
    FakeSnapshotSink,
    FakeSummarySink,
    make_quote,
)


def _build_recorder(
    *,
    provider: FakeOrderBookProvider,
    snapshot_sink: object,
    summary_sink: object,
    metrics: RecorderMetrics,
    tmp_path: Path,
    stop_after: int = 3,
) -> MarketDataRecorder:
    config = RecorderRuntimeConfig(
        output_dir=tmp_path,
        poll_interval_seconds=0.001,
        periodic_interval_seconds=0.001,
        write_batch_size=10,
        flush_interval_seconds=0.02,
    )
    sampler = SnapshotSampler(periodic_interval_seconds=0.001)
    buffer = BoundedSnapshotBuffer(
        max_size=100, policy=RecorderOverflowPolicy.DROP_OLDEST, metrics=metrics
    )
    mono = {"t": 0.0}
    wall = {"t": 1_700_000_000}
    calls = {"n": 0}
    holder: dict[str, MarketDataRecorder] = {}

    def monotonic() -> float:
        return mono["t"]

    def wall_clock() -> int:
        wall["t"] += 1
        return wall["t"]

    async def fake_sleep(_delay: float) -> None:
        calls["n"] += 1
        mono["t"] += 1.0
        if calls["n"] >= stop_after:
            holder["rec"].request_stop()
        await asyncio.sleep(0)

    recorder = MarketDataRecorder(
        provider=provider,
        sampler=sampler,
        buffer=buffer,
        snapshot_sink=snapshot_sink,  # type: ignore[arg-type]
        summary_sink=summary_sink,  # type: ignore[arg-type]
        config=config,
        window_id="btc-5m-window",
        market_slug="btc-updown",
        metrics=metrics,
        monotonic=monotonic,
        wall_clock=wall_clock,
        sleep=fake_sleep,
    )
    holder["rec"] = recorder
    return recorder


async def test_recorder_captures_persists_and_closes(tmp_path: Path) -> None:
    provider = FakeOrderBookProvider()
    snap_sink = FakeSnapshotSink()
    summ_sink = FakeSummarySink()
    metrics = RecorderMetrics()
    recorder = _build_recorder(
        provider=provider,
        snapshot_sink=snap_sink,
        summary_sink=summ_sink,
        metrics=metrics,
        tmp_path=tmp_path,
    )

    await asyncio.wait_for(recorder.run(), timeout=5.0)

    assert metrics.snapshots_captured >= 1
    # Every captured snapshot reached both sinks (persist_summaries default on).
    assert len(snap_sink.written) == metrics.snapshots_captured
    assert len(summ_sink.summaries) == metrics.snapshots_captured
    assert metrics.snapshots_written == metrics.snapshots_captured
    assert metrics.summaries_written == metrics.snapshots_captured
    assert metrics.write_errors == 0
    # Sinks are always closed for graceful shutdown.
    assert snap_sink.closed is True
    assert summ_sink.closed is True

    first = snap_sink.written[0]
    assert first.window_id == "btc-5m-window"
    assert first.market_slug == "btc-updown"
    assert first.up.token_id == UP_TOKEN
    assert first.down.token_id == DOWN_TOKEN
    assert SnapshotTrigger.PERIODIC in first.triggers
    # 0.60 + 0.60 top-of-book proxy (Decimal, never a float).
    assert first.executable_pair_cost == Decimal("1.20")
    assert first.top_depth == 10


async def test_recorder_survives_sink_errors(tmp_path: Path) -> None:
    class ExplodingSnapshotSink:
        def __init__(self) -> None:
            self.closed = False

        async def write_batch(
            self, snapshots: Sequence[RecordedPairSnapshot]
        ) -> int:
            raise RuntimeError("disk on fire")

        async def flush(self) -> None:
            return None

        async def aclose(self) -> None:
            self.closed = True

    provider = FakeOrderBookProvider()
    snap_sink = ExplodingSnapshotSink()
    summ_sink = FakeSummarySink()
    metrics = RecorderMetrics()
    recorder = _build_recorder(
        provider=provider,
        snapshot_sink=snap_sink,
        summary_sink=summ_sink,
        metrics=metrics,
        tmp_path=tmp_path,
    )

    # Best-effort writer: errors are counted, not raised.
    await asyncio.wait_for(recorder.run(), timeout=5.0)

    assert metrics.write_errors >= 1
    assert metrics.snapshots_written == 0
    assert snap_sink.closed is True
    assert summ_sink.closed is True


def test_executable_pair_cost_sums_best_asks() -> None:
    up = make_quote(OutcomeSide.UP, token_id=UP_TOKEN, best_ask="0.55")
    down = make_quote(OutcomeSide.DOWN, token_id=DOWN_TOKEN, best_ask="0.42")
    assert executable_pair_cost(up, down) == Decimal("0.97")


def test_executable_pair_cost_none_when_missing_ask() -> None:
    up = make_quote(
        OutcomeSide.UP,
        token_id=UP_TOKEN,
        status=FeedStatus.UNAVAILABLE,
        best_ask=None,
    )
    down = make_quote(OutcomeSide.DOWN, token_id=DOWN_TOKEN)
    assert executable_pair_cost(up, down) is None
