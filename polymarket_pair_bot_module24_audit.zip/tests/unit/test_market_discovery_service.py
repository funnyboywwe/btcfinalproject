"""Unit tests for the MarketDiscoveryService orchestration.

Uses in-memory fakes for the metadata source, the unit of work and the cache
so no HTTP, Postgres or Redis is touched. Verifies window matching, rejection
of contradictory metadata, persistence + cache wiring, and next-window preload.
"""

from __future__ import annotations

from collections.abc import Sequence
from types import TracebackType

import pytest

from polymarket_pair_bot.domain.coordination import MarketMetadata
from polymarket_pair_bot.domain.entities import BinaryMarket, MarketWindow
from polymarket_pair_bot.market_discovery.errors import (
    InvalidMarketMetadataError,
    MarketNotFoundError,
)
from polymarket_pair_bot.market_discovery.ports import RawMarket
from polymarket_pair_bot.market_discovery.service import MarketDiscoveryService
from polymarket_pair_bot.market_discovery.slugs import SlugTemplateStrategy
from tests.fixtures import gamma

# Clock inside the current test window (2025-01-01T00:02:30Z).
NOW_EPOCH = gamma.WINDOW_OPEN_EPOCH + 150


class FakeSource:
    """Maps a slug to a canned list of raw markets."""

    def __init__(self, by_slug: dict[str, list[RawMarket]]) -> None:
        self._by_slug = by_slug
        self.calls: list[str] = []

    async def fetch_markets_by_slug(self, slug: str) -> Sequence[RawMarket]:
        self.calls.append(slug)
        return list(self._by_slug.get(slug, []))


class FakeMarketRepo:
    def __init__(self) -> None:
        self.upserts: list[BinaryMarket] = []

    async def upsert_market(self, market: BinaryMarket) -> None:
        self.upserts.append(market)

    async def get_market(self, market_id: object) -> BinaryMarket | None:
        return None


class FakeWindowRepo:
    def __init__(self) -> None:
        self.upserts: list[MarketWindow] = []

    async def upsert_window(self, window: MarketWindow) -> None:
        self.upserts.append(window)

    async def get_window(self, market_id: object) -> MarketWindow | None:
        return None


class FakeUnitOfWork:
    def __init__(self) -> None:
        self.markets = FakeMarketRepo()
        self.windows = FakeWindowRepo()
        self.committed = False
        self.rolled_back = False

    async def __aenter__(self) -> "FakeUnitOfWork":
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> bool:
        if exc is not None and not self.committed:
            self.rolled_back = True
        return False

    async def commit(self) -> None:
        self.committed = True

    async def rollback(self) -> None:
        self.rolled_back = True


class FakeCache:
    def __init__(self) -> None:
        self.puts: list[tuple[MarketMetadata, int | None]] = []

    async def get(self, market_id: str) -> MarketMetadata | None:
        return None

    async def put(
        self, metadata: MarketMetadata, *, ttl_seconds: int | None = None
    ) -> None:
        self.puts.append((metadata, ttl_seconds))


SLUG_TEMPLATE = "btc-{open_epoch}"


def _slug(open_epoch: int) -> str:
    return f"btc-{open_epoch}"


def _service(
    source: FakeSource,
    *,
    uow: FakeUnitOfWork | None = None,
    cache: FakeCache | None = None,
    tolerance: int = 90,
) -> MarketDiscoveryService:
    return MarketDiscoveryService(
        source,
        SlugTemplateStrategy(SLUG_TEMPLATE),
        window_match_tolerance_seconds=tolerance,
        clock=lambda: NOW_EPOCH,
        uow_factory=(lambda: uow) if uow is not None else None,
        metadata_cache=cache,
        cache_ttl_seconds=17,
    )


@pytest.mark.asyncio
async def test_discover_current_persists_and_caches() -> None:
    source = FakeSource(
        {
            _slug(gamma.WINDOW_OPEN_EPOCH): [gamma.valid_market()],
            _slug(gamma.NEXT_OPEN_EPOCH): [gamma.next_window_market()],
        }
    )
    uow = FakeUnitOfWork()
    cache = FakeCache()
    service = _service(source, uow=uow, cache=cache)

    result = await service.run_once(preload_next=True)

    assert result.current.market_id == "512345"
    assert result.next is not None and result.next.market_id == "512346"
    assert result.persisted is True
    assert result.cached is True
    # Current + next both persisted and cached.
    assert len(uow.markets.upserts) == 2
    assert len(uow.windows.upserts) == 2
    assert uow.committed is True
    assert [ttl for _, ttl in cache.puts] == [17, 17]


@pytest.mark.asyncio
async def test_no_store_configured_reports_false() -> None:
    source = FakeSource({_slug(gamma.WINDOW_OPEN_EPOCH): [gamma.valid_market()]})
    service = _service(source)
    result = await service.run_once(preload_next=False)
    assert result.persisted is False
    assert result.cached is False
    assert result.next is None


@pytest.mark.asyncio
async def test_empty_response_raises_not_found() -> None:
    source = FakeSource({})
    service = _service(source)
    with pytest.raises(MarketNotFoundError):
        await service.run_once(preload_next=False)


@pytest.mark.asyncio
async def test_window_mismatch_rejected() -> None:
    # A valid market, but for a totally different window (1 day later).
    off_window = gamma.valid_market(
        start_iso="2025-01-02T00:00:00Z", end_iso="2025-01-02T00:05:00Z"
    )
    source = FakeSource({_slug(gamma.WINDOW_OPEN_EPOCH): [off_window]})
    service = _service(source)
    with pytest.raises(MarketNotFoundError):
        await service.run_once(preload_next=False)


@pytest.mark.asyncio
async def test_contradictory_metadata_is_skipped_and_fails_closed() -> None:
    source = FakeSource(
        {_slug(gamma.WINDOW_OPEN_EPOCH): [gamma.contradictory_active_closed_market()]}
    )
    service = _service(source)
    with pytest.raises(InvalidMarketMetadataError):
        await service.run_once(preload_next=False)


@pytest.mark.asyncio
async def test_ambiguous_window_match_rejected() -> None:
    dup = gamma.valid_market(market_id="999999", slug="btc-dup")
    source = FakeSource(
        {_slug(gamma.WINDOW_OPEN_EPOCH): [gamma.valid_market(), dup]}
    )
    service = _service(source)
    with pytest.raises(InvalidMarketMetadataError):
        await service.run_once(preload_next=False)


@pytest.mark.asyncio
async def test_preload_failure_is_non_fatal() -> None:
    # Current window discoverable; next window returns nothing.
    source = FakeSource({_slug(gamma.WINDOW_OPEN_EPOCH): [gamma.valid_market()]})
    service = _service(source)
    result = await service.run_once(preload_next=True)
    assert result.current.market_id == "512345"
    assert result.next is None
