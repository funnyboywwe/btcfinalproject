"""Unit tests for authenticated readiness state tracking."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from polymarket_pair_bot.auth.readiness import (
    AuthReadinessState,
    AuthReadinessTracker,
)


async def test_initial_state_is_uninitialized_and_not_ready() -> None:
    tracker = AuthReadinessTracker()
    assert tracker.state is AuthReadinessState.UNINITIALIZED
    assert tracker.is_ready is False


async def test_client_ready_is_ready() -> None:
    tracker = AuthReadinessTracker()
    await tracker.set(AuthReadinessState.CLIENT_READY, "ready")
    assert tracker.is_ready is True


async def test_stream_message_marks_live_and_freshness() -> None:
    tracker = AuthReadinessTracker()
    now = datetime.now(UTC)
    await tracker.mark_stream_message(now)
    snap = tracker.snapshot()
    assert snap.state is AuthReadinessState.STREAM_LIVE
    assert snap.stream_is_fresh(now=now, max_age_seconds=30) is True
    assert (
        snap.stream_is_fresh(now=now + timedelta(seconds=60), max_age_seconds=30)
        is False
    )


async def test_missing_stream_message_is_not_fresh() -> None:
    snap = AuthReadinessTracker().snapshot()
    # Fail closed: no message means never fresh.
    assert snap.stream_is_fresh(now=datetime.now(UTC), max_age_seconds=30) is False
