"""Unit tests for the local L2 order book (Module 6)."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.value_objects import TokenId
from polymarket_pair_bot.market_data.book import LocalOrderBook
from polymarket_pair_bot.market_data.errors import (
    CrossedBookError,
    NegativeSizeError,
    UpdateBeforeSnapshotError,
)
from polymarket_pair_bot.market_data.messages import (
    parse_frame,
)
from tests.fixtures.market_data import (
    UP_TOKEN,
    book_message,
    price_change_message,
)


def _book() -> LocalOrderBook:
    return LocalOrderBook(TokenId(UP_TOKEN), OutcomeSide.UP)


def _snapshot(book: LocalOrderBook, bids, asks) -> None:
    msg = parse_frame(book_message(UP_TOKEN, bids=bids, asks=asks)).message
    assert msg is not None
    book.apply_snapshot(
        msg.bids,  # type: ignore[attr-defined]
        msg.asks,  # type: ignore[attr-defined]
        exchange_ts_ms=msg.timestamp,  # type: ignore[attr-defined]
        receipt_epoch=100,
        processed_epoch=101,
        monotonic=10.0,
    )


def _changes(book: LocalOrderBook, changes, *, monotonic: float = 11.0) -> None:
    msg = parse_frame(price_change_message(UP_TOKEN, changes=changes)).message
    assert msg is not None
    book.apply_changes(
        msg.changes,  # type: ignore[attr-defined]
        exchange_ts_ms=msg.timestamp,  # type: ignore[attr-defined]
        receipt_epoch=102,
        processed_epoch=103,
        monotonic=monotonic,
    )


def test_snapshot_sets_best_prices_and_timestamps() -> None:
    book = _book()
    _snapshot(book, bids=[("0.40", "100"), ("0.39", "200")], asks=[("0.60", "50")])
    assert book.has_snapshot
    assert book.best_bid == Decimal("0.40")
    assert book.best_ask == Decimal("0.60")
    assert book.bid_levels == 2
    assert book.bid_depth() == Decimal("300")
    assert book.exchange_timestamp_ms == 1700000000000
    assert book.local_receipt_epoch == 100
    assert book.processed_epoch == 101


def test_zero_size_level_removed_on_change() -> None:
    book = _book()
    _snapshot(book, bids=[("0.40", "100")], asks=[("0.60", "50")])
    _changes(book, changes=[("0.40", "BUY", "0")])
    assert book.best_bid is None
    assert book.bid_levels == 0


def test_zero_size_level_omitted_in_snapshot() -> None:
    book = _book()
    _snapshot(book, bids=[("0.40", "0"), ("0.39", "5")], asks=[("0.60", "1")])
    assert book.best_bid == Decimal("0.39")
    assert book.bid_levels == 1


def test_change_before_snapshot_rejected() -> None:
    book = _book()
    with pytest.raises(UpdateBeforeSnapshotError):
        _changes(book, changes=[("0.40", "BUY", "1")])


def test_negative_size_rejected() -> None:
    book = _book()
    with pytest.raises(NegativeSizeError):
        _snapshot(book, bids=[("0.40", "-1")], asks=[])


def test_crossed_snapshot_rejected() -> None:
    book = _book()
    with pytest.raises(CrossedBookError):
        _snapshot(book, bids=[("0.60", "1")], asks=[("0.50", "1")])


def test_crossed_change_leaves_book_intact() -> None:
    book = _book()
    _snapshot(book, bids=[("0.40", "10")], asks=[("0.60", "10")])
    with pytest.raises(CrossedBookError):
        _changes(book, changes=[("0.70", "BUY", "5")])
    # The rejected update must not have mutated the book.
    assert book.best_bid == Decimal("0.40")
    assert book.best_ask == Decimal("0.60")


def test_reset_requires_new_snapshot() -> None:
    book = _book()
    _snapshot(book, bids=[("0.40", "10")], asks=[("0.60", "10")])
    book.reset()
    assert not book.has_snapshot
    with pytest.raises(UpdateBeforeSnapshotError):
        _changes(book, changes=[("0.40", "BUY", "1")])


def test_to_snapshot_is_sorted() -> None:
    book = _book()
    _snapshot(
        book,
        bids=[("0.39", "1"), ("0.41", "2"), ("0.40", "3")],
        asks=[("0.62", "1"), ("0.60", "2"), ("0.61", "3")],
    )
    snap = book.to_snapshot(as_of_epoch=200)
    assert [level.price.value for level in snap.bids] == [
        Decimal("0.41"),
        Decimal("0.40"),
        Decimal("0.39"),
    ]
    assert [level.price.value for level in snap.asks] == [
        Decimal("0.60"),
        Decimal("0.61"),
        Decimal("0.62"),
    ]
    assert snap.best_bid is not None and snap.best_bid.price.value == Decimal("0.41")
