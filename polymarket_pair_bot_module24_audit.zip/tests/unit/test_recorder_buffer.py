"""Unit tests for the bounded snapshot buffer and its overflow policy."""

from __future__ import annotations

import asyncio
from decimal import Decimal

import pytest

from polymarket_pair_bot.config.enums import RecorderOverflowPolicy
from polymarket_pair_bot.domain.recording import (
    DataQualityFlags,
    RecordedBookSide,
    RecordedPairSnapshot,
)
from polymarket_pair_bot.recorder.buffer import BoundedSnapshotBuffer
from polymarket_pair_bot.recorder.metrics import RecorderMetrics


def _flags() -> DataQualityFlags:
    return DataQualityFlags(
        has_snapshot=True,
        is_live=True,
        is_stale=False,
        is_unavailable=False,
        is_crossed=False,
        is_empty=False,
        missing_best_bid=False,
        missing_best_ask=False,
        missing_exchange_timestamp=False,
    )


def _side(token: str) -> RecordedBookSide:
    return RecordedBookSide(
        side="up",
        token_id=token,
        status="live",
        best_bid=Decimal("0.40"),
        best_ask=Decimal("0.60"),
        best_bid_size=Decimal("100"),
        best_ask_size=Decimal("100"),
        spread=Decimal("0.20"),
        mid=Decimal("0.50"),
        bid_levels_count=1,
        ask_levels_count=1,
        bid_depth_total=Decimal("100"),
        ask_depth_total=Decimal("100"),
        bids=(),
        asks=(),
        exchange_timestamp_ms=1,
        local_receipt_epoch=1,
        processed_epoch=1,
        age_seconds=0.1,
        flags=_flags(),
    )


def _snapshot(sequence: int) -> RecordedPairSnapshot:
    return RecordedPairSnapshot(
        window_id="w",
        market_slug="slug",
        sequence=sequence,
        capture_epoch=1_700_000_000 + sequence,
        triggers=(),
        up=_side("1"),
        down=_side("2"),
        executable_pair_cost=Decimal("1.00"),
        pair_cost_level=None,
        top_depth=10,
    )


async def test_drop_newest_keeps_backlog() -> None:
    metrics = RecorderMetrics()
    buffer = BoundedSnapshotBuffer(
        max_size=1, policy=RecorderOverflowPolicy.DROP_NEWEST, metrics=metrics
    )
    assert await buffer.put(_snapshot(1)) is True
    assert await buffer.put(_snapshot(2)) is False
    assert metrics.buffer_overflows == 1
    assert metrics.dropped_records == 1
    drained = buffer.drain_nowait()
    assert [s.sequence for s in drained] == [1]


async def test_drop_oldest_evicts_head() -> None:
    metrics = RecorderMetrics()
    buffer = BoundedSnapshotBuffer(
        max_size=1, policy=RecorderOverflowPolicy.DROP_OLDEST, metrics=metrics
    )
    await buffer.put(_snapshot(1))
    assert await buffer.put(_snapshot(2)) is True
    assert metrics.buffer_overflows == 1
    assert metrics.dropped_records == 1
    drained = buffer.drain_nowait()
    assert [s.sequence for s in drained] == [2]


async def test_block_applies_backpressure_until_space() -> None:
    buffer = BoundedSnapshotBuffer(
        max_size=1, policy=RecorderOverflowPolicy.BLOCK
    )
    await buffer.put(_snapshot(1))
    put_task = asyncio.create_task(buffer.put(_snapshot(2)))
    await asyncio.sleep(0)
    assert not put_task.done()  # blocked, buffer full
    got = await buffer.drain(max_items=1, timeout=1.0)
    assert [s.sequence for s in got] == [1]
    assert await put_task is True
    remaining = buffer.drain_nowait()
    assert [s.sequence for s in remaining] == [2]


async def test_drain_times_out_to_empty_list() -> None:
    buffer = BoundedSnapshotBuffer(
        max_size=4, policy=RecorderOverflowPolicy.DROP_OLDEST
    )
    assert await buffer.drain(max_items=4, timeout=0.01) == []


async def test_drain_batches_multiple_items() -> None:
    buffer = BoundedSnapshotBuffer(
        max_size=4, policy=RecorderOverflowPolicy.DROP_OLDEST
    )
    for i in range(3):
        await buffer.put(_snapshot(i))
    batch = await buffer.drain(max_items=10, timeout=1.0)
    assert [s.sequence for s in batch] == [0, 1, 2]


def test_max_size_must_be_positive() -> None:
    with pytest.raises(ValueError):
        BoundedSnapshotBuffer(max_size=0, policy=RecorderOverflowPolicy.BLOCK)
