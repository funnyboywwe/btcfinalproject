"""Unit tests for the reconciliation ChainStateProvider adapter (Module 16)."""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.blockchain.dual_rpc import DualRpcReader, Endpoint
from polymarket_pair_bot.blockchain.reconciliation_provider import (
    WalletServiceChainStateProvider,
)
from polymarket_pair_bot.blockchain.resilience import CircuitBreaker, RetryPolicy
from polymarket_pair_bot.blockchain.service import ChainReadParams, WalletStateService
from polymarket_pair_bot.domain.value_objects import TokenId
from tests.fixtures.blockchain import (
    CTF_ADDRESS,
    DOWN_TOKEN,
    UP_TOKEN,
    USDC_ADDRESS,
    WALLET_ADDRESS,
    FakeClock,
    FakeEthereumRpc,
    FakeSleep,
    collateral_calldata,
    token_calldata,
)


def _service(rpc: FakeEthereumRpc, *, usdc: str | None = USDC_ADDRESS) -> WalletStateService:
    clock = FakeClock()
    breaker = CircuitBreaker(name=rpc.label, fail_threshold=5, reset_seconds=30, clock=clock)
    endpoint = Endpoint(
        rpc,
        breaker=breaker,
        policy=RetryPolicy(max_retries=0, backoff_base_seconds=0.1, backoff_max_seconds=1),
        sleep=FakeSleep(),
        rng=lambda: 0.0,
    )
    params = ChainReadParams(
        chain_id=137,
        wallet_address=WALLET_ADDRESS,
        usdc_address=usdc,
        conditional_tokens_address=CTF_ADDRESS,
    )
    return WalletStateService(DualRpcReader(endpoint), params, clock=clock)


async def test_provider_maps_snapshot_to_chain_state() -> None:
    rpc = FakeEthereumRpc(
        call_returns={
            collateral_calldata(): 9_000_000,
            token_calldata(UP_TOKEN): 1_000_000,
            token_calldata(DOWN_TOKEN): 1_000_000,
        },
    )
    provider = WalletServiceChainStateProvider(_service(rpc))
    state = await provider.load([TokenId(UP_TOKEN), TokenId(DOWN_TOKEN)])
    assert state.available is True
    assert state.collateral_balance == Decimal(9)
    assert state.token_balances[UP_TOKEN] == Decimal(1)
    assert state.note is not None  # degraded (single RPC) note recorded


async def test_provider_reports_unavailable_on_error() -> None:
    # An RPC that always fails makes chain-id verification raise a ChainError,
    # which the provider converts to an "unavailable" ChainState (fail closed)
    # rather than fabricating balances.
    rpc = FakeEthereumRpc(fail_first=99)
    provider = WalletServiceChainStateProvider(_service(rpc))
    state = await provider.load([TokenId(UP_TOKEN)])
    assert state.available is False
    assert state.note is not None
