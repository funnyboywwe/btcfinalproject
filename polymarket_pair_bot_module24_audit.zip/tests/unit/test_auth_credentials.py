"""Unit tests for credential loading and redaction."""

from __future__ import annotations

import pytest
from pydantic import SecretStr

from polymarket_pair_bot.auth.credentials import (
    ConfigCredentialProvider,
    DerivedCredentialProvider,
)
from polymarket_pair_bot.auth.errors import (
    CredentialError,
    UnsupportedAuthOperationError,
)
from polymarket_pair_bot.config.models import PolymarketAuthSettings


def test_missing_credentials_lists_field_names() -> None:
    provider = ConfigCredentialProvider(PolymarketAuthSettings())
    with pytest.raises(CredentialError) as excinfo:
        provider.load()
    message = str(excinfo.value)
    assert "POLYMARKET_API_KEY" in message
    # The error names env vars, never secret values.
    assert "test-" not in message


def test_full_credentials_load_and_redact() -> None:
    provider = ConfigCredentialProvider(
        PolymarketAuthSettings(
            polymarket_api_key=SecretStr("real-key"),
            polymarket_api_secret=SecretStr("real-secret"),
            polymarket_api_passphrase=SecretStr("real-pass"),
        )
    )
    creds = provider.load()
    assert creds.as_header_material()["api_key"] == "real-key"
    # Neither repr nor str may leak the secret material.
    assert "real-key" not in repr(creds)
    assert "real-secret" not in str(creds)
    assert "REDACTED" in repr(creds)


def test_derived_provider_is_blocked() -> None:
    with pytest.raises(UnsupportedAuthOperationError) as excinfo:
        DerivedCredentialProvider().load()
    assert excinfo.value.operation == "derive_api_credentials"
