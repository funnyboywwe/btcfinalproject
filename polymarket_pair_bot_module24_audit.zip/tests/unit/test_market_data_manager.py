"""Unit tests for the OrderBookManager and freshness/status logic (Module 6)."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.market_data import FeedStatus, OrderBookProvider
from polymarket_pair_bot.domain.value_objects import TokenId
from polymarket_pair_bot.market_data.manager import OrderBookManager
from polymarket_pair_bot.market_data.messages import parse_frame
from tests.fixtures.market_data import (
    DOWN_TOKEN,
    UP_TOKEN,
    ManualClock,
    book_message,
    tick_size_message,
    trade_message,
)


def _manager(clock: ManualClock) -> OrderBookManager:
    wall = iter(range(1000, 100000))
    return OrderBookManager(
        TokenId(UP_TOKEN),
        TokenId(DOWN_TOKEN),
        stale_after_seconds=5.0,
        monotonic=clock,
        wall_clock=lambda: next(wall),
    )


def _apply(manager: OrderBookManager, payload: dict) -> None:
    msg = parse_frame(payload).message
    assert msg is not None
    manager.apply_message(msg)  # type: ignore[arg-type]


def test_manager_is_order_book_provider() -> None:
    manager = _manager(ManualClock())
    assert isinstance(manager, OrderBookProvider)


def test_rejects_equal_token_ids() -> None:
    with pytest.raises(ValueError):
        OrderBookManager(TokenId(UP_TOKEN), TokenId(UP_TOKEN))


def test_status_progression_to_live() -> None:
    clock = ManualClock(start=100.0)
    manager = _manager(clock)
    # Disconnected before connect.
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.UNAVAILABLE
    manager.mark_connected()
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.AWAITING_SNAPSHOT
    _apply(manager, book_message(UP_TOKEN, bids=[("0.40", "10")], asks=[("0.60", "5")]))
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.LIVE
    assert manager.is_fresh(OutcomeSide.UP)


def test_stale_after_age_exceeds_bound() -> None:
    clock = ManualClock(start=100.0)
    manager = _manager(clock)
    manager.mark_connected()
    _apply(manager, book_message(UP_TOKEN, bids=[("0.40", "10")], asks=[("0.60", "5")]))
    clock.advance(6.0)  # exceeds stale_after_seconds=5
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.STALE
    assert not manager.is_fresh(OutcomeSide.UP)


def test_disconnect_marks_unavailable_and_requires_fresh_snapshot() -> None:
    clock = ManualClock(start=100.0)
    manager = _manager(clock)
    manager.mark_connected()
    _apply(manager, book_message(UP_TOKEN, bids=[("0.40", "10")], asks=[("0.60", "5")]))
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.LIVE
    manager.mark_disconnected()
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.UNAVAILABLE
    # Reconnect: connected again but the book must await a fresh snapshot.
    manager.note_reconnect()
    manager.mark_connected()
    assert manager.reconnect_count == 1
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.AWAITING_SNAPSHOT
    assert manager.snapshot(OutcomeSide.UP) is None


def test_quote_reports_top_of_book_and_depth() -> None:
    clock = ManualClock(start=100.0)
    manager = _manager(clock)
    manager.mark_connected()
    _apply(
        manager,
        book_message(
            UP_TOKEN,
            bids=[("0.40", "10"), ("0.39", "20")],
            asks=[("0.60", "5"), ("0.61", "7")],
        ),
    )
    quote = manager.quote(OutcomeSide.UP)
    assert quote.best_bid is not None and quote.best_bid.value == Decimal("0.40")
    assert quote.best_ask is not None and quote.best_ask.value == Decimal("0.60")
    assert quote.best_bid_size is not None and quote.best_bid_size.value == Decimal("10")
    assert quote.spread == Decimal("0.20")
    assert quote.bid_depth.value == Decimal("30")
    assert quote.ask_depth.value == Decimal("12")
    assert quote.exchange_timestamp_ms == 1700000000000
    assert quote.age_seconds == 0.0
    assert not quote.is_crossed


def test_independent_up_and_down_books() -> None:
    clock = ManualClock(start=100.0)
    manager = _manager(clock)
    manager.mark_connected()
    _apply(manager, book_message(UP_TOKEN, bids=[("0.30", "1")], asks=[("0.70", "1")]))
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.LIVE
    # Down has no snapshot yet -> still awaiting, proving independence.
    assert manager.feed_status(OutcomeSide.DOWN) is FeedStatus.AWAITING_SNAPSHOT
    _apply(
        manager, book_message(DOWN_TOKEN, bids=[("0.45", "2")], asks=[("0.55", "2")])
    )
    assert manager.feed_status(OutcomeSide.DOWN) is FeedStatus.LIVE
    up = manager.quote(OutcomeSide.UP)
    down = manager.quote(OutcomeSide.DOWN)
    assert up.best_bid is not None and up.best_bid.value == Decimal("0.30")
    assert down.best_bid is not None and down.best_bid.value == Decimal("0.45")


def test_tick_size_and_trade_recorded_without_affecting_book() -> None:
    clock = ManualClock(start=100.0)
    manager = _manager(clock)
    manager.mark_connected()
    _apply(manager, book_message(UP_TOKEN, bids=[("0.40", "10")], asks=[("0.60", "5")]))
    _apply(manager, tick_size_message(UP_TOKEN, new="0.001"))
    _apply(manager, trade_message(UP_TOKEN, price="0.50", size="3"))
    assert manager.tick_size(OutcomeSide.UP) == Decimal("0.001")
    assert manager.last_trade_price(OutcomeSide.UP) == Decimal("0.50")
    # Book top unaffected by tick/trade events.
    up = manager.quote(OutcomeSide.UP)
    assert up.best_bid is not None and up.best_bid.value == Decimal("0.40")


def test_message_for_unsubscribed_asset_ignored() -> None:
    clock = ManualClock(start=100.0)
    manager = _manager(clock)
    manager.mark_connected()
    _apply(manager, book_message("9" * 40, bids=[("0.40", "1")], asks=[("0.60", "1")]))
    assert manager.feed_status(OutcomeSide.UP) is FeedStatus.AWAITING_SNAPSHOT
