"""Unit tests for the execution gate (fail-closed default)."""

from __future__ import annotations

from polymarket_pair_bot.coordination.gate import ExecutionGate
from polymarket_pair_bot.domain.coordination import ExecutionGateView


def test_gate_starts_disabled() -> None:
    gate = ExecutionGate()
    assert gate.is_enabled is False
    assert "standby" in gate.reason.lower()


def test_enable_then_disable() -> None:
    gate = ExecutionGate()
    gate.enable("execution leader")
    assert gate.is_enabled is True
    gate.disable("lost leadership")
    assert gate.is_enabled is False
    assert gate.reason == "lost leadership"


def test_gate_is_execution_gate_view() -> None:
    gate = ExecutionGate()
    assert isinstance(gate, ExecutionGateView)
    snap = gate.snapshot()
    assert snap.enabled is False
