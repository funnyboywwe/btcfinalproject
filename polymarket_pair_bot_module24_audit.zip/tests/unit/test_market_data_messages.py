"""Unit tests for market-channel message validation (Module 6)."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.market_data.errors import MalformedMessageError
from polymarket_pair_bot.market_data.messages import (
    BookSide,
    BookSnapshotMessage,
    PriceChangeMessage,
    TickSizeChangeMessage,
    TradeMessage,
    parse_frame,
)
from tests.fixtures.market_data import (
    UP_TOKEN,
    book_message,
    price_change_message,
    tick_size_message,
    trade_message,
)


def test_parse_book_snapshot_decimal() -> None:
    parsed = parse_frame(
        book_message(UP_TOKEN, bids=[("0.40", "100")], asks=[("0.60", "50")])
    )
    assert not parsed.heartbeat
    msg = parsed.message
    assert isinstance(msg, BookSnapshotMessage)
    assert msg.asset_id == UP_TOKEN
    assert msg.timestamp == 1700000000000
    assert msg.bids[0].price == Decimal("0.40")
    assert isinstance(msg.bids[0].price, Decimal)
    assert msg.asks[0].size == Decimal("50")


def test_parse_price_change_side_mapping() -> None:
    parsed = parse_frame(
        price_change_message(
            UP_TOKEN, changes=[("0.41", "BUY", "10"), ("0.59", "SELL", "0")]
        )
    )
    msg = parsed.message
    assert isinstance(msg, PriceChangeMessage)
    assert msg.changes[0].side is BookSide.BID
    assert msg.changes[1].side is BookSide.ASK
    assert msg.changes[1].size == Decimal(0)


def test_parse_tick_size_and_trade() -> None:
    tick = parse_frame(tick_size_message(UP_TOKEN, new="0.01", old="0.001")).message
    assert isinstance(tick, TickSizeChangeMessage)
    assert tick.new_tick_size == Decimal("0.01")
    trade = parse_frame(trade_message(UP_TOKEN, price="0.55", size="3")).message
    assert isinstance(trade, TradeMessage)
    assert trade.price == Decimal("0.55")
    assert trade.side is BookSide.BID


@pytest.mark.parametrize("payload", ["PONG", "ping", "", {"type": "PONG"}, {}])
def test_heartbeats_are_ignored(payload: object) -> None:
    parsed = parse_frame(payload)
    assert parsed.heartbeat is True
    assert parsed.message is None


def test_unknown_event_type_is_malformed() -> None:
    with pytest.raises(MalformedMessageError):
        parse_frame({"event_type": "totally_made_up", "asset_id": UP_TOKEN})


def test_missing_event_type_is_malformed() -> None:
    with pytest.raises(MalformedMessageError):
        parse_frame({"asset_id": UP_TOKEN, "bids": []})


def test_float_numeric_is_rejected() -> None:
    # A binary float leaking in for a price must be rejected, not silently used.
    bad = book_message(UP_TOKEN)
    bad["bids"] = [{"price": 0.4, "size": "1"}]  # 0.4 is a Python float
    with pytest.raises(MalformedMessageError):
        parse_frame(bad)


def test_non_object_frame_is_malformed() -> None:
    with pytest.raises(MalformedMessageError):
        parse_frame(12345)


def test_unknown_side_is_malformed() -> None:
    with pytest.raises(MalformedMessageError):
        parse_frame(
            price_change_message(UP_TOKEN, changes=[("0.4", "SIDEWAYS", "1")])
        )


def test_batched_frames_parsed_individually() -> None:
    # The market channel may batch messages in a JSON array; each element is a
    # standalone frame that parse_frame validates on its own.
    batch = [
        book_message(UP_TOKEN, bids=[("0.4", "1")]),
        "PONG",
    ]
    results = [parse_frame(item) for item in batch]
    assert isinstance(results[0].message, BookSnapshotMessage)
    assert results[1].heartbeat
