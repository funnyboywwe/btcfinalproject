"""Unit tests for pure CTF ABI argument encoding (keccak-free)."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.ctf.encoding import (
    encode_address,
    encode_bytes32,
    encode_uint256,
    encode_uint256_array,
    validate_binary_index_sets,
)
from polymarket_pair_bot.ctf.errors import CtfValidationError


def test_encode_address_pads_to_word() -> None:
    out = encode_address("0x" + "ab" * 20)
    assert len(out) == 64
    assert out == "0" * 24 + "ab" * 20


def test_encode_address_rejects_bad_length() -> None:
    with pytest.raises(CtfValidationError):
        encode_address("0x1234")


def test_encode_bytes32_roundtrip() -> None:
    value = "0x" + "cd" * 32
    assert encode_bytes32(value) == "cd" * 32


def test_encode_uint256_basic() -> None:
    assert encode_uint256(1) == "0" * 63 + "1"
    assert encode_uint256(0) == "0" * 64


def test_encode_uint256_rejects_bool_and_negative() -> None:
    with pytest.raises(CtfValidationError):
        encode_uint256(True)
    with pytest.raises(CtfValidationError):
        encode_uint256(-1)


def test_encode_uint256_rejects_overflow() -> None:
    with pytest.raises(CtfValidationError):
        encode_uint256(1 << 256)


def test_encode_uint256_array_layout() -> None:
    out = encode_uint256_array((1, 2))
    assert len(out) == 64 * 3
    assert out[:64] == encode_uint256(2)
    assert out[64:128] == encode_uint256(1)
    assert out[128:] == encode_uint256(2)


def test_validate_binary_index_sets_ok() -> None:
    assert validate_binary_index_sets(1, 2) == (1, 2)
    assert validate_binary_index_sets(2, 1) == (1, 2)


def test_validate_binary_index_sets_rejects_equal() -> None:
    with pytest.raises(CtfValidationError):
        validate_binary_index_sets(1, 1)


def test_validate_binary_index_sets_rejects_non_binary() -> None:
    with pytest.raises(CtfValidationError):
        validate_binary_index_sets(1, 4)
