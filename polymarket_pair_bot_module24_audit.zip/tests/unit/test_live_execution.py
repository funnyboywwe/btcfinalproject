"""LiveExecutionAdapter tests: guarded live order lifecycle (Module 14).

Every failure path is exercised against fakes; no test reaches a real write
endpoint. Covered: protocol conformance; gating (LIVE/PAPER, leadership, kill
switch, feeds, reconciliation, risk); validation (tick, notional, collateral,
allowance, unknown token); persistence-before-submit; idempotency claim +
replay-reconcile; ack-is-not-a-fill; taker fills + finalize; submission timeout
-> UNKNOWN + reconcile; clean vs uncertain rejection; bounded retry; cancels
allowed with kill switch on; reserve-aware cancel-and-replace; dry-run.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.config.models import LiveExecutionSettings
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus, TimeInForce
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    MarketId,
    OrderId,
)
from polymarket_pair_bot.execution.errors import (
    ExchangeErrorClass,
    ExchangeRejectedError,
)
from polymarket_pair_bot.execution.dry_run import DryRunOrderClient
from polymarket_pair_bot.execution.lifecycle import OrderLifecycleManager
from polymarket_pair_bot.execution.live import LiveExecutionAdapter
from polymarket_pair_bot.execution.live_models import CancelResult, OrderStateView
from polymarket_pair_bot.execution.ports import ExecutionAdapter
from polymarket_pair_bot.execution.submission_gate import LiveSubmissionGate
from polymarket_pair_bot.execution.types import CancelOutcome, SubmitOutcome

from tests.fixtures.execution import (
    MARKET,
    OPEN_S,
    UP,
    InMemoryPersistence,
    make_intent,
    make_market,
)
from tests.fixtures.live_execution import (
    FakeExecutionGate,
    FakeFeedHealth,
    FakeIdempotencyStore,
    FakeKillSwitch,
    FakeReconciliationStatus,
    FakeLiveOrderClient,
    PlaceBehavior,
    approve_decision,
    fill_record,
    make_live_harness,
    placement_ack,
)


def _buy(intent_id: str = "i-1", *, price: str = "0.40", size: str = "100", tif=TimeInForce.GTC):
    return make_intent(intent_id, price=price, size=size, tif=tif)


# --------------------------------------------------------------------------- #
# Protocol conformance
# --------------------------------------------------------------------------- #
def test_adapter_satisfies_execution_adapter_protocol() -> None:
    harness = make_live_harness()
    assert isinstance(harness.adapter, ExecutionAdapter)


# --------------------------------------------------------------------------- #
# Happy path
# --------------------------------------------------------------------------- #
async def test_maker_submit_persists_intent_and_ack_not_fill() -> None:
    h = make_live_harness()
    h.client.default_place = PlaceBehavior(placement=placement_ack("o-1"))
    ack = await h.adapter.submit_order(_buy("i-1"))
    assert ack.outcome is SubmitOutcome.ACCEPTED
    assert ack.order.status is OrderStatus.ACKNOWLEDGED  # ack != fill
    assert ack.order.filled_size.value == 0
    # Intent persisted before submission (req 4).
    assert "i-1" in h.persistence.intents.items
    # Idempotency key claimed (req 5).
    assert await h.idempotency.is_claimed("submit:i-1")
    assert len(h.client.place_calls) == 1
    assert h.client.place_calls[0].post_only is True


async def test_taker_submit_applies_authoritative_fills_and_finalizes() -> None:
    h = make_live_harness()
    h.client.default_place = PlaceBehavior(placement=placement_ack("o-2"))
    h.client.fills_by_order["o-2"] = [fill_record("f-1", "o-2", size="100")]
    ack = await h.adapter.submit_order(_buy("i-2", tif=TimeInForce.FOK))
    assert ack.outcome is SubmitOutcome.ACCEPTED
    assert ack.order.status is OrderStatus.FILLED
    assert ack.order.filled_size.value == Decimal("100")
    # Taker orders are not post-only.
    assert h.client.place_calls[0].post_only is False


async def test_taker_partial_fill_is_canceled_remainder() -> None:
    h = make_live_harness()
    h.client.default_place = PlaceBehavior(placement=placement_ack("o-2b"))
    h.client.fills_by_order["o-2b"] = [fill_record("f-1", "o-2b", size="30")]
    ack = await h.adapter.submit_order(_buy("i-2b", tif=TimeInForce.IOC))
    assert ack.order.status is OrderStatus.CANCELED
    assert ack.order.filled_size.value == Decimal("30")


# --------------------------------------------------------------------------- #
# Gating
# --------------------------------------------------------------------------- #
async def test_submit_blocked_when_live_trading_off() -> None:
    h = make_live_harness(live_trading=False)
    h.client.default_place = PlaceBehavior(placement=placement_ack("x"))
    ack = await h.adapter.submit_order(_buy("i-3"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert h.client.place_calls == []  # never reached the client


async def test_submit_blocked_when_paper_trading_on() -> None:
    h = make_live_harness(paper_trading=True)
    ack = await h.adapter.submit_order(_buy("i-3b"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert h.client.place_calls == []


async def test_submit_blocked_when_no_leadership() -> None:
    h = make_live_harness()
    h.execution_gate.enabled = False
    ack = await h.adapter.submit_order(_buy("i-4"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert h.client.place_calls == []


async def test_submit_blocked_when_kill_switch_active() -> None:
    h = make_live_harness()
    h.kill_switch.active = True
    ack = await h.adapter.submit_order(_buy("i-5"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert h.client.place_calls == []


async def test_submit_blocked_when_risk_rejects() -> None:
    from tests.fixtures.live_execution import reject_decision

    h = make_live_harness()
    h.risk.decision = reject_decision()
    ack = await h.adapter.submit_order(_buy("i-6"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert h.client.place_calls == []


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #
async def test_submit_rejects_unknown_token() -> None:
    h = make_live_harness(register=False)
    ack = await h.adapter.submit_order(_buy("i-7"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "unknown_token"
    assert h.client.place_calls == []


async def test_submit_rejects_tick_misaligned_price() -> None:
    h = make_live_harness()
    ack = await h.adapter.submit_order(_buy("i-8", price="0.405"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "tick_size_misaligned"


async def test_submit_rejects_over_notional() -> None:
    settings = LiveExecutionSettings(live_max_order_notional_usd=Decimal("10"))
    h = make_live_harness(settings=settings)
    ack = await h.adapter.submit_order(_buy("i-9", price="0.40", size="100"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "exceeds_max_order_notional"


async def test_submit_rejects_insufficient_collateral() -> None:
    h = make_live_harness()
    h.allowance.collateral = CollateralAmount(Decimal("1"))
    ack = await h.adapter.submit_order(_buy("i-10", price="0.40", size="100"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "insufficient_collateral"


async def test_submit_fails_closed_when_allowance_unverified() -> None:
    h = make_live_harness()
    h.allowance.allowance = None
    ack = await h.adapter.submit_order(_buy("i-11"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert ack.reason == "collateral_or_allowance_unverified"


# --------------------------------------------------------------------------- #
# Idempotency
# --------------------------------------------------------------------------- #
async def test_idempotency_replay_reconciles_and_never_resubmits() -> None:
    h = make_live_harness()
    await h.idempotency.claim("submit:i-12", ttl_seconds=300)  # pre-claimed
    h.client.default_place = PlaceBehavior(placement=placement_ack("o-12"))
    ack = await h.adapter.submit_order(_buy("i-12"))
    assert ack.outcome is SubmitOutcome.UNKNOWN
    assert h.client.place_calls == []  # never resubmitted
    assert ack.order.status is OrderStatus.UNKNOWN


# --------------------------------------------------------------------------- #
# Timeout + rejection classification
# --------------------------------------------------------------------------- #
async def test_submission_timeout_marks_unknown_and_reconciles() -> None:
    settings = LiveExecutionSettings(
        live_submit_timeout_seconds=0.01, live_order_poll_interval_seconds=0.001
    )
    h = make_live_harness(settings=settings)
    h.client.default_place = PlaceBehavior(sleep_s=0.05)  # exceeds deadline
    ack = await h.adapter.submit_order(_buy("i-13"))
    assert ack.outcome is SubmitOutcome.UNKNOWN
    assert ack.order.status is OrderStatus.UNKNOWN
    # Reconciliation queried authoritative sources.
    # (open orders + fills were fetched during reconcile)


async def test_clean_rejection_is_rejected_not_retried() -> None:
    h = make_live_harness()
    err = ExchangeRejectedError(ExchangeErrorClass.POST_ONLY_WOULD_CROSS, code="post_only")
    h.client.default_place = PlaceBehavior(error=err)
    ack = await h.adapter.submit_order(_buy("i-14"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert len(h.client.place_calls) == 1  # no retry


async def test_unknown_rejection_triggers_reconcile_unknown() -> None:
    h = make_live_harness()
    err = ExchangeRejectedError(ExchangeErrorClass.UNKNOWN, code="weird")
    h.client.default_place = PlaceBehavior(error=err)
    ack = await h.adapter.submit_order(_buy("i-15"))
    assert ack.outcome is SubmitOutcome.UNKNOWN
    assert ack.order.status is OrderStatus.UNKNOWN


async def test_retryable_rejection_retries_within_bound_then_succeeds() -> None:
    settings = LiveExecutionSettings(
        live_max_submit_retries=2, live_order_poll_interval_seconds=0.001
    )
    h = make_live_harness(settings=settings)
    err = ExchangeRejectedError(ExchangeErrorClass.RATE_LIMITED, code="429")
    h.client.place_queue = [
        PlaceBehavior(error=err),
        PlaceBehavior(placement=placement_ack("o-16")),
    ]
    ack = await h.adapter.submit_order(_buy("i-16"))
    assert ack.outcome is SubmitOutcome.ACCEPTED
    assert len(h.client.place_calls) == 2


async def test_retryable_rejection_exhausts_bound_and_rejects() -> None:
    settings = LiveExecutionSettings(
        live_max_submit_retries=1, live_order_poll_interval_seconds=0.001
    )
    h = make_live_harness(settings=settings)
    err = ExchangeRejectedError(ExchangeErrorClass.RATE_LIMITED, code="429")
    h.client.default_place = PlaceBehavior(error=err)
    ack = await h.adapter.submit_order(_buy("i-17"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert len(h.client.place_calls) == 2  # initial + 1 retry


async def test_no_retry_by_default() -> None:
    h = make_live_harness()  # default live_max_submit_retries == 0
    err = ExchangeRejectedError(ExchangeErrorClass.RATE_LIMITED, code="429")
    h.client.default_place = PlaceBehavior(error=err)
    ack = await h.adapter.submit_order(_buy("i-17b"))
    assert ack.outcome is SubmitOutcome.REJECTED
    assert len(h.client.place_calls) == 1


# --------------------------------------------------------------------------- #
# Cancellation (NOT gated by kill switch)
# --------------------------------------------------------------------------- #
async def test_cancel_allowed_while_kill_switch_active() -> None:
    h = make_live_harness()
    h.kill_switch.active = True
    # Seed a resting order.
    h.client.default_place = PlaceBehavior(placement=placement_ack("o-18"))
    h.client.order_states["o-18"] = OrderStateView(
        order_id="o-18", status=OrderStatus.OPEN, original_size=Decimal("100")
    )
    h.client.cancel_results["o-18"] = CancelResult(
        order_id="o-18", outcome=CancelOutcome.ACCEPTED
    )
    ack = await h.adapter.cancel_order(OrderId("o-18"))
    assert ack.outcome is CancelOutcome.ACCEPTED
    assert h.client.cancel_calls == ["o-18"]


async def test_cancel_not_found_maps_to_unknown_order() -> None:
    h = make_live_harness()
    h.client.cancel_error = ExchangeRejectedError(
        ExchangeErrorClass.NOT_FOUND, code="not_found"
    )
    ack = await h.adapter.cancel_order(OrderId("ghost"))
    assert ack.outcome is CancelOutcome.UNKNOWN_ORDER


async def test_cancel_updates_persisted_order_to_canceled() -> None:
    h = make_live_harness()
    h.client.default_place = PlaceBehavior(placement=placement_ack("o-19"))
    await h.adapter.submit_order(_buy("i-19"))
    ack = await h.adapter.cancel_order(OrderId("o-19"))
    assert ack.outcome is CancelOutcome.ACCEPTED
    assert h.persistence.orders.items["o-19"].status is OrderStatus.CANCELED


# --------------------------------------------------------------------------- #
# Reserve-aware cancel-and-replace
# --------------------------------------------------------------------------- #
async def test_cancel_and_replace_places_only_after_reserve_freed() -> None:
    settings = LiveExecutionSettings(
        live_submit_timeout_seconds=0.05, live_order_poll_interval_seconds=0.001
    )
    h = make_live_harness(settings=settings)
    # Old order becomes terminal (canceled, unfilled) => reserve freed.
    h.client.order_states["old"] = OrderStateView(
        order_id="old", status=OrderStatus.CANCELED, original_size=Decimal("100")
    )
    h.client.default_place = PlaceBehavior(placement=placement_ack("new"))
    result = await h.adapter.cancel_and_replace(OrderId("old"), _buy("i-20"))
    assert result.replacement is not None
    assert result.replacement.outcome is SubmitOutcome.ACCEPTED


async def test_cancel_and_replace_withholds_when_old_order_filled() -> None:
    settings = LiveExecutionSettings(
        live_submit_timeout_seconds=0.05, live_order_poll_interval_seconds=0.001
    )
    h = make_live_harness(settings=settings)
    h.client.order_states["old"] = OrderStateView(
        order_id="old",
        status=OrderStatus.FILLED,
        original_size=Decimal("100"),
        filled_size=Decimal("100"),
    )
    h.client.default_place = PlaceBehavior(placement=placement_ack("new"))
    result = await h.adapter.cancel_and_replace(OrderId("old"), _buy("i-21"))
    assert result.replacement is None
    assert h.client.place_calls == []  # replacement withheld; reserve not freed


async def test_cancel_and_replace_withholds_when_terminal_unconfirmed() -> None:
    settings = LiveExecutionSettings(
        live_submit_timeout_seconds=0.02, live_order_poll_interval_seconds=0.01
    )
    h = make_live_harness(settings=settings)
    # No terminal state ever reported => cannot confirm reserve freed.
    h.client.order_states["old"] = OrderStateView(
        order_id="old", status=OrderStatus.OPEN, original_size=Decimal("100")
    )
    h.client.default_place = PlaceBehavior(placement=placement_ack("new"))
    result = await h.adapter.cancel_and_replace(OrderId("old"), _buy("i-22"))
    assert result.replacement is None
    assert h.client.place_calls == []


# --------------------------------------------------------------------------- #
# Fill-before-ack via public event entrypoint + queries
# --------------------------------------------------------------------------- #
async def test_process_fill_event_before_ack_creates_placeholder() -> None:
    h = make_live_harness()
    app = await h.adapter.process_fill_event(fill_record("f-1", "ghost", size="25"))
    assert app.is_new
    assert app.order is not None
    assert app.order.status is OrderStatus.UNKNOWN
    fills = await h.adapter.get_fills(order_id=OrderId("ghost"))
    assert len(fills) == 1


async def test_duplicate_fill_event_dedups() -> None:
    h = make_live_harness()
    await h.adapter.process_fill_event(fill_record("f-1", "o-x", size="25"))
    app = await h.adapter.process_fill_event(fill_record("f-1", "o-x", size="25"))
    assert app.is_new is False


async def test_get_open_orders_rebuilt_from_persistence() -> None:
    h = make_live_harness()
    h.client.default_place = PlaceBehavior(placement=placement_ack("o-23"))
    await h.adapter.submit_order(_buy("i-23"))
    open_orders = await h.adapter.get_open_orders(MARKET)
    assert any(o.order_id.value == "o-23" for o in open_orders)
    # No-arg iterates registered markets.
    assert len(await h.adapter.get_open_orders()) >= 1


# --------------------------------------------------------------------------- #
# Dry-run: full live path, guaranteed no real endpoint
# --------------------------------------------------------------------------- #
async def test_dry_run_client_runs_full_path_without_reaching_endpoint() -> None:
    persistence = InMemoryPersistence()
    real = FakeLiveOrderClient()  # stand-in for a would-be real client
    dry = DryRunOrderClient(real)
    gate = LiveSubmissionGate(
        live_trading=True,
        paper_trading=False,
        execution_gate=FakeExecutionGate(),
        kill_switch=FakeKillSwitch(),
        feeds=FakeFeedHealth(),
        reconciliation=FakeReconciliationStatus(),
        reconciliation_max_age_seconds=300,
    )
    from tests.fixtures.live_execution import FakeAllowanceProvider, FakeRiskProvider

    lifecycle = OrderLifecycleManager(persistence=persistence, now_s=lambda: OPEN_S + 10)
    adapter = LiveExecutionAdapter(
        client=dry,
        persistence=persistence,
        submission_gate=gate,
        lifecycle=lifecycle,
        allowance_provider=FakeAllowanceProvider(),
        risk_provider=FakeRiskProvider(decision=approve_decision()),
        settings=LiveExecutionSettings(),
        idempotency_store=FakeIdempotencyStore(),
        idempotency_ttl_seconds=300,
        now_s=lambda: OPEN_S + 10,
    )
    adapter.register_market(make_market())
    ack = await adapter.submit_order(_buy("i-24"))
    assert ack.outcome is SubmitOutcome.ACCEPTED
    assert ack.order.order_id.value == "dryrun-submit:i-24"
    assert ack.order.status is OrderStatus.ACKNOWLEDGED
    assert ack.order.filled_size.value == 0
    # The underlying (would-be real) client was never written to.
    assert real.place_calls == []
    assert real.cancel_calls == []
