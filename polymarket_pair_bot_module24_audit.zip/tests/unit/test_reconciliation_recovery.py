"""Crash-recovery reconciliation tests (Module 15, requirement 13).

Each test drives the reconciliation service through a scenario where the bot
crashed at a hazardous moment, then asserts the authoritative pass classifies
and recovers it safely: never inventing a matched pair, never silently
deleting data, importing confirmed fills idempotently, cancelling unknown
remote orders, and stopping new trading (fail closed) when uncertain.
"""

from __future__ import annotations

import pytest

from polymarket_pair_bot.domain.enums import OrderStatus
from polymarket_pair_bot.reconciliation.classification import ReconciliationClass
from polymarket_pair_bot.reconciliation.models import (
    ChainState,
    DiscrepancyKind,
    LocalState,
    RemoteAccountState,
)
from polymarket_pair_bot.reconciliation.service import (
    ReconciliationService,
    ReconciliationTuning,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from tests.fixtures.reconciliation import (
    FakeCanceller,
    FakeChainStateProvider,
    FakeFillImporter,
    FakeLocalStateProvider,
    FakeMarketScope,
    FakeRemoteAccountProvider,
    FakeSink,
    FakeTradingHalt,
    FixedClock,
    make_remote_fill,
    make_local_fill,
    make_merge_tx,
    make_remote_order,
    make_order,
)


def _service(
    *,
    local=None,
    remote=None,
    chain=None,
    tuning=None,
):
    importer = FakeFillImporter()
    canceller = FakeCanceller()
    halt = FakeTradingHalt()
    sink = FakeSink()
    service = ReconciliationService(
        local=FakeLocalStateProvider(local),
        remote=FakeRemoteAccountProvider(
            remote if remote is not None else RemoteAccountState(available=True)
        ),
        chain=FakeChainStateProvider(
            chain if chain is not None else ChainState(available=False)
        ),
        sink=sink,
        market_scope=FakeMarketScope(),
        importer=importer,
        canceller=canceller,
        halt=halt,
        tuning=tuning or ReconciliationTuning(),
        clock=FixedClock(9000),
    )
    return service, importer, canceller, halt, sink


def _kinds(report):
    return {d.kind for d in report.discrepancies}


@pytest.mark.asyncio
async def test_crash_before_acknowledgement() -> None:
    # Local recorded a SUBMITTED order; crashed before any ack/fill. Remote has
    # no such order and no fill -> must refresh status, never assume filled.
    local = LocalState(
        open_orders=(make_order(order_id="o-1", status=OrderStatus.SUBMITTED),)
    )
    service, importer, canceller, halt, sink = _service(local=local)
    report = await service.on_startup()
    assert DiscrepancyKind.LOCAL_OPEN_NOT_ON_REMOTE in _kinds(report)
    assert report.classification is ReconciliationClass.LOCAL_REPAIR_REQUIRED
    assert report.halts_new_trading
    assert importer.received == []  # nothing invented
    assert canceller.cancelled == []
    assert len(sink.persisted) == 1


@pytest.mark.asyncio
async def test_crash_after_partial_fill() -> None:
    # Local order OPEN with 0 filled; remote confirms it PARTIALLY_FILLED and a
    # matching fill exists remotely but not locally -> import + state mismatch.
    local = LocalState(
        open_orders=(make_order(order_id="o-1", status=OrderStatus.OPEN, filled="0"),)
    )
    remote = RemoteAccountState(
        available=True,
        open_orders=(
            make_remote_order(
                order_id="o-1",
                status=OrderStatus.PARTIALLY_FILLED,
                size_matched="2",
            ),
        ),
        fills=(make_remote_fill(fill_id="f-1", order_id="o-1"),),
    )
    service, importer, _canceller, halt, _sink = _service(
        local=local, remote=remote
    )
    report = await service.periodic()
    assert DiscrepancyKind.MISSING_LOCAL_FILL in _kinds(report)
    assert DiscrepancyKind.ORDER_STATE_MISMATCH in _kinds(report)
    assert importer.seen == {"f-1"}
    # A local-repair-required state must stop new trading (no matched pair yet).
    assert report.classification is ReconciliationClass.LOCAL_REPAIR_REQUIRED
    assert report.halts_new_trading


@pytest.mark.asyncio
async def test_crash_during_cancellation_keeps_cancelling_with_kill_switch_on() -> None:
    # We were cancelling; the kill switch is already engaged. The order is gone
    # locally (terminal) but remote still shows it OPEN -> unknown remote order
    # must still be cancelled even though trading is halted.
    remote = RemoteAccountState(
        available=True, open_orders=(make_remote_order(order_id="r-1"),)
    )
    service, _importer, canceller, halt, _sink = _service(remote=remote)
    halt.halted = True  # kill switch already on
    report = await service.periodic()
    assert report.classification is ReconciliationClass.CANCELLATION_REQUIRED
    assert canceller.cancelled == ["r-1"]  # cancellation still possible


@pytest.mark.asyncio
async def test_crash_after_fill_before_database_write() -> None:
    # Fill confirmed remotely but the process died before writing it locally.
    remote = RemoteAccountState(
        available=True, fills=(make_remote_fill(fill_id="f-1", order_id="o-1"),)
    )
    service, importer, _canceller, halt, _sink = _service(remote=remote)
    report = await service.on_user_stream_reconnect()
    assert report.classification is ReconciliationClass.AUTOMATICALLY_RECOVERABLE
    assert importer.seen == {"f-1"}
    assert not halt.halted  # importing a confirmed fill is safe


@pytest.mark.asyncio
async def test_crash_during_merge() -> None:
    # A merge transaction was in flight when we crashed.
    local = LocalState(pending_chain_txs=(make_merge_tx(operation_key="merge-7"),))
    service, _importer, _canceller, halt, _sink = _service(local=local)
    report = await service.after_merge()
    assert report.trigger is ReconciliationTrigger.POST_MERGE
    assert DiscrepancyKind.PENDING_CHAIN_TX in _kinds(report)
    assert report.classification is ReconciliationClass.MANUAL_REVIEW
    assert report.halts_new_trading


@pytest.mark.asyncio
async def test_duplicate_fill_is_not_reimported() -> None:
    # The same confirmed fill appears remotely twice AND already exists locally.
    local = LocalState(fills=(make_local_fill(fill_id="f-1"),))
    remote = RemoteAccountState(
        available=True,
        fills=(
            make_remote_fill(fill_id="f-1"),
            make_remote_fill(fill_id="f-1"),  # duplicate delivery, not unique
        ),
        balances=(),
    )
    service, importer, _canceller, _halt, _sink = _service(
        local=local, remote=remote
    )
    report = await service.periodic()
    # Already present locally -> nothing queued for import.
    assert report.fills_to_import == ()
    assert importer.received == []
    assert DiscrepancyKind.MISSING_LOCAL_FILL not in _kinds(report)


@pytest.mark.asyncio
async def test_missing_local_order_triggers_cancellation() -> None:
    # An order exists remotely that we have no local record of at all.
    remote = RemoteAccountState(
        available=True, open_orders=(make_remote_order(order_id="ghost-1"),)
    )
    service, _importer, canceller, halt, sink = _service(remote=remote)
    report = await service.periodic()
    assert DiscrepancyKind.UNKNOWN_REMOTE_ORDER in _kinds(report)
    assert report.classification is ReconciliationClass.CANCELLATION_REQUIRED
    assert canceller.cancelled == ["ghost-1"]
    assert halt.halted
    assert len(sink.persisted) == 1
