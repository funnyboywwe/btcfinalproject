"""Unit tests confirming the live CLOB adapter is safely blocked.

The official CLOB package API is not verified locally, so every live read must
raise a typed unsupported-operation error rather than guessing an
implementation. These tests pin that contract.
"""

from __future__ import annotations

import pytest

from polymarket_pair_bot.auth.clob_adapter import (
    ClobAuthenticatedReader,
    ClobUserStreamConnectionFactory,
    initialize_authenticated_client,
)
from polymarket_pair_bot.auth.errors import UnsupportedAuthOperationError
from tests.fixtures.auth import make_credentials, make_identity


class _PublicSettingsStub:
    pass


def _reader() -> ClobAuthenticatedReader:
    return ClobAuthenticatedReader(
        identity=make_identity(),
        credentials=make_credentials(),
        public_settings=_PublicSettingsStub(),  # type: ignore[arg-type]
    )


async def test_all_reads_are_blocked_with_typed_error() -> None:
    reader = _reader()
    with pytest.raises(UnsupportedAuthOperationError):
        await reader.get_open_orders()
    with pytest.raises(UnsupportedAuthOperationError):
        await reader.get_order_status("order-1")
    with pytest.raises(UnsupportedAuthOperationError):
        await reader.get_trades()
    with pytest.raises(UnsupportedAuthOperationError):
        await reader.get_balances()
    with pytest.raises(UnsupportedAuthOperationError):
        await reader.get_allowances()


async def test_close_is_safe_noop() -> None:
    reader = _reader()
    await reader.aclose()  # must not raise


async def test_user_stream_connect_is_blocked() -> None:
    factory = ClobUserStreamConnectionFactory(
        identity=make_identity(),
        credentials=make_credentials(),
        public_settings=_PublicSettingsStub(),  # type: ignore[arg-type]
    )
    with pytest.raises(UnsupportedAuthOperationError):
        await factory.connect()


def test_initialize_client_is_blocked() -> None:
    with pytest.raises(UnsupportedAuthOperationError) as excinfo:
        initialize_authenticated_client(
            identity=make_identity(),
            credentials=make_credentials(),
            public_settings=_PublicSettingsStub(),  # type: ignore[arg-type]
        )
    assert excinfo.value.operation == "initialize_authenticated_client"
