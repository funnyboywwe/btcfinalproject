"""Scenario tests for the pair-opportunity detector (Module 10).

Covered scenarios (per the module spec): normal, thin, stale and rapidly
changing books, plus each of the five detector actions, purity/determinism and
the risk-approval gate. All monetary values are Decimal / domain value objects.
No test submits an order or performs I/O.
"""

from __future__ import annotations

import json
from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.value_objects import Shares, UnixTimestamp
from polymarket_pair_bot.strategy.detector import (
    DetectorAction,
    ExecutionRole,
)
from polymarket_pair_bot.strategy.engine import InventorySummary
from polymarket_pair_bot.strategy.observations import observation_from_result
from tests.fixtures.detector import approve, make_detector, make_market, reject
from tests.fixtures.engine import (
    NOW,
    deep_book,
    make_book,
    make_inventory,
)

UP = OutcomeSide.UP
DOWN = OutcomeSide.DOWN


def _evaluate(
    detector,
    *,
    up_book,
    down_book,
    inventory=None,
    target="10",
    now=NOW,
    up_is_fresh=True,
    down_is_fresh=True,
    risk=None,
    market=None,
):
    return detector.evaluate(
        market=market or make_market(now=now),
        up_book=up_book,
        down_book=down_book,
        inventory=inventory or make_inventory(),
        target_quantity=Shares(Decimal(target)),
        now=now,
        up_is_fresh=up_is_fresh,
        down_is_fresh=down_is_fresh,
        risk_input=risk,
    )


class TestImmediateTwoLeg:
    def test_normal_book_yields_two_taker_legs(self) -> None:
        detector = make_detector()
        result = _evaluate(
            detector,
            up_book=deep_book(make_market().up_token.token_id, best_ask="0.48"),
            down_book=deep_book(make_market().down_token.token_id, best_ask="0.48"),
            risk=approve(),
        )
        assert result.action is DetectorAction.IMMEDIATE_TWO_LEG
        assert len(result.candidates) == 2
        assert {c.side for c in result.candidates} == {UP, DOWN}
        assert all(c.role is ExecutionRole.TAKER for c in result.candidates)
        assert all(c.proposed_price.value == Decimal("0.48") for c in result.candidates)
        assert all(c.proposed_quantity.value == Decimal(10) for c in result.candidates)
        assert result.effective_pair_cost.value == Decimal("0.97")
        assert result.expected_net_edge.value == Decimal("0.03")
        assert all(c.required_hedge_depth.value == Decimal(10) for c in result.candidates)
        assert all(c.approved for c in result.candidates)
        assert result.approved is True
        assert result.rejection_reasons == ()

    def test_cancel_deadline_capped_at_close(self) -> None:
        detector = make_detector(taker_order_ttl_seconds=5)
        market = make_market(now=NOW, close_after=2)  # closes in 2s < ttl
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            risk=approve(),
            now=NOW,
            market=market,
        )
        # min_seconds_to_close default is 30 -> this window is too close.
        assert result.action is DetectorAction.NO_TRADE
        assert any("window_too_close" in r for r in result.rejection_reasons)

    def test_deadline_capped_but_actionable(self) -> None:
        detector = make_detector(taker_order_ttl_seconds=600, min_seconds_to_close=30)
        market = make_market(now=NOW, close_after=120)
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            risk=approve(),
            now=NOW,
            market=market,
        )
        assert result.action is DetectorAction.IMMEDIATE_TWO_LEG
        # ttl (600s) exceeds time to close (120s); deadline must cap at close.
        for candidate in result.candidates:
            assert candidate.cancel_deadline.value == market.window.close_time.value


class TestThinBook:
    def test_insufficient_depth_is_no_trade(self) -> None:
        detector = make_detector(min_book_depth="10")
        market = make_market()
        result = _evaluate(
            detector,
            up_book=make_book(market.up_token.token_id, asks=[("0.48", "2")]),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            risk=approve(),
            market=market,
        )
        assert result.action is DetectorAction.NO_TRADE
        assert result.candidates == ()
        assert any("up_depth_insufficient" in r for r in result.rejection_reasons)
        assert result.approved is False


class TestStaleBook:
    def test_stale_up_feed_is_no_trade(self) -> None:
        detector = make_detector()
        market = make_market()
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            up_is_fresh=False,
            risk=approve(),
            market=market,
        )
        assert result.action is DetectorAction.NO_TRADE
        assert any("stale" in r for r in result.rejection_reasons)
        assert result.candidates == ()


class TestRapidlyChangingBooks:
    def test_book_age_tracks_now_and_flips_to_no_trade(self) -> None:
        detector = make_detector()
        market = make_market(now=NOW, close_after=600)
        fresh_up = deep_book(market.up_token.token_id, best_ask="0.48")
        fresh_down = deep_book(market.down_token.token_id, best_ask="0.48")
        # First evaluation: books captured at NOW, evaluated at NOW.
        first = _evaluate(
            detector,
            up_book=fresh_up,
            down_book=fresh_down,
            risk=approve(),
            now=NOW,
            market=market,
        )
        assert first.action is DetectorAction.IMMEDIATE_TWO_LEG
        assert first.up_book_age_seconds == 0

        # Later evaluation: same book snapshots, clock advanced 100s, and the
        # feed layer now reports the up side as not fresh (rapid change/stall).
        later_now = UnixTimestamp(NOW.value + 100)
        second = _evaluate(
            detector,
            up_book=fresh_up,
            down_book=fresh_down,
            up_is_fresh=False,
            risk=approve(),
            now=later_now,
            market=market,
        )
        assert second.up_book_age_seconds == 100
        assert second.action is DetectorAction.NO_TRADE
        assert any("stale" in r for r in second.rejection_reasons)


class TestPassiveFirstLeg:
    def test_expensive_taker_cheap_maker_posts_one_maker_leg(self) -> None:
        detector = make_detector()
        market = make_market()
        # Asks too expensive to take, bids cheap enough to rest a maker order.
        up_book = make_book(
            market.up_token.token_id,
            bids=[("0.48", "50")],
            asks=[("0.55", "50")],
        )
        down_book = make_book(
            market.down_token.token_id,
            bids=[("0.48", "50")],
            asks=[("0.55", "50")],
        )
        result = _evaluate(
            detector,
            up_book=up_book,
            down_book=down_book,
            risk=approve(),
            market=market,
        )
        assert result.action is DetectorAction.PASSIVE_FIRST_LEG
        assert len(result.candidates) == 1
        candidate = result.candidates[0]
        assert candidate.role is ExecutionRole.MAKER
        assert candidate.proposed_price.value == Decimal("0.48")
        assert candidate.required_hedge_depth.value == Decimal(10)
        assert result.effective_pair_cost_maker is not None
        assert result.effective_pair_cost_maker.value == Decimal("0.97")


class TestPassiveSecondLeg:
    def test_one_side_held_completes_missing_leg(self) -> None:
        detector = make_detector()
        market = make_market()
        # Hold 1 unmatched UP; need 1 DOWN. target=1 keeps the engine's
        # per-leg price ceiling positive so a taker completion is feasible.
        inventory = InventorySummary(
            unmatched_up=Shares(Decimal(1)),
            unmatched_down=Shares(Decimal(0)),
            matched_pairs=Shares(Decimal(0)),
        )
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            inventory=inventory,
            target="1",
            risk=approve(),
            market=market,
        )
        assert result.action is DetectorAction.PASSIVE_SECOND_LEG
        assert len(result.candidates) == 1
        candidate = result.candidates[0]
        assert candidate.side is DOWN
        # The opposite leg is already held, so no further hedge depth is needed.
        assert candidate.required_hedge_depth.value == Decimal(0)
        assert candidate.proposed_quantity.value == Decimal(1)


class TestMatchedInventory:
    def test_both_sides_held_yields_no_new_candidates(self) -> None:
        detector = make_detector()
        market = make_market()
        inventory = InventorySummary(
            unmatched_up=Shares(Decimal(10)),
            unmatched_down=Shares(Decimal(10)),
            matched_pairs=Shares(Decimal(0)),
        )
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            inventory=inventory,
            risk=approve(),
            market=market,
        )
        assert result.action is DetectorAction.MATCHED_INVENTORY
        assert result.candidates == ()
        assert result.approved is False  # nothing to acquire


class TestRiskGate:
    def test_no_risk_input_cannot_approve(self) -> None:
        detector = make_detector()
        market = make_market()
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            risk=None,
            market=market,
        )
        assert result.action is DetectorAction.IMMEDIATE_TWO_LEG
        assert result.risk_input_available is False
        assert result.approved is False
        assert result.candidates  # candidates are still described
        assert all(not c.approved for c in result.candidates)
        assert all(
            "risk_input_unavailable" in c.approval_reason for c in result.candidates
        )

    def test_risk_reject_blocks_approval(self) -> None:
        detector = make_detector()
        market = make_market()
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            risk=reject(),
            market=market,
        )
        assert result.approved is False
        assert all("risk_rejected" in c.approval_reason for c in result.candidates)

    def test_risk_clamps_quantity_to_approved_size(self) -> None:
        detector = make_detector()
        market = make_market()
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            target="10",
            risk=approve(max_pair_size="3"),
            market=market,
        )
        assert result.approved is True
        assert all(c.proposed_quantity.value == Decimal(3) for c in result.candidates)


class TestPurityAndDeterminism:
    def test_deterministic_for_same_inputs(self) -> None:
        detector = make_detector()
        market = make_market()
        up_book = deep_book(market.up_token.token_id, best_ask="0.48")
        down_book = deep_book(market.down_token.token_id, best_ask="0.48")
        kwargs = dict(up_book=up_book, down_book=down_book, risk=approve(), market=market)
        first = _evaluate(detector, **kwargs)
        second = _evaluate(detector, **kwargs)
        assert first == second

    def test_inputs_not_mutated(self) -> None:
        detector = make_detector()
        market = make_market()
        inventory = make_inventory(unmatched_up="0", unmatched_down="0")
        up_book = deep_book(market.up_token.token_id, best_ask="0.48")
        before_bids = up_book.bids
        before_asks = up_book.asks
        _evaluate(
            detector,
            up_book=up_book,
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            inventory=inventory,
            risk=approve(),
            market=market,
        )
        assert up_book.bids is before_bids
        assert up_book.asks is before_asks
        assert inventory.unmatched_up.value == Decimal(0)


class TestObservationProjection:
    def test_observation_is_json_serializable(self) -> None:
        detector = make_detector()
        market = make_market()
        result = _evaluate(
            detector,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            risk=approve(),
            market=market,
        )
        observation = observation_from_result(result)
        assert observation.candidate_count == 2
        assert observation.action == "immediate_two_leg"
        # Monetary values are exact decimal strings, never floats. Collateral
        # amounts are quantized to 1e-6 by the engine, so "0.97" -> "0.970000".
        assert observation.effective_pair_cost == "0.970000"
        payload = json.dumps(observation.as_dict())
        assert "immediate_two_leg" in payload
        assert "0.970000" in payload


def test_zero_target_quantity_rejected() -> None:
    detector = make_detector()
    market = make_market()
    with pytest.raises(ValueError):
        detector.evaluate(
            market=market,
            up_book=deep_book(market.up_token.token_id, best_ask="0.48"),
            down_book=deep_book(market.down_token.token_id, best_ask="0.48"),
            inventory=make_inventory(),
            target_quantity=Shares(Decimal(0)),
            now=NOW,
            up_is_fresh=True,
            down_is_fresh=True,
            risk_input=approve(),
        )
