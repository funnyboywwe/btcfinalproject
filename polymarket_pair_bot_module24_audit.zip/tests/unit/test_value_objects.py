"""Boundary tests for immutable value objects."""

from __future__ import annotations

import dataclasses
from datetime import UTC, datetime
from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    ConditionId,
    FeeAmount,
    MarketId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
    WalletAddress,
)


@pytest.mark.parametrize("raw", ["0", "1", "0.5", "0.000001"])
def test_price_in_range(raw: str) -> None:
    assert ProbabilityPrice(Decimal(raw)).value == Decimal(raw)


@pytest.mark.parametrize("raw", ["-0.0001", "1.0001", "2"])
def test_price_out_of_range_rejected(raw: str) -> None:
    with pytest.raises(ValueError):
        ProbabilityPrice(Decimal(raw))


def test_value_objects_reject_float() -> None:
    for ctor in (ProbabilityPrice, Shares, CollateralAmount, FeeAmount, ProfitAmount):
        with pytest.raises(TypeError):
            ctor(0.5)  # type: ignore[arg-type]


def test_value_objects_are_frozen() -> None:
    price = ProbabilityPrice(Decimal("0.5"))
    with pytest.raises(dataclasses.FrozenInstanceError):
        price.value = Decimal("0.6")  # type: ignore[misc]


def test_shares_non_negative_and_positive_guard() -> None:
    assert Shares(Decimal(0)).value == 0
    with pytest.raises(ValueError):
        Shares(Decimal("-1"))
    with pytest.raises(ValueError):
        Shares(Decimal(0)).require_positive()
    assert Shares(Decimal("2")).require_positive().is_positive


def test_fee_and_collateral_non_negative() -> None:
    with pytest.raises(ValueError):
        FeeAmount(Decimal("-0.01"))
    with pytest.raises(ValueError):
        CollateralAmount(Decimal("-0.01"))


def test_profit_allows_negative() -> None:
    loss = ProfitAmount(Decimal("-1.25"))
    assert loss.is_loss
    assert loss.value == Decimal("-1.25")


def test_collateral_base_units_floor() -> None:
    assert CollateralAmount(Decimal("1.2345678")).base_units == 1_234_567


def test_basis_points_as_fraction() -> None:
    assert BasisPoints(Decimal("50")).as_fraction() == Decimal("0.005")
    with pytest.raises(ValueError):
        BasisPoints(Decimal("-1"))


@pytest.mark.parametrize("raw", ["0", "-0.1", "1.5"])
def test_tick_size_bounds(raw: str) -> None:
    with pytest.raises(ValueError):
        TickSize(Decimal(raw))


def test_tick_size_valid() -> None:
    assert TickSize(Decimal("0.01")).value == Decimal("0.01")


def test_unix_timestamp_rules() -> None:
    assert UnixTimestamp(0).value == 0
    with pytest.raises(ValueError):
        UnixTimestamp(-1)
    with pytest.raises(TypeError):
        UnixTimestamp(True)  # type: ignore[arg-type]
    moment = datetime(2026, 1, 1, tzinfo=UTC)
    assert UnixTimestamp.from_datetime(moment).to_datetime() == moment


def test_unix_timestamp_requires_tzaware() -> None:
    with pytest.raises(ValueError):
        UnixTimestamp.from_datetime(datetime(2026, 1, 1))  # noqa: DTZ001


def test_token_id_must_be_uint_string() -> None:
    assert TokenId("123").value == "123"
    with pytest.raises(ValueError):
        TokenId("0xabc")
    with pytest.raises(ValueError):
        TokenId(" ")


def test_condition_id_bytes32() -> None:
    good = "0x" + "a" * 64
    assert ConditionId(good).value == good
    with pytest.raises(ValueError):
        ConditionId("0x" + "a" * 63)


def test_wallet_address_validation_and_lowercasing() -> None:
    addr = "0x" + "AbCd" * 10
    assert WalletAddress(addr).value == addr.lower()
    with pytest.raises(ValueError):
        WalletAddress("0x123")


def test_market_id_nonempty() -> None:
    assert MarketId(" mkt ").value == "mkt"
    with pytest.raises(ValueError):
        MarketId("")
