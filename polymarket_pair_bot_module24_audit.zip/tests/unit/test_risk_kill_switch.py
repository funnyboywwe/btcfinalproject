"""Unit tests for the multi-level persistent kill switch (Module 14)."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.domain.coordination import (
    KillSwitchState,
    RedisUnavailableError,
)
from polymarket_pair_bot.domain.enums import ReconciliationStatus
from polymarket_pair_bot.risk.kill_switch import (
    CompositeKillSwitch,
    EnvKillSwitch,
    KillSwitchSignal,
    PostgresKillSwitchSource,
    ProcessKillSwitch,
    RedisKillSwitchSource,
    evaluate_clearance,
)
from polymarket_pair_bot.risk.ports import ReconciliationHealth
from tests.fixtures.risk import (
    FakeKillSwitchLatestReader,
    FakeKillSwitchStore,
    StaticSource,
)


async def test_process_switch_trip_and_reset() -> None:
    switch = ProcessKillSwitch()
    assert switch.is_active() is False
    switch.trip("manual halt")
    signal = await switch.read()
    assert switch.is_active() is True
    assert signal.active is True
    assert signal.reason == "manual halt"
    switch.reset()
    assert switch.is_active() is False


@pytest.mark.parametrize("raw", ["1", "true", "TRUE", "yes", "on", "active", " On "])
async def test_env_switch_truthy_values(raw: str) -> None:
    switch = EnvKillSwitch("PPB_KILL", env_reader=lambda key: raw)
    assert switch.is_active() is True
    signal = await switch.read()
    assert signal.active is True


@pytest.mark.parametrize("raw", [None, "", "0", "false", "off", "nope"])
async def test_env_switch_falsey_values(raw: str | None) -> None:
    switch = EnvKillSwitch("PPB_KILL", env_reader=lambda key: raw)
    assert switch.is_active() is False


async def test_redis_source_fails_closed_when_unavailable() -> None:
    class _BrokenStore(FakeKillSwitchStore):
        async def get_state(self) -> KillSwitchState:
            raise RedisUnavailableError("down")

    source = RedisKillSwitchSource(_BrokenStore())
    signal = await source.read()
    assert signal.active is True
    assert "fail closed" in signal.reason


async def test_redis_source_reports_state() -> None:
    source = RedisKillSwitchSource(FakeKillSwitchStore(active=True, reason="halt"))
    signal = await source.read()
    assert signal.active is True
    assert signal.reason == "halt"


async def test_postgres_source_absent_record_is_inactive() -> None:
    source = PostgresKillSwitchSource(FakeKillSwitchLatestReader(None), key="k")
    signal = await source.read()
    assert signal.active is False


async def test_postgres_source_reports_latest_state() -> None:
    reader = FakeKillSwitchLatestReader(
        KillSwitchState(active=True, reason="durable halt")
    )
    source = PostgresKillSwitchSource(reader, key="k")
    signal = await source.read()
    assert signal.active is True
    assert signal.reason == "durable halt"


async def test_composite_active_if_any_source_active() -> None:
    composite = CompositeKillSwitch(
        [
            StaticSource("a", KillSwitchSignal("a", False)),
            StaticSource("b", KillSwitchSignal("b", True, "tripped")),
        ]
    )
    snapshot = await composite.snapshot()
    assert snapshot.active is True
    assert snapshot.active_sources() == ("b",)
    assert "tripped" in snapshot.reason_summary()


async def test_composite_inactive_when_all_inactive() -> None:
    composite = CompositeKillSwitch(
        [
            StaticSource("a", KillSwitchSignal("a", False)),
            StaticSource("b", KillSwitchSignal("b", False)),
        ]
    )
    snapshot = await composite.snapshot()
    assert snapshot.active is False
    assert snapshot.active_sources() == ()


async def test_composite_fails_closed_on_read_error() -> None:
    composite = CompositeKillSwitch(
        [StaticSource("a", RuntimeError("boom"))]
    )
    snapshot = await composite.snapshot()
    assert snapshot.active is True
    assert "fail closed" in snapshot.reason_summary()


def test_clearance_allows_with_all_preconditions() -> None:
    decision = evaluate_clearance(
        reason="resolved incident",
        now=1_000,
        reconciliation=ReconciliationHealth(ReconciliationStatus.CONSISTENT, 990),
        feeds_healthy=True,
        max_reconciliation_age_seconds=300,
        env_switch_active=False,
    )
    assert decision.allowed is True
    assert decision.reasons == ()


def test_clearance_blocks_on_all_failures() -> None:
    decision = evaluate_clearance(
        reason="   ",
        now=1_000,
        reconciliation=None,
        feeds_healthy=False,
        max_reconciliation_age_seconds=300,
        env_switch_active=True,
    )
    assert decision.allowed is False
    assert len(decision.reasons) == 4


def test_clearance_blocks_on_stale_reconciliation() -> None:
    decision = evaluate_clearance(
        reason="resolved",
        now=2_000,
        reconciliation=ReconciliationHealth(ReconciliationStatus.CONSISTENT, 990),
        feeds_healthy=True,
        max_reconciliation_age_seconds=300,
        env_switch_active=False,
    )
    assert decision.allowed is False
    assert any("stale" in reason for reason in decision.reasons)


def test_clearance_blocks_on_inconsistent_reconciliation() -> None:
    decision = evaluate_clearance(
        reason="resolved",
        now=1_000,
        reconciliation=ReconciliationHealth(ReconciliationStatus.DISCREPANCY, 990),
        feeds_healthy=True,
        max_reconciliation_age_seconds=300,
        env_switch_active=False,
    )
    assert decision.allowed is False
    assert any("not consistent" in reason for reason in decision.reasons)
