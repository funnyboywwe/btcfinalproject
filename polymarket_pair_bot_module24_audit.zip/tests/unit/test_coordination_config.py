"""Unit tests for CoordinationSettings validation (pure pydantic, no Redis)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from polymarket_pair_bot.config.models import CoordinationSettings


def test_defaults_are_safe() -> None:
    settings = CoordinationSettings()
    # Short lease TTL, renewed well before expiry.
    assert settings.leader_lease_ttl_seconds > settings.leader_renew_interval_seconds
    assert settings.heartbeat_ttl_seconds > settings.heartbeat_interval_seconds
    assert settings.market_metadata_ttl_seconds > 0
    assert settings.idempotency_ttl_seconds > 0


def test_renew_interval_must_be_below_ttl() -> None:
    with pytest.raises(ValidationError):
        CoordinationSettings(
            leader_lease_ttl_seconds=5.0, leader_renew_interval_seconds=5.0
        )


def test_heartbeat_interval_must_be_below_ttl() -> None:
    with pytest.raises(ValidationError):
        CoordinationSettings(
            heartbeat_ttl_seconds=5.0, heartbeat_interval_seconds=10.0
        )


def test_positive_constraints() -> None:
    with pytest.raises(ValidationError):
        CoordinationSettings(redis_operation_timeout_seconds=0)
