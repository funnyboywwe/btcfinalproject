"""Retention configuration defaults and validation (pure, no infrastructure)."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from polymarket_pair_bot.config import load_config
from polymarket_pair_bot.config.models import RetentionSettings


def test_retention_defaults_are_conservative() -> None:
    settings = RetentionSettings()
    # Retention must be OFF by default so nothing is ever deleted implicitly.
    assert settings.retention_enabled is False
    assert settings.pair_opportunity_retention_days == 30
    assert settings.inventory_snapshot_retention_days == 90
    assert settings.reconciliation_retention_days == 90
    assert settings.system_event_retention_days == 180


def test_retention_is_part_of_appconfig() -> None:
    config = load_config()
    assert isinstance(config.retention, RetentionSettings)
    assert config.retention.retention_enabled is False


def test_retention_days_cannot_be_negative() -> None:
    with pytest.raises(ValidationError):
        RetentionSettings(system_event_retention_days=-1)


def test_retention_zero_means_retain_forever() -> None:
    settings = RetentionSettings(pair_opportunity_retention_days=0)
    assert settings.pair_opportunity_retention_days == 0


def test_retention_summary_is_secret_free() -> None:
    # Retention config carries no secrets; the redacted summary must include it
    # without raising.
    summary = load_config().redacted_summary()
    assert "retention" in summary
