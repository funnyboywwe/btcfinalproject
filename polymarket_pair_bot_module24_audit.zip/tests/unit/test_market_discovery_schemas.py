"""Fixture tests for Gamma market validation and cross-checking.

Required fixture cases (per Module 5): valid market, closed market, missing
token, reversed outcome order, invalid timestamps, missing condition id.
These exercise the pure validation path (no HTTP).
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.market_discovery.errors import InvalidMarketMetadataError
from polymarket_pair_bot.market_discovery.schemas import discovered_from_raw
from tests.fixtures import gamma

FETCHED_AT = 1_735_689_650


def _discover(raw: dict[str, object]):
    return discovered_from_raw(
        raw, expected_up="Up", expected_down="Down", fetched_at=FETCHED_AT
    )


def test_valid_market_extracts_all_fields() -> None:
    market = _discover(gamma.valid_market())
    assert market.slug == "btc-updown-2025-01-01-0000"
    assert market.market_id == "512345"
    assert market.condition_id == gamma.CONDITION_ID
    assert market.up_token_id == gamma.UP_TOKEN_ID
    assert market.down_token_id == gamma.DOWN_TOKEN_ID
    assert market.open_time == gamma.WINDOW_OPEN_EPOCH
    assert market.close_time == gamma.WINDOW_CLOSE_EPOCH
    assert market.active is True
    assert market.closed is False
    assert market.order_book_enabled is True
    assert market.tick_size == Decimal("0.001")
    assert market.min_order_size == Decimal("5")
    assert market.neg_risk is False
    assert market.resolution_source == "synthetic-test-source"
    assert market.is_open_for_trading is True
    market.ensure_open_for_trading()  # does not raise


def test_valid_market_accepts_plain_arrays() -> None:
    market = _discover(gamma.valid_market(encode_arrays=False))
    assert market.up_token_id == gamma.UP_TOKEN_ID


def test_closed_market_parses_but_is_not_tradeable() -> None:
    market = _discover(gamma.closed_market())
    assert market.closed is True
    assert market.active is False
    assert market.is_open_for_trading is False
    with pytest.raises(InvalidMarketMetadataError):
        market.ensure_open_for_trading()


def test_reversed_outcome_order_maps_by_name() -> None:
    # Down is listed first; name-based mapping must still resolve correctly.
    market = _discover(gamma.reversed_outcomes_market())
    assert market.up_token_id == gamma.UP_TOKEN_ID
    assert market.down_token_id == gamma.DOWN_TOKEN_ID


def test_missing_token_is_rejected() -> None:
    with pytest.raises(InvalidMarketMetadataError):
        _discover(gamma.missing_token_market())


def test_invalid_timestamps_are_rejected() -> None:
    with pytest.raises(InvalidMarketMetadataError):
        _discover(gamma.invalid_timestamps_market())


def test_missing_condition_id_is_rejected() -> None:
    with pytest.raises(InvalidMarketMetadataError):
        _discover(gamma.missing_condition_id_market())


def test_contradictory_active_and_closed_rejected() -> None:
    with pytest.raises(InvalidMarketMetadataError):
        _discover(gamma.contradictory_active_closed_market())


def test_unknown_outcome_names_rejected() -> None:
    raw = gamma.valid_market(encode_arrays=False)
    raw["outcomes"] = ["Yes", "No"]
    with pytest.raises(InvalidMarketMetadataError):
        _discover(raw)


def test_bad_condition_id_shape_rejected() -> None:
    raw = gamma.valid_market()
    raw["conditionId"] = "0xnothex"
    with pytest.raises(InvalidMarketMetadataError):
        _discover(raw)


def test_zero_tick_size_rejected() -> None:
    raw = gamma.valid_market()
    raw["orderPriceMinTickSize"] = "0"
    with pytest.raises(InvalidMarketMetadataError):
        _discover(raw)
