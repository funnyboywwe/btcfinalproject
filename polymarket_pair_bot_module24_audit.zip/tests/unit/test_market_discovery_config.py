"""Tests for the additive MarketDiscoverySettings config group.

Gated on pydantic-settings so the suite still collects in minimal environments.
"""

from __future__ import annotations

import pytest

pytest.importorskip("pydantic_settings")

from polymarket_pair_bot.config import AppConfig  # noqa: E402
from polymarket_pair_bot.config.models import MarketDiscoverySettings  # noqa: E402


def test_defaults_are_safe() -> None:
    settings = MarketDiscoverySettings()
    # No slug is guessed: discovery is blocked until an operator configures it.
    assert settings.btc_5m_slug_template is None
    assert settings.discovery_expected_up_outcome == "Up"
    assert settings.discovery_expected_down_outcome == "Down"
    assert settings.discovery_require_window_match is True
    assert settings.discovery_preload_next_window is True
    assert settings.discovery_max_retries >= 0


def test_backoff_bounds_validated() -> None:
    with pytest.raises(ValueError):
        MarketDiscoverySettings(
            discovery_backoff_base_seconds=5.0, discovery_backoff_max_seconds=1.0
        )


def test_up_and_down_must_differ() -> None:
    with pytest.raises(ValueError):
        MarketDiscoverySettings(
            discovery_expected_up_outcome="Same",
            discovery_expected_down_outcome="same",
        )


def test_appconfig_exposes_market_discovery() -> None:
    config = AppConfig()
    assert isinstance(config.market_discovery, MarketDiscoverySettings)
