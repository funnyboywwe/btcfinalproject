"""Unit tests for JSON logging and its redaction integration."""

from __future__ import annotations

import json
import logging

from polymarket_pair_bot.observability.logging import JsonFormatter, configure_logging


def _record(msg: str, args: tuple[object, ...] = ()) -> logging.LogRecord:
    return logging.LogRecord(
        name="test.logger",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg=msg,
        args=args,
        exc_info=None,
    )


def test_json_formatter_emits_valid_json_with_core_fields() -> None:
    output = JsonFormatter().format(_record("hello"))
    data = json.loads(output)
    assert data["level"] == "INFO"
    assert data["logger"] == "test.logger"
    assert data["message"] == "hello"
    assert "timestamp" in data


def test_json_formatter_redacts_message_and_context() -> None:
    record = _record("boot 0x%s", ("a" * 64,))
    record.api_key = "super-secret-token-value-1234"
    output = JsonFormatter().format(record)
    data = json.loads(output)
    assert "a" * 64 not in output
    assert "REDACTED" in data["message"]
    assert data["context"]["api_key"] == "***REDACTED***"


def test_configure_logging_installs_single_stdout_handler() -> None:
    configure_logging(level="DEBUG", json_output=True)
    root = logging.getLogger()
    assert root.level == logging.DEBUG
    assert len(root.handlers) == 1
    # Re-configuring must not accumulate handlers.
    configure_logging(level="INFO", json_output=True)
    assert len(logging.getLogger().handlers) == 1
