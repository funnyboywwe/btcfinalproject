"""Unit tests for the read-only authentication/diagnostics service."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.auth.clob_adapter import ClobAuthenticatedReader
from polymarket_pair_bot.auth.errors import UnsupportedAuthOperationError
from polymarket_pair_bot.auth.service import AuthenticationService
from polymarket_pair_bot.auth.stub_reader import StubAccountReader
from tests.fixtures.auth import (
    make_balance,
    make_credentials,
    make_fill,
    make_identity,
    make_open_order,
)


async def test_diagnose_returns_validated_snapshot() -> None:
    reader = StubAccountReader(
        make_identity(),
        open_orders=(make_open_order(),),
        trades=(make_fill(),),
        balances=(make_balance(),),
    )
    service = AuthenticationService(reader=reader)
    snapshot = await service.diagnose()
    assert snapshot.open_order_count == 1
    assert snapshot.fill_count == 1
    assert snapshot.balance_count == 1
    assert snapshot.allowances_supported is True
    assert service.readiness.is_ready is True
    # The summary is a non-secret count view safe for logs/CLI.
    assert snapshot.summary()["open_orders"] == 1


async def test_diagnose_flags_unsupported_allowances() -> None:
    reader = StubAccountReader(make_identity(), allowances_supported=False)
    service = AuthenticationService(reader=reader)
    snapshot = await service.diagnose()
    assert snapshot.allowances_supported is False
    assert snapshot.allowance_count == 0
    assert snapshot.notes  # a note explains why allowances are absent


async def test_diagnose_propagates_blocked_live_reads() -> None:
    reader = ClobAuthenticatedReader(
        identity=make_identity(),
        credentials=make_credentials(),
        public_settings=object(),  # type: ignore[arg-type]
    )
    service = AuthenticationService(reader=reader)
    with pytest.raises(UnsupportedAuthOperationError):
        await service.diagnose()


async def test_diagnose_never_calls_mutating_methods() -> None:
    # The reader protocol exposes no submit/cancel; this asserts the stub only
    # ever answered read calls during a diagnose sweep.
    calls: list[str] = []

    class _RecordingReader(StubAccountReader):
        async def get_open_orders(self, *, market_id=None):  # type: ignore[override]
            calls.append("get_open_orders")
            return await super().get_open_orders(market_id=market_id)

        async def get_trades(self, *, market_id=None):  # type: ignore[override]
            calls.append("get_trades")
            return await super().get_trades(market_id=market_id)

        async def get_balances(self):  # type: ignore[override]
            calls.append("get_balances")
            return await super().get_balances()

        async def get_allowances(self):  # type: ignore[override]
            calls.append("get_allowances")
            return await super().get_allowances()

    reader = _RecordingReader(make_identity())
    service = AuthenticationService(reader=reader)
    await service.diagnose()
    assert calls == [
        "get_open_orders",
        "get_trades",
        "get_balances",
        "get_allowances",
    ]
