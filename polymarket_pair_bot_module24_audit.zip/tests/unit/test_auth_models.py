"""Unit tests for auth Pydantic adapters (Decimal safety + invariants)."""

from __future__ import annotations

from decimal import Decimal

import pytest
from pydantic import ValidationError

from polymarket_pair_bot.auth.models import (
    BalanceView,
    OpenOrderView,
    OrderStatusView,
)
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus


def test_prices_and_sizes_are_decimal() -> None:
    order = OpenOrderView(
        order_id="o1",
        token_id="t1",
        side=OrderSide.BUY,
        status=OrderStatus.OPEN,
        price="0.51",
        original_size="10",
        size_matched="4",
    )
    assert order.price == Decimal("0.51")
    assert order.original_size == Decimal("10")
    assert order.is_confirmed_complete is False


def test_float_money_is_rejected_as_validation_error() -> None:
    with pytest.raises(ValidationError):
        OpenOrderView(
            order_id="o1",
            token_id="t1",
            side=OrderSide.BUY,
            status=OrderStatus.OPEN,
            price=0.51,  # type: ignore[arg-type]
            original_size="10",
        )


def test_price_out_of_range_rejected() -> None:
    with pytest.raises(ValidationError):
        OpenOrderView(
            order_id="o1",
            token_id="t1",
            side=OrderSide.BUY,
            status=OrderStatus.OPEN,
            price="1.5",
            original_size="10",
        )


def test_matched_cannot_exceed_original() -> None:
    with pytest.raises(ValidationError):
        OpenOrderView(
            order_id="o1",
            token_id="t1",
            side=OrderSide.BUY,
            status=OrderStatus.OPEN,
            price="0.5",
            original_size="1",
            size_matched="2",
        )


def test_filled_status_is_confirmed_complete() -> None:
    status = OrderStatusView(
        order_id="o1", status=OrderStatus.FILLED, size_matched="5"
    )
    assert status.is_confirmed_complete is True


def test_balance_available_cannot_exceed_total() -> None:
    with pytest.raises(ValidationError):
        BalanceView(asset="USDC", total="10", available="11")


def test_models_are_frozen() -> None:
    order = OpenOrderView(
        order_id="o1",
        token_id="t1",
        side=OrderSide.BUY,
        status=OrderStatus.OPEN,
        price="0.5",
        original_size="1",
    )
    with pytest.raises(ValidationError):
        order.price = Decimal("0.6")  # type: ignore[misc]
