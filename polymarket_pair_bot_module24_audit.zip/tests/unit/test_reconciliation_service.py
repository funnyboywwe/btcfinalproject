"""Unit tests for the reconciliation service orchestration (Module 15)."""

from __future__ import annotations

import asyncio

import pytest

from polymarket_pair_bot.domain.enums import ReconciliationStatus
from polymarket_pair_bot.domain.value_objects import OrderId
from polymarket_pair_bot.reconciliation.classification import ReconciliationClass
from polymarket_pair_bot.reconciliation.errors import (
    ReconciliationDataUnavailableError,
    UnsupportedReconciliationOperationError,
)
from polymarket_pair_bot.reconciliation.models import (
    ChainState,
    LocalState,
    RemoteAccountState,
)
from polymarket_pair_bot.reconciliation.service import (
    ReconciliationService,
    ReconciliationTuning,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from tests.fixtures.reconciliation import (
    FakeCanceller,
    FakeChainStateProvider,
    FakeFillImporter,
    FakeLocalStateProvider,
    FakeMarketScope,
    FakeRemoteAccountProvider,
    FakeSink,
    FakeTradingHalt,
    FixedClock,
    make_remote_fill,
    make_remote_order,
)


def _build(
    *,
    local=None,
    remote=None,
    chain=None,
    remote_exc=None,
    chain_exc=None,
    tuning=None,
    importer=None,
    canceller=None,
    halt=None,
    sink=None,
):
    importer = importer if importer is not None else FakeFillImporter()
    canceller = canceller if canceller is not None else FakeCanceller()
    halt = halt if halt is not None else FakeTradingHalt()
    sink = sink if sink is not None else FakeSink()
    service = ReconciliationService(
        local=FakeLocalStateProvider(local),
        remote=FakeRemoteAccountProvider(remote, exc=remote_exc),
        chain=FakeChainStateProvider(chain, exc=chain_exc),
        sink=sink,
        market_scope=FakeMarketScope(),
        importer=importer,
        canceller=canceller,
        halt=halt,
        tuning=tuning or ReconciliationTuning(),
        clock=FixedClock(4242),
    )
    return service, importer, canceller, halt, sink


@pytest.mark.asyncio
async def test_consistent_run_persists_and_does_not_halt() -> None:
    service, importer, canceller, halt, sink = _build(
        remote=RemoteAccountState(available=True)
    )
    report = await service.on_startup()
    assert report.trigger is ReconciliationTrigger.STARTUP
    assert report.classification is ReconciliationClass.CONSISTENT
    assert not halt.halted
    assert canceller.cancelled == []
    assert len(sink.persisted) == 1
    assert sink.persisted[0].status is ReconciliationStatus.CONSISTENT


@pytest.mark.asyncio
async def test_missing_fill_imported_idempotently() -> None:
    remote = RemoteAccountState(
        available=True, fills=(make_remote_fill(fill_id="f-1", order_id="o-1"),)
    )
    service, importer, _canceller, halt, sink = _build(remote=remote)
    report = await service.periodic()
    assert report.classification is ReconciliationClass.AUTOMATICALLY_RECOVERABLE
    assert not halt.halted
    assert importer.batches == 1
    assert importer.seen == {"f-1"}
    # Re-running is idempotent at the importer level.
    await service.periodic()
    assert importer.received[0].fill_id.value == "f-1"
    assert len(sink.persisted) == 2


@pytest.mark.asyncio
async def test_unknown_remote_order_is_cancelled_and_halts() -> None:
    remote = RemoteAccountState(
        available=True, open_orders=(make_remote_order(order_id="r-1"),)
    )
    service, _importer, canceller, halt, _sink = _build(remote=remote)
    report = await service.periodic()
    assert report.classification is ReconciliationClass.CANCELLATION_REQUIRED
    assert canceller.cancelled == ["r-1"]
    assert halt.halted


@pytest.mark.asyncio
async def test_unknown_order_without_canceller_is_critical_review() -> None:
    remote = RemoteAccountState(
        available=True, open_orders=(make_remote_order(order_id="r-1"),)
    )
    # No canceller => cannot auto-cancel => escalate to critical review.
    service, _importer, _canceller, halt, _sink = _build(
        remote=remote, canceller=None
    )
    # Rebuild without a canceller explicitly.
    service = ReconciliationService(
        local=FakeLocalStateProvider(),
        remote=FakeRemoteAccountProvider(remote),
        chain=FakeChainStateProvider(),
        sink=FakeSink(),
        market_scope=FakeMarketScope(),
        importer=FakeFillImporter(),
        canceller=None,
        halt=halt,
        clock=FixedClock(1),
    )
    report = await service.periodic()
    assert report.classification is ReconciliationClass.CRITICAL_STOP
    assert halt.halted


@pytest.mark.asyncio
async def test_remote_load_failure_fails_closed() -> None:
    service, _importer, _canceller, halt, sink = _build(
        remote_exc=ReconciliationDataUnavailableError("remote", "boom")
    )
    report = await service.on_user_stream_reconnect()
    assert report.trigger is ReconciliationTrigger.USER_STREAM_RECONNECT
    assert report.classification is ReconciliationClass.CRITICAL_STOP
    assert halt.halted
    assert len(sink.persisted) == 1


@pytest.mark.asyncio
async def test_chain_unsupported_is_tolerated_when_not_required() -> None:
    service, _importer, _canceller, halt, _sink = _build(
        remote=RemoteAccountState(available=True),
        chain_exc=UnsupportedReconciliationOperationError("load_chain_state"),
    )
    report = await service.before_merge()
    assert report.trigger is ReconciliationTrigger.PRE_MERGE
    assert report.classification is ReconciliationClass.CONSISTENT
    assert not halt.halted


@pytest.mark.asyncio
async def test_halt_disabled_by_tuning_still_persists() -> None:
    remote = RemoteAccountState(available=False, note="down")
    service, _importer, _canceller, halt, sink = _build(
        remote=remote,
        tuning=ReconciliationTuning(halt_on_halting_class=False),
    )
    report = await service.on_shutdown()
    assert report.halts_new_trading
    assert not halt.halted  # tuning disabled the halt side effect
    assert len(sink.persisted) == 1


@pytest.mark.asyncio
async def test_on_unknown_submission_uses_correct_trigger() -> None:
    service, *_ = _build(remote=RemoteAccountState(available=True))
    report = await service.on_unknown_submission(OrderId("o-77"))
    assert report.trigger is ReconciliationTrigger.UNKNOWN_SUBMISSION


@pytest.mark.asyncio
async def test_run_periodic_stops_on_event_and_is_cancellation_safe() -> None:
    service, _importer, _canceller, _halt, sink = _build(
        remote=RemoteAccountState(available=True)
    )
    stop = asyncio.Event()

    async def stopper() -> None:
        await asyncio.sleep(0.02)
        stop.set()

    await asyncio.gather(
        service.run_periodic(interval_seconds=0.005, stop_event=stop),
        stopper(),
    )
    assert len(sink.persisted) >= 1


@pytest.mark.asyncio
async def test_run_periodic_rejects_nonpositive_interval() -> None:
    service, *_ = _build(remote=RemoteAccountState(available=True))
    with pytest.raises(ValueError):
        await service.run_periodic(
            interval_seconds=0.0, stop_event=asyncio.Event()
        )
