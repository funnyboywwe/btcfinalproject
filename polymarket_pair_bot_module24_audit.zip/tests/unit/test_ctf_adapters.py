"""Tests that the concrete CTF write adapters fail closed (blocked)."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.ctf.chain_writer import BlockedCtfChainWriter
from polymarket_pair_bot.ctf.errors import (
    GaslessUnavailableError,
    UnsupportedChainOperationError,
)
from polymarket_pair_bot.ctf.models import UnsignedCtfTransaction
from polymarket_pair_bot.ctf.preparer import BlockedCtfTransactionPreparer
from polymarket_pair_bot.ctf.relayer import NullGaslessRelayer
from tests.fixtures.ctf import CONDITION_ID, make_contracts


@pytest.mark.asyncio
async def test_blocked_preparer_split_raises() -> None:
    preparer = BlockedCtfTransactionPreparer(make_contracts())
    with pytest.raises(UnsupportedChainOperationError) as exc:
        await preparer.prepare_split(
            condition_id=CONDITION_ID, partition=(1, 2), amount_base_units=1
        )
    assert exc.value.operation == "ctf.splitPosition"


@pytest.mark.asyncio
async def test_blocked_preparer_merge_redeem_approve_raise() -> None:
    preparer = BlockedCtfTransactionPreparer(make_contracts())
    with pytest.raises(UnsupportedChainOperationError):
        await preparer.prepare_merge(
            condition_id=CONDITION_ID, partition=(1, 2), amount_base_units=1
        )
    with pytest.raises(UnsupportedChainOperationError):
        await preparer.prepare_redeem(condition_id=CONDITION_ID, index_sets=(1, 2))
    with pytest.raises(UnsupportedChainOperationError):
        await preparer.prepare_erc20_approval(
            token_address="0x" + "22" * 20,
            spender="0x" + "33" * 20,
            amount_base_units=1,
        )


@pytest.mark.asyncio
async def test_blocked_chain_writer_raises() -> None:
    writer = BlockedCtfChainWriter()
    unsigned = UnsignedCtfTransaction(
        to="0x" + "33" * 20, data="0xdead", value=0, description="m"
    )
    with pytest.raises(UnsupportedChainOperationError):
        await writer.sign_and_broadcast(
            unsigned,
            nonce=1,
            gas_limit=100,
            max_fee_per_gas_wei=1,
            max_priority_fee_per_gas_wei=1,
        )


@pytest.mark.asyncio
async def test_null_gasless_relayer_unavailable() -> None:
    relayer = NullGaslessRelayer()
    assert relayer.available is False
    unsigned = UnsignedCtfTransaction(
        to="0x" + "33" * 20, data="0x", value=0, description="m"
    )
    with pytest.raises(GaslessUnavailableError):
        await relayer.relay(unsigned, operation_id="op-1")
