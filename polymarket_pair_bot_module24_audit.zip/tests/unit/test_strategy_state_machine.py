"""Scenario tests for the pair-accumulation state machine (Module 18).

Every scenario required by the prompt is covered, plus idempotency, restart and
transition-persistence guarantees. Tests use only in-memory fakes -- no real
order is ever placed (a global safety rule).
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.enums import (
    CtfOperationStatus,
    OutcomeSide,
    ReconciliationStatus,
)
from polymarket_pair_bot.domain.value_objects import MarketId, UnixTimestamp
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.strategy.detector import DetectorAction, ExecutionRole
from polymarket_pair_bot.strategy.session_events import (
    BooksUpdatedEvent,
    FillConfirmedEvent,
    KillSwitchEvent,
    LimitCheckEvent,
    MarketValidatedEvent,
    MergeEvaluateEvent,
    MergeResultEvent,
    ReconciledEvent,
    WindowClosingEvent,
)
from polymarket_pair_bot.strategy.session_states import SessionState
from tests.fixtures.state_machine import (
    DOWN_TOKEN,
    UP_TOKEN,
    FakeReconciliationPort,
    FakeRiskApprovalPort,
    build_harness,
    make_book,
    make_fill,
    make_limits,
    make_market,
)

MAKER = ExecutionRole.MAKER


def _books(market, *, at: int, fresh: bool = True, stc: int = 240):
    return BooksUpdatedEvent(
        event_id=f"books-{at}",
        market_id=market.market_id,
        occurred_at=UnixTimestamp(at),
        market=market,
        up_book=make_book(UP_TOKEN, as_of=at),
        down_book=make_book(DOWN_TOKEN, as_of=at),
        up_is_fresh=fresh,
        down_is_fresh=fresh,
        feed_live=fresh,
        seconds_to_close=stc,
    )


async def _to_ready(h, *, at: int = 100):
    return await h.machine.process(
        MarketValidatedEvent(
            event_id="mv-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(at),
            market=h.market,
        )
    )


async def _first_leg_open(h, *, at: int = 110):
    h.detector.program(DetectorAction.PASSIVE_FIRST_LEG, [(OutcomeSide.UP, MAKER, "0.48", "5")])
    return await h.machine.process(_books(h.market, at=at))


# --------------------------------------------------------------------------- #
# Lifecycle / requirement 5
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
async def test_market_validation_and_book_sync():
    h = build_harness()
    out = await _to_ready(h)
    assert out.state is SessionState.BOOK_SYNCING
    # Stale books keep us waiting (fail closed).
    out = await h.machine.process(_books(h.market, at=105, fresh=False))
    assert out.state is SessionState.BOOK_SYNCING


# 1. no opportunity
@pytest.mark.asyncio
async def test_no_opportunity():
    h = build_harness()
    await _to_ready(h)
    out = await h.machine.process(_books(h.market, at=110))  # empty detector script
    assert out.state is SessionState.WAITING_FOR_EDGE
    assert h.execution.submitted == []


# requirement 7: risk rejection blocks execution
@pytest.mark.asyncio
async def test_risk_rejection_blocks_first_leg():
    h = build_harness(risk=FakeRiskApprovalPort(approved=False))
    await _to_ready(h)
    h.detector.program(DetectorAction.PASSIVE_FIRST_LEG, [(OutcomeSide.UP, MAKER, "0.48", "5")])
    out = await h.machine.process(_books(h.market, at=110))
    assert out.state is SessionState.WAITING_FOR_EDGE
    assert h.execution.submitted == []


# 2. no first-leg fill
@pytest.mark.asyncio
async def test_no_first_leg_fill_then_close():
    h = build_harness()
    await _to_ready(h)
    out = await _first_leg_open(h)
    assert out.state is SessionState.FIRST_LEG_OPEN
    assert len(h.execution.submitted) == 1
    out = await h.machine.process(
        WindowClosingEvent(
            event_id="wc-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(400),
            market=h.market,
            seconds_to_close=5,
        )
    )
    assert out.state is SessionState.CLOSED
    assert h.execution.cancel_market_calls >= 1


# requirement 11: stop new first legs after cutoff
@pytest.mark.asyncio
async def test_first_leg_cutoff_stops_new_legs():
    h = build_harness()
    await _to_ready(h)
    h.detector.program(DetectorAction.PASSIVE_FIRST_LEG, [(OutcomeSide.UP, MAKER, "0.48", "5")])
    out = await h.machine.process(_books(h.market, at=110, stc=45))  # < 90 cutoff
    assert out.state is SessionState.WAITING_FOR_EDGE
    assert h.execution.submitted == []


def _fill_event(market, *, eid, side, price, size, at, fee="0", fid=None):
    return FillConfirmedEvent(
        event_id=eid,
        market_id=market.market_id,
        occurred_at=UnixTimestamp(at),
        market=market,
        fill=make_fill(fill_id=fid or eid, side=side, price=price, size=size, fee=fee, at=at),
    )


# 3. full pair
@pytest.mark.asyncio
async def test_full_pair():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    out = await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    assert out.state is SessionState.UNMATCHED_INVENTORY
    assert out.snapshot.max_second_leg_price is not None
    # second leg placed, then filled
    h.detector.program(DetectorAction.PASSIVE_SECOND_LEG, [(OutcomeSide.DOWN, MAKER, "0.49", "5")])
    out = await h.machine.process(_books(h.market, at=130))
    assert out.state is SessionState.SECOND_LEG_OPEN
    out = await h.machine.process(
        _fill_event(h.market, eid="f2", side=OutcomeSide.DOWN, price="0.49", size="5", at=140)
    )
    assert out.state is SessionState.MATCHED_PAIR
    assert out.snapshot.matched_pairs.value == Decimal("5")
    assert out.snapshot.locked_net_profit is not None


# 4. partial first leg
@pytest.mark.asyncio
async def test_partial_first_leg():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    out = await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="3", at=120)
    )
    assert out.state is SessionState.UNMATCHED_INVENTORY
    assert out.snapshot.unmatched_up.value == Decimal("3")
    # a small opposite fill matches 1, leaving 2 unmatched up
    out = await h.machine.process(
        _fill_event(h.market, eid="f2", side=OutcomeSide.DOWN, price="0.49", size="1", at=125)
    )
    assert out.state is SessionState.UNMATCHED_INVENTORY
    assert out.snapshot.matched_pairs.value == Decimal("1")
    assert out.snapshot.unmatched_up.value == Decimal("2")


# 5. expensive second leg (no affordable completion -> stays unmatched)
@pytest.mark.asyncio
async def test_expensive_second_leg_no_completion():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    # detector finds no affordable second leg
    out = await h.machine.process(_books(h.market, at=130))
    assert out.state is SessionState.UNMATCHED_INVENTORY
    assert len(h.execution.submitted) == 1  # only the first leg


# 6. hedge success
@pytest.mark.asyncio
async def test_hedge_success():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    # FOK hedge completes: program the down fill the hedge order will show
    h.execution.program_fills(
        [make_fill(fill_id="hedge1", side=OutcomeSide.DOWN, price="0.50", size="5", at=300)]
    )
    out = await h.machine.process(
        LimitCheckEvent(
            event_id="lc-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(300),
            market=h.market,
        )
    )
    assert out.state is SessionState.MATCHED_PAIR
    assert out.snapshot.matched_pairs.value == Decimal("5")


# 7. hedge failure (FOK returns no fill)
@pytest.mark.asyncio
async def test_hedge_failure():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    # no programmed fills -> FOK yields nothing
    out = await h.machine.process(
        LimitCheckEvent(
            event_id="lc-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(300),
            market=h.market,
        )
    )
    assert out.state is SessionState.UNWIND_REQUIRED


# hedge not approved -> unwind
@pytest.mark.asyncio
async def test_hedge_not_approved_unwind():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    h.risk.approved = False
    out = await h.machine.process(
        LimitCheckEvent(
            event_id="lc-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(300),
            market=h.market,
        )
    )
    assert out.state is SessionState.UNWIND_REQUIRED


# 8. disconnect while unmatched
@pytest.mark.asyncio
async def test_disconnect_while_unmatched():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    out = await h.machine.process(_books(h.market, at=130, fresh=False))
    assert out.state is SessionState.RECONCILIATION_REQUIRED
    assert ReconciliationTrigger.USER_STREAM_RECONNECT in h.reconciliation.triggers


# 9. restart while unmatched
@pytest.mark.asyncio
async def test_restart_while_unmatched():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    # New machine sharing the SAME store simulates a process restart.
    fresh = build_harness(store=h.store)
    restored = await fresh.machine.restore(MarketId(h.market.market_id.value))
    assert restored is not None
    assert restored.state is SessionState.UNMATCHED_INVENTORY
    assert restored.unmatched_up.value == Decimal("5")
    # It continues from the restored state.
    out = await fresh.machine.process(
        WindowClosingEvent(
            event_id="wc-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(400),
            market=h.market,
            seconds_to_close=5,
        )
    )
    assert out.state is SessionState.UNWIND_REQUIRED


async def _to_matched(h):
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    h.detector.program(DetectorAction.PASSIVE_SECOND_LEG, [(OutcomeSide.DOWN, MAKER, "0.49", "5")])
    await h.machine.process(_books(h.market, at=130))
    await h.machine.process(
        _fill_event(h.market, eid="f2", side=OutcomeSide.DOWN, price="0.49", size="5", at=140)
    )


# 10. merge success
@pytest.mark.asyncio
async def test_merge_success():
    h = build_harness()
    await _to_matched(h)
    out = await h.machine.process(
        MergeEvaluateEvent(
            event_id="me-1", market_id=h.market.market_id, occurred_at=UnixTimestamp(150), market=h.market
        )
    )
    assert out.state is SessionState.MERGE_PENDING
    out = await h.machine.process(
        MergeEvaluateEvent(
            event_id="me-2", market_id=h.market.market_id, occurred_at=UnixTimestamp(160), market=h.market
        )
    )
    assert out.state is SessionState.CLOSED
    assert out.snapshot.matched_pairs.value == Decimal("0")
    assert h.merge.merge_calls == 1


# 11. pending merge (mergeable balance not yet available)
@pytest.mark.asyncio
async def test_pending_merge_awaits_balance():
    from tests.fixtures.state_machine import FakeMergePort

    h = build_harness(merge=FakeMergePort(mergeable="0"))
    await _to_matched(h)
    await h.machine.process(
        MergeEvaluateEvent(
            event_id="me-1", market_id=h.market.market_id, occurred_at=UnixTimestamp(150), market=h.market
        )
    )
    out = await h.machine.process(
        MergeEvaluateEvent(
            event_id="me-2", market_id=h.market.market_id, occurred_at=UnixTimestamp(160), market=h.market
        )
    )
    assert out.state is SessionState.MERGE_PENDING
    assert h.merge.merge_calls == 0


# pending merge -> MERGING -> result confirmed
@pytest.mark.asyncio
async def test_merge_submitted_then_result_confirmed():
    from tests.fixtures.state_machine import FakeMergePort

    h = build_harness(merge=FakeMergePort(status=CtfOperationStatus.SUBMITTED))
    await _to_matched(h)
    await h.machine.process(
        MergeEvaluateEvent(
            event_id="me-1", market_id=h.market.market_id, occurred_at=UnixTimestamp(150), market=h.market
        )
    )
    out = await h.machine.process(
        MergeEvaluateEvent(
            event_id="me-2", market_id=h.market.market_id, occurred_at=UnixTimestamp(160), market=h.market
        )
    )
    assert out.state is SessionState.MERGING
    out = await h.machine.process(
        MergeResultEvent(
            event_id="mr-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(200),
            operation_id="merge-op-1",
            status=CtfOperationStatus.CONFIRMED,
            quantity=out.snapshot.matched_pairs,
        )
    )
    assert out.state is SessionState.CLOSED


# 12. close before merge
@pytest.mark.asyncio
async def test_close_before_merge():
    h = build_harness()
    await _to_matched(h)
    out = await h.machine.process(
        WindowClosingEvent(
            event_id="wc-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(400),
            market=h.market,
            seconds_to_close=2,
        )
    )
    assert out.state is SessionState.MERGE_PENDING
    assert out.snapshot.matched_pairs.value == Decimal("5")


# 13. kill-switch activation
@pytest.mark.asyncio
async def test_kill_switch_activation():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    out = await h.machine.process(
        KillSwitchEvent(
            event_id="ks-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(130),
            reason="operator_halt",
        )
    )
    assert out.state is SessionState.HALTED
    assert h.execution.cancel_market_calls >= 1


# requirement 3: idempotency (event + fill dedup)
@pytest.mark.asyncio
async def test_idempotent_event_replay():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    first = await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    replay = await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    assert replay.idempotent_replay is True
    assert replay.snapshot.unmatched_up.value == first.snapshot.unmatched_up.value


# requirement 1: every transition persisted
@pytest.mark.asyncio
async def test_transitions_persisted():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    assert len(h.store.transitions) >= 2
    assert h.store.transitions[0].to_state is SessionState.BOOK_SYNCING


# uncertain event -> reconcile + stop (requirement 13)
@pytest.mark.asyncio
async def test_uncertain_event_reconciles():
    from polymarket_pair_bot.strategy.session_events import UncertainEvent

    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    out = await h.machine.process(
        UncertainEvent(
            event_id="u-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(130),
            reason="ambiguous",
            trigger=ReconciliationTrigger.MANUAL,
        )
    )
    assert out.state is SessionState.RECONCILIATION_REQUIRED
    assert h.reconciliation.triggers == [ReconciliationTrigger.MANUAL]


# reconciled consistent resumes to a safe state
@pytest.mark.asyncio
async def test_reconciled_resume():
    h = build_harness()
    await _to_ready(h)
    await _first_leg_open(h)
    await h.machine.process(
        _fill_event(h.market, eid="f1", side=OutcomeSide.UP, price="0.48", size="5", at=120)
    )
    await h.machine.process(_books(h.market, at=130, fresh=False))  # -> RECON
    from polymarket_pair_bot.domain.entities import ReconciliationResult

    out = await h.machine.process(
        ReconciledEvent(
            event_id="rc-1",
            market_id=h.market.market_id,
            occurred_at=UnixTimestamp(140),
            result=ReconciliationResult(
                status=ReconciliationStatus.CONSISTENT, as_of=UnixTimestamp(140)
            ),
        )
    )
    assert out.state is SessionState.UNMATCHED_INVENTORY
