"""Unit tests for the pure centralized risk engine (Module 13)."""

from __future__ import annotations

from decimal import Decimal

import pytest
from hypothesis import given
from hypothesis import strategies as st

from polymarket_pair_bot.domain.enums import RiskVerdict
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ProfitAmount,
    Shares,
)
from polymarket_pair_bot.risk.context import OperationKind
from polymarket_pair_bot.risk.engine import RiskEngine
from tests.fixtures.risk import approving_context, make_limits


def test_all_rules_pass_approves() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context())
    assert result.verdict is RiskVerdict.APPROVE
    assert result.approved
    assert result.approved_size.value == Decimal("10")
    assert result.failures() == ()
    # every evaluated rule carries a human reason
    assert all(outcome.reason for outcome in result.outcomes)


def test_default_is_deny_when_leader_unknown() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context(is_execution_leader=None))
    assert result.verdict is RiskVerdict.REJECT
    assert result.approved_size.value == Decimal(0)
    assert "execution_leader" in {o.rule for o in result.failures()}


def test_not_leader_denies() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context(is_execution_leader=False))
    assert result.verdict is RiskVerdict.REJECT


def test_leader_not_required_by_policy() -> None:
    engine = RiskEngine(make_limits(require_execution_leader=False))
    result = engine.evaluate(approving_context(is_execution_leader=None))
    assert result.verdict is RiskVerdict.APPROVE


@pytest.mark.parametrize(
    ("rule", "override"),
    [
        ("max_order_quantity", {"order_quantity": Shares(Decimal("51"))}),
        ("max_order_collateral", {"order_collateral": CollateralAmount(Decimal("26"))}),
        (
            "max_position_per_market",
            {"market_position_notional": CollateralAmount(Decimal("101"))},
        ),
        ("max_unmatched_shares", {"unmatched_shares": Shares(Decimal("51"))}),
        (
            "max_unmatched_collateral",
            {"unmatched_collateral": CollateralAmount(Decimal("51"))},
        ),
        ("max_unmatched_duration", {"oldest_unmatched_age_seconds": 121}),
        ("max_deployed_capital", {"deployed_capital": CollateralAmount(Decimal("201"))}),
        (
            "max_reserved_collateral",
            {"reserved_collateral": CollateralAmount(Decimal("101"))},
        ),
        ("max_open_orders", {"open_orders": 11}),
        ("max_loss_per_window", {"window_loss": CollateralAmount(Decimal("11"))}),
        ("max_daily_loss", {"daily_loss": CollateralAmount(Decimal("26"))}),
        (
            "min_expected_pair_edge",
            {"expected_pair_edge": ProfitAmount(Decimal("0.001"))},
        ),
        ("min_hedge_depth", {"hedge_depth": Shares(Decimal("0"))}),
        ("max_book_age", {"book_age_seconds": 6}),
        ("max_api_failures", {"api_failures": 6}),
        ("max_ws_reconnects", {"ws_reconnects": 11}),
        ("min_wallet_collateral", {"wallet_collateral": CollateralAmount(Decimal("1"))}),
        ("min_polygon_gas", {"gas_balance_native": Decimal("0.1")}),
    ],
)
def test_each_limit_breach_rejects_and_names_rule(
    rule: str, override: dict[str, object]
) -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context(**override))
    assert result.verdict is RiskVerdict.REJECT
    assert result.approved_size.value == Decimal(0)
    failed = {o.rule for o in result.failures()}
    assert rule in failed
    # the failing outcome records both observed and limit for auditability
    outcome = next(o for o in result.outcomes if o.rule == rule)
    assert outcome.observed is not None
    assert outcome.limit is not None


@pytest.mark.parametrize(
    "override",
    [
        {"feed_live": None},
        {"order_quantity": None},
        {"wallet_collateral": None},
        {"seconds_to_close": None},
        {"gas_balance_native": None},
    ],
)
def test_missing_required_input_fails_closed(override: dict[str, object]) -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context(**override))
    assert result.verdict is RiskVerdict.REJECT


def test_dead_feed_rejects() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context(feed_live=False))
    assert result.verdict is RiskVerdict.REJECT
    assert "feed_live" in {o.rule for o in result.failures()}


def test_kill_switch_injection_rejects() -> None:
    engine = RiskEngine(make_limits())
    context = approving_context().with_kill_switch(active=True, reason="halt")
    result = engine.evaluate(context)
    assert result.verdict is RiskVerdict.REJECT
    failure = next(o for o in result.failures() if o.rule == "kill_switch")
    assert failure.reason == "halt"


def test_mandatory_cancel_window_blocks_new_orders() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context(seconds_to_close=20))
    assert result.verdict is RiskVerdict.REJECT
    assert "mandatory_cancel_window" in {o.rule for o in result.failures()}


def test_first_leg_entry_only_checked_when_opening() -> None:
    engine = RiskEngine(make_limits())
    # Not opening a first leg: 40s to close is fine (above cancel window).
    ok = engine.evaluate(approving_context(seconds_to_close=40))
    assert ok.verdict is RiskVerdict.APPROVE
    # Opening a first leg with only 40s left violates latest-first-leg entry.
    late = engine.evaluate(
        approving_context(opening_first_leg=True, seconds_to_close=40)
    )
    assert late.verdict is RiskVerdict.REJECT
    assert "latest_first_leg_entry" in {o.rule for o in late.failures()}


def test_blockchain_operation_checks_gas_and_api_only() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(
        approving_context(
            operation_id="bc-1",
            kind=OperationKind.BLOCKCHAIN,
            order_quantity=None,
        )
    )
    assert result.verdict is RiskVerdict.APPROVE
    # blockchain ops never approve a share size
    assert result.approved_size.value == Decimal(0)
    checked = {o.rule for o in result.outcomes}
    assert checked == {
        "kill_switch",
        "execution_leader",
        "min_polygon_gas",
        "max_api_failures",
    }


def test_blockchain_low_gas_rejects() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(
        approving_context(
            operation_id="bc-2",
            kind=OperationKind.BLOCKCHAIN,
            gas_balance_native=Decimal("0.0"),
        )
    )
    assert result.verdict is RiskVerdict.REJECT


def test_hedge_operation_uses_order_checks() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context(kind=OperationKind.HEDGE))
    assert result.verdict is RiskVerdict.APPROVE
    assert result.approved_size.value == Decimal("10")


def test_to_decision_and_audit_payload_are_consistent() -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(approving_context())
    decision = result.to_decision()
    assert decision.decision_id == "op-1"
    assert decision.verdict is RiskVerdict.APPROVE
    payload = result.audit_payload()
    assert payload["verdict"] == RiskVerdict.APPROVE.value
    assert isinstance(payload["outcomes"], list)


@given(quantity=st.integers(min_value=0, max_value=200))
def test_property_order_quantity_limit_is_monotonic(quantity: int) -> None:
    engine = RiskEngine(make_limits())
    result = engine.evaluate(
        approving_context(order_quantity=Shares(Decimal(quantity)))
    )
    expected_pass = quantity <= 50
    rule_pass = all(
        o.passed for o in result.outcomes if o.rule == "max_order_quantity"
    )
    assert rule_pass is expected_pass
