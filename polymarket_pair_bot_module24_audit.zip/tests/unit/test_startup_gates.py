"""Unit tests for production startup gates.

Infrastructure checks are injected as fakes so no real services are contacted.
Requires pydantic-settings (run via `uv run pytest`).
"""

from __future__ import annotations

import pytest

from polymarket_pair_bot.config.gates import (
    evaluate_config_gates,
    run_production_gates,
)
from polymarket_pair_bot.config.settings import load_config
from polymarket_pair_bot.shared.health import HealthCheckResult

_LIVE_ENV = {
    "PAPER_TRADING": "false",
    "LIVE_TRADING": "true",
    "POLYMARKET_API_KEY": "key-placeholder",
    "POLYMARKET_API_SECRET": "secret-placeholder",
    "POLYMARKET_API_PASSPHRASE": "pass-placeholder",
    "POLYMARKET_PRIVATE_KEY": "0x" + "a" * 64,
    "POLYMARKET_FUNDER_ADDRESS": "0x" + "b" * 40,
    "POLYGON_RPC_PRIMARY": "https://rpc.example/primary",
    "POLYGON_RPC_SECONDARY": "https://rpc.example/secondary",
}


class _FakeCheck:
    def __init__(self, name: str, healthy: bool) -> None:
        self._name = name
        self._healthy = healthy

    @property
    def name(self) -> str:
        return self._name

    async def check(self) -> HealthCheckResult:
        return HealthCheckResult(healthy=self._healthy, detail="fake")


def test_config_gates_fail_on_defaults(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in _LIVE_ENV:
        monkeypatch.delenv(key, raising=False)
    config = load_config()
    results = {gate.name: gate.passed for gate in evaluate_config_gates(config)}
    # Defaults: no wallet ack, no RPC, monitoring disabled.
    assert results["dedicated_wallet_ack"] is False
    assert results["dual_rpc_endpoints"] is False
    assert results["monitoring_enabled"] is False
    # Risk limits and kill switch are positive/configured by default.
    assert results["positive_risk_limits"] is True
    assert results["kill_switch_configured"] is True


def test_all_gates_pass_when_fully_configured(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    for key, value in _LIVE_ENV.items():
        monkeypatch.setenv(key, value)
    monkeypatch.setenv("APP_ENV", "production")
    monkeypatch.setenv("WALLET_IS_DEDICATED_ACK", "true")
    monkeypatch.setenv("MONITORING_ENABLED", "true")
    config = load_config()

    async def _run() -> bool:
        report = await run_production_gates(
            config,
            postgres_check=_FakeCheck("postgres", True),
            redis_check=_FakeCheck("redis", True),
        )
        return report.passed

    import asyncio

    assert asyncio.run(_run()) is True


def test_infra_failure_fails_report(monkeypatch: pytest.MonkeyPatch) -> None:
    for key, value in _LIVE_ENV.items():
        monkeypatch.setenv(key, value)
    monkeypatch.setenv("APP_ENV", "production")
    monkeypatch.setenv("WALLET_IS_DEDICATED_ACK", "true")
    monkeypatch.setenv("MONITORING_ENABLED", "true")
    config = load_config()

    async def _run() -> list[str]:
        report = await run_production_gates(
            config,
            postgres_check=_FakeCheck("postgres", False),
            redis_check=_FakeCheck("redis", True),
        )
        return [f.name for f in report.failures()]

    import asyncio

    failures = asyncio.run(_run())
    assert "postgres_available" in failures
