"""Unit tests for pure recorded-snapshot conversion (Module 22).

Exercises freshness (fail-closed), book conversion and conservative synthetic
trade inference. These functions must never use future information.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.backtest.events import (
    side_is_fresh,
    synthesize_trades,
    to_book_snapshot,
)
from polymarket_pair_bot.domain.enums import OrderSide
from polymarket_pair_bot.domain.value_objects import TokenId, UnixTimestamp
from tests.fixtures.backtest import make_side

_TOKEN = TokenId(
    "100000000000000000000000000000000000000000000000000000000000000001"
)


def test_fresh_side_is_fresh() -> None:
    side = make_side(side="UP", token_id=_TOKEN.value, best_bid="0.44", best_ask="0.45")
    assert side_is_fresh(side) is True


def test_outage_side_is_not_fresh() -> None:
    side = make_side(
        side="UP", token_id=_TOKEN.value, best_bid="0", best_ask="0", live=False
    )
    assert side_is_fresh(side) is False
    assert to_book_snapshot(side, _TOKEN, UnixTimestamp(1_000_000)) is None


def test_to_book_snapshot_sorts_and_validates() -> None:
    side = make_side(side="UP", token_id=_TOKEN.value, best_bid="0.44", best_ask="0.45")
    book = to_book_snapshot(side, _TOKEN, UnixTimestamp(1_000_000))
    assert book is not None
    assert book.best_bid is not None and book.best_ask is not None
    assert book.best_bid.value == Decimal("0.44")
    assert book.best_ask.value == Decimal("0.45")


def test_first_snapshot_yields_no_trades() -> None:
    curr = make_side(side="UP", token_id=_TOKEN.value, best_bid="0.44", best_ask="0.45")
    assert synthesize_trades(None, curr, _TOKEN, trade_id_prefix="t0") == ()


def test_reduced_ask_size_infers_buy_print() -> None:
    prev = make_side(
        side="UP", token_id=_TOKEN.value, best_bid="0.44", best_ask="0.45", depth="500"
    )
    curr = make_side(
        side="UP", token_id=_TOKEN.value, best_bid="0.44", best_ask="0.45", depth="300"
    )
    trades = synthesize_trades(prev, curr, _TOKEN, trade_id_prefix="t1")
    # Bid size also shrank (500 -> 300) so both a SELL and BUY print appear.
    aggressors = {t.aggressor for t in trades}
    assert OrderSide.BUY in aggressors
    for trade in trades:
        assert trade.size.value == Decimal(200)


def test_outage_between_snapshots_yields_no_trades() -> None:
    prev = make_side(side="UP", token_id=_TOKEN.value, best_bid="0.44", best_ask="0.45")
    curr = make_side(
        side="UP", token_id=_TOKEN.value, best_bid="0", best_ask="0", live=False
    )
    assert synthesize_trades(prev, curr, _TOKEN, trade_id_prefix="t2") == ()
