"""Domain <-> ORM round-trip mapping tests (in-memory; no database).

These confirm that mapping preserves ``Decimal`` values exactly and that no
float is introduced anywhere in the conversion.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.entities import (
    ExchangeOrder,
    Fill,
    InventorySnapshot,
    MatchedPair,
    Position,
)
from polymarket_pair_bot.domain.enums import (
    OrderSide,
    OrderStatus,
    OutcomeSide,
)
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ConditionId,
    FeeAmount,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.persistence import mappers


def test_fill_round_trip_preserves_decimal() -> None:
    fill = Fill(
        fill_id=FillId("fill-1"),
        order_id=OrderId("order-1"),
        token_id=TokenId("123"),
        side=OrderSide.BUY,
        price=ProbabilityPrice(Decimal("0.421000")),
        size=Shares(Decimal("12.500000")),
        fee=FeeAmount(Decimal("0.010000")),
        filled_at=UnixTimestamp(1_760_000_000),
    )
    restored = mappers.fill_from_row(mappers.fill_to_row(fill))
    assert restored == fill
    assert isinstance(restored.price.value, Decimal)


def test_exchange_order_round_trip() -> None:
    order = ExchangeOrder(
        order_id=OrderId("order-1"),
        intent_id="intent-1",
        token_id=TokenId("123"),
        side=OrderSide.BUY,
        limit_price=ProbabilityPrice(Decimal("0.500000")),
        original_size=Shares(Decimal("10.000000")),
        filled_size=Shares(Decimal("4.000000")),
        status=OrderStatus.PARTIALLY_FILLED,
        created_at=UnixTimestamp(1_760_000_000),
        updated_at=UnixTimestamp(1_760_000_050),
    )
    row = mappers.order_to_row(order, market_id=MarketId("mkt-1"))
    assert row.market_id == "mkt-1"
    restored = mappers.order_from_row(row)
    assert restored == order


def test_inventory_round_trip() -> None:
    snapshot = InventorySnapshot(
        market_id=MarketId("mkt-1"),
        up_position=Position(
            token_id=TokenId("111"),
            side=OutcomeSide.UP,
            quantity=Shares(Decimal("5.000000")),
            average_price=ProbabilityPrice(Decimal("0.480000")),
            fees_paid=FeeAmount(Decimal("0.020000")),
        ),
        down_position=Position(
            token_id=TokenId("222"),
            side=OutcomeSide.DOWN,
            quantity=Shares(Decimal("5.000000")),
            average_price=ProbabilityPrice(Decimal("0.500000")),
            fees_paid=FeeAmount(Decimal("0.020000")),
        ),
        matched_pairs=Shares(Decimal("5.000000")),
        as_of=UnixTimestamp(1_760_000_000),
    )
    restored = mappers.inventory_from_row(mappers.inventory_to_row(snapshot))
    assert restored == snapshot


def test_matched_pair_round_trip_allows_negative_profit() -> None:
    pair = MatchedPair(
        market_id=MarketId("mkt-1"),
        condition_id=ConditionId("0x" + "ab" * 32),
        quantity=Shares(Decimal("5.000000")),
        up_cost=CollateralAmount(Decimal("2.400000")),
        down_cost=CollateralAmount(Decimal("2.550000")),
        fees=FeeAmount(Decimal("0.050000")),
        locked_value=CollateralAmount(Decimal("5.000000")),
        net_profit=ProfitAmount(Decimal("-0.000000")),
        created_at=UnixTimestamp(1_760_000_000),
    )
    restored = mappers.matched_pair_from_row(mappers.matched_pair_to_row(pair))
    assert restored == pair
