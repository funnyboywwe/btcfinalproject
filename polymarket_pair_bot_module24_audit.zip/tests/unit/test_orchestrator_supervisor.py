"""Unit tests for the orchestrator supervisor, degraded mode and readiness."""

from __future__ import annotations

import asyncio

import pytest

from polymarket_pair_bot.orchestrator.degraded import DegradedModeController
from polymarket_pair_bot.orchestrator.readiness import ReadinessProbe
from polymarket_pair_bot.orchestrator.supervisor import TaskSupervisor
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.shared.health import HealthState, HealthTracker

from tests.fixtures.orchestrator import (
    FakeDependencyCheck,
    FakeKillSwitch,
    FakeMetrics,
    RecordingExecutionControl,
    RecordingReconciler,
)


@pytest.mark.asyncio
async def test_supervisor_critical_failure_is_surfaced() -> None:
    supervisor = TaskSupervisor()

    async def boom() -> None:
        raise RuntimeError("kaboom")

    supervisor.start("critical-task", boom(), critical=True)
    failure = await asyncio.wait_for(supervisor.wait_for_critical_failure(), 1.0)
    assert failure.name == "critical-task"
    assert failure.critical is True
    assert isinstance(failure.error, RuntimeError)


@pytest.mark.asyncio
async def test_supervisor_noncritical_failure_is_not_critical() -> None:
    supervisor = TaskSupervisor()

    async def boom() -> None:
        raise RuntimeError("minor")

    supervisor.start("noncritical-task", boom(), critical=False)
    await asyncio.sleep(0)
    await asyncio.sleep(0)
    assert supervisor.first_failure is None


@pytest.mark.asyncio
async def test_supervisor_marks_producers_done() -> None:
    supervisor = TaskSupervisor()
    supervisor.expect_completion = True

    async def finite() -> None:
        return None

    supervisor.start("producer:a", finite(), critical=True, is_producer=True)
    await asyncio.wait_for(supervisor.wait_producers_done(), 1.0)
    assert supervisor.all_producers_done() is True
    assert supervisor.first_failure is None


@pytest.mark.asyncio
async def test_supervisor_cancel_all_stops_running_tasks() -> None:
    supervisor = TaskSupervisor()

    async def forever() -> None:
        await asyncio.Event().wait()

    supervisor.start("long", forever(), critical=False)
    await asyncio.sleep(0)
    await supervisor.cancel_all(1.0)
    assert supervisor.active_count == 0


def _degraded(consistent: bool, *, raises: bool = False):
    log: list[str] = []
    stops: list[str] = []
    execution = RecordingExecutionControl(log)
    reconciler = RecordingReconciler(log, consistent=consistent, raises=raises)
    controller = DegradedModeController(
        execution=execution,
        reconciler=reconciler,
        health=HealthTracker(),
        metrics=FakeMetrics(),
        request_stop=stops.append,
    )
    return controller, execution, reconciler, stops


@pytest.mark.asyncio
async def test_degraded_consistent_blocks_cancels_and_stops() -> None:
    controller, execution, reconciler, stops = _degraded(True)
    await controller.enter("boom", trigger=ReconciliationTrigger.UNKNOWN_SUBMISSION)
    assert execution.new_orders_blocked is True
    assert execution.cancel_calls == 1
    assert reconciler.triggers == [ReconciliationTrigger.UNKNOWN_SUBMISSION]
    assert stops and stops[0].startswith("degraded:")


@pytest.mark.asyncio
async def test_degraded_inconsistent_stops_uncertain() -> None:
    controller, _e, _r, stops = _degraded(False)
    await controller.enter("boom")
    assert stops and stops[0].startswith("degraded-uncertain:")


@pytest.mark.asyncio
async def test_degraded_reconcile_error_fails_closed() -> None:
    controller, _e, _r, stops = _degraded(True, raises=True)
    await controller.enter("boom")
    # A reconcile error must be treated as uncertainty (fail closed).
    assert stops and stops[0].startswith("degraded-uncertain:")


@pytest.mark.asyncio
async def test_degraded_is_idempotent() -> None:
    controller, execution, _r, stops = _degraded(True)
    await controller.enter("first")
    await controller.enter("second")
    assert execution.cancel_calls == 1
    assert len(stops) == 1


def _probe(*, health_state, active=False, unreadable=False, blocked=False, checks=()):
    health = HealthTracker()
    execution = RecordingExecutionControl([])
    probe = ReadinessProbe(
        health=health,
        kill_switch=FakeKillSwitch(active=active, unreadable=unreadable),
        execution=execution,
        dependency_checks=checks,
        session_ready=lambda: True,
    )
    return probe, health, execution


@pytest.mark.asyncio
async def test_readiness_ready_when_all_green() -> None:
    probe, health, _e = _probe(health_state=HealthState.READY)
    await health.set(HealthState.READY, "ok")
    report = await probe.evaluate()
    assert report.ready is True


@pytest.mark.asyncio
async def test_readiness_not_ready_when_kill_switch_active() -> None:
    probe, health, _e = _probe(health_state=HealthState.READY, active=True)
    await health.set(HealthState.READY, "ok")
    report = await probe.evaluate()
    assert report.ready is False
    assert report.checks["kill_switch_inactive"] is False


@pytest.mark.asyncio
async def test_readiness_fails_closed_when_kill_switch_unreadable() -> None:
    probe, health, _e = _probe(health_state=HealthState.READY, unreadable=True)
    await health.set(HealthState.READY, "ok")
    report = await probe.evaluate()
    assert report.ready is False


@pytest.mark.asyncio
async def test_readiness_reflects_dependency_checks() -> None:
    probe, health, _e = _probe(
        health_state=HealthState.READY,
        checks=[FakeDependencyCheck("postgres", healthy=False)],
    )
    await health.set(HealthState.READY, "ok")
    report = await probe.evaluate()
    assert report.ready is False
    assert report.checks["postgres"] is False
