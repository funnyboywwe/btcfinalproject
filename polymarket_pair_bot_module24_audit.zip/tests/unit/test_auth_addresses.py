"""Unit tests for address validation / identity construction."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.auth.addresses import build_account_identity
from polymarket_pair_bot.auth.errors import AddressValidationError
from polymarket_pair_bot.config.enums import SignatureType
from tests.fixtures.auth import FUNDER_ADDRESS, SIGNER_ADDRESS


def test_build_identity_normalizes_addresses() -> None:
    identity = build_account_identity(
        signer_address=SIGNER_ADDRESS.upper().replace("0X", "0x"),
        funder_address=FUNDER_ADDRESS,
        signature_type=SignatureType.EOA,
        chain_id=137,
    )
    assert identity.signer_address == SIGNER_ADDRESS
    assert identity.funder_address == FUNDER_ADDRESS
    assert identity.signature_type is SignatureType.EOA
    assert identity.chain_id == 137


def test_all_documented_signature_types_supported() -> None:
    for sig_type in SignatureType:
        identity = build_account_identity(
            signer_address=SIGNER_ADDRESS,
            funder_address=FUNDER_ADDRESS,
            signature_type=sig_type,
            chain_id=137,
        )
        assert identity.signature_type is sig_type


def test_invalid_address_raises_typed_error() -> None:
    with pytest.raises(AddressValidationError):
        build_account_identity(
            signer_address="not-an-address",
            funder_address=FUNDER_ADDRESS,
            signature_type=SignatureType.EOA,
            chain_id=137,
        )


def test_invalid_chain_id_raises_typed_error() -> None:
    with pytest.raises(AddressValidationError):
        build_account_identity(
            signer_address=SIGNER_ADDRESS,
            funder_address=FUNDER_ADDRESS,
            signature_type=SignatureType.EOA,
            chain_id=0,
        )
