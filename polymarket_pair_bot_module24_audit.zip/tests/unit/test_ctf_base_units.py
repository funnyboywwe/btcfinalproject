"""Regression tests for CTF share -> on-chain base-unit conversion.

The review hardened ``CtfOperationService._to_base_units`` to floor (round
toward zero for non-negative shares) instead of using the ambient Decimal
context rounding (ROUND_HALF_EVEN). Rounding UP could request more base units
than are actually held and revert a merge/split on-chain (wasted gas / stuck
state). This mirrors the existing ``CollateralAmount.base_units`` convention.
"""

from __future__ import annotations

from decimal import Decimal
from types import SimpleNamespace

from polymarket_pair_bot.ctf.service import CtfOperationService
from polymarket_pair_bot.domain.value_objects import Shares


def _base_units(shares: Shares, decimals: int = 6) -> int:
    fake_self = SimpleNamespace(
        _contracts=SimpleNamespace(collateral_decimals=decimals)
    )
    return CtfOperationService._to_base_units(fake_self, shares)


def test_exact_for_quantized_shares() -> None:
    assert _base_units(Shares(Decimal("1.5"))) == 1_500_000
    assert _base_units(Shares(Decimal("0.000001"))) == 1
    assert _base_units(Shares(Decimal("0"))) == 0


def test_sub_base_unit_dust_floors_down_never_up() -> None:
    # 1.0000005 shares -> 1_000_000 base units (floored), never 1_000_001.
    assert _base_units(Shares(Decimal("1.0000005"))) == 1_000_000
    # 0.9999999 shares -> 999_999 base units, never rounded up to 1_000_000.
    assert _base_units(Shares(Decimal("0.9999999"))) == 999_999


def test_floor_with_smaller_collateral_decimals() -> None:
    # 2-decimal collateral: 1.239 -> 123 (floor), never 124.
    assert _base_units(Shares(Decimal("1.239")), decimals=2) == 123
