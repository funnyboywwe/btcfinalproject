"""Static invariant tests for the production deployment packaging (Module 25).

These tests intentionally use plain text/regex assertions (no YAML or Docker
dependency) so they run in the standard unit-test environment without extra
packages or a Docker daemon. They guard the security-critical properties of the
deployment artifacts:

* the image runs as a non-root user and is minimal,
* the entrypoint supports the migrate/bot/health roles and execs the target,
* Postgres/Redis are never published to the host and stay on an internal network,
* the bot container is read-only, drops privileges, and has resource/log limits,
* trading is OFF by default in the env template,
* NO secret material is committed anywhere under the deployment tree.

They place no orders and touch no infrastructure.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
DOCKERFILE = ROOT / "Dockerfile"
ENTRYPOINT = ROOT / "docker" / "entrypoint.sh"
COMPOSE = ROOT / "docker" / "docker-compose.prod.yml"
APP_ENV = ROOT / "docker" / "env" / "app.env.example"
SECRETS_ENV = ROOT / "docker" / "secrets" / "secrets.env.example"
ENV_PROD = ROOT / "docker" / ".env.prod.example"
SYSTEMD = ROOT / "deploy" / "systemd" / "polymarket-pair-bot.service"
SYSTEMD_NATIVE = ROOT / "deploy" / "systemd" / "polymarket-pair-bot-native.service"
SCRIPTS_DIR = ROOT / "deploy" / "scripts"


def _read(path: Path) -> str:
    assert path.is_file(), f"missing deployment artifact: {path.relative_to(ROOT)}"
    return path.read_text(encoding="utf-8")


# --------------------------------------------------------------------------- #
# Dockerfile
# --------------------------------------------------------------------------- #
def test_dockerfile_runs_as_non_root() -> None:
    text = _read(DOCKERFILE)
    assert re.search(r"^USER\s+ppb", text, re.MULTILINE), "image must drop to non-root USER ppb"
    assert "useradd" in text and "10001" in text, "must create a fixed unprivileged uid"


def test_dockerfile_is_minimal_and_no_dev() -> None:
    text = _read(DOCKERFILE)
    assert "python:3.12-slim" in text, "use a slim base image"
    assert "--no-dev" in text, "dev/test tooling must be excluded from the runtime image"


def test_dockerfile_has_healthcheck() -> None:
    assert "HEALTHCHECK" in _read(DOCKERFILE)


# --------------------------------------------------------------------------- #
# Entrypoint
# --------------------------------------------------------------------------- #
def test_entrypoint_supports_roles_and_execs() -> None:
    text = _read(ENTRYPOINT)
    for role in ("bot)", "migrate)", "healthcheck)"):
        assert role in text, f"entrypoint must handle '{role}'"
    assert "exec polymarket-pair-bot" in text, "bot role must exec the app for signal delivery"
    assert "persistence.cli migrate" in text, "migrate role must run the migration CLI"


# --------------------------------------------------------------------------- #
# Compose (production)
# --------------------------------------------------------------------------- #
def test_compose_does_not_publish_db_or_cache_ports() -> None:
    text = _read(COMPOSE)
    # Split the file into per-service blocks and assert neither postgres nor
    # redis declares a `ports:` mapping.
    for svc in ("postgres", "redis"):
        block = _service_block(text, svc)
        assert "ports:" not in block, f"{svc} must not publish host ports"


def test_compose_published_ports_are_loopback_only() -> None:
    text = _read(COMPOSE)
    # Every published port mapping must be bound to BIND_ADDR (loopback default).
    for line in text.splitlines():
        stripped = line.strip()
        m = re.match(r'-\s*"([^"]+:\d+:\d+)"', stripped)
        if m:
            assert "${BIND_ADDR" in m.group(1), f"port mapping must bind BIND_ADDR: {stripped}"


def test_compose_backend_network_is_internal() -> None:
    text = _read(COMPOSE)
    assert re.search(r"backend:\s*\n\s*internal:\s*true", text), "backend network must be internal"


def test_compose_bot_is_hardened() -> None:
    block = _service_block(_read(COMPOSE), "bot")
    assert "read_only: true" in block
    assert "no-new-privileges:true" in block
    assert "cap_drop:" in block and "ALL" in block
    assert 'restart: "no"' in block, "bot restart must be 'no' so systemd is the single supervisor"
    assert "limits:" in block, "bot must declare resource limits"
    assert "stop_grace_period" in block, "bot must allow graceful shutdown"


def test_compose_bot_waits_for_migrations() -> None:
    block = _service_block(_read(COMPOSE), "bot")
    assert "service_completed_successfully" in block, "bot must wait for the migrate job"


# --------------------------------------------------------------------------- #
# Env / secret templates
# --------------------------------------------------------------------------- #
def test_app_env_defaults_to_paper_trading() -> None:
    text = _read(APP_ENV)
    assert "PAPER_TRADING=true" in text
    assert "LIVE_TRADING=false" in text


def test_secret_templates_have_blank_values() -> None:
    text = _read(SECRETS_ENV)
    secret_keys = [
        "POLYMARKET_API_KEY",
        "POLYMARKET_API_SECRET",
        "POLYMARKET_API_PASSPHRASE",
        "POLYMARKET_PRIVATE_KEY",
        "POLYMARKET_FUNDER_ADDRESS",
        "POLYGON_RPC_PRIMARY",
        "POLYGON_RPC_SECONDARY",
        "DASHBOARD_AUTH_TOKEN",
    ]
    for key in secret_keys:
        assert re.search(rf"^{key}=\s*$", text, re.MULTILINE), f"{key} must be present and blank"
    # Dual RPC must be represented in the template.
    assert "POLYGON_RPC_PRIMARY" in text and "POLYGON_RPC_SECONDARY" in text


# --------------------------------------------------------------------------- #
# systemd
# --------------------------------------------------------------------------- #
def test_systemd_units_have_restart_limits() -> None:
    for unit in (SYSTEMD, SYSTEMD_NATIVE):
        text = _read(unit)
        assert "StartLimitBurst" in text, f"{unit.name} must cap restarts"
        assert "StartLimitIntervalSec" in text
        assert "TimeoutStopSec" in text, f"{unit.name} must allow graceful stop"


def test_native_systemd_unit_is_hardened_non_root() -> None:
    text = _read(SYSTEMD_NATIVE)
    assert re.search(r"^User=ppb", text, re.MULTILINE)
    assert "NoNewPrivileges=true" in text
    assert "ProtectSystem=strict" in text


# --------------------------------------------------------------------------- #
# No secret material anywhere in the deployment tree
# --------------------------------------------------------------------------- #
SECRET_PATTERNS = [
    re.compile(r"0x[0-9a-fA-F]{40,}"),          # private keys / signed tx blobs / addresses+
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
]


def _deployment_files() -> list[Path]:
    files: list[Path] = [DOCKERFILE, ENTRYPOINT, COMPOSE, APP_ENV, SECRETS_ENV, ENV_PROD]
    files += sorted(SCRIPTS_DIR.glob("*.sh"))
    files += sorted((ROOT / "deploy" / "systemd").glob("*"))
    files += sorted((ROOT / "docs" / "runbooks").glob("*.md"))
    files.append(ROOT / "docs" / "deployment.md")
    return [f for f in files if f.is_file()]


@pytest.mark.parametrize("path", _deployment_files(), ids=lambda p: str(p.name))
def test_no_secret_material_committed(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    for pattern in SECRET_PATTERNS:
        assert not pattern.search(text), f"possible secret material in {path.relative_to(ROOT)}"


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _service_block(compose_text: str, service: str) -> str:
    """Return the text of a single top-level compose service block.

    Services are indented by two spaces under `services:`. A block runs until the
    next service at the same indentation (or the `volumes:`/`networks:` sections).
    """
    lines = compose_text.splitlines()
    start = None
    for i, line in enumerate(lines):
        if re.match(rf"^  {re.escape(service)}:\s*$", line):
            start = i
            break
    assert start is not None, f"service '{service}' not found in compose file"
    end = len(lines)
    for j in range(start + 1, len(lines)):
        line = lines[j]
        if line and not line.startswith("   ") and not line.startswith("  #"):
            # De-dented to <=2 spaces of a new top-level key or service.
            if re.match(r"^  \S", line) or re.match(r"^\S", line):
                end = j
                break
    return "\n".join(lines[start:end])
