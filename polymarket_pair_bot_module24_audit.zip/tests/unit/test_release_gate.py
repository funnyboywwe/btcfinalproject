"""Unit tests for the release gate (Module 24).

Everything runs offline through a :class:`FakeCommandRunner`; no subprocess is
ever spawned and no network or order path is touched.
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal
from pathlib import Path

import pytest

from polymarket_pair_bot.release import (
    CHECKLIST_ITEMS,
    COMMAND_GATES,
    GateStatus,
    PaperStatistics,
    ReleaseGateRunner,
    SecretScanner,
    StaticPaperStatistics,
    build_checklist,
)
from polymarket_pair_bot.release.gates import CommandResult

ALL_KEYS = tuple(key for key, _ in CHECKLIST_ITEMS)


class FakeCommandRunner:
    """Returns a scripted result per command; passes unless told otherwise."""

    def __init__(
        self,
        *,
        failures: frozenset[str] = frozenset(),
        raises: frozenset[str] = frozenset(),
    ) -> None:
        self.failures = failures
        self.raises = raises
        self.calls: list[tuple[str, ...]] = []

    def run(self, command: Sequence[str]) -> CommandResult:
        cmd = tuple(command)
        self.calls.append(cmd)
        tool = cmd[0]
        if tool in self.raises:
            raise OSError(f"boom: {tool}")
        if tool in self.failures:
            return CommandResult(returncode=1, stderr=f"{tool} failed")
        return CommandResult(returncode=0, stdout="ok")


def _sufficient_stats() -> PaperStatistics:
    return PaperStatistics(
        paper_sessions=250,
        confirmed_pairs=10,
        unmatched_incidents=1,
        gross_pair_cost=Decimal("0"),
        required_sessions=200,
    )


def test_all_pass_but_checklist_incomplete_is_not_live_ready(tmp_path: Path) -> None:
    runner = ReleaseGateRunner(
        command_runner=FakeCommandRunner(),
        project_root=tmp_path,
        paper_statistics=StaticPaperStatistics(_sufficient_stats()),
    )
    report = runner.run()
    # Every command gate + the secret scan passed.
    assert report.all_mandatory_passed is True
    assert all(g.passed for g in report.gates)
    # ...but the human checklist defaults to unconfirmed, so NOT live ready.
    assert report.checklist_complete is False
    assert report.live_ready is False
    # There is one gate per command plus the in-process secret scan.
    assert len(report.gates) == len(COMMAND_GATES) + 1


def test_full_checklist_and_gates_is_live_ready(tmp_path: Path) -> None:
    runner = ReleaseGateRunner(
        command_runner=FakeCommandRunner(),
        project_root=tmp_path,
        paper_statistics=StaticPaperStatistics(_sufficient_stats()),
        confirmed_checklist=ALL_KEYS,
    )
    report = runner.run()
    assert report.all_mandatory_passed is True
    assert report.checklist_complete is True
    assert report.live_ready is True


def test_one_mandatory_failure_blocks_readiness(tmp_path: Path) -> None:
    runner = ReleaseGateRunner(
        command_runner=FakeCommandRunner(failures=frozenset({"mypy"})),
        project_root=tmp_path,
        paper_statistics=StaticPaperStatistics(_sufficient_stats()),
        confirmed_checklist=ALL_KEYS,
    )
    report = runner.run()
    type_check = next(g for g in report.gates if g.name == "type-check")
    assert type_check.status is GateStatus.FAILED
    assert report.all_mandatory_passed is False
    assert report.live_ready is False
    assert any("type-check" in risk for risk in report.unresolved_risks)


def test_missing_tool_fails_closed_as_error(tmp_path: Path) -> None:
    runner = ReleaseGateRunner(
        command_runner=FakeCommandRunner(raises=frozenset({"ruff"})),
        project_root=tmp_path,
        paper_statistics=StaticPaperStatistics(_sufficient_stats()),
        confirmed_checklist=ALL_KEYS,
    )
    report = runner.run()
    formatting = next(g for g in report.gates if g.name == "formatting")
    assert formatting.status is GateStatus.ERROR
    assert formatting.passed is False
    assert report.all_mandatory_passed is False
    assert report.live_ready is False


def test_secret_scan_finds_planted_secret(tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    planted = "PRIVATE_KEY = \"0x" + "a" * 64 + "\"\n"
    (src / "leak.py").write_text(planted, encoding="utf-8")
    runner = ReleaseGateRunner(
        command_runner=FakeCommandRunner(),
        project_root=tmp_path,
        paper_statistics=StaticPaperStatistics(_sufficient_stats()),
        confirmed_checklist=ALL_KEYS,
    )
    report = runner.run()
    secret_gate = next(g for g in report.gates if g.name == "secret-scan")
    assert secret_gate.status is GateStatus.FAILED
    assert report.live_ready is False
    # The value itself is never echoed into the report.
    assert "a" * 64 not in secret_gate.detail
    assert "REDACTED" in secret_gate.detail


def test_insufficient_paper_sample_is_unresolved_risk(tmp_path: Path) -> None:
    stats = PaperStatistics(paper_sessions=5, required_sessions=200)
    runner = ReleaseGateRunner(
        command_runner=FakeCommandRunner(),
        project_root=tmp_path,
        paper_statistics=StaticPaperStatistics(stats),
        confirmed_checklist=ALL_KEYS,
    )
    report = runner.run()
    assert report.paper_statistics.sufficient_sample is False
    assert any("Paper sample" in risk for risk in report.unresolved_risks)


def test_secret_scanner_direct_text_scan() -> None:
    scanner = SecretScanner()
    findings = scanner.scan_text("api_secret = 'super-secret-value-123'", path="x.py")
    assert findings
    assert findings[0].rule == "quoted_secret_assignment"
    # Ordinary code with the word secret in a comment is not flagged.
    assert scanner.scan_text("# this handles the secret safely", path="y.py") == []


def test_build_checklist_marks_confirmations() -> None:
    checklist = build_checklist({"dedicated_wallet"})
    confirmed = {item.key for item in checklist if item.confirmed}
    assert confirmed == {"dedicated_wallet"}
    assert len(checklist) == len(CHECKLIST_ITEMS)


def test_no_gates_configured_is_not_ready(tmp_path: Path) -> None:
    # Defensive: an empty gate set must not read as "all passed".
    runner = ReleaseGateRunner(
        command_runner=FakeCommandRunner(),
        project_root=tmp_path,
        paper_statistics=StaticPaperStatistics(_sufficient_stats()),
        confirmed_checklist=ALL_KEYS,
        command_gates=(),
    )
    report = runner.run()
    # Only the secret-scan gate remains; that is still mandatory and passes,
    # so all_mandatory_passed is True with a single mandatory gate.
    assert report.all_mandatory_passed is True
    assert len(report.gates) == 1


if __name__ == "__main__":  # pragma: no cover - convenience for offline runs
    raise SystemExit(pytest.main([__file__, "-q"]))
