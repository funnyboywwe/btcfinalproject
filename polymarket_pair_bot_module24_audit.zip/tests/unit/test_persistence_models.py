"""Schema-shape unit tests: numeric types, table set, and unique constraints.

These assert on SQLAlchemy metadata only (no database connection needed).
"""

from __future__ import annotations

import sqlalchemy as sa

from polymarket_pair_bot.persistence.base import Base
from polymarket_pair_bot.persistence.models import ALL_TABLES

_EXPECTED_TABLES = {
    "markets",
    "market_windows",
    "order_intents",
    "exchange_orders",
    "fills",
    "inventory_snapshots",
    "pair_opportunities",
    "matched_pairs",
    "ctf_operations",
    "blockchain_transactions",
    "reconciliation_runs",
    "reconciliation_discrepancies",
    "risk_events",
    "kill_switch_events",
    "system_events",
}


def test_all_expected_tables_present() -> None:
    assert set(Base.metadata.tables) == _EXPECTED_TABLES
    assert len(ALL_TABLES) == len(_EXPECTED_TABLES)


def test_no_column_uses_binary_float() -> None:
    # Requirement 2: monetary/price/quantity values must never be binary floats.
    for table in Base.metadata.tables.values():
        for column in table.columns:
            assert not isinstance(column.type, sa.Float), (
                f"{table.name}.{column.name} uses a binary Float type"
            )


def test_money_columns_are_numeric() -> None:
    money_columns = {
        ("fills", "price"),
        ("fills", "size"),
        ("fills", "fee"),
        ("matched_pairs", "net_profit"),
        ("matched_pairs", "locked_value"),
        ("inventory_snapshots", "matched_pairs"),
        ("pair_opportunities", "effective_pair_cost"),
    }
    for table_name, column_name in money_columns:
        column = Base.metadata.tables[table_name].columns[column_name]
        assert isinstance(column.type, sa.Numeric)
        assert not isinstance(column.type, sa.Float)


def test_idempotency_unique_and_primary_keys() -> None:
    tables = Base.metadata.tables
    # Exchange order id, fill id, intent id, risk decision id, CTF operation id
    # are primary keys (implicitly unique).
    assert list(tables["exchange_orders"].primary_key.columns.keys()) == ["order_id"]
    assert list(tables["fills"].primary_key.columns.keys()) == ["fill_id"]
    assert list(tables["order_intents"].primary_key.columns.keys()) == ["intent_id"]
    assert list(tables["risk_events"].primary_key.columns.keys()) == ["decision_id"]
    assert list(tables["ctf_operations"].primary_key.columns.keys()) == [
        "operation_id"
    ]


def test_blockchain_operation_key_is_unique() -> None:
    table = Base.metadata.tables["blockchain_transactions"]
    unique_cols = {
        tuple(c.name for c in constraint.columns)
        for constraint in table.constraints
        if isinstance(constraint, sa.UniqueConstraint)
    }
    assert ("operation_key",) in unique_cols


def test_condition_id_is_unique_on_markets() -> None:
    table = Base.metadata.tables["markets"]
    unique_cols = {
        tuple(c.name for c in constraint.columns)
        for constraint in table.constraints
        if isinstance(constraint, sa.UniqueConstraint)
    }
    assert ("condition_id",) in unique_cols
