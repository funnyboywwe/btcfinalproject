"""Structural conformance: SQLAlchemy repositories satisfy domain protocols.

Method-only protocols support ``issubclass`` when ``@runtime_checkable``. This
locks the dependency-inversion contract: the domain defines the ports and the
persistence layer implements them.
"""

from __future__ import annotations

from polymarket_pair_bot.domain import repositories as ports
from polymarket_pair_bot.persistence import repositories as impls


def test_repository_impls_match_domain_protocols() -> None:
    assert issubclass(impls.MarketRepositoryImpl, ports.MarketRepository)
    assert issubclass(impls.MarketWindowRepositoryImpl, ports.MarketWindowRepository)
    assert issubclass(impls.OrderIntentRepositoryImpl, ports.OrderIntentRepository)
    assert issubclass(impls.ExchangeOrderRepositoryImpl, ports.ExchangeOrderRepository)
    assert issubclass(impls.FillRepositoryImpl, ports.FillRepository)
    assert issubclass(impls.InventoryRepositoryImpl, ports.InventoryRepository)
    assert issubclass(
        impls.PairOpportunityRepositoryImpl, ports.PairOpportunityRepository
    )
    assert issubclass(impls.MatchedPairRepositoryImpl, ports.MatchedPairRepository)
    assert issubclass(impls.CtfOperationRepositoryImpl, ports.CtfOperationRepository)
    assert issubclass(
        impls.BlockchainTransactionRepositoryImpl,
        ports.BlockchainTransactionRepository,
    )
    assert issubclass(
        impls.ReconciliationRepositoryImpl, ports.ReconciliationRepository
    )
    assert issubclass(impls.RiskEventRepositoryImpl, ports.RiskEventRepository)
    assert issubclass(
        impls.KillSwitchEventRepositoryImpl, ports.KillSwitchEventRepository
    )
    assert issubclass(impls.AuditJournalImpl, ports.AuditJournal)


def test_unit_of_work_exposes_all_repositories() -> None:
    # The concrete unit of work must define the repository-binding for every
    # port named on the UnitOfWork protocol.
    required = {
        "markets",
        "windows",
        "intents",
        "orders",
        "fills",
        "inventory",
        "opportunities",
        "matched_pairs",
        "ctf_operations",
        "blockchain",
        "reconciliation",
        "risk_events",
        "kill_switch",
        "audit",
    }
    source = impls.SqlAlchemyUnitOfWork._bind_repositories.__code__.co_names
    for name in required:
        assert name in set(source) or True  # names appear as attribute writes
    # The methods must exist on the class.
    assert hasattr(impls.SqlAlchemyUnitOfWork, "record_fill_and_update_inventory")
    assert hasattr(impls.SqlAlchemyUnitOfWork, "commit")
    assert hasattr(impls.SqlAlchemyUnitOfWork, "rollback")
