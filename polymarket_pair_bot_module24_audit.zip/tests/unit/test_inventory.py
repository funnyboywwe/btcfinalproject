"""Unit tests for inventory and matched-pair accounting (architecture item 12).

Each modeled requirement from the module brief has at least one test:

1. positions derive only from confirmed fills;
2. a documented lot method (weighted-average cost);
3. idempotent duplicate fills;
4. never negative inventory;
5. residual marked at executable bid prices;
6. never midpoint for emergency liquidation;
7. matched and unmatched accounted separately;
8. every transition persisted (snapshot appended per new fill);
9. rebuild entirely from the fill journal;
10. rebuilt vs stored comparison;
11. invariants;
12. audit command surface.

No test performs I/O, places an order, or touches a secret.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus, OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    FeeAmount,
    ProbabilityPrice,
    Shares,
)
from polymarket_pair_bot.inventory import (
    InventoryService,
    LotAllocationMethod,
    NegativeInventoryError,
    build_inventory,
    compare_inventories,
    empty_inventory,
    mark_residual,
    summarize_pending,
)
from polymarket_pair_bot.inventory.accounting import outcome_side_for
from polymarket_pair_bot.inventory.audit import build_audit
from tests.fixtures.inventory import (
    DOWN,
    UP,
    FakeMarketFillJournal,
    FakeUnitOfWorkFactory,
    make_book,
    make_fill,
    make_market,
    make_order,
)

MARKET_OBJ = make_market()


def _paired_fills() -> list:
    return [
        make_fill("f1", UP, price="0.40", size="10", fee="0.02", filled_at=10),
        make_fill("f2", DOWN, price="0.55", size="6", fee="0.01", filled_at=11),
        make_fill("f3", UP, price="0.42", size="2", filled_at=12),
    ]


def test_positions_derive_only_from_confirmed_fills() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    assert inv.up.quantity.value == Decimal(12)
    assert inv.down.quantity.value == Decimal(6)
    # Acquisition cost excludes fees and equals sum(price*size).
    assert inv.up.acquisition_cost.value == Decimal("4.84")


def test_documented_lot_method_is_weighted_average_cost() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    assert inv.lot_method is LotAllocationMethod.WEIGHTED_AVERAGE_COST
    # WAC: (0.40*10 + 0.42*2) / 12 = 4.84/12 = 0.403333...
    assert inv.up.average_cost is not None
    assert inv.up.average_cost.value == Decimal("0.403333")


def test_duplicate_fill_is_idempotent() -> None:
    fills = _paired_fills()
    once = build_inventory(MARKET_OBJ, fills)
    twice = build_inventory(MARKET_OBJ, [*fills, fills[0]])
    assert once.to_snapshot() == twice.to_snapshot()
    assert once.up.quantity.value == Decimal(12)


def test_never_negative_inventory_on_oversell() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    with pytest.raises(NegativeInventoryError):
        inv.up.with_sell(ProbabilityPrice(Decimal("0.5")), Shares(Decimal(999)), FeeAmount(Decimal(0)))


def test_matched_and_unmatched_accounted_separately() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    assert inv.matched_quantity.value == Decimal(6)
    assert inv.residual_up.value == Decimal(6)
    assert inv.residual_down.value == Decimal(0)
    # Matched + residual cost basis reconstructs total cost basis.
    total = inv.up.cost_basis.value + inv.down.cost_basis.value
    assert inv.matched_cost_basis.value + inv.residual_cost_basis.value == total


def test_locked_pair_value_and_net_profit() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    assert inv.locked_pair_value.value == Decimal(6)  # 6 pairs * $1
    # Net profit = locked value - matched cost basis; deterministic and <= value.
    assert inv.locked_net_profit.value <= inv.locked_pair_value.value


def test_residual_marked_at_executable_bid_not_midpoint() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    # Bids can absorb 5 of the 6 residual Up shares; asks would be ignored.
    book = make_book(UP, bids=(("0.41", "4"), ("0.39", "1")), asks=(("0.99", "100"),))
    mark = mark_residual(inv, up_book=book)
    # VWAP over 5 shares = (0.41*4 + 0.39*1)/5 = 0.406 -> value 2.03.
    assert mark.up.marketable.value == Decimal(5)
    assert mark.up.executable_bid is not None
    assert mark.up.executable_bid.value == Decimal("0.406")
    assert mark.up.marked_value.value == Decimal("2.03")
    # Shortfall (1 share) is marked at zero, so value ignores unmarketable depth.
    assert mark.up.shortfall.value == Decimal(1)
    assert mark.has_shortfall


def test_no_bid_liquidity_marks_zero_and_full_shortfall() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    mark = mark_residual(inv, up_book=make_book(UP, bids=()))
    assert mark.up.marked_value.value == Decimal(0)
    assert mark.up.shortfall.value == inv.residual_up.value
    assert mark.emergency_liquidation_value.value == mark.total_marked_value.value


def test_emergency_liquidation_value_is_bids_only_floor() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    book = make_book(UP, bids=(("0.41", "10"),), asks=(("0.50", "10"),))
    mark = mark_residual(inv, up_book=book)
    # Value uses the bid (0.41), never the 0.50 ask or a 0.455 midpoint.
    assert mark.emergency_liquidation_value.value == Decimal("2.46")


def test_rebuild_from_journal_is_order_independent() -> None:
    fills = _paired_fills()
    forward = build_inventory(MARKET_OBJ, fills)
    reverse = build_inventory(MARKET_OBJ, list(reversed(fills)))
    assert forward.to_snapshot() == reverse.to_snapshot()


def test_compare_rebuilt_with_stored_snapshot() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    consistent = compare_inventories(inv, inv.to_snapshot())
    assert consistent.consistent
    assert consistent.discrepancies == ()
    missing = compare_inventories(inv, None)
    assert not missing.consistent


def test_compare_detects_discrepancy() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    other = build_inventory(
        MARKET_OBJ,
        [make_fill("g1", UP, price="0.40", size="1", filled_at=10)],
    )
    result = compare_inventories(inv, other.to_snapshot())
    assert not result.consistent
    assert any("up_quantity" in d for d in result.discrepancies)


def test_outcome_side_resolution_rejects_foreign_token() -> None:
    assert outcome_side_for(MARKET_OBJ, UP) is OutcomeSide.UP
    assert outcome_side_for(MARKET_OBJ, DOWN) is OutcomeSide.DOWN
    from polymarket_pair_bot.domain.value_objects import TokenId

    with pytest.raises(ValueError):
        outcome_side_for(MARKET_OBJ, TokenId("9" * 64))


def test_empty_inventory_is_flat() -> None:
    inv = empty_inventory(MARKET_OBJ)
    assert inv.up.quantity.value == Decimal(0)
    assert inv.up.average_cost is None
    assert inv.matched_quantity.value == Decimal(0)
    assert inv.to_matched_pair() is None


def test_pending_orders_reserve_collateral_and_shares() -> None:
    orders = [
        make_order("o1", UP, side=OrderSide.BUY, limit_price="0.40", original_size="10", filled_size="3"),
        make_order("o2", DOWN, side=OrderSide.SELL, limit_price="0.60", original_size="5", filled_size="1"),
        make_order("o3", UP, side=OrderSide.BUY, limit_price="0.50", original_size="4", filled_size="4", status=OrderStatus.FILLED),
    ]
    pending = summarize_pending(orders)
    assert pending.pending_count == 2  # filled order excluded
    # BUY reserves remaining 7 * 0.40 = 2.80 collateral.
    assert pending.reserved_collateral.value == Decimal("2.80")
    # SELL reserves remaining 4 shares.
    assert pending.reserved_sell_shares.value == Decimal(4)


def test_audit_report_is_secret_free_and_complete() -> None:
    inv = build_inventory(MARKET_OBJ, _paired_fills())
    mark = mark_residual(inv, up_book=make_book(UP, bids=(("0.41", "6"),)))
    audit = build_audit(inv, residual_mark=mark, comparison=compare_inventories(inv, inv.to_snapshot()))
    text = audit.render_text().lower()
    for banned in ("private", "secret", "0x" + "key", "api_key", "mnemonic"):
        assert banned not in text
    data = audit.as_dict()
    for key in ("matched_quantity", "residual_up", "locked_net_profit", "marked_residual_value"):
        assert key in data


# -- service (persistence orchestration) tests -----------------------------


async def test_service_records_fill_and_persists_snapshot() -> None:
    factory = FakeUnitOfWorkFactory(market=MARKET_OBJ)
    service = InventoryService(factory, FakeMarketFillJournal([]))
    applied = await service.record_fill(
        MARKET_OBJ, make_fill("f1", UP, price="0.40", size="10", fee="0.02", filled_at=10)
    )
    assert applied is True
    assert factory.inventory.append_calls == 1
    latest = await factory.inventory.get_latest(MARKET_OBJ.market_id.value)
    assert latest is not None
    assert latest.up_position.quantity.value == Decimal(10)


async def test_service_duplicate_fill_does_not_double_count() -> None:
    factory = FakeUnitOfWorkFactory(market=MARKET_OBJ)
    service = InventoryService(factory, FakeMarketFillJournal([]))
    fill = make_fill("f1", UP, price="0.40", size="10", filled_at=10)
    assert await service.record_fill(MARKET_OBJ, fill) is True
    assert await service.record_fill(MARKET_OBJ, fill) is False
    latest = await factory.inventory.get_latest(MARKET_OBJ.market_id.value)
    assert latest is not None
    assert latest.up_position.quantity.value == Decimal(10)
    assert factory.inventory.append_calls == 1


async def test_service_rebuild_and_verify_consistent() -> None:
    fills = _paired_fills()
    factory = FakeUnitOfWorkFactory(market=MARKET_OBJ)
    service = InventoryService(factory, FakeMarketFillJournal(fills))
    for fill in fills:
        await service.record_fill(MARKET_OBJ, fill)
    result = await service.rebuild_and_verify(MARKET_OBJ)
    assert result.comparison.consistent
    assert result.stored is not None
    assert result.rebuilt.up.quantity.value == Decimal(12)
