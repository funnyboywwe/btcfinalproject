"""Unit tests for the bounded dedup cache."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.auth.dedup import BoundedDedupCache


def test_add_reports_new_then_duplicate() -> None:
    cache = BoundedDedupCache(8)
    assert cache.add("a") is True
    assert cache.add("a") is False
    assert "a" in cache


def test_capacity_is_bounded_and_lru_evicts() -> None:
    cache = BoundedDedupCache(2)
    cache.add("a")
    cache.add("b")
    cache.add("c")  # evicts oldest ("a")
    assert len(cache) == 2
    # "a" was evicted, so it is treated as new again.
    assert cache.add("a") is True


def test_invalid_capacity_rejected() -> None:
    with pytest.raises(ValueError):
        BoundedDedupCache(0)
