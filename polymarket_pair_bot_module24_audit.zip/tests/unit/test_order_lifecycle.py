"""OrderLifecycleManager tests: authoritative state transitions (Module 14).

Covers: an acknowledgement is never a fill; partial then full fill recompute;
fill-before-acknowledgement placeholder; duplicate-fill de-duplication; taker
finalization (FILLED vs killed remainder); and UNKNOWN marking for timed-out
submissions.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.enums import OrderStatus, TimeInForce
from polymarket_pair_bot.domain.value_objects import OrderId
from polymarket_pair_bot.execution.lifecycle import OrderLifecycleManager

from tests.fixtures.execution import InMemoryPersistence, make_intent
from tests.fixtures.live_execution import fill_record, placement_ack

NOW = 1_700_000_050


def _manager() -> tuple[OrderLifecycleManager, InMemoryPersistence]:
    persistence = InMemoryPersistence()
    manager = OrderLifecycleManager(persistence=persistence, now_s=lambda: NOW)
    return manager, persistence


async def test_record_placement_ack_is_not_a_fill() -> None:
    manager, persistence = _manager()
    intent = make_intent("i-1", price="0.40", size="100")
    order = await manager.record_placement(intent, placement_ack("o-1", filled="100"))
    # The ack claims filled=100 but there are no authoritative fills yet.
    assert order.status is OrderStatus.ACKNOWLEDGED
    assert order.filled_size.value == 0
    assert persistence.orders.items["o-1"].status is OrderStatus.ACKNOWLEDGED


async def test_rejected_placement_is_persisted_rejected() -> None:
    manager, _ = _manager()
    intent = make_intent("i-2", price="0.40", size="100")
    from polymarket_pair_bot.execution.live_models import OrderPlacement

    placement = OrderPlacement(order_id=None, status=OrderStatus.REJECTED)
    order = await manager.record_placement(intent, placement)
    assert order.status is OrderStatus.REJECTED
    assert order.filled_size.value == 0


async def test_partial_then_full_fill_promotes_status() -> None:
    manager, persistence = _manager()
    intent = make_intent("i-3", price="0.40", size="100")
    await manager.record_placement(intent, placement_ack("o-3"))

    app1 = await manager.process_fill(fill_record("f-1", "o-3", size="40"))
    assert app1.is_new
    assert app1.order is not None
    assert app1.order.status is OrderStatus.PARTIALLY_FILLED
    assert app1.order.filled_size.value == Decimal("40")

    app2 = await manager.process_fill(fill_record("f-2", "o-3", size="60"))
    assert app2.order is not None
    assert app2.order.status is OrderStatus.FILLED
    assert app2.order.filled_size.value == Decimal("100")


async def test_duplicate_fill_is_ignored() -> None:
    manager, persistence = _manager()
    intent = make_intent("i-4", price="0.40", size="100")
    await manager.record_placement(intent, placement_ack("o-4"))
    await manager.process_fill(fill_record("f-1", "o-4", size="40"))
    dup = await manager.process_fill(fill_record("f-1", "o-4", size="40"))
    assert dup.is_new is False
    # No double counting.
    assert persistence.orders.items["o-4"].filled_size.value == Decimal("40")
    assert persistence.fills.insert_calls == 2
    assert len(persistence.fills.items) == 1


async def test_fill_total_is_clamped_to_original_size() -> None:
    manager, persistence = _manager()
    intent = make_intent("i-5", price="0.40", size="100")
    await manager.record_placement(intent, placement_ack("o-5"))
    # An over-large authoritative fill must never overstate filled size.
    app = await manager.process_fill(fill_record("f-1", "o-5", size="140"))
    assert app.order is not None
    assert app.order.filled_size.value == Decimal("100")
    assert app.order.status is OrderStatus.FILLED


async def test_fill_before_ack_creates_unknown_placeholder() -> None:
    manager, persistence = _manager()
    app = await manager.process_fill(fill_record("f-1", "ghost", size="25"))
    assert app.is_new
    assert app.order is not None
    assert app.order.status is OrderStatus.UNKNOWN
    assert app.order.filled_size.value == Decimal("25")
    assert persistence.orders.items["ghost"].intent_id.startswith("unknown:")


async def test_finalize_taker_fully_filled_is_filled() -> None:
    manager, _ = _manager()
    intent = make_intent("i-6", price="0.40", size="100", tif=TimeInForce.FOK)
    await manager.record_placement(intent, placement_ack("o-6"))
    await manager.process_fill(fill_record("f-1", "o-6", size="100"))
    order = await manager.finalize_taker(OrderId("o-6"), time_in_force=TimeInForce.FOK)
    assert order is not None
    assert order.status is OrderStatus.FILLED


async def test_finalize_taker_partial_kills_remainder() -> None:
    manager, _ = _manager()
    intent = make_intent("i-7", price="0.40", size="100", tif=TimeInForce.IOC)
    await manager.record_placement(intent, placement_ack("o-7"))
    await manager.process_fill(fill_record("f-1", "o-7", size="30"))
    order = await manager.finalize_taker(OrderId("o-7"), time_in_force=TimeInForce.IOC)
    assert order is not None
    assert order.status is OrderStatus.CANCELED
    assert order.filled_size.value == Decimal("30")


async def test_finalize_taker_unknown_order_returns_none() -> None:
    manager, _ = _manager()
    assert await manager.finalize_taker(OrderId("nope"), time_in_force=TimeInForce.IOC) is None


async def test_mark_unknown_persists_unknown_order() -> None:
    manager, persistence = _manager()
    intent = make_intent("i-8", price="0.40", size="100")
    order = await manager.mark_unknown(order_id=OrderId("unknown-i-8"), intent=intent)
    assert order.status is OrderStatus.UNKNOWN
    assert persistence.orders.items["unknown-i-8"].status is OrderStatus.UNKNOWN


async def test_mark_unknown_respects_prior_terminal_state() -> None:
    manager, persistence = _manager()
    intent = make_intent("i-9", price="0.40", size="100")
    await manager.record_placement(intent, placement_ack("o-9"))
    await manager.process_fill(fill_record("f-1", "o-9", size="100"))
    await manager.finalize_taker(OrderId("o-9"), time_in_force=TimeInForce.FOK)
    # Marking an already-terminal order UNKNOWN must not downgrade it.
    order = await manager.mark_unknown(order_id=OrderId("o-9"), intent=intent)
    assert order.status is OrderStatus.FILLED
