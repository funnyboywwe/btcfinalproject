"""Unit tests for the async lifecycle manager and task supervisor."""

from __future__ import annotations

import asyncio

import pytest

from polymarket_pair_bot.app.lifecycle import LifecycleManager, TaskSupervisor
from polymarket_pair_bot.shared.health import HealthState, HealthTracker


class RecordingService:
    def __init__(self, name: str, events: list[str]) -> None:
        self._name = name
        self._events = events

    @property
    def name(self) -> str:
        return self._name

    async def start(self) -> None:
        self._events.append(f"start:{self._name}")

    async def stop(self) -> None:
        self._events.append(f"stop:{self._name}")


class FailingStartService:
    name = "boom"

    async def start(self) -> None:
        raise RuntimeError("startup exploded")

    async def stop(self) -> None:  # pragma: no cover - never started
        pass


class HangingStopService:
    name = "hang"

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        await asyncio.sleep(10)


async def test_start_then_reverse_stop_order() -> None:
    events: list[str] = []
    health = HealthTracker()
    manager = LifecycleManager(
        [RecordingService("a", events), RecordingService("b", events)],
        health=health,
        shutdown_timeout=5.0,
    )
    run_task = asyncio.create_task(manager.run())
    await asyncio.sleep(0.05)
    assert health.state is HealthState.READY
    manager.request_shutdown("test")
    await run_task
    assert events == ["start:a", "start:b", "stop:b", "stop:a"]
    assert health.state is HealthState.STOPPING


async def test_startup_failure_marks_degraded_and_raises() -> None:
    health = HealthTracker()
    manager = LifecycleManager(
        [FailingStartService()], health=health, shutdown_timeout=1.0
    )
    with pytest.raises(RuntimeError, match="startup exploded"):
        await manager.run()
    assert health.state in {HealthState.DEGRADED, HealthState.STOPPING}


async def test_stop_timeout_is_bounded_and_survivable() -> None:
    health = HealthTracker()
    manager = LifecycleManager(
        [HangingStopService()], health=health, shutdown_timeout=0.1
    )
    run_task = asyncio.create_task(manager.run())
    await asyncio.sleep(0.05)
    manager.request_shutdown("test")
    await asyncio.wait_for(run_task, timeout=2.0)
    assert health.state is HealthState.STOPPING


async def test_task_supervisor_cancels_all() -> None:
    supervisor = TaskSupervisor()

    async def _forever() -> None:
        await asyncio.sleep(3600)

    supervisor.create_task(_forever(), name="t1")
    supervisor.create_task(_forever(), name="t2")
    assert supervisor.active_count == 2
    await supervisor.cancel_all(timeout=1.0)
    await asyncio.sleep(0)
    assert supervisor.active_count == 0
