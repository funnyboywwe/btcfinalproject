"""Unit tests for pure CTF validation helpers."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.ctf.errors import CtfRiskRejectedError, CtfValidationError
from polymarket_pair_bot.ctf.models import OutcomeMapping
from polymarket_pair_bot.ctf.validation import (
    cap_merge_quantity,
    require_risk_approval,
    validate_condition_id,
    validate_outcome_mapping,
)
from polymarket_pair_bot.domain.value_objects import ConditionId, Shares
from tests.fixtures.ctf import CONDITION_ID, make_mapping, make_risk_decision


def test_validate_condition_id_ok() -> None:
    cid = validate_condition_id(CONDITION_ID)
    assert isinstance(cid, ConditionId)


def test_validate_condition_id_rejects_bad() -> None:
    with pytest.raises(CtfValidationError):
        validate_condition_id("not-a-condition")


def test_validate_outcome_mapping_ok() -> None:
    assert validate_outcome_mapping(make_mapping()) == (1, 2)


def test_validate_outcome_mapping_rejects_bad_parent() -> None:
    bad = OutcomeMapping(up_index_set=1, down_index_set=2, parent_collection="0x12")
    with pytest.raises(CtfValidationError):
        validate_outcome_mapping(bad)


def test_cap_merge_quantity_caps_to_min() -> None:
    capped = cap_merge_quantity(
        Shares(Decimal("10")),
        confirmed_up=Shares(Decimal("4")),
        confirmed_down=Shares(Decimal("7")),
    )
    assert capped.value == Decimal("4")


def test_cap_merge_quantity_respects_requested() -> None:
    capped = cap_merge_quantity(
        Shares(Decimal("2")),
        confirmed_up=Shares(Decimal("5")),
        confirmed_down=Shares(Decimal("5")),
    )
    assert capped.value == Decimal("2")


def test_require_risk_approval_ok() -> None:
    require_risk_approval(make_risk_decision("op-1"), operation_id="op-1")


def test_require_risk_approval_rejects_missing_key() -> None:
    with pytest.raises(CtfValidationError):
        require_risk_approval(make_risk_decision("op-1"), operation_id="   ")


def test_require_risk_approval_rejects_reject_verdict() -> None:
    with pytest.raises(CtfRiskRejectedError):
        require_risk_approval(
            make_risk_decision("op-1", approve=False), operation_id="op-1"
        )


def test_require_risk_approval_rejects_mismatched_key() -> None:
    with pytest.raises(CtfRiskRejectedError):
        require_risk_approval(make_risk_decision("op-2"), operation_id="op-1")
