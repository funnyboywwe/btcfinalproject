"""Unit tests for the pure transaction-status classifier (Module 16)."""

from __future__ import annotations

from polymarket_pair_bot.blockchain.models import TransactionStatus
from polymarket_pair_bot.blockchain.tx_status import classify_transaction

_HASH = "0x" + "e" * 64


def test_success_with_confirmations() -> None:
    out = classify_transaction(
        tx_hash=_HASH,
        receipt={"status": 1, "blockNumber": 100, "gasUsed": 21000},
        tx_present=True,
        latest_nonce=None,
        expected_nonce=None,
        latest_block=103,
        required_confirmations=2,
    )
    assert out.status is TransactionStatus.SUCCESS
    assert out.confirmations == 4
    assert out.detail is None


def test_success_but_shallow_reports_detail() -> None:
    out = classify_transaction(
        tx_hash=_HASH,
        receipt={"status": 1, "blockNumber": 100},
        tx_present=False,
        latest_nonce=None,
        expected_nonce=None,
        latest_block=100,
        required_confirmations=5,
    )
    assert out.status is TransactionStatus.SUCCESS
    assert out.confirmations == 1
    assert out.detail is not None


def test_reverted() -> None:
    out = classify_transaction(
        tx_hash=_HASH,
        receipt={"status": 0, "blockNumber": 100},
        tx_present=False,
        latest_nonce=None,
        expected_nonce=None,
    )
    assert out.status is TransactionStatus.REVERTED


def test_pending_when_in_mempool() -> None:
    out = classify_transaction(
        tx_hash=_HASH,
        receipt=None,
        tx_present=True,
        latest_nonce=None,
        expected_nonce=5,
    )
    assert out.status is TransactionStatus.PENDING


def test_replaced_when_nonce_advanced() -> None:
    out = classify_transaction(
        tx_hash=_HASH,
        receipt=None,
        tx_present=False,
        latest_nonce=8,
        expected_nonce=5,
    )
    assert out.status is TransactionStatus.REPLACED


def test_dropped_when_nonce_not_advanced() -> None:
    out = classify_transaction(
        tx_hash=_HASH,
        receipt=None,
        tx_present=False,
        latest_nonce=5,
        expected_nonce=5,
    )
    assert out.status is TransactionStatus.DROPPED


def test_unknown_without_nonce_info() -> None:
    out = classify_transaction(
        tx_hash=_HASH,
        receipt=None,
        tx_present=False,
        latest_nonce=None,
        expected_nonce=None,
    )
    assert out.status is TransactionStatus.UNKNOWN
