"""Unit tests for backtest report rendering (Module 22).

Verifies JSON/CSV/HTML export shape, HTML escaping, the explicit
non-profitability disclaimer, and that no secret-like content leaks. Monetary
figures are emitted as exact decimal strings (never binary floats).
"""

from __future__ import annotations

import json
from decimal import Decimal

from polymarket_pair_bot.backtest.metrics import BacktestReport, WindowResult
from polymarket_pair_bot.backtest.reporting import (
    render_csv,
    render_html,
    render_json,
    write_reports,
)


def _window(wid: str = "btc-5m") -> WindowResult:
    return WindowResult(
        window_id=wid,
        duration_seconds=300,
        snapshots=6,
        total_opportunities=3,
        attempted_trades=2,
        complete_pairs=Decimal(5),
        unmatched_events=1,
        gross_edge=Decimal("0.55"),
        fees=Decimal("0.01"),
        slippage=Decimal("0.02"),
        emergency_hedge_pnl=Decimal("0"),
        realized_net_pnl=Decimal("0.52"),
        residual_pnl=Decimal("0"),
        merged_pairs=Decimal(5),
        final_state="CLOSED",
        failure_reasons={"unmatched_at_close": 1},
    )


def _report(wid: str = "btc-5m") -> BacktestReport:
    return BacktestReport.from_windows((_window(wid),), label="unit", seed=42)


def test_render_json_is_valid_and_has_disclaimer() -> None:
    payload = json.loads(render_json(_report()))
    assert payload["seed"] == 42
    assert "profitable" in payload["disclaimer"].lower()
    # Monetary totals are strings, not JSON numbers/floats.
    assert isinstance(payload["totals"]["realized_net_pnl"], str)
    assert payload["totals"]["realized_net_pnl"] == "0.52"


def test_render_csv_has_header_and_rows() -> None:
    csv_text = render_csv(_report())
    lines = [line for line in csv_text.splitlines() if line.strip()]
    assert any("window_id" in line for line in lines)
    assert any("btc-5m" in line for line in lines)


def test_render_html_escapes_and_discloses() -> None:
    html_text = render_html(_report("<script>alert(1)</script>"))
    assert "<script>alert(1)</script>" not in html_text
    assert "&lt;script&gt;" in html_text
    assert "profitable" in html_text.lower()


def test_write_reports_emits_three_formats(tmp_path) -> None:
    paths = write_reports(_report(), tmp_path, stem="run")
    assert set(paths) == {"json", "csv", "html"}
    for fmt, path in paths.items():
        assert path.exists(), fmt
        assert path.read_text(encoding="utf-8").strip()
