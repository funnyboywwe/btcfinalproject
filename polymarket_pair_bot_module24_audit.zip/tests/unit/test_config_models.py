"""Unit tests for individual settings-model validation and coercion.

Requires pydantic-settings (run via `uv run pytest`).
"""

from __future__ import annotations

from decimal import Decimal

import pytest
from pydantic import ValidationError

from polymarket_pair_bot.config.enums import SignatureType
from polymarket_pair_bot.config.models import (
    PairStrategySettings,
    PolygonSettings,
    WalletSettings,
)


def test_chain_id_default_is_supported() -> None:
    assert PolygonSettings().polygon_chain_id == 137


def test_unsupported_chain_id_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("POLYGON_CHAIN_ID", "1")
    with pytest.raises(ValidationError):
        PolygonSettings()


def test_invalid_wallet_address_rejected(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POLYMARKET_FUNDER_ADDRESS", "0xnothex")
    with pytest.raises(ValidationError):
        WalletSettings()


def test_malformed_private_key_rejected(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POLYMARKET_PRIVATE_KEY", "0xshort")
    with pytest.raises(ValidationError):
        WalletSettings()


def test_signature_type_parses_int(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("POLYMARKET_SIGNATURE_TYPE", "2")
    assert WalletSettings().polymarket_signature_type is SignatureType.POLY_GNOSIS_SAFE


def test_pair_cost_must_be_below_one(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MAX_EFFECTIVE_PAIR_COST_USD", "1.00")
    with pytest.raises(ValidationError):
        PairStrategySettings()


def test_pair_cost_is_decimal(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MAX_EFFECTIVE_PAIR_COST_USD", "0.985")
    settings = PairStrategySettings()
    assert settings.max_effective_pair_cost_usd == Decimal("0.985")
    assert isinstance(settings.max_effective_pair_cost_usd, Decimal)


def test_pair_size_bounds_validated(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MIN_PAIR_SIZE_TOKENS", "10")
    monkeypatch.setenv("MAX_PAIR_SIZE_TOKENS", "5")
    with pytest.raises(ValidationError):
        PairStrategySettings()
