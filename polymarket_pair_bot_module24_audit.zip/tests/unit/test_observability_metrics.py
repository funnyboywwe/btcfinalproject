"""Unit tests for the Module 20 metric catalog and Prometheus metrics sink.

The catalog assertions run with only the standard library. The sink tests are
skipped when ``prometheus_client`` is not installed so the suite still runs in a
minimal environment.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.observability.metric_names import (
    METRIC_SPECS,
    MetricKind,
    spec_by_name,
)

# Every metric required by the Module 20 prompt, mapped to its catalog base name.
REQUIRED_BASE_NAMES = {
    "market_websocket_age_seconds",
    "user_websocket_age_seconds",
    "order_book_age_seconds",
    "processing_latency_seconds",
    "rest_latency_seconds",
    "rpc_latency_seconds",
    "reconnects",
    "opportunities_detected",
    "expected_pair_edge_usd",
    "order_submissions",
    "order_rejections",
    "partial_fills",
    "maker_fills",
    "taker_fills",
    "cancel_latency_seconds",
    "unmatched_shares",
    "unmatched_duration_seconds",
    "matched_pairs",
    "merge_transactions",
    "gross_pnl_usd",
    "fees_usd",
    "slippage_usd",
    "realized_net_pnl_usd",
    "risk_rejections",
    "kill_switch_active",
    "reconciliation_differences",
    "event_loop_lag_seconds",
}


def test_catalog_covers_every_required_metric() -> None:
    names = {spec.name for spec in METRIC_SPECS}
    missing = REQUIRED_BASE_NAMES - names
    assert not missing, f"missing metrics: {sorted(missing)}"


def test_catalog_names_are_unique() -> None:
    names = [spec.name for spec in METRIC_SPECS]
    assert len(names) == len(set(names))


def test_counter_names_have_no_total_suffix() -> None:
    # prometheus_client appends _total automatically; storing it here would
    # double-suffix the exported sample.
    for spec in METRIC_SPECS:
        if spec.kind is MetricKind.COUNTER:
            assert not spec.name.endswith("_total"), spec.name


def test_only_histograms_declare_buckets() -> None:
    for spec in METRIC_SPECS:
        if spec.kind is MetricKind.HISTOGRAM:
            assert spec.buckets, spec.name
        else:
            assert spec.buckets is None, spec.name


def test_spec_by_name_roundtrip() -> None:
    assert spec_by_name("kill_switch_active") is not None
    assert spec_by_name("does_not_exist") is None


# --------------------------------------------------------------------------
# Sink tests (require prometheus_client).
# --------------------------------------------------------------------------


def _make_sink():  # type: ignore[no-untyped-def]
    pytest.importorskip("prometheus_client")
    from polymarket_pair_bot.observability.metrics import create_metrics_sink

    return create_metrics_sink(namespace="ppb")


def test_render_exposes_namespaced_series() -> None:
    sink = _make_sink()
    sink.set_kill_switch(True)
    sink.incr_reconnect("market")
    sink.observe_processing_latency(0.01)
    payload, content_type = sink.render()
    text = payload.decode("utf-8")
    assert "text/plain" in content_type
    assert "ppb_kill_switch_active" in text
    # Counter exposed with the _total suffix appended by the client.
    assert "ppb_reconnects_total" in text
    assert "ppb_processing_latency_seconds_bucket" in text


def test_kill_switch_gauge_reflects_state() -> None:
    sink = _make_sink()
    sink.set_kill_switch(True)
    assert "ppb_kill_switch_active 1.0" in sink.render()[0].decode("utf-8")
    sink.set_kill_switch(False)
    assert "ppb_kill_switch_active 0.0" in sink.render()[0].decode("utf-8")


def test_decimal_helpers_are_accepted() -> None:
    sink = _make_sink()
    sink.set_gross_pnl(Decimal("1.23"))
    sink.set_realized_net_pnl(Decimal("-0.50"))
    sink.add_fees(Decimal("0.01"))
    sink.set_unmatched_shares("up", Decimal("3"))
    text = sink.render()[0].decode("utf-8")
    assert "ppb_gross_pnl_usd 1.23" in text
    assert "ppb_realized_net_pnl_usd -0.5" in text
    assert 'ppb_unmatched_shares{outcome="up"} 3.0' in text


def test_generic_orchestrator_names_work() -> None:
    sink = _make_sink()
    # Orchestrator emits generic names via the MetricsSink protocol.
    sink.incr("orchestrator_degraded_total")
    sink.gauge("orchestrator_session_state", 1.0, state="running")
    text = sink.render()[0].decode("utf-8")
    assert "ppb_orchestrator_degraded_total" in text
    assert "ppb_orchestrator_session_state" in text


def test_sink_never_raises_on_bad_labels() -> None:
    sink = _make_sink()
    # order_book_age_seconds requires an 'outcome' label; a wrong label name
    # must be swallowed rather than raising.
    sink.gauge("order_book_age_seconds", 1.0, wrong_label="x")
    # Missing label entirely: also swallowed.
    sink.gauge("order_book_age_seconds", 1.0)
