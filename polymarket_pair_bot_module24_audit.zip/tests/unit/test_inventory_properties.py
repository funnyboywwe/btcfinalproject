"""Property-based invariants for inventory accounting (architecture item 12).

Hypothesis strategies build Decimals from integers so we never construct a
Decimal from a float. The invariants assert accounting identities that must
hold for any sequence of confirmed buy fills:

* quantity == sum of buy sizes per side (idempotent under duplicates);
* matched + residual reconstructs each side's quantity;
* matched_cost_basis + residual_cost_basis == total cost basis;
* rebuild is order-independent;
* locked_net_profit == locked_pair_value - matched_cost_basis;
* inventory never goes negative;
* residual executable-bid marked value never exceeds the notional at best bid.
"""

from __future__ import annotations

from decimal import Decimal

from hypothesis import assume, given, settings
from hypothesis import strategies as st

from polymarket_pair_bot.domain.enums import OrderSide
from polymarket_pair_bot.inventory import build_inventory, mark_residual
from tests.fixtures.inventory import DOWN, UP, make_book, make_fill, make_market

MARKET_OBJ = make_market()

# Decimal strategies derived from ints (never from float).
prices = st.integers(min_value=1, max_value=99).map(lambda c: Decimal(c) / Decimal(100))
sizes = st.integers(min_value=1, max_value=1000).map(lambda m: Decimal(m) / Decimal(10))
fees = st.integers(min_value=0, max_value=100).map(lambda m: Decimal(m) / Decimal(100))

# A single confirmed buy fill: (token_is_up, price, size, fee).
fill_specs = st.tuples(st.booleans(), prices, sizes, fees)
fill_lists = st.lists(fill_specs, min_size=0, max_size=25)


def _build(specs: list[tuple[bool, Decimal, Decimal, Decimal]]):
    fills = []
    for index, (is_up, price, size, fee) in enumerate(specs):
        token = UP if is_up else DOWN
        fills.append(
            make_fill(
                f"f{index}",
                token,
                price=str(price),
                size=str(size),
                fee=str(fee),
                filled_at=1_700_000_000 + index,
                side=OrderSide.BUY,
            )
        )
    return fills


@settings(max_examples=150)
@given(fill_lists)
def test_quantity_matches_sum_of_buys(specs: list) -> None:
    inv = build_inventory(MARKET_OBJ, _build(specs))
    up_expected = sum((s[2] for s in specs if s[0]), Decimal(0))
    down_expected = sum((s[2] for s in specs if not s[0]), Decimal(0))
    assert inv.up.quantity.value == up_expected
    assert inv.down.quantity.value == down_expected


@settings(max_examples=150)
@given(fill_lists)
def test_matched_plus_residual_reconstructs_quantity(specs: list) -> None:
    inv = build_inventory(MARKET_OBJ, _build(specs))
    assert inv.matched_quantity.value + inv.residual_up.value == inv.up.quantity.value
    assert inv.matched_quantity.value + inv.residual_down.value == inv.down.quantity.value
    # Never negative.
    assert inv.residual_up.value >= 0
    assert inv.residual_down.value >= 0
    assert inv.matched_quantity.value >= 0


@settings(max_examples=150)
@given(fill_lists)
def test_cost_basis_decomposition(specs: list) -> None:
    inv = build_inventory(MARKET_OBJ, _build(specs))
    total = inv.up.cost_basis.value + inv.down.cost_basis.value
    assert inv.matched_cost_basis.value + inv.residual_cost_basis.value == total


@settings(max_examples=150)
@given(fill_lists)
def test_rebuild_is_order_independent(specs: list) -> None:
    fills = _build(specs)
    forward = build_inventory(MARKET_OBJ, fills)
    reverse = build_inventory(MARKET_OBJ, list(reversed(fills)))
    assert forward.to_snapshot() == reverse.to_snapshot()


@settings(max_examples=150)
@given(fill_lists)
def test_locked_net_profit_identity(specs: list) -> None:
    inv = build_inventory(MARKET_OBJ, _build(specs))
    expected = inv.locked_pair_value.value - inv.matched_cost_basis.value
    # locked_net_profit rounds down; it must never exceed the exact identity
    # and must stay within one cent of it.
    assert inv.locked_net_profit.value <= expected
    assert expected - inv.locked_net_profit.value <= Decimal("0.01")


@settings(max_examples=100)
@given(fill_lists, prices, sizes)
def test_marked_value_never_exceeds_best_bid_notional(
    specs: list, bid_price: Decimal, bid_size: Decimal
) -> None:
    inv = build_inventory(MARKET_OBJ, _build(specs))
    assume(inv.residual_up.is_positive)
    book = make_book(UP, bids=((str(bid_price), str(bid_size)),))
    mark = mark_residual(inv, up_book=book)
    # Executable VWAP <= best (only) bid, so value <= marketable * best_bid.
    assert mark.up.marked_value.value <= mark.up.marketable.value * bid_price
    # Marketable never exceeds residual, and shortfall is non-negative.
    assert mark.up.marketable.value <= inv.residual_up.value
    assert mark.up.shortfall.value >= 0
