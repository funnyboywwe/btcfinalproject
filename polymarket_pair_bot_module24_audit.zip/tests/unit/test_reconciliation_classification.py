"""Unit tests for the reconciliation classification taxonomy (Module 15)."""

from __future__ import annotations

from polymarket_pair_bot.domain.enums import ReconciliationStatus
from polymarket_pair_bot.reconciliation.classification import (
    ReconciliationClass,
    combine,
    escalate,
)


def test_only_consistent_and_auto_recoverable_keep_trading() -> None:
    keep = {
        ReconciliationClass.CONSISTENT,
        ReconciliationClass.AUTOMATICALLY_RECOVERABLE,
    }
    for cls in ReconciliationClass:
        assert cls.halts_new_trading is (cls not in keep)


def test_severity_is_strictly_ordered() -> None:
    order = [
        ReconciliationClass.CONSISTENT,
        ReconciliationClass.AUTOMATICALLY_RECOVERABLE,
        ReconciliationClass.LOCAL_REPAIR_REQUIRED,
        ReconciliationClass.CANCELLATION_REQUIRED,
        ReconciliationClass.MANUAL_REVIEW,
        ReconciliationClass.CRITICAL_STOP,
    ]
    severities = [c.severity for c in order]
    assert severities == sorted(severities)
    assert len(set(severities)) == len(severities)


def test_escalate_and_combine_pick_most_severe() -> None:
    assert escalate(
        ReconciliationClass.CONSISTENT, ReconciliationClass.MANUAL_REVIEW
    ) is ReconciliationClass.MANUAL_REVIEW
    assert combine([]) is ReconciliationClass.CONSISTENT
    assert combine(
        [
            ReconciliationClass.AUTOMATICALLY_RECOVERABLE,
            ReconciliationClass.LOCAL_REPAIR_REQUIRED,
            ReconciliationClass.CRITICAL_STOP,
        ]
    ) is ReconciliationClass.CRITICAL_STOP


def test_to_status_maps_to_domain_enum() -> None:
    assert (
        ReconciliationClass.CONSISTENT.to_status()
        is ReconciliationStatus.CONSISTENT
    )
    assert (
        ReconciliationClass.MANUAL_REVIEW.to_status()
        is ReconciliationStatus.UNKNOWN
    )
    for cls in (
        ReconciliationClass.AUTOMATICALLY_RECOVERABLE,
        ReconciliationClass.LOCAL_REPAIR_REQUIRED,
        ReconciliationClass.CANCELLATION_REQUIRED,
        ReconciliationClass.CRITICAL_STOP,
    ):
        assert cls.to_status() is ReconciliationStatus.DISCREPANCY
