"""Unit tests for recorder runtime config and settings translation."""

from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest

from polymarket_pair_bot.config.enums import RecorderOverflowPolicy
from polymarket_pair_bot.config.models import RecorderSettings
from polymarket_pair_bot.recorder.config import RecorderRuntimeConfig


def test_defaults_are_safe() -> None:
    config = RecorderRuntimeConfig(output_dir=Path("data/market_data"))
    assert config.poll_interval_seconds <= config.periodic_interval_seconds
    assert config.overflow_policy is RecorderOverflowPolicy.DROP_OLDEST
    assert config.persist_summaries is True


def test_poll_interval_cannot_exceed_periodic() -> None:
    with pytest.raises(ValueError):
        RecorderRuntimeConfig(
            output_dir=Path("x"),
            poll_interval_seconds=2.0,
            periodic_interval_seconds=1.0,
        )


def test_negative_pair_cost_level_rejected() -> None:
    with pytest.raises(ValueError):
        RecorderRuntimeConfig(
            output_dir=Path("x"),
            pair_cost_levels=(Decimal("-0.5"),),
        )


def test_settings_pair_cost_levels_parsing() -> None:
    settings = RecorderSettings(recorder_pair_cost_levels="1.00, 0.99 ,0.98,0.99")
    # sorted + de-duplicated
    assert settings.pair_cost_levels == (
        Decimal("0.98"),
        Decimal("0.99"),
        Decimal("1.00"),
    )


def test_settings_reject_invalid_level() -> None:
    with pytest.raises(ValueError):
        RecorderSettings(recorder_pair_cost_levels="abc")


def test_settings_reject_poll_gt_snapshot_interval() -> None:
    with pytest.raises(ValueError):
        RecorderSettings(
            recorder_poll_interval_seconds=2.0,
            recorder_snapshot_interval_seconds=1.0,
        )
