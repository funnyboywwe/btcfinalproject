"""Unit tests for exact base-unit conversions (Module 16)."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.blockchain.units import (
    base_units_to_decimal,
    decimal_to_base_units,
    wei_to_native,
)


def test_base_units_to_decimal_is_exact() -> None:
    assert base_units_to_decimal(1_500_000, 6) == Decimal("1.5")
    assert base_units_to_decimal(0, 6) == Decimal(0)
    assert base_units_to_decimal(123, 0) == Decimal(123)


def test_wei_to_native_exact() -> None:
    assert wei_to_native(10**18) == Decimal(1)
    assert wei_to_native(5 * 10**17) == Decimal("0.5")


def test_decimal_to_base_units_floors() -> None:
    # 1.2345678 USDC -> floored to 6 decimals (1_234_567), never rounded up.
    assert decimal_to_base_units(Decimal("1.2345678"), 6) == 1_234_567
    assert decimal_to_base_units(Decimal("2"), 6) == 2_000_000


def test_negative_and_bool_rejected() -> None:
    with pytest.raises(ValueError):
        base_units_to_decimal(-1, 6)
    with pytest.raises(TypeError):
        base_units_to_decimal(True, 6)  # type: ignore[arg-type]
    with pytest.raises(ValueError):
        decimal_to_base_units(Decimal("-1"), 6)
