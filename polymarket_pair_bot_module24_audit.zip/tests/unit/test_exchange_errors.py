"""Exchange error classification tests (Module 14)."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.execution.errors import (
    ExchangeErrorClass,
    classify_exchange_error,
)


@pytest.mark.parametrize(
    ("code", "expected"),
    [
        ("rate_limited", ExchangeErrorClass.RATE_LIMITED),
        ("429", ExchangeErrorClass.RATE_LIMITED),
        ("503", ExchangeErrorClass.RETRYABLE),
        ("timeout", ExchangeErrorClass.RETRYABLE),
        ("invalid_tick", ExchangeErrorClass.INVALID_REQUEST),
        ("400", ExchangeErrorClass.INVALID_REQUEST),
        ("insufficient_funds", ExchangeErrorClass.INSUFFICIENT_FUNDS),
        ("unauthorized", ExchangeErrorClass.AUTH),
        ("403", ExchangeErrorClass.AUTH),
        ("post_only", ExchangeErrorClass.POST_ONLY_WOULD_CROSS),
        ("order_not_found", ExchangeErrorClass.NOT_FOUND),
    ],
)
def test_classify_by_code(code: str, expected: ExchangeErrorClass) -> None:
    assert classify_exchange_error(code=code) is expected


def test_code_is_case_insensitive() -> None:
    assert classify_exchange_error(code="  RATE_LIMITED ") is ExchangeErrorClass.RATE_LIMITED


@pytest.mark.parametrize(
    ("message", "expected"),
    [
        ("Rate limit exceeded", ExchangeErrorClass.RATE_LIMITED),
        ("Request timed out", ExchangeErrorClass.RETRYABLE),
        ("Insufficient balance for order", ExchangeErrorClass.INSUFFICIENT_FUNDS),
        ("Unauthorized API key", ExchangeErrorClass.AUTH),
        ("post-only order would cross", ExchangeErrorClass.POST_ONLY_WOULD_CROSS),
        ("order not found", ExchangeErrorClass.NOT_FOUND),
        ("invalid price", ExchangeErrorClass.INVALID_REQUEST),
    ],
)
def test_classify_by_message(message: str, expected: ExchangeErrorClass) -> None:
    assert classify_exchange_error(message=message) is expected


def test_code_takes_precedence_over_message() -> None:
    got = classify_exchange_error(code="429", message="invalid")
    assert got is ExchangeErrorClass.RATE_LIMITED


def test_unrecognized_is_unknown_and_not_retryable() -> None:
    got = classify_exchange_error(code="weird", message="strange happening")
    assert got is ExchangeErrorClass.UNKNOWN
    assert got.is_retryable is False
    assert got.is_clean_reject is False


def test_empty_inputs_are_unknown() -> None:
    assert classify_exchange_error() is ExchangeErrorClass.UNKNOWN


def test_retryable_and_clean_reject_partitions() -> None:
    assert ExchangeErrorClass.RATE_LIMITED.is_retryable
    assert ExchangeErrorClass.RETRYABLE.is_retryable
    assert not ExchangeErrorClass.INVALID_REQUEST.is_retryable
    assert ExchangeErrorClass.POST_ONLY_WOULD_CROSS.is_clean_reject
    assert ExchangeErrorClass.INSUFFICIENT_FUNDS.is_clean_reject
    assert not ExchangeErrorClass.UNKNOWN.is_clean_reject
