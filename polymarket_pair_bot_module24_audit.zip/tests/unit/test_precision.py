"""Unit tests for the Decimal precision policy and rounding primitives."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.precision import (
    USDC_BASE_UNITS_PER_USD,
    coerce_decimal,
    nearest_tick,
    round_down_to_tick,
    round_fee_up,
    round_profit_down,
    round_to_tick,
    round_up_to_tick,
)


def test_coerce_rejects_float() -> None:
    with pytest.raises(TypeError):
        coerce_decimal(0.1)  # type: ignore[arg-type]


def test_coerce_rejects_bool() -> None:
    with pytest.raises(TypeError):
        coerce_decimal(True)  # type: ignore[arg-type]


def test_coerce_accepts_str_int_decimal() -> None:
    assert coerce_decimal("0.25") == Decimal("0.25")
    assert coerce_decimal(7) == Decimal(7)
    assert coerce_decimal(Decimal("1.5")) == Decimal("1.5")


def test_coerce_rejects_non_finite() -> None:
    with pytest.raises(ValueError):
        coerce_decimal("NaN")
    with pytest.raises(ValueError):
        coerce_decimal("Infinity")


def test_fee_rounds_up() -> None:
    # 0.0000011 must round UP at 1e-6 -> 0.000002
    assert round_fee_up(Decimal("0.0000011")) == Decimal("0.000002")


def test_profit_rounds_down_even_when_negative() -> None:
    # toward -inf: a positive value truncates down, a negative goes more negative
    assert round_profit_down(Decimal("0.0000019")) == Decimal("0.000001")
    assert round_profit_down(Decimal("-0.0000011")) == Decimal("-0.000002")


def test_tick_rounding_directions() -> None:
    tick = Decimal("0.01")
    assert round_down_to_tick(Decimal("0.126"), tick) == Decimal("0.12")
    assert round_up_to_tick(Decimal("0.121"), tick) == Decimal("0.13")
    assert nearest_tick(Decimal("0.124"), tick) == Decimal("0.12")
    assert nearest_tick(Decimal("0.126"), tick) == Decimal("0.13")


def test_tick_rounding_is_aligned_and_deterministic() -> None:
    tick = Decimal("0.001")
    result = round_to_tick(Decimal("0.123456"), tick, "ROUND_HALF_EVEN")
    assert result == Decimal("0.123")
    # Aligned to the tick exponent and repeatable.
    assert result.as_tuple().exponent == tick.as_tuple().exponent
    assert result == round_to_tick(Decimal("0.123456"), tick, "ROUND_HALF_EVEN")


def test_tick_must_be_positive() -> None:
    with pytest.raises(ValueError):
        round_to_tick(Decimal("0.5"), Decimal(0), "ROUND_FLOOR")


def test_usdc_base_units_constant() -> None:
    assert USDC_BASE_UNITS_PER_USD == Decimal(1_000_000)
