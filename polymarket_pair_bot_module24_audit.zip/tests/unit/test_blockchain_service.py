"""Unit tests for the read-only WalletStateService (Module 16)."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.blockchain.dual_rpc import DualRpcReader, Endpoint
from polymarket_pair_bot.blockchain.errors import (
    ChainConfigurationError,
    ReceiptTimeoutError,
    UnsupportedChainOperationError,
)
from polymarket_pair_bot.blockchain.models import TransactionStatus
from polymarket_pair_bot.blockchain.resilience import CircuitBreaker, RetryPolicy
from polymarket_pair_bot.blockchain.service import ChainReadParams, WalletStateService
from tests.fixtures.blockchain import (
    CTF_ADDRESS,
    DOWN_TOKEN,
    SPENDER_ADDRESS,
    UP_TOKEN,
    USDC_ADDRESS,
    WALLET_ADDRESS,
    FakeClock,
    FakeEthereumRpc,
    FakeSleep,
    allowance_calldata,
    collateral_calldata,
    make_receipt,
    token_calldata,
)

_TX = "0x" + "f" * 64


def _service(
    rpc: FakeEthereumRpc,
    *,
    clock: FakeClock | None = None,
    sleep: FakeSleep | None = None,
    usdc: str | None = USDC_ADDRESS,
    ctf: str | None = CTF_ADDRESS,
) -> WalletStateService:
    clock = clock or FakeClock()
    breaker = CircuitBreaker(name=rpc.label, fail_threshold=5, reset_seconds=30, clock=clock)
    endpoint = Endpoint(
        rpc,
        breaker=breaker,
        policy=RetryPolicy(max_retries=1, backoff_base_seconds=0.1, backoff_max_seconds=1),
        sleep=FakeSleep(),
        rng=lambda: 0.0,
    )
    reader = DualRpcReader(endpoint)
    params = ChainReadParams(
        chain_id=137,
        wallet_address=WALLET_ADDRESS,
        usdc_address=usdc,
        usdc_decimals=6,
        conditional_tokens_address=ctf,
        outcome_token_decimals=6,
        receipt_timeout_seconds=30,
        receipt_poll_interval_seconds=1,
        required_confirmations=1,
        gas_estimate_buffer=Decimal("1.25"),
    )
    return WalletStateService(reader, params, clock=clock, sleep=sleep or FakeSleep())


async def test_verify_chain_id_ok() -> None:
    svc = _service(FakeEthereumRpc(chain_id=137))
    identity = await svc.verify_chain_id()
    assert identity.chain_id == 137


async def test_verify_chain_id_mismatch() -> None:
    svc = _service(FakeEthereumRpc(chain_id=1))
    with pytest.raises(ChainConfigurationError):
        await svc.verify_chain_id()


async def test_balances_reads() -> None:
    rpc = FakeEthereumRpc(
        native_balance=3 * 10**18,
        call_returns={
            collateral_calldata(): 12_500_000,  # 12.5 USDC
            token_calldata(UP_TOKEN): 4_000_000,
            token_calldata(DOWN_TOKEN): 4_000_000,
            allowance_calldata(): 1_000_000_000,
        },
    )
    svc = _service(rpc)
    native = await svc.get_native_gas_balance()
    assert native.amount == Decimal(3)
    coll = await svc.get_collateral_balance()
    assert coll.amount == Decimal("12.5")
    up = await svc.get_token_balance(UP_TOKEN)
    down = await svc.get_token_balance(DOWN_TOKEN)
    assert up.amount == Decimal(4) and down.amount == Decimal(4)
    allow = await svc.get_allowance(spender=SPENDER_ADDRESS)
    assert allow.amount == Decimal(1000)


async def test_missing_contract_fails_closed() -> None:
    svc = _service(FakeEthereumRpc(), usdc=None)
    with pytest.raises(ChainConfigurationError):
        await svc.get_collateral_balance()


async def test_nonce_reads() -> None:
    svc = _service(FakeEthereumRpc(nonce_latest=7, nonce_pending=9))
    assert await svc.get_nonce() == 7
    assert await svc.get_nonce(pending=True) == 9


async def test_transaction_status_success() -> None:
    rpc = FakeEthereumRpc(
        receipts={_TX: make_receipt(status=1, block_number=990)},
        transactions={_TX: {"hash": _TX}},
        block_number=995,
    )
    svc = _service(rpc)
    out = await svc.get_transaction_status(_TX)
    assert out.status is TransactionStatus.SUCCESS
    assert out.confirmations == 6


async def test_transaction_status_replaced() -> None:
    rpc = FakeEthereumRpc(receipts={}, transactions={}, nonce_latest=10)
    svc = _service(rpc)
    out = await svc.get_transaction_status(_TX, expected_nonce=5)
    assert out.status is TransactionStatus.REPLACED


async def test_wait_for_receipt_times_out() -> None:
    clock = FakeClock()
    sleep = FakeSleep(clock)
    rpc = FakeEthereumRpc(receipts={}, transactions={_TX: {"hash": _TX}})
    svc = _service(rpc, clock=clock, sleep=sleep)
    with pytest.raises(ReceiptTimeoutError):
        await svc.wait_for_receipt(_TX, timeout_seconds=5, poll_interval_seconds=1)


async def test_wait_for_receipt_success() -> None:
    clock = FakeClock()
    sleep = FakeSleep(clock)
    rpc = FakeEthereumRpc(
        receipts={_TX: make_receipt(status=1, block_number=990)},
        transactions={_TX: {"hash": _TX}},
        block_number=995,
    )
    svc = _service(rpc, clock=clock, sleep=sleep)
    out = await svc.wait_for_receipt(_TX, timeout_seconds=5, poll_interval_seconds=1)
    assert out.succeeded


async def test_simulate_success_and_revert() -> None:
    calldata = collateral_calldata()
    rpc = FakeEthereumRpc(call_returns={calldata: 1})
    svc = _service(rpc)
    ok = await svc.simulate(to=USDC_ADDRESS, data=calldata)
    assert ok.success
    bad = await svc.simulate(to=USDC_ADDRESS, data="0xdeadbeef")
    assert bad.success is False
    assert bad.revert_reason is not None


async def test_estimate_gas_applies_buffer() -> None:
    rpc = FakeEthereumRpc(gas_estimate=100000, gas_price=10**9)
    svc = _service(rpc)
    est = await svc.estimate_gas(to=USDC_ADDRESS, data=collateral_calldata())
    assert est.gas_limit == 100000
    assert est.buffered_gas_limit == 125000
    assert est.max_cost_wei == 125000 * 10**9


async def test_submit_ctf_operation_blocked() -> None:
    svc = _service(FakeEthereumRpc())
    with pytest.raises(UnsupportedChainOperationError):
        await svc.submit_ctf_operation()


async def test_wallet_snapshot_aggregate() -> None:
    rpc = FakeEthereumRpc(
        call_returns={
            collateral_calldata(): 10_000_000,
            token_calldata(UP_TOKEN): 2_000_000,
            token_calldata(DOWN_TOKEN): 3_000_000,
            allowance_calldata(): 500_000_000,
        },
    )
    svc = _service(rpc)
    snap = await svc.get_wallet_snapshot(
        token_ids=(UP_TOKEN, DOWN_TOKEN),
        allowance_spenders=(SPENDER_ADDRESS,),
    )
    assert snap.chain_id == 137
    assert snap.collateral is not None and snap.collateral.amount == Decimal(10)
    assert snap.token_balances[UP_TOKEN].amount == Decimal(2)
    assert snap.allowances[SPENDER_ADDRESS].amount == Decimal(500)
