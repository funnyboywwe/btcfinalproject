"""Regression tests for the review hardening of secret redaction.

Covers two gaps closed during the Module-24 security review:

* free-text redaction of long opaque secrets that contain base64 symbol
  characters (``+`` ``/`` ``=``) -- previously such secrets were split into
  short, unredacted fragments (category 15: secret exposure);
* fail-closed redaction of raw ``bytes`` / ``bytearray`` values, which are
  almost always key material or signatures.
"""

from __future__ import annotations

from polymarket_pair_bot.security.redaction import (
    REDACTED,
    redact_mapping,
    redact_text,
    redact_value,
)


def test_redact_text_redacts_base64_secret_with_symbols() -> None:
    secret = "abcd+efgh/ijklmnop+qrstuvwx/yzABCDEF0123456789=="
    assert len(secret) >= 40
    out = redact_text(f"authorization header {secret} trailing")
    assert secret not in out
    assert REDACTED in out


def test_redact_text_still_redacts_hex_private_key() -> None:
    key = "0x" + "a" * 64
    out = redact_text(f"pk={key}")
    assert key not in out
    assert REDACTED in out


def test_redact_value_redacts_bytes_and_bytearray() -> None:
    assert redact_value(None, b"\x00\x01deadbeefsecret") == REDACTED
    assert redact_value(None, bytearray(b"secretbytes")) == REDACTED


def test_redact_mapping_scrubs_nested_symbol_secret_and_bytes() -> None:
    secret = "AAAA1111+BBBB2222/CCCC3333+DDDD4444/EEEE5555=="
    assert len(secret) >= 40
    payload = {
        "note": f"token {secret} end",
        "raw": b"deadbeefsecretmaterial",
        "nested": {"password": "hunter2", "count": 5},
    }
    out = redact_mapping(payload)
    assert secret not in out["note"]
    assert REDACTED in out["note"]
    assert out["raw"] == REDACTED
    assert out["nested"]["password"] == REDACTED
    assert out["nested"]["count"] == 5


def test_short_non_secret_text_is_untouched() -> None:
    # A short, ordinary string must not be over-redacted.
    assert redact_text("order accepted for market btc-5m") == (
        "order accepted for market btc-5m"
    )
