"""Unit tests for LeadershipCoordinator using an in-memory fake elector.

These exercise promotion, lease-loss demotion and Redis-failure demotion
without any real Redis, complementing the real-Redis concurrency/expiration
integration tests.
"""

from __future__ import annotations

import asyncio

from polymarket_pair_bot.coordination.coordinator import LeadershipCoordinator
from polymarket_pair_bot.coordination.gate import ExecutionGate
from polymarket_pair_bot.domain.coordination import RedisUnavailableError


class FakeElector:
    """Programmable in-memory LeaderElector."""

    def __init__(self) -> None:
        self.scope = "test-scope"
        self.token = "host:1:abc"
        self.acquire_result = True
        self.renew_result = True
        self.raise_on_renew = False
        self.released = False

    async def acquire(self) -> bool:
        return self.acquire_result

    async def renew(self) -> bool:
        if self.raise_on_renew:
            raise RedisUnavailableError("ConnectionError")
        return self.renew_result

    async def release(self) -> None:
        self.released = True

    async def current_owner(self) -> str | None:
        return self.token


class RecordingObserver:
    def __init__(self) -> None:
        self.promoted = 0
        self.demoted: list[str] = []

    async def on_promoted(self) -> None:
        self.promoted += 1

    async def on_demoted(self, reason: str) -> None:
        self.demoted.append(reason)


def _make() -> tuple[LeadershipCoordinator, FakeElector, ExecutionGate, RecordingObserver]:
    elector = FakeElector()
    gate = ExecutionGate()
    observer = RecordingObserver()
    coord = LeadershipCoordinator(
        elector, gate, observer, renew_interval_seconds=0.01
    )
    return coord, elector, gate, observer


async def test_acquire_promotes_and_enables_gate() -> None:
    coord, _elector, gate, observer = _make()
    await coord.start()
    try:
        assert coord.is_leader is True
        assert gate.is_enabled is True
        assert observer.promoted == 1
    finally:
        await coord.stop()
    # After stop the gate is disabled and lease released.
    assert gate.is_enabled is False


async def test_standby_stays_read_only() -> None:
    coord, elector, gate, observer = _make()
    elector.acquire_result = False
    await coord.start()
    try:
        assert coord.is_leader is False
        assert gate.is_enabled is False
        assert observer.promoted == 0
    finally:
        await coord.stop()


async def test_lease_loss_demotes_and_disables_gate() -> None:
    coord, elector, gate, observer = _make()
    await coord.start()
    try:
        assert gate.is_enabled is True
        # Simulate the lease being lost on the next renewal.
        elector.renew_result = False
        await asyncio.sleep(0.05)
        assert coord.is_leader is False
        assert gate.is_enabled is False
        assert observer.demoted and "lease-lost" in observer.demoted[0]
    finally:
        await coord.stop()


async def test_redis_failure_disables_execution() -> None:
    coord, elector, gate, observer = _make()
    await coord.start()
    try:
        assert gate.is_enabled is True
        elector.raise_on_renew = True
        await asyncio.sleep(0.05)
        assert coord.is_leader is False
        assert gate.is_enabled is False
        assert "redis-unavailable" in observer.demoted
    finally:
        await coord.stop()
