"""LiveSubmissionGate tests: every live-submission precondition (Module 14).

The gate is fail-closed: any missing or unreadable signal blocks submission.
Cancellation is intentionally NOT gated (verified in the adapter tests).
"""

from __future__ import annotations

import pytest

from polymarket_pair_bot.execution.live_ports import ReconciliationView
from polymarket_pair_bot.execution.submission_gate import LiveSubmissionGate

from tests.fixtures.execution import OPEN_S
from tests.fixtures.live_execution import (
    FakeExecutionGate,
    FakeFeedHealth,
    FakeKillSwitch,
    FakeReconciliationStatus,
    approve_decision,
    reject_decision,
)

NOW = OPEN_S + 10


def _gate(
    *,
    live_trading: bool = True,
    paper_trading: bool = False,
    execution_gate: FakeExecutionGate | None = None,
    kill_switch: FakeKillSwitch | None = None,
    feeds: FakeFeedHealth | None = None,
    reconciliation: FakeReconciliationStatus | None = None,
) -> LiveSubmissionGate:
    return LiveSubmissionGate(
        live_trading=live_trading,
        paper_trading=paper_trading,
        execution_gate=execution_gate or FakeExecutionGate(),
        kill_switch=kill_switch or FakeKillSwitch(),
        feeds=feeds or FakeFeedHealth(),
        reconciliation=reconciliation or FakeReconciliationStatus(),
        reconciliation_max_age_seconds=300,
    )


async def test_all_conditions_met_authorizes() -> None:
    decision = await _gate().authorize(now_s=NOW, risk_decision=approve_decision())
    assert decision.allowed
    assert decision.blockers == ()


async def test_live_trading_off_blocks() -> None:
    decision = await _gate(live_trading=False).authorize(
        now_s=NOW, risk_decision=approve_decision()
    )
    assert not decision.allowed
    assert any("LIVE_TRADING" in b for b in decision.blockers)


async def test_paper_trading_on_blocks() -> None:
    decision = await _gate(paper_trading=True).authorize(
        now_s=NOW, risk_decision=approve_decision()
    )
    assert not decision.allowed
    assert any("PAPER_TRADING" in b for b in decision.blockers)


async def test_no_execution_leadership_blocks() -> None:
    gate = _gate(execution_gate=FakeExecutionGate(enabled=False, reason="not leader"))
    decision = await gate.authorize(now_s=NOW, risk_decision=approve_decision())
    assert not decision.allowed
    assert any("leadership" in b for b in decision.blockers)


async def test_kill_switch_active_blocks() -> None:
    gate = _gate(kill_switch=FakeKillSwitch(active=True))
    decision = await gate.authorize(now_s=NOW, risk_decision=approve_decision())
    assert not decision.allowed
    assert any("kill switch" in b for b in decision.blockers)


async def test_unhealthy_feeds_block() -> None:
    gate = _gate(feeds=FakeFeedHealth(healthy=False))
    decision = await gate.authorize(now_s=NOW, risk_decision=approve_decision())
    assert not decision.allowed
    assert any("feeds" in b for b in decision.blockers)


async def test_missing_reconciliation_blocks() -> None:
    gate = _gate(reconciliation=FakeReconciliationStatus(view=None))
    decision = await gate.authorize(now_s=NOW, risk_decision=approve_decision())
    assert not decision.allowed
    assert any("reconciliation" in b for b in decision.blockers)


async def test_stale_reconciliation_blocks() -> None:
    stale = FakeReconciliationStatus(
        view=ReconciliationView(is_consistent=True, as_of_s=OPEN_S - 10_000)
    )
    decision = await _gate(reconciliation=stale).authorize(
        now_s=NOW, risk_decision=approve_decision()
    )
    assert not decision.allowed
    assert any("stale" in b for b in decision.blockers)


async def test_inconsistent_reconciliation_blocks() -> None:
    bad = FakeReconciliationStatus(
        view=ReconciliationView(is_consistent=False, as_of_s=NOW)
    )
    decision = await _gate(reconciliation=bad).authorize(
        now_s=NOW, risk_decision=approve_decision()
    )
    assert not decision.allowed
    assert any("not consistent" in b for b in decision.blockers)


async def test_missing_risk_decision_blocks() -> None:
    decision = await _gate().authorize(now_s=NOW, risk_decision=None)
    assert not decision.allowed
    assert any("no risk decision" in b for b in decision.blockers)


async def test_rejected_risk_decision_blocks() -> None:
    decision = await _gate().authorize(now_s=NOW, risk_decision=reject_decision())
    assert not decision.allowed
    assert any("risk engine rejected" in b for b in decision.blockers)


async def test_unreadable_signals_fail_closed() -> None:
    class ExplodingKillSwitch:
        async def is_active(self) -> bool:
            raise RuntimeError("redis down")

    gate = LiveSubmissionGate(
        live_trading=True,
        paper_trading=False,
        execution_gate=FakeExecutionGate(),
        kill_switch=ExplodingKillSwitch(),
        feeds=FakeFeedHealth(),
        reconciliation=FakeReconciliationStatus(),
        reconciliation_max_age_seconds=300,
    )
    decision = await gate.authorize(now_s=NOW, risk_decision=approve_decision())
    assert not decision.allowed
    assert any("kill switch" in b for b in decision.blockers)


def test_constructor_rejects_nonpositive_max_age() -> None:
    with pytest.raises(ValueError):
        LiveSubmissionGate(
            live_trading=True,
            paper_trading=False,
            execution_gate=FakeExecutionGate(),
            kill_switch=FakeKillSwitch(),
            feeds=FakeFeedHealth(),
            reconciliation=FakeReconciliationStatus(),
            reconciliation_max_age_seconds=0,
        )
