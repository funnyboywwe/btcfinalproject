"""Unit tests for backtest metric aggregation (Module 22).

Exercises the per-window accounting funnel (complete pairs, gross edge, fees,
slippage, hedge P&L) and the cross-window drawdown formula. All monetary
assertions use Decimal; no binary floats.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.backtest.metrics import (
    BacktestReport,
    WindowResult,
    build_window_result,
)
from polymarket_pair_bot.domain.entities import Fill
from polymarket_pair_bot.domain.enums import OrderSide
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    FeeAmount,
    FillId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.inventory.accounting import build_inventory
from tests.fixtures.backtest import make_market


def _fill(*, fid: str, oid: str, token: str, price: str, size: str, fee: str, ts: int) -> Fill:
    return Fill(
        fill_id=FillId(fid),
        order_id=OrderId(oid),
        token_id=TokenId(token),
        side=OrderSide.BUY,
        price=ProbabilityPrice(Decimal(price)),
        size=Shares(Decimal(size)),
        fee=FeeAmount(Decimal(fee)),
        filled_at=UnixTimestamp(ts),
    )


def test_matched_pair_window_accounting() -> None:
    market = make_market()
    up_token = market.up_token.token_id.value
    down_token = market.down_token.token_id.value
    fills = [
        _fill(
            fid="f1", oid="m:up:first:1", token=up_token,
            price="0.45", size="5", fee="0", ts=10,
        ),
        _fill(
            fid="f2", oid="m:down:second:2", token=down_token,
            price="0.44", size="5", fee="0", ts=11,
        ),
    ]
    inventory = build_inventory(market, fills)
    result = build_window_result(
        window_id=market.market_id.value,
        duration_seconds=300,
        snapshots=6,
        decisions=(),
        transitions=(),
        attempted_trades=2,
        fills=fills,
        inventory=inventory,
        last_up_bid=ProbabilityPrice(Decimal("0.44")),
        last_down_bid=ProbabilityPrice(Decimal("0.43")),
        overhead=CollateralAmount(0),
        slippage_bps=BasisPoints(0),
        merged_pairs=Shares(5),
        final_state="CLOSED",
        ttc_edges=(60, 120, 180, 240),
        size_edges=(Decimal(5), Decimal(25), Decimal(100)),
    )
    # Five confirmed pairs; passive (non-taker) fills => no slippage / hedge P&L.
    assert result.complete_pairs == Decimal(5)
    assert result.slippage == Decimal(0)
    assert result.emergency_hedge_pnl == Decimal(0)
    assert result.fees == Decimal(0)
    # Gross edge = pairs * (1 - up_avg - down_avg) = 5 * (1 - 0.45 - 0.44) = 0.55.
    assert result.gross_edge == Decimal("0.55")
    # No overhead and no unmatched residual => realized net equals gross edge.
    assert result.realized_net_pnl == result.gross_edge


def test_drawdown_is_max_peak_to_trough() -> None:
    def _window(wid: str, pnl: str) -> WindowResult:
        return WindowResult(
            window_id=wid,
            duration_seconds=300,
            snapshots=1,
            total_opportunities=0,
            attempted_trades=0,
            complete_pairs=Decimal(0),
            unmatched_events=0,
            gross_edge=Decimal(0),
            fees=Decimal(0),
            slippage=Decimal(0),
            emergency_hedge_pnl=Decimal(0),
            realized_net_pnl=Decimal(pnl),
            residual_pnl=Decimal(0),
            merged_pairs=Decimal(0),
            final_state="CLOSED",
        )

    windows = (_window("w1", "1"), _window("w2", "-3"), _window("w3", "2"))
    report = BacktestReport.from_windows(windows, label="t", seed=7)
    # Cumulative: 1, -2, 0; peak 1; max drawdown = 1 - (-2) = 3.
    assert report.max_drawdown == Decimal(3)
    assert report.realized_net_pnl == Decimal(0)
    assert report.window_count == 3
    assert report.seed == 7
