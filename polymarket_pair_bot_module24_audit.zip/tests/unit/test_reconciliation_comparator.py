"""Unit tests for the pure reconciliation comparator (Module 15)."""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.enums import OrderStatus
from polymarket_pair_bot.domain.value_objects import UnixTimestamp
from polymarket_pair_bot.reconciliation.classification import ReconciliationClass
from polymarket_pair_bot.reconciliation.comparator import reconcile_states
from polymarket_pair_bot.reconciliation.models import (
    ChainState,
    DiscrepancyKind,
    LocalState,
    RemoteAccountState,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from tests.fixtures.reconciliation import (
    make_allowance,
    make_balance,
    make_remote_fill,
    make_local_fill,
    make_merge_tx,
    make_remote_order,
    make_order,
)

NOW = UnixTimestamp(5000)


def _run(**kw):
    base = dict(
        trigger=ReconciliationTrigger.PERIODIC,
        local=LocalState(),
        remote=RemoteAccountState(available=True),
        chain=ChainState(available=False),
        now=NOW,
        share_tolerance=Decimal("0.000001"),
        price_tolerance=Decimal("0.000001"),
        collateral_tolerance=Decimal("0.01"),
        auto_cancel_unknown_orders=True,
        require_chain_verification=False,
        expected_allowance_spender="",
    )
    base.update(kw)
    return reconcile_states(**base)


def _kinds(report):
    return {d.kind for d in report.discrepancies}


def test_empty_is_consistent() -> None:
    report = _run()
    assert report.classification is ReconciliationClass.CONSISTENT
    assert report.is_consistent
    assert report.discrepancies == ()
    # CONSISTENT never carries discrepancy strings downstream.
    assert report.to_domain_result().discrepancies == ()


def test_remote_unavailable_is_critical_stop_fail_closed() -> None:
    report = _run(remote=RemoteAccountState(available=False, note="down"))
    assert report.classification is ReconciliationClass.CRITICAL_STOP
    assert report.halts_new_trading
    assert DiscrepancyKind.REMOTE_STATE_UNVERIFIED in _kinds(report)


def test_unknown_remote_order_requires_cancellation_when_enabled() -> None:
    report = _run(
        remote=RemoteAccountState(
            available=True, open_orders=(make_remote_order(order_id="r-1"),)
        ),
        auto_cancel_unknown_orders=True,
    )
    assert report.classification is ReconciliationClass.CANCELLATION_REQUIRED
    assert report.unknown_remote_order_ids == ("r-1",)
    assert DiscrepancyKind.UNKNOWN_REMOTE_ORDER in _kinds(report)


def test_unknown_remote_order_critical_when_autocancel_disabled() -> None:
    report = _run(
        remote=RemoteAccountState(
            available=True, open_orders=(make_remote_order(order_id="r-1"),)
        ),
        auto_cancel_unknown_orders=False,
    )
    assert report.classification is ReconciliationClass.CRITICAL_STOP


def test_missing_local_fill_is_auto_recoverable_and_queued() -> None:
    report = _run(
        remote=RemoteAccountState(
            available=True, fills=(make_remote_fill(fill_id="f-1", order_id="o-1"),)
        )
    )
    assert report.classification is ReconciliationClass.AUTOMATICALLY_RECOVERABLE
    assert not report.halts_new_trading
    assert len(report.fills_to_import) == 1
    assert report.fills_to_import[0].fill_id.value == "f-1"


def test_local_only_fill_is_manual_review_never_deleted() -> None:
    report = _run(local=LocalState(fills=(make_local_fill(fill_id="f-9"),)))
    assert DiscrepancyKind.MISSING_REMOTE_FILL in _kinds(report)
    assert report.classification is ReconciliationClass.MANUAL_REVIEW
    assert report.fills_to_import == ()


def test_token_balance_mismatch_is_critical_stop() -> None:
    # Confirmed buy of 2 shares of token-1, but wallet reports only 1.
    report = _run(
        local=LocalState(fills=(make_local_fill(fill_id="f-1", size="2"),)),
        remote=RemoteAccountState(
            available=True,
            fills=(make_remote_fill(fill_id="f-1"),),
            balances=(make_balance(asset="2001", total="1", available="1"),),
        ),
    )
    assert report.classification is ReconciliationClass.CRITICAL_STOP
    assert DiscrepancyKind.TOKEN_BALANCE_MISMATCH in _kinds(report)


def test_pending_merge_tx_is_manual_review() -> None:
    report = _run(
        trigger=ReconciliationTrigger.PRE_MERGE,
        local=LocalState(pending_chain_txs=(make_merge_tx(),)),
    )
    assert DiscrepancyKind.PENDING_CHAIN_TX in _kinds(report)
    assert report.classification is ReconciliationClass.MANUAL_REVIEW


def test_require_chain_verification_flags_unverified_chain() -> None:
    report = _run(
        chain=ChainState(available=False, note="blocked"),
        require_chain_verification=True,
    )
    assert DiscrepancyKind.CHAIN_STATE_UNVERIFIED in _kinds(report)
    assert report.classification is ReconciliationClass.MANUAL_REVIEW


def test_allowance_shortfall_flagged_for_expected_spender() -> None:
    report = _run(
        remote=RemoteAccountState(
            available=True,
            allowances=(make_allowance(spender="0xother", amount="5"),),
        ),
        expected_allowance_spender="0xexchange",
    )
    assert DiscrepancyKind.ALLOWANCE_SHORTFALL in _kinds(report)


def test_order_state_mismatch_is_local_repair() -> None:
    local = LocalState(
        open_orders=(
            make_order(order_id="o-1", status=OrderStatus.OPEN, filled="0"),
        )
    )
    remote = RemoteAccountState(
        available=True,
        open_orders=(
            make_remote_order(
                order_id="o-1",
                status=OrderStatus.PARTIALLY_FILLED,
                size_matched="2",
            ),
        ),
    )
    report = _run(local=local, remote=remote)
    assert DiscrepancyKind.ORDER_STATE_MISMATCH in _kinds(report)
    assert report.classification is ReconciliationClass.LOCAL_REPAIR_REQUIRED
