"""Unit tests for the Module 20 Prometheus alert rules."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.observability.alerts import (
    default_alert_rules,
    render_rules_document,
)

REQUIRED_ALERTS = {
    "StaleOrderBooks",
    "StaleUserStream",
    "UnmatchedDurationBreach",
    "UnknownOrderDetected",
    "BalanceMismatch",
    "FailedMerge",
    "ProcessRestart",
    "DailyLossLimit",
    "KillSwitchActive",
    "RpcDisagreement",
}


def test_all_required_alerts_present() -> None:
    rules = default_alert_rules()
    names = {rule.name for rule in rules}
    assert REQUIRED_ALERTS <= names


def test_thresholds_are_materialised_into_expressions() -> None:
    rules = default_alert_rules(
        namespace="ppb",
        stale_book_seconds=5.0,
        stale_user_seconds=30.0,
        unmatched_duration_seconds=120,
        daily_loss_usd=Decimal("50"),
    )
    by_name = {rule.name: rule for rule in rules}
    assert "ppb_order_book_age_seconds > 5.0" == by_name["StaleOrderBooks"].expr
    assert "ppb_user_websocket_age_seconds > 30.0" == by_name["StaleUserStream"].expr
    assert "120" in by_name["UnmatchedDurationBreach"].expr
    assert "-50" in by_name["DailyLossLimit"].expr
    assert by_name["KillSwitchActive"].expr == "ppb_kill_switch_active == 1"


def test_process_restart_uses_unnamespaced_process_metric() -> None:
    rules = {rule.name: rule for rule in default_alert_rules()}
    # process_start_time_seconds is exported by the client ProcessCollector and
    # must NOT be namespaced.
    assert "process_start_time_seconds" in rules["ProcessRestart"].expr
    assert "ppb_process_start_time_seconds" not in rules["ProcessRestart"].expr


def test_every_rule_has_severity_and_annotations() -> None:
    for rule in default_alert_rules():
        rendered = rule.to_prometheus()
        assert rendered["labels"]["severity"] in {"info", "warning", "error", "critical"}
        assert rendered["annotations"]["summary"]
        assert rendered["annotations"]["description"]


def test_render_rules_document_structure() -> None:
    doc = render_rules_document(default_alert_rules(), group_name="ppb")
    assert doc["groups"][0]["name"] == "ppb"
    assert len(doc["groups"][0]["rules"]) == len(default_alert_rules())


def test_to_yaml_roundtrips_when_pyyaml_available() -> None:
    yaml = pytest.importorskip("yaml")
    from polymarket_pair_bot.observability.alerts import to_yaml

    doc = render_rules_document(default_alert_rules())
    text = to_yaml(doc)
    loaded = yaml.safe_load(text)
    assert loaded == doc
