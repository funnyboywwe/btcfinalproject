"""Unit tests for typed configuration and safety defaults."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from polymarket_pair_bot.config.settings import Settings


def test_safety_defaults() -> None:
    settings = Settings()
    assert settings.live_trading is False
    assert settings.paper_trading is True
    assert settings.trading_mode == "paper"


def test_secrets_are_not_exposed_in_repr() -> None:
    settings = Settings()
    assert "pair_bot" not in repr(settings.postgres_dsn)
    assert settings.postgres_dsn.get_secret_value().startswith("postgresql+asyncpg://")


def test_live_and_paper_cannot_both_be_true(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("LIVE_TRADING", "true")
    monkeypatch.setenv("PAPER_TRADING", "true")
    with pytest.raises(ValidationError):
        Settings()


def test_env_overrides_are_applied(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("LOG_LEVEL", "WARNING")
    monkeypatch.setenv("SHUTDOWN_TIMEOUT_SECONDS", "12.5")
    settings = Settings()
    assert settings.log_level == "WARNING"
    assert settings.shutdown_timeout_seconds == 12.5
