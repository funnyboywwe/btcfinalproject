"""Extensive synthetic-order-book tests for Module 8: pair-cost engine.

All prices, quantities and monetary values are Decimal or domain value objects.
No binary floats are used for monetary quantities.

Test groups:
  1. EngineParameters construction and validation.
  2. Depth assessment — empty, thin, deep, multi-level walk.
  3. VWAP computation — exact, partial, empty book.
  4. Taker acquisition cost and fee calculations.
  5. Maker acquisition cost calculation.
  6. Effective pair cost formula.
  7. Gross and net profit.
  8. Max acceptable first-leg and second-leg prices.
  9. Tick sensitivity (1, 2, 3 ticks).
  10. Result classification — all six outcome types.
  11. Rejection conditions (stale, insufficient depth, too close to close,
      each rejection reason string).
  12. Conservative rounding invariants.
  13. Hypothesis property-based tests (monotonicity, budget invariants).
  14. Full round-trip integration scenarios.
"""

from __future__ import annotations

import math
from decimal import Decimal

import pytest
from hypothesis import assume, given, settings as hyp_settings
from hypothesis import strategies as st

from polymarket_pair_bot.domain.entities import OrderBookSnapshot, PriceLevel
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.strategy.engine import (
    DepthAssessment,
    EngineParameters,
    FeeParameters,
    InventorySummary,
    PairCostResult,
    PairOpportunityResult,
    TickSensitivity,
    evaluate_pair_cost,
)
from tests.fixtures.engine import (
    DOWN_TOKEN,
    NOW,
    TICK,
    UP_TOKEN,
    deep_book,
    make_book,
    make_inventory,
    make_params,
    thin_book,
)


# ===========================================================================
# 1. EngineParameters construction and validation
# ===========================================================================


class TestEngineParametersValidation:
    def test_valid_defaults(self) -> None:
        params = make_params()
        assert params.max_effective_pair_cost.value < Decimal(1)
        assert params.min_seconds_to_close == 30

    def test_max_cost_must_be_below_one_dollar(self) -> None:
        with pytest.raises(ValueError, match="max_effective_pair_cost"):
            make_params(max_effective_pair_cost="1.00")

    def test_max_cost_exactly_one_rejected(self) -> None:
        with pytest.raises(ValueError):
            make_params(max_effective_pair_cost="1")

    def test_negative_min_seconds_rejected(self) -> None:
        with pytest.raises(ValueError):
            EngineParameters(
                fee_parameters=FeeParameters(
                    taker_fee_bps=BasisPoints(Decimal(0))
                ),
                slippage_reserve=CollateralAmount(Decimal(0)),
                merge_gas_overhead=CollateralAmount(Decimal("0.005")),
                safety_reserve=CollateralAmount(Decimal("0.005")),
                max_effective_pair_cost=CollateralAmount(Decimal("0.99")),
                required_net_profit=ProfitAmount(Decimal(0)),
                min_book_depth=Shares(Decimal(1)),
                min_seconds_to_close=-1,
                tick_size=TICK,
            )

    def test_overhead_sums_correctly(self) -> None:
        params = make_params(
            slippage_reserve="0.002",
            merge_gas_overhead="0.003",
            safety_reserve="0.005",
        )
        # overhead rounds UP
        assert params.overhead.value == Decimal("0.010")

    def test_fee_parameters_defaults_maker_to_zero(self) -> None:
        fp = FeeParameters(taker_fee_bps=BasisPoints(Decimal("100")))
        assert fp.maker_fee_bps.value == Decimal(0)


# ===========================================================================
# 2. Depth assessment
# ===========================================================================


class TestDepthAssessment:
    def test_none_book_is_insufficient(self) -> None:
        params = make_params()
        result = evaluate_pair_cost(
            None,
            deep_book(DOWN_TOKEN, best_ask="0.50"),
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=params,
            seconds_to_close=120,
            up_is_fresh=False,
            down_is_fresh=True,
        )
        assert result.up_depth.is_sufficient is False
        assert result.up_depth.available.value == Decimal(0)
        assert result.is_rejected

    def test_empty_asks_is_insufficient(self) -> None:
        empty = make_book(UP_TOKEN, bids=[("0.49", "10")], asks=[])
        result = evaluate_pair_cost(
            empty,
            deep_book(DOWN_TOKEN, best_ask="0.50"),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_depth.is_sufficient is False
        assert result.up_vwap.average_price is None
        assert result.is_rejected

    def test_single_level_exact_depth(self) -> None:
        book = make_book(UP_TOKEN, asks=[("0.50", "10")])
        result = evaluate_pair_cost(
            book,
            deep_book(DOWN_TOKEN, best_ask="0.49"),
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(min_book_depth="10"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_depth.is_sufficient is True
        assert result.up_depth.available.value == Decimal(10)
        assert result.up_depth.levels_consumed == 1

    def test_multi_level_depth_walk(self) -> None:
        book = make_book(
            UP_TOKEN,
            asks=[("0.50", "3"), ("0.51", "4"), ("0.52", "5")],
        )
        result = evaluate_pair_cost(
            book,
            deep_book(DOWN_TOKEN, best_ask="0.48"),
            target_quantity=Shares(Decimal(8)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_depth.is_sufficient is True
        assert result.up_depth.levels_consumed == 3  # 3+4+1
        assert result.up_depth.available.value >= Decimal(8)

    def test_thin_book_insufficient_for_target(self) -> None:
        book = make_book(UP_TOKEN, asks=[("0.50", "2")])
        result = evaluate_pair_cost(
            book,
            deep_book(DOWN_TOKEN, best_ask="0.49"),
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(min_book_depth="10"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_depth.is_sufficient is False
        assert result.up_depth.available.value == Decimal(2)
        assert result.is_rejected

    def test_levels_consumed_stops_at_target(self) -> None:
        # Has more depth than needed; levels_consumed must stop once target met.
        book = make_book(
            UP_TOKEN,
            asks=[("0.50", "10"), ("0.51", "10"), ("0.52", "10")],
        )
        result = evaluate_pair_cost(
            book,
            deep_book(DOWN_TOKEN, best_ask="0.48"),
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_depth.levels_consumed == 1


# ===========================================================================
# 3. VWAP computation
# ===========================================================================


class TestVwapComputation:
    def test_single_level_vwap_exact_price(self) -> None:
        book = make_book(UP_TOKEN, asks=[("0.50", "10")])
        result = evaluate_pair_cost(
            book,
            deep_book(DOWN_TOKEN, best_ask="0.48"),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_vwap.average_price is not None
        assert result.up_vwap.average_price.value == Decimal("0.50")
        assert result.up_vwap.is_complete is True

    def test_multi_level_vwap_weighted_average(self) -> None:
        # 5 @ 0.50 + 5 @ 0.52 = notional 5.10 / 10 = 0.51
        book = make_book(
            UP_TOKEN,
            asks=[("0.50", "5"), ("0.52", "5")],
        )
        result = evaluate_pair_cost(
            book,
            deep_book(DOWN_TOKEN, best_ask="0.47"),
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_vwap.average_price is not None
        assert result.up_vwap.average_price.value == Decimal("0.51")

    def test_partial_fill_vwap(self) -> None:
        # Only 3 available, want 10 → partial
        book = make_book(UP_TOKEN, asks=[("0.50", "3")])
        result = evaluate_pair_cost(
            book,
            deep_book(DOWN_TOKEN, best_ask="0.48"),
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(min_book_depth="10"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_vwap.is_complete is False
        assert result.up_vwap.filled.value == Decimal(3)

    def test_none_book_vwap_empty(self) -> None:
        result = evaluate_pair_cost(
            None,
            deep_book(DOWN_TOKEN, best_ask="0.48"),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=False,
            down_is_fresh=True,
        )
        assert result.up_vwap.average_price is None
        assert result.up_vwap.filled.value == Decimal(0)
        assert result.up_vwap.is_complete is False

    def test_max_executable_quantity_limited_by_thinner_side(self) -> None:
        up = make_book(UP_TOKEN, asks=[("0.50", "5")])
        down = make_book(DOWN_TOKEN, asks=[("0.48", "20")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(min_book_depth="5"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.max_executable_quantity.value == Decimal(5)

    def test_max_executable_quantity_when_both_full(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.50", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.48", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.max_executable_quantity.value == Decimal(10)


# ===========================================================================
# 4. Taker acquisition costs and fees
# ===========================================================================


class TestTakerCostsAndFees:
    def test_zero_fee_taker_cost(self) -> None:
        # UP VWAP 0.50, qty 10 → cost 5.00; DOWN VWAP 0.48, qty 10 → 4.80
        up = deep_book(UP_TOKEN, best_ask="0.50", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.48", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(taker_fee_bps="0"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_taker_cost.value == Decimal("5.000000")
        assert result.down_taker_cost.value == Decimal("4.800000")
        assert result.total_taker_fee.value == Decimal(0)

    def test_nonzero_fee_rounds_up(self) -> None:
        # UP cost = 0.50 * 1 = 0.50; fee 100bps = 0.005
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.49", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(taker_fee_bps="100"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # up_taker_cost = 0.50 * 1 = 0.50
        # fee on 0.50 at 100bps = 0.50 * 0.01 = 0.005
        assert result.taker_fee_up.value == Decimal("0.005000")
        assert result.taker_fee_down.value == Decimal("0.004900")
        # total = 0.0099
        assert result.total_taker_fee.value == Decimal("0.009900")

    def test_fees_never_negative(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.50")
        down = deep_book(DOWN_TOKEN, best_ask="0.48")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(taker_fee_bps="0"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.taker_fee_up.value >= Decimal(0)
        assert result.taker_fee_down.value >= Decimal(0)
        assert result.total_taker_fee.value >= Decimal(0)

    def test_fee_is_sum_of_individual_fees(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.52")
        down = deep_book(DOWN_TOKEN, best_ask="0.45")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(7)),
            inventory=make_inventory(),
            parameters=make_params(taker_fee_bps="50"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # total_taker_fee rounds up independently, individual also rounds up
        total_computed = result.taker_fee_up.value + result.taker_fee_down.value
        # total_taker_fee should be >= sum (may round up once more)
        assert result.total_taker_fee.value >= total_computed


# ===========================================================================
# 5. Maker acquisition cost
# ===========================================================================


class TestMakerCost:
    def test_maker_cost_uses_best_bid(self) -> None:
        # best bid = 0.49, qty = 10 → maker cost = 4.90
        up = make_book(UP_TOKEN, bids=[("0.49", "20")], asks=[("0.50", "20")])
        down = make_book(DOWN_TOKEN, bids=[("0.47", "20")], asks=[("0.48", "20")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_maker_cost is not None
        assert result.up_maker_cost.value == Decimal("4.900000")
        assert result.down_maker_cost is not None
        assert result.down_maker_cost.value == Decimal("4.700000")

    def test_maker_cost_none_when_no_bids(self) -> None:
        up = make_book(UP_TOKEN, bids=[], asks=[("0.50", "20")])
        down = make_book(DOWN_TOKEN, bids=[], asks=[("0.48", "20")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_maker_cost is None
        assert result.down_maker_cost is None
        assert result.effective_pair_cost_maker is None

    def test_maker_cost_none_when_book_unavailable(self) -> None:
        result = evaluate_pair_cost(
            None,
            deep_book(DOWN_TOKEN),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=False,
            down_is_fresh=True,
        )
        assert result.up_maker_cost is None

    def test_maker_cost_lower_than_taker_cost(self) -> None:
        # By construction: best bid < best ask → maker < taker
        up = make_book(UP_TOKEN, bids=[("0.48", "20")], asks=[("0.50", "20")])
        down = make_book(DOWN_TOKEN, bids=[("0.46", "20")], asks=[("0.48", "20")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_maker_cost is not None
        assert result.up_maker_cost.value < result.up_taker_cost.value
        assert result.down_maker_cost is not None
        assert result.down_maker_cost.value < result.down_taker_cost.value


# ===========================================================================
# 6. Effective pair cost formula
# ===========================================================================


class TestEffectivePairCost:
    def test_zero_fee_zero_overhead(self) -> None:
        # up = 0.50, down = 0.48, qty = 1, zero fees/overhead
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.48", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # (0.50 + 0.48) * (1+0) + 0 = 0.98
        assert result.effective_pair_cost_taker.value == Decimal("0.980000")

    def test_with_100bps_fee(self) -> None:
        # up = 0.50, down = 0.48, qty = 1, fee=100bps
        # (0.50 + 0.48) * 1.01 = 0.9898
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.48", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="100",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.effective_pair_cost_taker.value == Decimal("0.989800")

    def test_with_overhead_components(self) -> None:
        up = make_book(UP_TOKEN, asks=[("0.48", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.47", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0.002",
                merge_gas_overhead="0.003",
                safety_reserve="0.005",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # (0.48 + 0.47) + (0.002 + 0.003 + 0.005) = 0.95 + 0.010 = 0.960
        assert result.effective_pair_cost_taker.value == Decimal("0.960000")

    def test_effective_pair_cost_rounds_up(self) -> None:
        # Construct a case where the raw sum has a fractional part below quantum
        up = make_book(UP_TOKEN, asks=[("0.333333", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.333333", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # 0.333333 + 0.333333 = 0.666666 exact – no rounding needed here
        assert result.effective_pair_cost_taker.value == Decimal("0.666666")

    def test_effective_pair_cost_never_below_raw_sum(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.50")
        down = deep_book(DOWN_TOKEN, best_ask="0.48")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(taker_fee_bps="75"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # effective_pair_cost is PER PAIR; compare against per-pair raw prices
        assert result.up_vwap.average_price is not None
        assert result.down_vwap.average_price is not None
        per_pair_raw = result.up_vwap.average_price.value + result.down_vwap.average_price.value
        assert result.effective_pair_cost_taker.value >= per_pair_raw


# ===========================================================================
# 7. Gross and net profit
# ===========================================================================


class TestProfit:
    def test_gross_profit_below_dollar(self) -> None:
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.48", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # gross = 1 - 0.50 - 0.48 = 0.02 (before fees)
        assert result.gross_profit.value == Decimal("0.02")

    def test_net_profit_accounts_for_fees_and_overhead(self) -> None:
        up = make_book(UP_TOKEN, asks=[("0.48", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.47", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0.005",
                safety_reserve="0.005",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # effective = 0.48 + 0.47 + 0.01 = 0.96
        # net profit = 1 - 0.96 = 0.04
        assert result.net_profit.value == Decimal("0.04")

    def test_net_profit_can_be_negative(self) -> None:
        # Cost too high
        up = make_book(UP_TOKEN, asks=[("0.55", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.55", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
                max_effective_pair_cost="0.99",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # 0.55 + 0.55 = 1.10 > 1 → net profit = 1 - 1.10 = -0.10
        assert result.net_profit.value == Decimal("-0.10")

    def test_net_profit_rounds_down(self) -> None:
        # Ensure net profit is floor-rounded (conservative)
        up = make_book(UP_TOKEN, asks=[("0.333334", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.333333", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # net = 1 - effective → effective rounds up → net rounds down
        assert result.net_profit.value <= Decimal(1) - Decimal("0.333334") - Decimal("0.333333")


# ===========================================================================
# 8. Max acceptable prices
# ===========================================================================


class TestMaxAcceptablePrices:
    def test_max_first_leg_price_below_budget(self) -> None:
        # down VWAP = 0.48, max_cost = 0.99, overhead = 0, fee = 0, qty = 1
        # max_up = (0.99 - 0) / (1+0) / 1 - 0.48 = 0.99 - 0.48 = 0.51
        # round to tick 0.01 → 0.51
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.48", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.max_first_leg_price is not None
        assert result.max_first_leg_price.value == Decimal("0.51")

    def test_max_second_leg_price_after_up_fill(self) -> None:
        # up fills at 0.50, max_cost = 0.99, overhead=0, fee=0, qty=1
        # max_down = 0.99 - 0.50 = 0.49 → round down to 0.49
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.48", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.max_second_leg_price is not None
        assert result.max_second_leg_price.value == Decimal("0.49")

    def test_max_first_leg_none_when_down_unavailable(self) -> None:
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        result = evaluate_pair_cost(
            up, None,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=False,
        )
        assert result.max_first_leg_price is None

    def test_max_price_rounds_down_to_tick(self) -> None:
        # max_up budget = 0.99 - 0.48 = 0.51 exactly → nearest tick = 0.51
        # Use a case that doesn't divide evenly: max_cost=0.985, down=0.48
        # max_up = 0.985 - 0.48 = 0.505 → round down to 0.50 with tick=0.01
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.48", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
                max_effective_pair_cost="0.985",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # max_up = 0.985 - 0.48 = 0.505 → floor to tick 0.01 → 0.50
        assert result.max_first_leg_price is not None
        assert result.max_first_leg_price.value == Decimal("0.50")

    def test_max_prices_none_when_cost_leaves_no_room(self) -> None:
        # Both prices = 0.55 → together = 1.10; max_cost = 0.99
        # max_up = 0.99 - 0.55 = 0.44; but that's still valid
        # Let's force a case: both = 0.60, max_cost = 0.99
        # max_up = 0.99 - 0.60 = 0.39 → valid (0.39 > 0)
        # Use both = 0.51, overhead = 0, max_cost = 0.99
        # max_up = 0.99 - 0.51 = 0.48 → still valid
        # Force none: need other_leg_cost > budget
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(
            DOWN_TOKEN,
            asks=[("0.99", "10")],  # down cost = 0.99 > 0.98 budget
            bids=[("0.98", "10")],
        )
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
                max_effective_pair_cost="0.99",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # max_up = 0.99 - 0.99 = 0.00 → None (non-positive)
        assert result.max_first_leg_price is None


# ===========================================================================
# 9. Tick sensitivity
# ===========================================================================


class TestTickSensitivity:
    def _base_result(
        self, net_profit: str = "0.02", taker_fee_bps: str = "0"
    ) -> PairCostResult:
        # up=0.50, down=0.48 → net_profit = 1 - 0.98 - overhead
        up = make_book(UP_TOKEN, asks=[("0.50", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.48", "10")])
        return evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps=taker_fee_bps,
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )

    def test_sensitivity_tuple_length_three(self) -> None:
        result = self._base_result()
        assert len(result.tick_sensitivity) == 3

    def test_sensitivity_ticks_are_one_two_three(self) -> None:
        result = self._base_result()
        assert result.tick_sensitivity[0].ticks == 1
        assert result.tick_sensitivity[1].ticks == 2
        assert result.tick_sensitivity[2].ticks == 3

    def test_sensitivity_cost_increase_monotone(self) -> None:
        result = self._base_result()
        c1 = result.tick_sensitivity[0].cost_increase.value
        c2 = result.tick_sensitivity[1].cost_increase.value
        c3 = result.tick_sensitivity[2].cost_increase.value
        assert c1 < c2 < c3

    def test_sensitivity_profit_decreases_by_tick_increment(self) -> None:
        result = self._base_result()
        # Each extra tick adds 2 * tick * qty = 2 * 0.01 * 1 = 0.02
        p0 = result.net_profit.value
        p1 = result.tick_sensitivity[0].adjusted_net_profit.value
        p2 = result.tick_sensitivity[1].adjusted_net_profit.value
        p3 = result.tick_sensitivity[2].adjusted_net_profit.value
        # step down = 2 * 0.01 * 1 = 0.02 per tick
        delta = Decimal("0.02")
        assert p1 == p0 - delta
        assert p2 == p0 - 2 * delta
        assert p3 == p0 - 3 * delta

    def test_sensitivity_cost_increase_correct_formula(self) -> None:
        # qty=5, tick=0.01 → 1-tick cost increase = 2 * 1 * 0.01 * 5 = 0.10
        up = deep_book(UP_TOKEN, best_ask="0.50", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.48", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # Sensitivity is PER PAIR: 2*N*tick (no qty multiplier)
        assert result.tick_sensitivity[0].cost_increase.value == Decimal("0.020000")  # 2*1*0.01
        assert result.tick_sensitivity[1].cost_increase.value == Decimal("0.040000")  # 2*2*0.01
        assert result.tick_sensitivity[2].cost_increase.value == Decimal("0.060000")  # 2*3*0.01

    def test_remains_viable_true_when_still_profitable(self) -> None:
        # Net profit = 0.02, 1-tick loss = 0.02 → adjusted = 0.00 → still meets required = 0
        result = self._base_result()
        assert result.tick_sensitivity[0].remains_viable is True  # 0.00 >= 0

    def test_remains_viable_false_when_profit_flips(self) -> None:
        # Net profit = 0.02, 3-tick loss = 0.06 → adjusted = -0.04 < 0
        result = self._base_result()
        assert result.tick_sensitivity[2].remains_viable is False


# ===========================================================================
# 10. Result classification
# ===========================================================================


class TestClassification:
    def test_immediate_two_leg_when_within_budget(self) -> None:
        # up=0.48, down=0.47, no fees, no overhead → cost = 0.95 < 0.99
        up = deep_book(UP_TOKEN, best_ask="0.48", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.47", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.result is PairOpportunityResult.IMMEDIATE_TWO_LEG
        assert not result.is_rejected
        assert result.is_actionable

    def test_observation_only_when_above_budget(self) -> None:
        # up=0.55, down=0.55 → 1.10 > 0.99
        up = deep_book(UP_TOKEN, best_ask="0.55", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.55", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.result is PairOpportunityResult.OBSERVATION_ONLY
        assert not result.is_rejected
        assert not result.is_actionable

    def test_passive_first_leg_when_maker_within_budget(self) -> None:
        # Taker: up=0.55 + down=0.55 = 1.10 > 0.99 → rejected as taker
        # Maker: bid up=0.44 + bid down=0.44 = 0.88 < 0.99 → passive OK
        up = make_book(UP_TOKEN, bids=[("0.44", "20")], asks=[("0.55", "20")])
        down = make_book(DOWN_TOKEN, bids=[("0.44", "20")], asks=[("0.55", "20")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
                max_effective_pair_cost="0.99",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.result is PairOpportunityResult.PASSIVE_FIRST_LEG

    def test_passive_second_leg_when_up_inventory_sufficient(self) -> None:
        # Already have 10 unmatched Up; only need Down
        up = deep_book(UP_TOKEN, best_ask="0.50", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.48", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(unmatched_up="10"),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.result is PairOpportunityResult.PASSIVE_SECOND_LEG

    def test_passive_second_leg_when_down_inventory_sufficient(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.50", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.48", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(unmatched_down="10"),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.result is PairOpportunityResult.PASSIVE_SECOND_LEG

    def test_matched_pair_when_both_sides_sufficient(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.50", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.48", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(unmatched_up="10", unmatched_down="10"),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.result is PairOpportunityResult.MATCHED_PAIR
        assert result.is_actionable

    def test_rejected_beats_matched_pair_when_stale(self) -> None:
        # Even if inventory is sufficient, stale book → REJECTED
        result = evaluate_pair_cost(
            None,
            deep_book(DOWN_TOKEN),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(unmatched_up="10", unmatched_down="10"),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=False,  # stale
            down_is_fresh=True,
        )
        assert result.result is PairOpportunityResult.REJECTED

    def test_is_immediate_candidate_property(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.48")
        down = deep_book(DOWN_TOKEN, best_ask="0.47")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.is_immediate_candidate


# ===========================================================================
# 11. Rejection conditions
# ===========================================================================


class TestRejectionConditions:
    def test_up_book_stale_rejected(self) -> None:
        result = evaluate_pair_cost(
            deep_book(UP_TOKEN),
            deep_book(DOWN_TOKEN),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=False,  # stale
            down_is_fresh=True,
        )
        assert result.is_rejected
        assert any("up_book" in r and "stale" in r for r in result.rejection_reasons)

    def test_down_book_stale_rejected(self) -> None:
        result = evaluate_pair_cost(
            deep_book(UP_TOKEN),
            deep_book(DOWN_TOKEN),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=False,  # stale
        )
        assert result.is_rejected
        assert any("down_book" in r and "stale" in r for r in result.rejection_reasons)

    def test_both_books_stale_both_reasons_reported(self) -> None:
        result = evaluate_pair_cost(
            deep_book(UP_TOKEN),
            deep_book(DOWN_TOKEN),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=False,
            down_is_fresh=False,
        )
        assert sum(1 for r in result.rejection_reasons if "stale" in r) >= 2

    def test_up_book_none_rejected(self) -> None:
        result = evaluate_pair_cost(
            None,
            deep_book(DOWN_TOKEN),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=False,
            down_is_fresh=True,
        )
        assert result.is_rejected
        assert any("unavailable" in r for r in result.rejection_reasons)

    def test_down_book_none_rejected(self) -> None:
        result = evaluate_pair_cost(
            deep_book(UP_TOKEN),
            None,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=False,
        )
        assert result.is_rejected

    def test_insufficient_depth_rejected(self) -> None:
        # Only 2 shares available on UP, need 10
        up = make_book(UP_TOKEN, asks=[("0.50", "2")])
        result = evaluate_pair_cost(
            up,
            deep_book(DOWN_TOKEN),
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(min_book_depth="10"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.is_rejected
        assert any("insufficient" in r for r in result.rejection_reasons)

    def test_window_too_close_rejected(self) -> None:
        result = evaluate_pair_cost(
            deep_book(UP_TOKEN),
            deep_book(DOWN_TOKEN),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(min_seconds_to_close=60),
            seconds_to_close=30,  # below minimum
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.is_rejected
        assert any("too_close" in r for r in result.rejection_reasons)

    def test_window_exactly_at_minimum_not_rejected_for_that_reason(self) -> None:
        result = evaluate_pair_cost(
            deep_book(UP_TOKEN, best_ask="0.48"),
            deep_book(DOWN_TOKEN, best_ask="0.47"),
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(
                min_seconds_to_close=60,
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=60,  # exactly at minimum
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # Window boundary: 60 >= 60 should NOT trigger rejection
        assert not any("too_close" in r for r in result.rejection_reasons)

    def test_multiple_rejection_reasons_all_reported(self) -> None:
        result = evaluate_pair_cost(
            None,
            None,
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(min_seconds_to_close=120),
            seconds_to_close=10,  # also too close
            up_is_fresh=False,
            down_is_fresh=False,
        )
        # Expect: up unavailable, up stale, down unavailable, down stale,
        # window_too_close, up/down depth_insufficient
        assert len(result.rejection_reasons) >= 4

    def test_rejection_reasons_are_strings(self) -> None:
        result = evaluate_pair_cost(
            None,
            None,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=False,
            down_is_fresh=False,
        )
        assert all(isinstance(r, str) for r in result.rejection_reasons)

    def test_no_rejection_reasons_when_valid(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.48", size_per_level="20")
        down = deep_book(DOWN_TOKEN, best_ask="0.47", size_per_level="20")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.rejection_reasons == ()
        assert not result.is_rejected


# ===========================================================================
# 12. Conservative rounding invariants
# ===========================================================================


class TestRoundingInvariants:
    def test_fees_always_round_up(self) -> None:
        # Construct a notional that produces a non-terminating decimal for fee
        # fee = 0.333333 * 100bps = 0.00333333...
        up = make_book(UP_TOKEN, asks=[("0.333333", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.333333", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="100",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # fee on 0.333333 at 100bps = 0.00333333 → rounded UP = 0.003334
        assert result.taker_fee_up.value == Decimal("0.003334")

    def test_effective_pair_cost_greater_than_raw_sum(self) -> None:
        up = deep_book(UP_TOKEN, best_ask="0.50")
        down = deep_book(DOWN_TOKEN, best_ask="0.48")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(taker_fee_bps="50"),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        raw = result.up_taker_cost.value + result.down_taker_cost.value
        assert result.effective_pair_cost_taker.value >= raw

    def test_net_profit_at_most_gross_minus_overhead(self) -> None:
        up = make_book(UP_TOKEN, asks=[("0.48", "10")])
        down = make_book(DOWN_TOKEN, asks=[("0.47", "10")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="50",
                merge_gas_overhead="0.005",
                safety_reserve="0.005",
                slippage_reserve="0.001",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.net_profit.value <= result.gross_profit.value

    def test_maker_cost_not_greater_than_taker_cost(self) -> None:
        # Best bid < best ask by design → maker < taker
        up = make_book(UP_TOKEN, bids=[("0.45", "20")], asks=[("0.50", "20")])
        down = make_book(DOWN_TOKEN, bids=[("0.43", "20")], asks=[("0.48", "20")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_maker_cost is not None
        assert result.up_maker_cost.value <= result.up_taker_cost.value
        assert result.down_maker_cost is not None
        assert result.down_maker_cost.value <= result.down_taker_cost.value

    def test_max_prices_not_above_one(self) -> None:
        up = make_book(UP_TOKEN, asks=[("0.01", "100")])
        down = make_book(DOWN_TOKEN, asks=[("0.01", "100")])
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(1)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
                max_effective_pair_cost="0.99",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        if result.max_first_leg_price is not None:
            assert result.max_first_leg_price.value <= Decimal(1)
        if result.max_second_leg_price is not None:
            assert result.max_second_leg_price.value <= Decimal(1)


# ===========================================================================
# 13. Hypothesis property-based tests
# ===========================================================================


def _price_st() -> st.SearchStrategy[Decimal]:
    """Strategy: Decimal prices in (0.01, 0.95) step 0.01."""
    return st.integers(min_value=1, max_value=95).map(
        lambda n: Decimal(n) * Decimal("0.01")
    )


def _qty_st() -> st.SearchStrategy[Decimal]:
    return st.integers(min_value=1, max_value=20).map(Decimal)


def _bps_st() -> st.SearchStrategy[Decimal]:
    return st.integers(min_value=0, max_value=300).map(Decimal)


@given(
    up_ask=_price_st(),
    down_ask=_price_st(),
    qty=_qty_st(),
    fee_bps=_bps_st(),
)
@hyp_settings(max_examples=200)
def test_hypothesis_effective_cost_never_below_raw_sum(
    up_ask: Decimal,
    down_ask: Decimal,
    qty: Decimal,
    fee_bps: Decimal,
) -> None:
    """effective_pair_cost_taker >= up_cost + down_cost (fees + overhead add)."""
    assume(up_ask + down_ask < Decimal(1))  # avoid price > 1 issues
    up = make_book(UP_TOKEN, asks=[(str(up_ask), str(qty + 5))])
    down = make_book(DOWN_TOKEN, asks=[(str(down_ask), str(qty + 5))])
    result = evaluate_pair_cost(
        up, down,
        target_quantity=Shares(qty),
        inventory=make_inventory(),
        parameters=make_params(
            taker_fee_bps=str(fee_bps),
            slippage_reserve="0",
            merge_gas_overhead="0",
            safety_reserve="0",
        ),
        seconds_to_close=120,
        up_is_fresh=True,
        down_is_fresh=True,
    )
    # effective_pair_cost is PER PAIR; compare against per-pair VWAP prices
    if result.up_vwap.average_price is not None and result.down_vwap.average_price is not None:
        per_pair_raw = result.up_vwap.average_price.value + result.down_vwap.average_price.value
        assert result.effective_pair_cost_taker.value >= per_pair_raw


@given(
    up_ask=_price_st(),
    down_ask=_price_st(),
    qty=_qty_st(),
)
@hyp_settings(max_examples=200)
def test_hypothesis_net_profit_plus_effective_cost_equals_dollar(
    up_ask: Decimal,
    down_ask: Decimal,
    qty: Decimal,
) -> None:
    """net_profit + effective_pair_cost_taker ≈ $1 (within rounding quantum)."""
    assume(up_ask + down_ask < Decimal("0.98"))  # ensure within budget
    up = make_book(UP_TOKEN, asks=[(str(up_ask), str(qty + 5))])
    down = make_book(DOWN_TOKEN, asks=[(str(down_ask), str(qty + 5))])
    result = evaluate_pair_cost(
        up, down,
        target_quantity=Shares(qty),
        inventory=make_inventory(),
        parameters=make_params(
            taker_fee_bps="0",
            slippage_reserve="0",
            merge_gas_overhead="0",
            safety_reserve="0",
        ),
        seconds_to_close=120,
        up_is_fresh=True,
        down_is_fresh=True,
    )
    total = result.net_profit.value + result.effective_pair_cost_taker.value
    # Due to floor rounding on profit and ceiling on cost, total ≈ 1.
    # The rounding gap is bounded by 2 * quantum = 2e-6.
    assert abs(total - Decimal(1)) <= Decimal("0.000002")


@given(
    up_ask=_price_st(),
    down_ask=_price_st(),
    qty=_qty_st(),
)
@hyp_settings(max_examples=150)
def test_hypothesis_sensitivity_monotone_decreasing(
    up_ask: Decimal,
    down_ask: Decimal,
    qty: Decimal,
) -> None:
    """tick_sensitivity profit is strictly decreasing as ticks increase."""
    assume(up_ask + down_ask < Decimal("0.95"))
    up = make_book(UP_TOKEN, asks=[(str(up_ask), str(qty + 5))])
    down = make_book(DOWN_TOKEN, asks=[(str(down_ask), str(qty + 5))])
    result = evaluate_pair_cost(
        up, down,
        target_quantity=Shares(qty),
        inventory=make_inventory(),
        parameters=make_params(
            taker_fee_bps="0",
            slippage_reserve="0",
            merge_gas_overhead="0",
            safety_reserve="0",
        ),
        seconds_to_close=120,
        up_is_fresh=True,
        down_is_fresh=True,
    )
    profits = [s.adjusted_net_profit.value for s in result.tick_sensitivity]
    assert profits[0] > profits[1] > profits[2]


@given(
    up_ask=_price_st(),
    down_ask=_price_st(),
    qty=_qty_st(),
)
@hyp_settings(max_examples=150)
def test_hypothesis_depth_sufficient_iff_vwap_complete(
    up_ask: Decimal,
    down_ask: Decimal,
    qty: Decimal,
) -> None:
    """depth.is_sufficient iff vwap.is_complete when book has one level."""
    up = make_book(UP_TOKEN, asks=[(str(up_ask), str(qty + 1))])
    down = make_book(DOWN_TOKEN, asks=[(str(down_ask), str(qty + 1))])
    result = evaluate_pair_cost(
        up, down,
        target_quantity=Shares(qty),
        inventory=make_inventory(),
        parameters=make_params(min_book_depth=str(qty)),
        seconds_to_close=120,
        up_is_fresh=True,
        down_is_fresh=True,
    )
    # With depth = qty + 1 >= qty → sufficient AND complete
    assert result.up_depth.is_sufficient is True
    assert result.up_vwap.is_complete is True


@given(
    up_ask=_price_st(),
    down_ask=_price_st(),
)
@hyp_settings(max_examples=100)
def test_hypothesis_immediate_two_leg_implies_within_budget(
    up_ask: Decimal,
    down_ask: Decimal,
) -> None:
    """IMMEDIATE_TWO_LEG always implies effective_pair_cost <= max_cost."""
    assume(up_ask + down_ask < Decimal("0.97"))  # reasonable budget
    up = make_book(UP_TOKEN, asks=[(str(up_ask), "50")])
    down = make_book(DOWN_TOKEN, asks=[(str(down_ask), "50")])
    result = evaluate_pair_cost(
        up, down,
        target_quantity=Shares(Decimal(5)),
        inventory=make_inventory(),
        parameters=make_params(
            taker_fee_bps="0",
            slippage_reserve="0",
            merge_gas_overhead="0",
            safety_reserve="0",
        ),
        seconds_to_close=120,
        up_is_fresh=True,
        down_is_fresh=True,
    )
    if result.result is PairOpportunityResult.IMMEDIATE_TWO_LEG:
        max_cost = result.parameters.max_effective_pair_cost.value
        assert result.effective_pair_cost_taker.value <= max_cost


# ===========================================================================
# 14. Full round-trip integration scenarios
# ===========================================================================


class TestFullRoundTrip:
    def test_deep_balanced_books_immediate_two_leg(self) -> None:
        """Classic scenario: balanced books comfortably within budget."""
        up = deep_book(UP_TOKEN, best_ask="0.50", levels=10, size_per_level="50")
        down = deep_book(DOWN_TOKEN, best_ask="0.47", levels=10, size_per_level="50")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(20)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="50",
                slippage_reserve="0.001",
                merge_gas_overhead="0.005",
                safety_reserve="0.003",
                max_effective_pair_cost="0.99",
                min_book_depth="20",
            ),
            seconds_to_close=300,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # 0.50 + 0.47 = 0.97 + ~0.05% fee + overhead ~= still likely within 0.99
        # (20 * 0.50 + 20 * 0.47) * 1.005 + 0.009 = (10+9.4)*1.005+0.009 = 19.4*1.005+0.009
        # Per pair: (0.50+0.47)*1.005+0.009 = 0.97*1.005+0.009 = 0.97485+0.009 = 0.98385
        assert result.result is PairOpportunityResult.IMMEDIATE_TWO_LEG
        assert result.is_actionable
        assert not result.is_rejected
        assert result.max_executable_quantity.value == Decimal(20)
        assert result.up_vwap.is_complete is True
        assert result.down_vwap.is_complete is True

    def test_skewed_book_multi_level_vwap(self) -> None:
        """UP book has uneven liquidity across 3 price levels."""
        up = make_book(
            UP_TOKEN,
            bids=[("0.49", "10"), ("0.48", "10")],
            asks=[("0.50", "5"), ("0.51", "5"), ("0.52", "10")],
        )
        down = deep_book(DOWN_TOKEN, best_ask="0.46", size_per_level="20")
        # 5@0.50 + 5@0.51 + 10@0.52 = qty=20
        # notional = 2.50 + 2.55 + 5.20 = 10.25; vwap = 10.25/20 = 0.5125
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(20)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_vwap.average_price is not None
        assert result.up_vwap.average_price.value == Decimal("0.5125")
        assert result.up_depth.levels_consumed == 3

    def test_result_is_immutable_frozen(self) -> None:
        """PairCostResult must be frozen (immutable)."""
        up = deep_book(UP_TOKEN)
        down = deep_book(DOWN_TOKEN)
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        with pytest.raises((AttributeError, TypeError)):
            result.result = PairOpportunityResult.OBSERVATION_ONLY  # type: ignore[misc]

    def test_from_strategy_settings_factory(self) -> None:
        """EngineParameters.from_strategy_settings produces correct values."""
        from polymarket_pair_bot.config.models import PairStrategySettings

        settings = PairStrategySettings(
            max_effective_pair_cost_usd=Decimal("0.98"),
            safety_reserve_usd=Decimal("0.005"),
            assumed_taker_fee_bps=Decimal("100"),
            assumed_slippage_bps=Decimal("20"),
            merge_gas_overhead_usd=Decimal("0.008"),
        )
        params = EngineParameters.from_strategy_settings(
            settings,
            tick_size=TickSize(Decimal("0.01")),
            min_seconds_to_close=45,
        )
        assert params.max_effective_pair_cost.value == Decimal("0.98")
        assert params.safety_reserve.value == Decimal("0.005")
        assert params.fee_parameters.taker_fee_bps.value == Decimal("100")
        assert params.merge_gas_overhead.value == Decimal("0.008")
        assert params.min_seconds_to_close == 45
        # slippage_bps=20 → 20 * 0.0001 = 0.002 (per $1 par)
        assert params.slippage_reserve.value == Decimal("0.002")

    def test_zero_inventory_observation_when_above_budget(self) -> None:
        """With no inventory and cost above budget → OBSERVATION_ONLY."""
        up = deep_book(UP_TOKEN, best_ask="0.60")
        down = deep_book(DOWN_TOKEN, best_ask="0.60")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(5)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
            ),
            seconds_to_close=120,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.result is PairOpportunityResult.OBSERVATION_ONLY
        assert result.net_profit.value == Decimal("-0.200000")
        assert result.gross_profit.value == Decimal("-0.200000")

    def test_all_fields_populated_in_valid_result(self) -> None:
        """Every non-optional field is populated in a valid evaluation."""
        up = make_book(
            UP_TOKEN,
            bids=[("0.49", "20")],
            asks=[("0.50", "20")],
        )
        down = make_book(
            DOWN_TOKEN,
            bids=[("0.47", "20")],
            asks=[("0.48", "20")],
        )
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(10)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="50",
                slippage_reserve="0.001",
                merge_gas_overhead="0.004",
                safety_reserve="0.003",
            ),
            seconds_to_close=180,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        # VWAPs
        assert result.up_vwap.average_price is not None
        assert result.down_vwap.average_price is not None
        # Costs
        assert result.up_taker_cost.value > 0
        assert result.down_taker_cost.value > 0
        # Maker costs
        assert result.up_maker_cost is not None
        assert result.down_maker_cost is not None
        # Fees
        assert result.taker_fee_up.value >= 0
        assert result.taker_fee_down.value >= 0
        # Effective
        assert result.effective_pair_cost_taker.value > 0
        assert result.effective_pair_cost_maker is not None
        # Max prices
        assert result.max_first_leg_price is not None
        assert result.max_second_leg_price is not None
        # Sensitivity
        assert len(result.tick_sensitivity) == 3
        # Depth
        assert result.up_depth.is_sufficient
        assert result.down_depth.is_sufficient
        # Freshness
        assert result.up_is_fresh
        assert result.down_is_fresh
        # Classification
        assert result.result is not None

    def test_large_quantity_across_many_levels(self) -> None:
        """Deep book with 10 levels, large quantity walks all levels."""
        # Build a book: 10 levels, 100 each, ask from 0.50 to 0.59
        asks = [(str(Decimal("0.50") + i * Decimal("0.01")), "100")
                for i in range(10)]
        bids = [(str(Decimal("0.49") - i * Decimal("0.01")), "100")
                for i in range(10)]
        up = make_book(UP_TOKEN, bids=bids, asks=asks)
        down = deep_book(DOWN_TOKEN, best_ask="0.39", levels=20, size_per_level="100")
        result = evaluate_pair_cost(
            up, down,
            target_quantity=Shares(Decimal(500)),
            inventory=make_inventory(),
            parameters=make_params(
                taker_fee_bps="0",
                slippage_reserve="0",
                merge_gas_overhead="0",
                safety_reserve="0",
                min_book_depth="500",
                max_effective_pair_cost="0.99",
            ),
            seconds_to_close=300,
            up_is_fresh=True,
            down_is_fresh=True,
        )
        assert result.up_vwap.is_complete is True
        assert result.up_vwap.filled.value == Decimal(500)
        # VWAP across 10 levels: (50*0.50 + 50*0.51 + ... + 50*0.59)*10 / 500
        # = (0.50+0.51+0.52+0.53+0.54+0.55+0.56+0.57+0.58+0.59)/10 = 5.45/10 = 0.545
        # Actually 100 each: notional = 100*(0.50+0.51+...+0.59)=100*5.45=545, qty=1000 … wait
        # qty=500, 10 levels * 100 = 1000 available; takes first 5 levels at 100 each
        # Notional: 100*0.50 + 100*0.51 + 100*0.52 + 100*0.53 + 100*0.54
        # = 50 + 51 + 52 + 53 + 54 = 260; vwap = 260/500 = 0.52
        assert result.up_vwap.average_price is not None
        assert result.up_vwap.average_price.value == Decimal("0.52")
