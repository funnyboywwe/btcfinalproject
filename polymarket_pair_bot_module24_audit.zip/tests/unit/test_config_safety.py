"""Unit tests for configuration safety invariants and mode gating.

These exercise the cross-cutting rules: paper/live exclusivity, live-mode auth
requirements, and that recorder/paper modes run without wallet credentials.
Requires pydantic-settings (run via `uv run pytest`).
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from polymarket_pair_bot.config.enums import RunMode
from polymarket_pair_bot.config.settings import load_config

_AUTH_ENV = {
    "POLYMARKET_API_KEY": "key-placeholder",
    "POLYMARKET_API_SECRET": "secret-placeholder",
    "POLYMARKET_API_PASSPHRASE": "pass-placeholder",
    "POLYMARKET_PRIVATE_KEY": "0x" + "a" * 64,
    "POLYMARKET_FUNDER_ADDRESS": "0x" + "b" * 40,
    "POLYGON_RPC_PRIMARY": "https://polygon-rpc.example/primary",
    "POLYGON_RPC_SECONDARY": "https://polygon-rpc.example/secondary",
}


def test_defaults_are_paper_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in (*_AUTH_ENV, "PAPER_TRADING", "LIVE_TRADING"):
        monkeypatch.delenv(key, raising=False)
    config = load_config()
    assert config.application.live_trading is False
    assert config.application.paper_trading is True
    assert config.run_mode is RunMode.PAPER


def test_recorder_mode_needs_no_wallet(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in _AUTH_ENV:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("PAPER_TRADING", "false")
    monkeypatch.setenv("LIVE_TRADING", "false")
    config = load_config()
    assert config.run_mode is RunMode.RECORDER
    assert config.wallet.polymarket_private_key is None


def test_paper_and_live_both_true_rejected(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("PAPER_TRADING", "true")
    monkeypatch.setenv("LIVE_TRADING", "true")
    with pytest.raises(ValidationError):
        load_config()


def test_live_without_auth_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in _AUTH_ENV:
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("PAPER_TRADING", "false")
    monkeypatch.setenv("LIVE_TRADING", "true")
    with pytest.raises(ValidationError) as excinfo:
        load_config()
    message = str(excinfo.value)
    assert "POLYMARKET_PRIVATE_KEY" in message
    assert "POLYGON_RPC_SECONDARY" in message


def test_live_with_complete_auth_succeeds(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("PAPER_TRADING", "false")
    monkeypatch.setenv("LIVE_TRADING", "true")
    for key, value in _AUTH_ENV.items():
        monkeypatch.setenv(key, value)
    config = load_config()
    assert config.run_mode is RunMode.LIVE
    # Secret material is wrapped, not exposed.
    assert config.wallet.polymarket_private_key is not None
    assert "a" * 64 not in repr(config.wallet)
