"""Unit tests for RiskLimits construction and RiskContext invariants."""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.domain.value_objects import Shares, UnixTimestamp
from polymarket_pair_bot.risk.context import OperationKind, RiskContext
from tests.fixtures.risk import approving_context, make_limits


def test_make_limits_is_frozen() -> None:
    limits = make_limits()
    with pytest.raises(Exception):  # noqa: B017 - frozen dataclass raises FrozenInstanceError
        limits.max_open_orders = 99  # type: ignore[misc]


def test_limits_carry_expected_values() -> None:
    limits = make_limits()
    assert limits.max_order_quantity.value == Decimal("50")
    assert limits.max_open_orders == 10
    assert limits.require_execution_leader is True


def test_context_rejects_empty_operation_id() -> None:
    with pytest.raises(ValueError):
        RiskContext(
            operation_id="",
            kind=OperationKind.ORDER_INTENT,
            now=UnixTimestamp(1),
        )


def test_with_kill_switch_returns_new_instance() -> None:
    context = approving_context()
    updated = context.with_kill_switch(active=True, reason="halt")
    assert context.kill_switch_active is False
    assert updated.kill_switch_active is True
    assert updated.kill_switch_reason == "halt"
    # unrelated fields are preserved
    assert updated.order_quantity == context.order_quantity


def test_defaults_are_conservative() -> None:
    context = RiskContext(
        operation_id="op",
        kind=OperationKind.ORDER_INTENT,
        now=UnixTimestamp(1),
    )
    assert context.kill_switch_active is False
    assert context.is_execution_leader is None
    assert context.order_quantity is None
    assert context.opening_first_leg is False
    assert isinstance(context.now, UnixTimestamp)
    assert Shares(Decimal(0)).value == Decimal(0)
