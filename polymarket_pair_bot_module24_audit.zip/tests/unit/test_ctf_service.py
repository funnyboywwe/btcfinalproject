"""Unit tests for CtfOperationService orchestration (mocked RPC + tx).

Every test uses in-memory fakes -- no web3, no signing, no network, no real
order or transaction. Covers: read-only mergeable-quantity, chain-id verify,
validation, risk gating, idempotency, duplicate prevention, merge cap, simulate
before sign, persist-pending-before-broadcast, persist-tx-hash, receipt
monitoring (success / revert / timeout), kill switch and write-gate blocking,
and the optional gasless path.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from polymarket_pair_bot.blockchain.models import TransactionStatus
from polymarket_pair_bot.ctf.errors import (
    CtfConfigurationError,
    CtfDuplicateOperationError,
    CtfKillSwitchError,
    CtfRiskRejectedError,
    CtfSimulationError,
    CtfValidationError,
    CtfWritesDisabledError,
)
from polymarket_pair_bot.ctf.models import CtfOperationRequest
from polymarket_pair_bot.ctf.service import CtfOperationService
from polymarket_pair_bot.domain.enums import CtfOperationStatus, CtfOperationType
from polymarket_pair_bot.domain.value_objects import Shares
from tests.fixtures.ctf import (
    CONDITION_ID,
    DOWN_TOKEN,
    UP_TOKEN,
    FakeChainStateReader,
    FakeCtfChainWriter,
    FakeCtfTransactionPreparer,
    FakeCtfUnitOfWorkFactory,
    FakeGaslessRelayer,
    FakeKillSwitch,
    make_contracts,
    make_mapping,
    make_risk_decision,
)


def _clock() -> int:
    return 1_700_000_000


def _service(
    *,
    reader: FakeChainStateReader,
    uow: FakeCtfUnitOfWorkFactory | None,
    enable_writes: bool = True,
    kill_switch: FakeKillSwitch | None = None,
    use_gasless: bool = False,
    gasless: FakeGaslessRelayer | None = None,
    writer: FakeCtfChainWriter | None = None,
) -> CtfOperationService:
    return CtfOperationService(
        reader=reader,
        preparer=FakeCtfTransactionPreparer(),
        writer=writer or FakeCtfChainWriter(),
        contracts=make_contracts(),
        mapping=make_mapping(),
        gasless=gasless or FakeGaslessRelayer(),
        uow_factory=uow,
        kill_switch=kill_switch,
        enable_writes=enable_writes,
        use_gasless=use_gasless,
        clock=_clock,
    )


def _merge_request(operation_id: str = "op-1", qty: str = "5") -> CtfOperationRequest:
    return CtfOperationRequest(
        operation_id=operation_id,
        operation_type=CtfOperationType.MERGE,
        condition_id=CONDITION_ID,
        up_token_id=UP_TOKEN,
        down_token_id=DOWN_TOKEN,
        quantity=Shares(Decimal(qty)),
    )


@pytest.mark.asyncio
async def test_mergeable_quantity_is_min_confirmed() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "4", DOWN_TOKEN: "7"})
    service = _service(reader=reader, uow=None, enable_writes=False)
    result = await service.mergeable_quantity(
        condition_id=CONDITION_ID, up_token_id=UP_TOKEN, down_token_id=DOWN_TOKEN
    )
    assert result.up_confirmed.value == Decimal("4")
    assert result.down_confirmed.value == Decimal("7")
    assert result.mergeable.value == Decimal("4")
    assert "verify_chain_id" in reader.calls


@pytest.mark.asyncio
async def test_execute_writes_disabled_blocks() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "5", DOWN_TOKEN: "5"})
    service = _service(reader=reader, uow=FakeCtfUnitOfWorkFactory(), enable_writes=False)
    with pytest.raises(CtfWritesDisabledError):
        await service.execute(_merge_request(), make_risk_decision("op-1"))


@pytest.mark.asyncio
async def test_execute_kill_switch_blocks() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "5", DOWN_TOKEN: "5"})
    service = _service(
        reader=reader,
        uow=FakeCtfUnitOfWorkFactory(),
        kill_switch=FakeKillSwitch(active=True),
    )
    with pytest.raises(CtfKillSwitchError):
        await service.execute(_merge_request(), make_risk_decision("op-1"))


@pytest.mark.asyncio
async def test_execute_requires_uow() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "5", DOWN_TOKEN: "5"})
    service = _service(reader=reader, uow=None, enable_writes=True)
    with pytest.raises(CtfConfigurationError):
        await service.execute(_merge_request(), make_risk_decision("op-1"))


@pytest.mark.asyncio
async def test_execute_rejects_unapproved_risk() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "5", DOWN_TOKEN: "5"})
    service = _service(reader=reader, uow=FakeCtfUnitOfWorkFactory())
    with pytest.raises(CtfRiskRejectedError):
        await service.execute(
            _merge_request(), make_risk_decision("op-1", approve=False)
        )


@pytest.mark.asyncio
async def test_execute_simulation_failure_before_persist() -> None:
    reader = FakeChainStateReader(
        balances={UP_TOKEN: "5", DOWN_TOKEN: "5"},
        simulate_ok=False,
        revert_reason="would revert",
    )
    uow = FakeCtfUnitOfWorkFactory()
    service = _service(reader=reader, uow=uow)
    with pytest.raises(CtfSimulationError):
        await service.execute(_merge_request(), make_risk_decision("op-1"))
    # Nothing persisted because simulation failed before persisting pending.
    assert uow.recorded.tx_rows == {}
    assert uow.recorded.operations == {}


@pytest.mark.asyncio
async def test_execute_happy_path_merge() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "5", DOWN_TOKEN: "5"})
    uow = FakeCtfUnitOfWorkFactory()
    writer = FakeCtfChainWriter()
    service = _service(reader=reader, uow=uow, writer=writer)
    result = await service.execute(_merge_request(), make_risk_decision("op-1"))
    assert result.status == CtfOperationStatus.CONFIRMED.value
    assert result.tx_hash is not None
    assert result.effective_quantity.value == Decimal("5")
    # pending row keyed by operation id + hash row keyed by tx hash.
    assert "op-1" in uow.recorded.tx_rows
    assert result.tx_hash in uow.recorded.tx_rows
    # simulate happened before broadcast.
    assert reader.calls.index("simulate") < reader.calls.index("wait_for_receipt")
    assert writer.calls and writer.calls[0]["nonce"] == 7
    # before + after balances reconciled.
    assert result.before is not None and result.after is not None


@pytest.mark.asyncio
async def test_execute_merge_capped_to_min_confirmed() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "3", DOWN_TOKEN: "9"})
    uow = FakeCtfUnitOfWorkFactory()
    service = _service(reader=reader, uow=uow)
    result = await service.execute(_merge_request(qty="8"), make_risk_decision("op-1"))
    assert result.effective_quantity.value == Decimal("3")
    assert any("capped" in n for n in result.notes)


@pytest.mark.asyncio
async def test_execute_merge_zero_confirmed_raises() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "0", DOWN_TOKEN: "9"})
    uow = FakeCtfUnitOfWorkFactory()
    service = _service(reader=reader, uow=uow)
    with pytest.raises(CtfValidationError):
        await service.execute(_merge_request(), make_risk_decision("op-1"))


@pytest.mark.asyncio
async def test_execute_duplicate_prevented() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "5", DOWN_TOKEN: "5"})
    uow = FakeCtfUnitOfWorkFactory()
    service = _service(reader=reader, uow=uow)
    await service.execute(_merge_request(), make_risk_decision("op-1"))
    # Second attempt with same idempotency key must be rejected.
    with pytest.raises(CtfDuplicateOperationError):
        await service.execute(_merge_request(), make_risk_decision("op-1"))


@pytest.mark.asyncio
async def test_execute_reverted_receipt_marks_failed() -> None:
    reader = FakeChainStateReader(
        balances={UP_TOKEN: "5", DOWN_TOKEN: "5"},
        receipt_status=TransactionStatus.REVERTED,
    )
    uow = FakeCtfUnitOfWorkFactory()
    service = _service(reader=reader, uow=uow)
    result = await service.execute(_merge_request(), make_risk_decision("op-1"))
    assert result.status == CtfOperationStatus.FAILED.value


@pytest.mark.asyncio
async def test_execute_receipt_timeout_marks_unknown() -> None:
    reader = FakeChainStateReader(
        balances={UP_TOKEN: "5", DOWN_TOKEN: "5"},
        raise_receipt_timeout=True,
    )
    uow = FakeCtfUnitOfWorkFactory()
    service = _service(reader=reader, uow=uow)
    result = await service.execute(_merge_request(), make_risk_decision("op-1"))
    assert result.status == CtfOperationStatus.UNKNOWN.value
    assert any("reconcile" in n for n in result.notes)
    # tx hash still persisted immediately, even though the receipt is unknown.
    assert result.tx_hash in uow.recorded.tx_rows


@pytest.mark.asyncio
async def test_execute_split_happy_path() -> None:
    reader = FakeChainStateReader(collateral="50")
    uow = FakeCtfUnitOfWorkFactory()
    service = _service(reader=reader, uow=uow)
    request = CtfOperationRequest(
        operation_id="op-split",
        operation_type=CtfOperationType.SPLIT,
        condition_id=CONDITION_ID,
        up_token_id=UP_TOKEN,
        down_token_id=DOWN_TOKEN,
        quantity=Shares(Decimal("5")),
    )
    result = await service.execute(request, make_risk_decision("op-split"))
    assert result.status == CtfOperationStatus.CONFIRMED.value
    assert result.effective_quantity.value == Decimal("5")


@pytest.mark.asyncio
async def test_execute_gasless_unavailable_fails_closed() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "5", DOWN_TOKEN: "5"})
    uow = FakeCtfUnitOfWorkFactory()
    service = _service(
        reader=reader,
        uow=uow,
        use_gasless=True,
        gasless=FakeGaslessRelayer(available=False),
    )
    with pytest.raises(CtfConfigurationError):
        await service.execute(_merge_request(), make_risk_decision("op-1"))


@pytest.mark.asyncio
async def test_execute_gasless_available_uses_relayer() -> None:
    reader = FakeChainStateReader(balances={UP_TOKEN: "5", DOWN_TOKEN: "5"})
    uow = FakeCtfUnitOfWorkFactory()
    relayer = FakeGaslessRelayer(available=True)
    writer = FakeCtfChainWriter()
    service = _service(
        reader=reader, uow=uow, use_gasless=True, gasless=relayer, writer=writer
    )
    result = await service.execute(_merge_request(), make_risk_decision("op-1"))
    assert result.status == CtfOperationStatus.CONFIRMED.value
    assert relayer.calls == ["op-1"]
    assert writer.calls == []  # self-funded writer not used when gasless
