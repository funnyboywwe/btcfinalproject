"""Unit tests for the Module 20 event-loop lag monitor."""

from __future__ import annotations

import asyncio

import pytest

from polymarket_pair_bot.observability.event_loop import EventLoopLagMonitor


class _RecordingSink:
    def __init__(self) -> None:
        self.samples: list[float] = []

    def set_event_loop_lag(self, seconds: float) -> None:
        self.samples.append(seconds)


async def test_monitor_publishes_non_negative_lag_samples() -> None:
    sink = _RecordingSink()
    monitor = EventLoopLagMonitor(metrics=sink, poll_interval_seconds=0.01)
    await monitor.start()
    await asyncio.sleep(0.05)
    await monitor.stop()
    assert sink.samples, "expected at least one lag sample"
    assert all(sample >= 0.0 for sample in sink.samples)


async def test_stop_is_safe_when_never_started() -> None:
    monitor = EventLoopLagMonitor(metrics=_RecordingSink())
    await monitor.stop()  # must not raise


async def test_start_is_idempotent() -> None:
    sink = _RecordingSink()
    monitor = EventLoopLagMonitor(metrics=sink, poll_interval_seconds=0.01)
    await monitor.start()
    await monitor.start()  # second call is a no-op
    await monitor.stop()


def test_rejects_non_positive_interval() -> None:
    with pytest.raises(ValueError, match="poll_interval_seconds"):
        EventLoopLagMonitor(metrics=_RecordingSink(), poll_interval_seconds=0)


async def test_metric_failure_does_not_crash_loop() -> None:
    class _BoomSink:
        def __init__(self) -> None:
            self.calls = 0

        def set_event_loop_lag(self, seconds: float) -> None:
            self.calls += 1
            raise RuntimeError("metric backend down")

    sink = _BoomSink()
    monitor = EventLoopLagMonitor(metrics=sink, poll_interval_seconds=0.01)
    await monitor.start()
    await asyncio.sleep(0.05)
    await monitor.stop()
    # The loop kept sampling despite the sink raising each time.
    assert sink.calls >= 1
