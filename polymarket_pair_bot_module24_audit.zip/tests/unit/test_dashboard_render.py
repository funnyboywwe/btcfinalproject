"""Unit tests for the operator-dashboard HTML renderer (Module 21).

The headline requirement is #6: every displayed external value must be escaped.
These tests inject HTML-hostile strings into external fields and assert the raw
markup never appears in the output, only its escaped form. They also cover the
empty-skeleton banner, freshness/kill-switch badges, and read-only guarantees
(no <form>/<button>). None of this needs FastAPI or the config stack.
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal

from polymarket_pair_bot.dashboard.models import (
    BooksView,
    ConnectivityView,
    DashboardSnapshot,
    FillView,
    FreshnessView,
    InventoryView,
    KillSwitchView,
    MarketView,
    MergeView,
    OpenOrderView,
    OpportunityView,
    PairCostView,
    PnlView,
    ReconciliationView,
    RiskView,
    TopOfBookView,
)
from polymarket_pair_bot.dashboard.render import render_dashboard_html
from polymarket_pair_bot.domain.enums import (
    CtfOperationStatus,
    OrderSide,
    OrderStatus,
    OutcomeSide,
    ReconciliationStatus,
    RiskVerdict,
)

_XSS = "<script>alert('x')</script>"


def _hostile_snapshot() -> DashboardSnapshot:
    now = datetime(2026, 7, 18, 12, 0, tzinfo=UTC)
    return DashboardSnapshot(
        generated_at=now,
        run_mode="PAPER",
        data_available=True,
        market=MarketView(
            slug=_XSS,
            question=f"Will BTC be up? {_XSS}",
            condition_id="0xcond",
            up_token_id="up-1",
            down_token_id="down-1",
            opens_at=now,
            closes_at=now,
            time_remaining_seconds=42.5,
        ),
        books=BooksView(
            up=TopOfBookView(
                outcome=OutcomeSide.UP,
                best_bid=Decimal("0.51"),
                best_bid_size=Decimal("100"),
                best_ask=Decimal("0.53"),
                best_ask_size=Decimal("120"),
                bid_depth=Decimal("500"),
                ask_depth=Decimal("480"),
                depth_levels=5,
            ),
            down=TopOfBookView(
                outcome=OutcomeSide.DOWN,
                best_bid=Decimal("0.46"),
                best_ask=Decimal("0.48"),
            ),
        ),
        freshness=FreshnessView(
            market_ws_age_seconds=0.5,
            up_book_age_seconds=0.4,
            down_book_age_seconds=0.6,
            stale_threshold_seconds=2.0,
            is_stale=False,
        ),
        pair_cost=PairCostView(
            up_acquisition_cost=Decimal("0.51"),
            down_acquisition_cost=Decimal("0.46"),
            taker_fees=Decimal("0.01"),
            expected_slippage=Decimal("0.005"),
            merge_or_gas_overhead=Decimal("0.002"),
            safety_reserve=Decimal("0.003"),
            effective_pair_cost=Decimal("0.99"),
            threshold=Decimal("1"),
        ),
        opportunity=OpportunityView(
            decision="hold",
            cost_margin=Decimal("0.01"),
            reason=f"waiting {_XSS}",
            evaluated_at=now,
        ),
        inventory=InventoryView(
            up_quantity=Decimal("10"),
            down_quantity=Decimal("8"),
            matched_quantity=Decimal("8"),
            unmatched_up_quantity=Decimal("2"),
            unmatched_down_quantity=Decimal("0"),
            oldest_unmatched_age_seconds=12.0,
        ),
        open_orders=(
            OpenOrderView(
                order_id=f"ord-{_XSS}",
                outcome=OutcomeSide.UP,
                side=OrderSide.BUY,
                status=OrderStatus.OPEN,
                price=Decimal("0.51"),
                quantity=Decimal("5"),
                filled_quantity=Decimal("0"),
                created_at=now,
            ),
        ),
        recent_fills=(
            FillView(
                fill_id=f"fill-{_XSS}",
                order_id="ord-1",
                outcome=OutcomeSide.DOWN,
                price=Decimal("0.46"),
                quantity=Decimal("8"),
                fee=Decimal("0.01"),
                liquidity="taker",
                filled_at=now,
            ),
        ),
        merges=(
            MergeView(
                operation_id="merge-1",
                status=CtfOperationStatus.CONFIRMED,
                pair_quantity=Decimal("8"),
                collateral_recovered=Decimal("8"),
                tx_hash=f"0x{_XSS}",
                updated_at=now,
            ),
        ),
        risk=RiskView(
            verdict=RiskVerdict.APPROVE,
            blocked=False,
            reasons=(f"note {_XSS}",),
            daily_loss_limit=Decimal("50"),
            rejections_today=1,
        ),
        kill_switch=KillSwitchView(
            active=False,
            reason=None,
            actor=f"op {_XSS}",
            since=now,
        ),
        reconciliation=ReconciliationView(
            status=ReconciliationStatus.CONSISTENT,
            last_run_at=now,
            differences=0,
            unknown_orders=0,
            detail=f"ok {_XSS}",
        ),
        pnl=PnlView(
            day="2026-07-18",
            realized_gross=Decimal("1.23"),
            fees=Decimal("0.10"),
            slippage=Decimal("0.05"),
            realized_net=Decimal("1.08"),
            as_of=now,
        ),
        connectivity=ConnectivityView(
            api_healthy=True,
            api_detail=f"200 {_XSS}",
            rpc_primary_healthy=True,
            rpc_secondary_healthy=True,
            rpc_in_agreement=True,
            rpc_detail="agree",
        ),
    )


def test_render_escapes_all_hostile_external_strings() -> None:
    html = render_dashboard_html(_hostile_snapshot())
    # The raw injected markup must never appear anywhere in the output.
    assert _XSS not in html
    assert "<script>" not in html
    # ...but its escaped form must, proving the value was displayed safely.
    assert "&lt;script&gt;" in html


def test_render_is_read_only_no_controls() -> None:
    html = render_dashboard_html(_hostile_snapshot())
    lowered = html.lower()
    assert "<form" not in lowered
    assert "<button" not in lowered
    assert "<input" not in lowered


def test_render_shows_all_required_sections() -> None:
    html = render_dashboard_html(_hostile_snapshot())
    for title in (
        "Active BTC market",
        "Up top-of-book",
        "Down top-of-book",
        "Data freshness",
        "Pair-cost calculation",
        "Opportunity decision",
        "Inventory",
        "Open orders",
        "Recent fills",
        "Merge status",
        "Risk status",
        "Kill switch",
        "Reconciliation status",
        "Daily P&amp;L",
        "API &amp; RPC health",
    ):
        assert title in html


def test_render_freshness_and_kill_switch_badges() -> None:
    html = render_dashboard_html(_hostile_snapshot())
    assert "fresh" in html
    assert "inactive" in html


def test_render_empty_skeleton_shows_banner() -> None:
    snap = DashboardSnapshot(
        generated_at=datetime(2026, 7, 18, tzinfo=UTC),
        run_mode="PAPER",
        data_available=False,
        message="awaiting live data",
    )
    html = render_dashboard_html(snap, refresh_seconds=9)
    assert "awaiting live data" in html
    assert "content='9'" in html  # meta refresh honoured


def test_render_refresh_floor_is_one_second() -> None:
    snap = DashboardSnapshot(
        generated_at=datetime(2026, 7, 18, tzinfo=UTC),
        run_mode="PAPER",
    )
    html = render_dashboard_html(snap, refresh_seconds=0)
    assert "content='1'" in html
