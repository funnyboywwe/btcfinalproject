"""Dry-run interceptor tests: no real write endpoint is ever reached (Module 14)."""

from __future__ import annotations

from polymarket_pair_bot.domain.enums import OrderStatus
from polymarket_pair_bot.execution.dry_run import DryRunOrderClient
from polymarket_pair_bot.execution.live_ports import LiveOrderRequest
from polymarket_pair_bot.execution.types import CancelOutcome

from tests.fixtures.live_execution import FakeLiveOrderClient, fill_record
from tests.fixtures.execution import make_intent


def _request() -> LiveOrderRequest:
    intent = make_intent("i-1", price="0.40", size="100")
    return LiveOrderRequest(intent=intent, idempotency_key="submit:i-1", post_only=True)


async def test_place_order_is_intercepted_and_never_filled() -> None:
    inner = FakeLiveOrderClient()
    client = DryRunOrderClient(inner)
    placement = await client.place_order(_request())
    assert placement.status is OrderStatus.ACKNOWLEDGED
    assert placement.filled_size == 0
    assert placement.order_id == "dryrun-submit:i-1"
    # The wrapped (real/fake) client was never asked to place anything.
    assert inner.place_calls == []


async def test_cancel_is_intercepted() -> None:
    inner = FakeLiveOrderClient()
    client = DryRunOrderClient(inner)
    result = await client.cancel_order("dryrun-x")
    assert result.outcome is CancelOutcome.ACCEPTED
    assert inner.cancel_calls == []
    assert await client.cancel_market_orders("m") == ()
    assert await client.cancel_all_orders() == ()


async def test_reads_delegate_to_inner_when_present() -> None:
    inner = FakeLiveOrderClient()
    inner.fills_by_order["o-1"] = [fill_record("f-1", "o-1")]
    client = DryRunOrderClient(inner)
    fills = await client.get_fills(order_id="o-1")
    assert len(fills) == 1


async def test_reads_are_empty_without_inner() -> None:
    client = DryRunOrderClient()
    assert await client.get_open_orders() == ()
    assert await client.get_order("o-1") is None
    assert await client.get_fills(order_id="o-1") == ()
