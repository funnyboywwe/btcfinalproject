"""Unit tests for the pure snapshot sampler (Module 7)."""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.recording import SnapshotTrigger
from polymarket_pair_bot.recorder.sampler import SideObservation, SnapshotSampler


def _obs(
    *,
    best_bid: str | None = "0.40",
    best_ask: str | None = "0.60",
    spread: str | None = "0.20",
    is_live: bool = True,
) -> SideObservation:
    return SideObservation(
        best_bid=None if best_bid is None else Decimal(best_bid),
        best_ask=None if best_ask is None else Decimal(best_ask),
        spread=None if spread is None else Decimal(spread),
        is_live=is_live,
    )


def test_first_evaluation_always_records_periodic() -> None:
    sampler = SnapshotSampler(periodic_interval_seconds=1.0)
    decision = sampler.evaluate(
        up=_obs(), down=_obs(), pair_cost=Decimal("1.00"), now_monotonic=100.0
    )
    assert decision.should_record
    assert SnapshotTrigger.PERIODIC in decision.triggers


def test_periodic_only_fires_after_interval() -> None:
    sampler = SnapshotSampler(periodic_interval_seconds=1.0)
    sampler.evaluate(up=_obs(), down=_obs(), pair_cost=None, now_monotonic=100.0)
    # No change and interval not elapsed -> nothing.
    decision = sampler.evaluate(
        up=_obs(), down=_obs(), pair_cost=None, now_monotonic=100.5
    )
    assert not decision.should_record
    # Interval elapsed -> periodic fires again.
    decision = sampler.evaluate(
        up=_obs(), down=_obs(), pair_cost=None, now_monotonic=101.0
    )
    assert SnapshotTrigger.PERIODIC in decision.triggers


def test_best_bid_ask_and_spread_changes_are_detected() -> None:
    sampler = SnapshotSampler(periodic_interval_seconds=1000.0)
    sampler.evaluate(up=_obs(), down=_obs(), pair_cost=None, now_monotonic=0.0)
    decision = sampler.evaluate(
        up=_obs(best_bid="0.41", spread="0.19"),
        down=_obs(),
        pair_cost=None,
        now_monotonic=0.1,
    )
    assert SnapshotTrigger.BEST_BID_CHANGE in decision.triggers
    assert SnapshotTrigger.SPREAD_CHANGE in decision.triggers
    assert SnapshotTrigger.PERIODIC not in decision.triggers


def test_feed_stale_and_recover() -> None:
    sampler = SnapshotSampler(periodic_interval_seconds=1000.0)
    sampler.evaluate(up=_obs(), down=_obs(), pair_cost=None, now_monotonic=0.0)
    stale = sampler.evaluate(
        up=_obs(is_live=False), down=_obs(), pair_cost=None, now_monotonic=0.1
    )
    assert SnapshotTrigger.FEED_STALE in stale.triggers
    recover = sampler.evaluate(
        up=_obs(is_live=True), down=_obs(), pair_cost=None, now_monotonic=0.2
    )
    assert SnapshotTrigger.FEED_RECOVER in recover.triggers


def test_pair_cost_crossing_a_configured_level() -> None:
    sampler = SnapshotSampler(
        periodic_interval_seconds=1000.0,
        pair_cost_levels=(Decimal("0.99"),),
    )
    sampler.evaluate(
        up=_obs(), down=_obs(), pair_cost=Decimal("1.01"), now_monotonic=0.0
    )
    decision = sampler.evaluate(
        up=_obs(), down=_obs(), pair_cost=Decimal("0.98"), now_monotonic=0.1
    )
    assert SnapshotTrigger.PAIR_COST_CROSS in decision.triggers
    assert decision.crossed_level == Decimal("0.99")


def test_pair_cost_no_cross_when_no_level_between() -> None:
    sampler = SnapshotSampler(
        periodic_interval_seconds=1000.0,
        pair_cost_levels=(Decimal("0.99"),),
    )
    sampler.evaluate(
        up=_obs(), down=_obs(), pair_cost=Decimal("0.90"), now_monotonic=0.0
    )
    decision = sampler.evaluate(
        up=_obs(), down=_obs(), pair_cost=Decimal("0.92"), now_monotonic=0.1
    )
    assert SnapshotTrigger.PAIR_COST_CROSS not in decision.triggers
    assert decision.crossed_level is None
