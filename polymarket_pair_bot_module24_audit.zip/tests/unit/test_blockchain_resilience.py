"""Unit tests for bounded retries and the circuit breaker (Module 16)."""

from __future__ import annotations

import pytest

from polymarket_pair_bot.blockchain.errors import (
    ChainRpcUnavailableError,
    CircuitOpenError,
)
from polymarket_pair_bot.blockchain.resilience import (
    CircuitBreaker,
    CircuitState,
    RetryPolicy,
    guarded_read,
)
from tests.fixtures.blockchain import FakeClock, FakeSleep


def _breaker(clock: FakeClock, *, threshold: int = 3, reset: float = 30.0) -> CircuitBreaker:
    return CircuitBreaker(
        name="primary", fail_threshold=threshold, reset_seconds=reset, clock=clock
    )


def test_retry_policy_validation() -> None:
    with pytest.raises(ValueError):
        RetryPolicy(max_retries=-1)
    with pytest.raises(ValueError):
        RetryPolicy(backoff_base_seconds=0)
    with pytest.raises(ValueError):
        RetryPolicy(backoff_base_seconds=5, backoff_max_seconds=1)


def test_circuit_opens_after_threshold_and_half_opens() -> None:
    clock = FakeClock()
    breaker = _breaker(clock, threshold=2, reset=10.0)
    breaker.record_failure()
    assert breaker.state is CircuitState.CLOSED
    breaker.record_failure()
    assert breaker.state is CircuitState.OPEN
    with pytest.raises(CircuitOpenError):
        breaker.before_call()
    clock.advance(11.0)
    breaker.before_call()  # transitions to half-open, allows a trial
    assert breaker.state is CircuitState.HALF_OPEN
    breaker.record_success()
    assert breaker.state is CircuitState.CLOSED


async def test_guarded_read_retries_then_succeeds() -> None:
    clock = FakeClock()
    breaker = _breaker(clock)
    sleep = FakeSleep()
    calls = {"n": 0}

    async def flaky() -> int:
        calls["n"] += 1
        if calls["n"] < 3:
            raise OSError("boom")
        return 42

    result = await guarded_read(
        "op",
        flaky,
        breaker=breaker,
        policy=RetryPolicy(max_retries=3, backoff_base_seconds=0.1, backoff_max_seconds=1),
        transient=(OSError,),
        sleep=sleep,
        rng=lambda: 0.5,
    )
    assert result == 42
    assert calls["n"] == 3
    assert len(sleep.delays) == 2
    assert breaker.state is CircuitState.CLOSED


async def test_guarded_read_exhausts_and_raises() -> None:
    clock = FakeClock()
    breaker = _breaker(clock, threshold=10)
    sleep = FakeSleep()

    async def always_fail() -> int:
        raise OSError("down")

    with pytest.raises(ChainRpcUnavailableError):
        await guarded_read(
            "op",
            always_fail,
            breaker=breaker,
            policy=RetryPolicy(max_retries=2, backoff_base_seconds=0.1, backoff_max_seconds=1),
            transient=(OSError,),
            sleep=sleep,
            rng=lambda: 0.0,
        )


async def test_guarded_read_non_transient_propagates() -> None:
    clock = FakeClock()
    breaker = _breaker(clock)

    async def bad() -> int:
        raise ValueError("semantic")

    with pytest.raises(ValueError):
        await guarded_read(
            "op",
            bad,
            breaker=breaker,
            policy=RetryPolicy(),
            transient=(OSError,),
            sleep=FakeSleep(),
        )
