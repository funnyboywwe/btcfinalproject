"""Unit tests for the dashboard bearer-token authenticator (Module 21).

Covers disabled auth (private-binding-only), and enabled auth for the
missing/invalid/valid cases, plus header vs query-param extraction. The token is
never exposed by the API surface; these tests only exercise the boolean gate.
"""

from __future__ import annotations

from polymarket_pair_bot.dashboard.auth import DashboardAuthenticator


def test_disabled_auth_authorizes_everything() -> None:
    auth = DashboardAuthenticator(None)
    assert auth.enabled is False
    assert auth.authorize() is True
    assert auth.authorize(authorization="Bearer whatever") is True


def test_enabled_auth_rejects_missing_token() -> None:
    auth = DashboardAuthenticator("s3cr3t")
    assert auth.enabled is True
    assert auth.authorize() is False
    assert auth.authorize(authorization="") is False


def test_enabled_auth_rejects_invalid_token() -> None:
    auth = DashboardAuthenticator("s3cr3t")
    assert auth.authorize(authorization="Bearer nope") is False
    assert auth.authorize(query_token="nope") is False


def test_enabled_auth_accepts_valid_bearer_header() -> None:
    auth = DashboardAuthenticator("s3cr3t")
    assert auth.authorize(authorization="Bearer s3cr3t") is True
    # Case-insensitive scheme prefix.
    assert auth.authorize(authorization="bearer s3cr3t") is True


def test_enabled_auth_accepts_valid_query_token() -> None:
    auth = DashboardAuthenticator("s3cr3t")
    assert auth.authorize(query_token="s3cr3t") is True


def test_enabled_auth_accepts_raw_header_without_scheme() -> None:
    auth = DashboardAuthenticator("s3cr3t")
    assert auth.authorize(authorization="s3cr3t") is True


def test_empty_string_token_is_treated_as_disabled() -> None:
    auth = DashboardAuthenticator("")
    assert auth.enabled is False
    assert auth.authorize() is True
