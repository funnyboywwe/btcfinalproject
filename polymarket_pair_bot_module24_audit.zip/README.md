# polymarket_pair_bot

Production-oriented **Polymarket BTC 5-minute two-sided pair-accumulation bot**.

> **Module 24 — end-to-end verification and release gate.**
> Deterministic, offline **end-to-end crash and recovery tests** (`tests/e2e/`)
> that stitch the implemented modules together across all 23 required scenarios
> (discovery, snapshot/incremental updates, opportunity detection, passive
> first leg, partial fill, second-leg completion, inventory match, simulated
> merge, P&L accounting, crash before ack, crash after partial fill, reconnect,
> unknown status, PostgreSQL/Redis/RPC outages, RPC disagreement, duplicate
> fill, stale data, kill switch, market close while unmatched, graceful
> shutdown). Each asserts a safety invariant — most importantly that a
> submitted/acked/open/partially-filled order is **never** counted as a matched
> pair. It also adds a **`release-gate` command** that runs formatting, lint,
> type-check, unit/integration/replay/e2e tests, a report-only reconciliation,
> a dependency audit and an in-process secret scan, then prints paper
> statistics (descriptive only — **no profitability claim**), unresolved risks
> and a **human go-live checklist**. `live_ready` is reported only when every
> mandatory gate passes **and** every human checklist item is confirmed; the
> checklist defaults to unconfirmed, so an automated run alone can never report
> readiness. The gate is read-only and **never enables live trading or places
> an order**. Run `uv run polymarket-pair-bot release-gate [--json]`. See
> `docs/release-gate.md` and `docs/go-live-checklist.md`.
>
> **Module 15 — Polymarket authentication and read-only account access.**
> Read-only authenticated account access: open orders, order status,
> fills/trades, balances and (where reportable) allowances, plus the
> authenticated readiness state and a reconnecting, de-duplicating user-stream
> driver. It implements **no** order submission, cancellation or state change,
> and `LIVE_TRADING` stays disabled. Paper/dev uses a deterministic in-memory
> `StubAccountReader`; the **live CLOB adapter is a blocked adapter** — because
> the official CLOB package could not be installed/inspected in this
> environment, every live read raises a typed `UnsupportedAuthOperationError`
> naming the exact operation to wire once the package API is verified, rather
> than guessing method names. Both readers implement the same
> `AuthenticatedAccountReader` interface. Credentials are `SecretStr` and
> redacted; addresses and all documented signature types are validated; every
> external payload is validated by frozen `Decimal`-only Pydantic adapters; the
> user stream enforces freshness, fresh authoritative resync on reconnect,
> bounded retries, dedup and graceful shutdown. Read-only diagnostics via
> `python -m polymarket_pair_bot.auth.cli diagnose`. It makes **no
> profitability claim**. See `docs/authentication.md`.
>
> **Modules 13-14 — centralized risk engine and persistent kill switches.**
> A pure, **default-DENY** decision gate that every order intent, hedge and
> blockchain operation must pass. A verdict is `APPROVE` only when *every*
> configured limit passes; missing inputs, an unknown operation kind and any
> unreadable kill-switch source all **fail closed**. Every decision records a
> per-rule outcome (observed value + limit) and is persisted with an audit
> event. The kill switch is persistent and multi-level (process / environment /
> Redis / PostgreSQL), is active if **any** source is active or unreadable,
> survives restarts, blocks new orders immediately, and — by design — never
> blocks cancellation or reconciliation. Clearing requires an explicit operator
> reason, a recent consistent reconciliation and healthy feeds; critical
> reconciliation differences trip it automatically. Inspect/activate/clear via
> `python -m polymarket_pair_bot.risk.cli`. The core imports no SQLAlchemy,
> redis-py, HTTP or blockchain client. It makes **no profitability claim**. See
> `docs/risk-engine.md`.
>
> **Module 12 — inventory and matched-pair accounting.**
> A pure, deterministic accounting model of what the bot owns, derived
> *exclusively* from confirmed fills. Per market it tracks confirmed Up/Down
> quantity, acquisition cost, weighted-average cost, matched quantity, residual
> Up/Down, locked pair value, locked net profit, realized P&L, fees, authoritative
> rebates, pending-order reserves and marked residual value. It uses a documented
> **weighted-average-cost** lot method, is idempotent under duplicate fills,
> **never** represents negative inventory, keeps matched and unmatched positions
> strictly separate, and marks residual exposure conservatively at **executable
> bid** prices (never midpoint) for emergency-liquidation value. Every transition
> persists a new snapshot in the same transaction as its fill; inventory can be
> rebuilt entirely from the fill journal and compared against the stored snapshot,
> and `python -m polymarket_pair_bot.inventory.cli audit --market <id>` prints a
> complete, secret-free audit. Invariants are covered by unit and property-based
> tests. It makes **no profitability claim**. See `docs/inventory-accounting.md`.
>
> **Module 11 — realistic paper execution simulator.**
> A deterministic, offline `PaperExecutionAdapter` implements a common
> `ExecutionAdapter` protocol (submit / cancel / cancel-by-market / cancel-all /
> get-order / get-open-orders / get-fills) shared with the future live adapter.
> It models post-only rejection, maker queue position, partial fills, ack and
> cancellation latency, fill-before-cancel races, multi-level taker execution,
> FOK/FAK behavior, tick-size and minimum-size rejection, fees, slippage,
> stale-book rejection, WebSocket outage, missed fills during fast movement,
> duplicate-event de-duplication, unknown submission outcomes, and a
> configurable seeded latency distribution. A passive order is **never** filled
> just because the displayed price touched it — maker fills require real trade
> prints past the queue-ahead. All money is `Decimal`; runs are reproducible
> from a single seeded RNG; simulated intents/orders/fills persist through the
> existing repositories. No network, no real orders, **no profitability claim**.
> See `docs/paper-execution-adapter.md`.
>
> **Module 10 — pair-opportunity detector.**
> A pure, deterministic, side-effect-free detector turns a Module 8/9
> `PairCostResult` into fully described trade *candidates* or a documented
> no-trade decision across five actions (immediate dual-leg capture, passive
> first-leg accumulation, passive second-leg completion, existing matched
> inventory, no-trade). Each candidate reports market/window, side, proposed
> price/quantity, maker vs taker role, matched and unmatched inventory,
> all-in per-pair cost, expected net edge, required hedge depth, book age,
> time remaining, a cancel deadline capped at window close, and the complete
> engine rejection reasons. It **submits no orders** and can only mark a
> candidate approved when abstract risk-engine input is present and approves;
> the quantity is then clamped to the approved size. Detector observations are
> persisted through a separate asynchronous, bounded-queue `ObservationConsumer`
> (configurable overflow policy, best-effort on sink errors, graceful flush +
> close) behind an injected `ObservationSink` protocol — no persistence,
> network, or blockchain imports leak into the strategy layer. It makes **no
> profitability claim**. See `docs/pair-opportunity-detector.md`.
>
> **Modules 0–7 — scaffold, typed configuration, domain models, PostgreSQL
> persistence, Redis coordination, BTC five-minute market discovery, the
> public CLOB market-data WebSocket + local Up/Down order books, and the
> research-grade market-data recorder.**
> Module 7 adds a read-only recorder that captures one-second and event-driven
> Up/Down pair snapshots (best-bid/ask/spread changes, executable-pair-cost
> level crossings, feed stale/recover) with configurable depth, three
> timestamps, data-quality flags, and window/token identifiers. Bulk research
> data is written to compressed Parquet (`pyarrow`); compact queryable
> summaries go to PostgreSQL (`market_data_snapshots`, idempotent inserts). A
> bounded buffer with a configurable overflow policy + metric decouples writes
> so the recorder never blocks the WebSocket reader; files rotate by window or
> time interval and flush safely on shutdown. Commands: `record-market-data`,
> `market-data-export`, `market-data-validate`, `market-data-replay`. It reads
> market data only and never submits orders. See `docs/market-data-recorder.md`.
> Module 6 adds an asynchronous, read-only connection to Polymarket's
> documented public market WebSocket: every frame is Pydantic-validated,
> independent level-two books for Up and Down are maintained with `Decimal`
> price levels (zero-size levels removed), and faults are detected (stale,
> crossed, malformed, update-before-snapshot, negative size). The feed is
> marked unavailable immediately on disconnect and requires a fresh
> authoritative snapshot after every reconnect; a bounded queue separates
> socket reading from book processing so a slow consumer can never block
> reads. A read-only `OrderBookProvider` protocol lives in the domain, and a
> `market-data-monitor` command shows live Up/Down bid/ask, spread, depth and
> freshness. It reads market data only and never submits orders. See
> `docs/market-data.md`.
> Module 5 adds asynchronous discovery of the Polymarket BTC five-minute
> Up/Down market over the documented public Gamma metadata API: pure
> five-minute UTC window math, Pydantic validation with name-based Up/Down
> token mapping, rejection of contradictory/incomplete metadata, bounded
> retries with backoff+jitter and rate-limit handling, next-window preload,
> and validated-only persistence (Postgres) + caching (Redis). It performs
> only safe GETs and never submits orders. See `docs/market-discovery.md`.
> This repository contains the
> engineering foundation, fully typed configuration (grouped
> `pydantic-settings` models, secret protection, production startup gates), the
> `Decimal`-based domain model, an asynchronous PostgreSQL persistence layer
> (SQLAlchemy 2 async + asyncpg + Alembic), and Redis coordination (distributed
> execution-leader lease, persistent kill-switch cache, market-metadata cache,
> risk counters, idempotency keys, heartbeats) with ports in the domain and
> adapters in each infrastructure package. **There is no Polymarket networking
> or trading logic yet** (no order submission), and this project makes **no
> claim of profitability**.
>
> See `docs/configuration.md`, `docs/persistence.md` and
> `docs/coordination.md` for design details.

## Strategy context (informational only)

The eventual bot tries to acquire equal quantities of BTC 5-minute **Up** and
**Down** outcome tokens when the combined all-in acquisition cost is below `$1`:

```
effective_pair_cost = up_acquisition_cost
                    + down_acquisition_cost
                    + taker_fees
                    + expected_slippage
                    + merge_or_gas_overhead
                    + safety_reserve
```

A position is **locked only when equal quantities of Up and Down tokens are
confirmed filled**. A submitted, acknowledged, open, or partially filled order
is never treated as a matched pair. None of that logic exists in Module 0.

## Requirements

- Python **3.12+**
- [`uv`](https://docs.astral.sh/uv/) for dependency and project management
- Docker + Docker Compose (for local PostgreSQL 16 and Redis 7)

## Quick start

```bash
# 1. Install dependencies into a uv-managed virtual environment
uv sync

# 2. Create your local env file (placeholders only; no real secrets)
cp .env.example .env

# 3. Start local infrastructure (PostgreSQL 16 + Redis 7)
make infra-up            # or: docker compose -f docker/docker-compose.yml up -d

# 4. Run the application (starts, reports READY, waits for a signal)
uv run polymarket-pair-bot
#    Stop it with Ctrl-C (SIGINT) or SIGTERM -> graceful shutdown.

# 5. Stop local infrastructure when done
make infra-down
```

The application **starts without any secrets**. Trading is OFF
(`LIVE_TRADING=false`) and paper trading is ON (`PAPER_TRADING=true`) by
default.

## Developer commands

All commands are available via `make` (see `make help`) and map to `uv run`:

| Task              | Make target        | Underlying command                 |
| ----------------- | ------------------ | ---------------------------------- |
| Install deps      | `make sync`        | `uv sync`                          |
| Run               | `make run`         | `uv run polymarket-pair-bot`       |
| Test              | `make test`        | `uv run pytest`                    |
| Lint              | `make lint`        | `uv run ruff check .`              |
| Format            | `make format`      | `uv run ruff format .`             |
| Format check      | `make format-check`| `uv run ruff format --check .`     |
| Type check        | `make typecheck`   | `uv run mypy src`                  |
| All quality gates | `make check`       | format-check + lint + type + test  |
| Start infra       | `make infra-up`    | `docker compose ... up -d`         |
| Stop infra        | `make infra-down`  | `docker compose ... down`          |
| DB migrate        | `make db-migrate`  | `... persistence.cli migrate`      |
| DB health         | `make db-health`   | `... persistence.cli health`       |
| DB reset          | `make db-reset`    | `... persistence.cli reset`        |
| DB retention      | `make db-retention`| `... persistence.cli retention`    |
| Leader inspect    | `make coord-leader`| `... coordination.cli leader`      |
| Kill-switch state | `make coord-kill-status` | `... coordination.cli kill-switch status` |
| Discover market   | `make discover-market` | `uv run polymarket-pair-bot discover-market` |
| Monitor books     | `make market-data-monitor` | `uv run polymarket-pair-bot market-data-monitor` |
| Record market data| `make record-market-data` | `uv run polymarket-pair-bot record-market-data` |
| Export recording  | `make market-data-export` | `uv run polymarket-pair-bot market-data-export` |
| Validate recording| `make market-data-validate` | `uv run polymarket-pair-bot market-data-validate` |
| Replay recording  | `make market-data-replay` | `uv run polymarket-pair-bot market-data-replay` |
| Wallet diagnostics| `make wallet-diagnostics` | `uv run polymarket-pair-bot wallet-diagnostics` |
| CTF mergeable qty | `make ctf-mergeable` | `uv run polymarket-pair-bot ctf-mergeable` |

## Verifying infrastructure health

With infrastructure running:

```bash
uv run python scripts/healthcheck.py           # prints redaction-safe JSON
RUN_INFRA_TESTS=1 uv run pytest tests/integration
```

Integration tests self-skip unless `RUN_INFRA_TESTS=1` is set, so the default
test run never touches external services and never places orders.

## Application orchestrator (Module 19)

The orchestrator (`src/polymarket_pair_bot/orchestrator/`) is the top-level
coordinator for the whole pipeline: market discovery, market-data feed,
opportunity detector, risk engine, execution adapter, inventory, reconciliation,
CTF operations, persistence and metrics. It depends only on abstract ports, so
paper and live builds share one code path.

Key properties:

- Structured asyncio task supervision with **no untracked tasks**; every task is
  owned by a `TaskSupervisor` and classified critical vs noncritical.
- A single **bounded** event queue with backpressure.
- **Fail-closed degraded mode** on critical failure, machine `HALTED`, or a stale
  feed: block new orders, cancel where safe, reconcile, and stop if any
  uncertainty remains.
- A strict **graceful-shutdown ordering**: stop new strategy actions -> local
  execution block -> cancel open orders -> wait for authoritative updates ->
  reconcile -> flush persistence -> close WebSockets -> close database, then
  Redis.
- **Readiness checks** aggregating health, kill switch, execution gate, session
  restore, and dependency health checks.
- It **never auto-enables live trading**; it only reads `run_mode` and drives the
  adapters the composition layer injected.

Deterministic paper-mode integration tests live in
`tests/integration/test_orchestrator_paper.py` (no network, no sleeps, no
orders). See `docs/orchestrator.md` for the full design.

## Safety posture

- `LIVE_TRADING` defaults to `false`; `PAPER_TRADING` defaults to `true`.
- Both cannot be `true` at once (validated at config load).
- Secrets are typed as `SecretStr` and never logged; logging applies automatic
  redaction of sensitive keys and secret-looking values.
- The system is designed to **fail closed** and shut down gracefully.
- Monetary values will use `Decimal` / integer base units (enforced starting in
  the domain module).

## Project layout

```
polymarket_pair_bot/
  pyproject.toml            # uv project, deps, ruff, mypy(strict), pytest
  .env.example              # placeholders only
  .dockerignore .gitignore
  Makefile                  # developer commands
  docker/docker-compose.yml # PostgreSQL 16 + Redis 7
  scripts/                  # dev.sh, healthcheck.py
  alembic.ini               # DSN injected programmatically (never stored)
  alembic/                  # async migration env + versions/0001_initial_schema
  docs/
    architecture/overview.md
    persistence.md            # Module 3 persistence design
    coordination.md           # Module 4 coordination / leader election
    orchestrator.md           # Module 19 application orchestrator
    runbooks/local-development.md
  src/polymarket_pair_bot/
    __init__.py __main__.py py.typed
    app/         # lifecycle, service protocol, composition
    config/      # typed settings + secrets (pydantic-settings)
    observability/ # JSON logging + redaction + health checks
    security/    # secret redaction helpers
    shared/      # health state primitives
    domain/ market_discovery/ market_data/ strategy/ execution/
    persistence/ # SQLAlchemy models, repositories, unit of work, admin CLI
    coordination/ # Redis leader lease, kill-switch cache, caches, CLI
    inventory/   # inventory & matched-pair accounting (Module 12)
    risk/        # centralized risk engine & persistent kill switches (Modules 13-14)
    auth/        # Polymarket authentication & read-only account access (Module 15)
    reconciliation/ blockchain/ ctf/  # exchange reconciliation, chain reads, CTF ops
    orchestrator/ # Module 19 application orchestrator (task supervision, degraded mode)
  tests/
    unit/ integration/ replay/ fixtures/
```

See `docs/architecture/overview.md` for the modular-monolith design and the
27-module roadmap.
| Module 8 | VWAP / Fee Engine | `evaluate_pair_cost` | strategy/engine.py |
| Module 11 | Paper execution simulator | `PaperExecutionAdapter` | execution/paper.py |
| Module 12 | Inventory & matched-pair accounting | `InventoryService` / `MarketInventory` | inventory/ |
| Modules 13-14 | Centralized risk engine & persistent kill switches | `RiskEngine` / `KillSwitchService` | risk/ |
| Module 15 | Polymarket authentication & read-only account access | `AuthenticationService` / `AuthenticatedAccountReader` | auth/ |
| Module 24 | End-to-end verification & release gate | `ReleaseGateRunner` / e2e suite | release/ , tests/e2e/ |
