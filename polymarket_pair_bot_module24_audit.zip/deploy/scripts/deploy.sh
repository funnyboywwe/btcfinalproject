#!/usr/bin/env bash
# MANUALLY GATED deployment helper. Does NOT deploy automatically.
#
# Steps (in order): preflight -> build/pull -> migrate (one-shot) -> up -d ->
# wait for health. Requires an explicit --yes (or interactive confirmation).
# It never enables live trading; that stays controlled by env/app.env and the
# go-live runbook.
#
# Usage:
#   deploy/scripts/deploy.sh [--yes] [--build|--pull]
set -euo pipefail
. "$(dirname "$0")/_common.sh"

require_cmd docker

assume_yes=0
source_mode="build"
for arg in "$@"; do
  case "$arg" in
    --yes|-y) assume_yes=1 ;;
    --build) source_mode="build" ;;
    --pull) source_mode="pull" ;;
    *) die "unknown argument: $arg" ;;
  esac
done

log "Running preflight checks..."
"$(dirname "$0")/preflight.sh"

if [ "${assume_yes}" -ne 1 ]; then
  printf 'Proceed with deployment (image %s)? [y/N] ' "${source_mode}" >&2
  read -r reply
  case "${reply}" in y|Y|yes|YES) : ;; *) die 'aborted by operator' ;; esac
fi

if [ "${source_mode}" = "pull" ]; then
  log 'Pulling images...'
  dc pull
else
  log 'Building image...'
  dc build
fi

log 'Applying migrations (one-shot)...'
dc run --rm migrate

log 'Starting services...'
dc up -d

log 'Waiting for the bot to report healthy...'
ok=0
for _ in $(seq 1 30); do
  status="$(dc ps --format '{{.Service}} {{.Health}}' 2>/dev/null | awk '$1=="bot"{print $2}')"
  if [ "${status}" = "healthy" ]; then ok=1; break; fi
  sleep 5
done
if [ "${ok}" -eq 1 ]; then
  log 'Deployment complete: bot is healthy.'
else
  log 'Bot did not report healthy in time; check logs: dc logs -f bot'
  exit 1
fi

log 'Reminder: trading stays in PAPER mode unless env/app.env enables LIVE (see the go-live runbook).'
