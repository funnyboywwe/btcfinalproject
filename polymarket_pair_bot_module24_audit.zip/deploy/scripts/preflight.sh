#!/usr/bin/env bash
# Pre-deployment safety checks. Exits non-zero on any HARD failure.
#
# Verifies the host is in a safe state before (re)starting the bot:
#   * secret/env files exist and are not world/group readable,
#   * trading safety switches are sane (paper/live not both true),
#   * dual Polygon RPC is configured IF live trading is enabled,
#   * a firewall is active,
#   * the system clock is NTP-synchronized,
#   * (best effort) no other execution leader is already active.
# Prints redaction-safe output only (never the secret values themselves).
#
# Usage: deploy/scripts/preflight.sh
set -euo pipefail
. "$(dirname "$0")/_common.sh"

hard=0
warn=0
fail() { log "FAIL: $*"; hard=1; }
warnf() { log "WARN: $*"; warn=1; }

env_file="${PPB_DOCKER_DIR}/${PPB_ENV_FILE}"
app_env="${PPB_DOCKER_DIR}/env/app.env"
secrets_env="${PPB_DOCKER_DIR}/secrets/secrets.env"

log "== file presence + permissions =="
for f in "${env_file}" "${app_env}" "${secrets_env}"; do
  if [ ! -f "${f}" ]; then
    fail "missing config file: ${f}"
    continue
  fi
  # Reject group/other readable bits on files that carry secrets.
  mode="$(stat -c '%a' "${f}" 2>/dev/null || stat -f '%Lp' "${f}" 2>/dev/null || echo '')"
  case "${f}" in
    *secrets.env|*/.env)
      case "${mode}" in
        600|400) : ;;
        *) fail "insecure permissions ${mode} on ${f} (want 600)" ;;
      esac
      ;;
  esac
done

log "== trading safety switches =="
if [ -f "${app_env}" ]; then
  paper="$(grep -E '^PAPER_TRADING=' "${app_env}" | tail -n1 | cut -d= -f2 || true)"
  live="$(grep -E '^LIVE_TRADING=' "${app_env}" | tail -n1 | cut -d= -f2 || true)"
  log "PAPER_TRADING=${paper:-unset} LIVE_TRADING=${live:-unset}"
  if [ "${paper:-}" = "true" ] && [ "${live:-}" = "true" ]; then
    fail "PAPER_TRADING and LIVE_TRADING must not both be true"
  fi
  if [ "${live:-}" = "true" ]; then
    warnf "LIVE_TRADING=true: ensure you have completed the go-live runbook"
    for k in POLYGON_RPC_PRIMARY POLYGON_RPC_SECONDARY POLYMARKET_PRIVATE_KEY POLYMARKET_FUNDER_ADDRESS; do
      if ! grep -Eq "^${k}=.+$" "${secrets_env}" 2>/dev/null; then
        fail "LIVE requires ${k} to be set in secrets.env"
      fi
    done
    if grep -Eq '^WALLET_IS_DEDICATED_ACK=true$' "${app_env}"; then :; else
      fail "LIVE requires WALLET_IS_DEDICATED_ACK=true (dedicated limited-capital wallet)"
    fi
  fi
fi

log "== firewall =="
if command -v ufw >/dev/null 2>&1; then
  ufw status | grep -qi 'Status: active' && log 'ufw active' || warnf 'ufw installed but not active'
elif command -v firewall-cmd >/dev/null 2>&1; then
  firewall-cmd --state 2>/dev/null | grep -qi running && log 'firewalld running' || warnf 'firewalld not running'
else
  warnf 'no ufw/firewalld detected; verify nftables/iptables rules manually'
fi

log "== clock synchronization =="
if command -v timedatectl >/dev/null 2>&1; then
  if timedatectl show -p NTPSynchronized --value 2>/dev/null | grep -qi yes; then
    log 'clock NTP-synchronized'
  else
    fail 'system clock is NOT NTP-synchronized (enable chrony/systemd-timesyncd)'
  fi
else
  warnf 'timedatectl unavailable; verify chrony/ntpd manually'
fi

log "== execution leader (best effort) =="
if docker compose -f "${PPB_DOCKER_DIR}/${PPB_COMPOSE_FILE}" --env-file "${env_file}" ps redis >/dev/null 2>&1; then
  owner="$(dc exec -T redis redis-cli --no-raw KEYS 'ppb*leader*' 2>/dev/null || true)"
  [ -n "${owner}" ] && log "leader key(s) present: ${owner}" || log 'no active leader key (ok for a cold start)'
else
  log 'redis not running yet (ok for a cold start)'
fi

log "== summary =="
if [ "${hard}" -ne 0 ]; then
  log 'PREFLIGHT FAILED (hard errors above)'
  exit 1
fi
[ "${warn}" -ne 0 ] && log 'PREFLIGHT PASSED WITH WARNINGS' || log 'PREFLIGHT PASSED'
exit 0
