#!/usr/bin/env bash
# Encrypted PostgreSQL backup for polymarket_pair_bot.
#
# * Dumps the database via the running compose `postgres` service (custom format).
# * ENCRYPTS to a recipient with `age` or `gpg`. It REFUSES to write a plaintext
#   backup (fails closed if no recipient is configured).
# * Writes atomically (temp file + mv), umask 077, then enforces retention.
# * Never prints secrets.
#
# Configuration (env, e.g. from /etc/polymarket-pair-bot/backup.env):
#   BACKUP_DIR       default: /var/backups/polymarket-pair-bot
#   RETENTION_DAYS   default: 14
#   Exactly one recipient:
#     AGE_RECIPIENT=age1...             (uses `age`)
#     BACKUP_GPG_RECIPIENT=ops@ex.com   (uses `gpg`, recipient must be trusted)
#
# Usage: deploy/scripts/backup_postgres.sh
set -euo pipefail
umask 077
. "$(dirname "$0")/_common.sh"

require_cmd docker
load_compose_env

BACKUP_DIR="${BACKUP_DIR:-/var/backups/polymarket-pair-bot}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
POSTGRES_USER="${POSTGRES_USER:-bot}"
POSTGRES_DB="${POSTGRES_DB:-pair_bot}"

# --- Choose an encryptor; fail closed if none configured. ---
if [ -n "${AGE_RECIPIENT:-}" ]; then
  require_cmd age
  enc_suffix="age"
  encrypt() { age -r "${AGE_RECIPIENT}" -o "$1"; }
elif [ -n "${BACKUP_GPG_RECIPIENT:-}" ]; then
  require_cmd gpg
  enc_suffix="gpg"
  encrypt() { gpg --batch --yes --trust-model always \
                  --encrypt --recipient "${BACKUP_GPG_RECIPIENT}" -o "$1"; }
else
  die "no encryption recipient set (AGE_RECIPIENT or BACKUP_GPG_RECIPIENT); refusing to write a plaintext backup"
fi

mkdir -p "${BACKUP_DIR}"
ts="$(date -u +%Y%m%dT%H%M%SZ)"
base="pair_bot_${ts}.dump"
out="${BACKUP_DIR}/${base}.${enc_suffix}"
tmp="${out}.partial"

log "Dumping ${POSTGRES_DB} and encrypting with ${enc_suffix}..."
# pg_dump custom format (compressed) -> encryptor -> temp file, then atomic mv.
# Pipefail ensures a pg_dump failure aborts before we publish a partial file.
if dc exec -T postgres pg_dump -U "${POSTGRES_USER}" -d "${POSTGRES_DB}" -F c | encrypt "${tmp}"; then
  mv "${tmp}" "${out}"
  log "Backup written: ${out}"
else
  rm -f "${tmp}"
  die "backup failed; no file written"
fi

# Record a checksum for integrity verification (non-secret).
if command -v sha256sum >/dev/null 2>&1; then
  ( cd "${BACKUP_DIR}" && sha256sum "$(basename "${out}")" > "$(basename "${out}").sha256" )
fi

log "Enforcing retention: deleting encrypted backups older than ${RETENTION_DAYS} days"
find "${BACKUP_DIR}" -type f -name 'pair_bot_*.dump.*' -mtime "+${RETENTION_DAYS}" -print -delete || true
log "Done."
