#!/usr/bin/env bash
# Operator-facing health probe for a running deployment.
#
# Reports (and exits non-zero on any failure):
#   * compose service/container status,
#   * database connectivity + current migration revision,
#   * redis reachability,
#   * private operator API /health (if MONITORING_ENABLED and reachable).
# Prints redaction-safe output only.
#
# Usage: deploy/scripts/healthcheck.sh
set -euo pipefail
. "$(dirname "$0")/_common.sh"

require_cmd docker
load_compose_env

rc=0

log "== compose status =="
dc ps || rc=1

log "== database health =="
if ! dc run --rm bot db-health; then
  log "database health check FAILED"
  rc=1
fi

log "== redis health =="
if ! dc exec -T redis redis-cli ping | grep -q PONG; then
  log "redis ping FAILED"
  rc=1
fi

log "== operator API =="
bind="${BIND_ADDR:-127.0.0.1}"
scheme="http"
health_url="${scheme}://${bind}:8081/health"
if command -v curl >/dev/null 2>&1; then
  if curl -fsS --max-time 5 "${health_url}" >/dev/null 2>&1; then
    log "operator API /health OK (${health_url})"
  else
    log "operator API not reachable on ${bind}:8081 (may be disabled or tunnel-only)"
  fi
else
  log "curl not installed; skipping operator API probe"
fi

if [ "$rc" -eq 0 ]; then
  log "ALL HEALTHY"
else
  log "UNHEALTHY (see above)"
fi
exit "$rc"
