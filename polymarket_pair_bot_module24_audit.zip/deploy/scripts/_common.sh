#!/usr/bin/env bash
# Shared helpers for polymarket_pair_bot deployment scripts.
# Sourced by the other scripts; do not execute directly.
set -euo pipefail

# Resolve repository layout from this file's location.
PPB_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PPB_ROOT="$(cd "${PPB_SCRIPT_DIR}/../.." && pwd)"
PPB_DOCKER_DIR="${PPB_DOCKER_DIR:-${PPB_ROOT}/docker}"
PPB_COMPOSE_FILE="${PPB_COMPOSE_FILE:-docker-compose.prod.yml}"
PPB_ENV_FILE="${PPB_ENV_FILE:-.env}"

log()  { printf '[%s] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

# Run docker compose in the project directory with the prod file + env file.
dc() {
  ( cd "${PPB_DOCKER_DIR}" \
    && docker compose -f "${PPB_COMPOSE_FILE}" --env-file "${PPB_ENV_FILE}" "$@" )
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "required command not found: $1"
}

# Load POSTGRES_* (and other compose vars) without echoing them.
load_compose_env() {
  local f="${PPB_DOCKER_DIR}/${PPB_ENV_FILE}"
  [ -f "$f" ] || die "compose env file not found: $f (copy .env.prod.example)"
  # shellcheck disable=SC1090
  set -a; . "$f"; set +a
}
