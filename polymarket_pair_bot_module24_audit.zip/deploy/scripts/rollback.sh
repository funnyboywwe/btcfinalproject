#!/usr/bin/env bash
# Roll the bot back to a previously published image tag.
#
# Application rollback is safe and fast (swap the image tag, restart). DATABASE
# rollback is DANGEROUS and manual: only forward migrations are routine. This
# script will run an Alembic downgrade ONLY with an explicit flag and a typed
# confirmation, and it insists you take a fresh backup first.
#
# Usage:
#   deploy/scripts/rollback.sh --to-tag <IMAGE_TAG> [--db-downgrade <revision>]
set -euo pipefail
. "$(dirname "$0")/_common.sh"

require_cmd docker

to_tag=""
db_downgrade=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --to-tag) to_tag="${2:-}"; shift 2 ;;
    --db-downgrade) db_downgrade="${2:-}"; shift 2 ;;
    *) die "unknown argument: $1" ;;
  esac
done
[ -n "${to_tag}" ] || die 'usage: rollback.sh --to-tag <IMAGE_TAG> [--db-downgrade <revision>]'

log "Rolling application back to image tag: ${to_tag}"
export IMAGE_TAG="${to_tag}"

if [ -n "${db_downgrade}" ]; then
  log 'DATABASE DOWNGRADE REQUESTED. This can cause irreversible data loss.'
  log 'Take/verify a backup NOW: deploy/scripts/backup_postgres.sh && deploy/scripts/restore_verify.sh'
  printf 'Type EXACTLY "downgrade %s" to proceed: ' "${db_downgrade}" >&2
  read -r confirm
  [ "${confirm}" = "downgrade ${db_downgrade}" ] || die 'confirmation mismatch; aborted'
  log "Stopping bot before schema change..."
  dc stop bot || true
  log "Running alembic downgrade to ${db_downgrade}..."
  dc run --rm bot python -m alembic downgrade "${db_downgrade}" \
    || die 'alembic downgrade failed; investigate before starting the bot'
fi

log "Recreating services on tag ${to_tag}..."
dc up -d
log 'Rollback issued. Verify health: deploy/scripts/healthcheck.sh'
