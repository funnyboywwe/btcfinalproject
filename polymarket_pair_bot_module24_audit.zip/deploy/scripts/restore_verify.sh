#!/usr/bin/env bash
# Restore-VERIFICATION for an encrypted PostgreSQL backup.
#
# Proves a backup is restorable WITHOUT touching production:
#   1. decrypts the chosen (or latest) backup,
#   2. starts a throwaway, isolated PostgreSQL 16 container,
#   3. pg_restore into it,
#   4. runs the app image's db-health (connectivity + migration revision) and
#      row counts against the throwaway database,
#   5. tears everything down (trap-based cleanup) and reports pass/fail.
#
# It never connects to the production database, network, or wallet.
#
# Configuration (env):
#   BACKUP_DIR       default: /var/backups/polymarket-pair-bot
#   BACKUP_FILE      default: newest pair_bot_*.dump.(age|gpg) in BACKUP_DIR
#   AGE_IDENTITY     path to age identity file (for .age backups)
#   (gpg uses the local keyring for .gpg backups)
#
# Usage: deploy/scripts/restore_verify.sh [BACKUP_FILE]
set -euo pipefail
umask 077
. "$(dirname "$0")/_common.sh"

require_cmd docker
load_compose_env

BACKUP_DIR="${BACKUP_DIR:-/var/backups/polymarket-pair-bot}"
BACKUP_FILE="${1:-${BACKUP_FILE:-}}"
if [ -z "${BACKUP_FILE}" ]; then
  BACKUP_FILE="$(find "${BACKUP_DIR}" -type f -name 'pair_bot_*.dump.*' ! -name '*.sha256' -print 2>/dev/null | sort | tail -n1)"
fi
[ -n "${BACKUP_FILE}" ] && [ -f "${BACKUP_FILE}" ] || die "no backup file found (set BACKUP_FILE or place backups in ${BACKUP_DIR})"
log "Verifying backup: ${BACKUP_FILE}"

IMAGE="${IMAGE_NAME:-polymarket-pair-bot}:${IMAGE_TAG:-latest}"
suffix="${BACKUP_FILE##*.}"
stamp="$(date -u +%Y%m%d%H%M%S)$$"
net="ppb-verify-${stamp}"
pg="ppb-verify-pg-${stamp}"
pgpass="verify-$(head -c 18 /dev/urandom | od -An -tx1 | tr -d ' \n')"
workdir="$(mktemp -d)"
dump="${workdir}/restore.dump"

cleanup() {
  docker rm -f "${pg}" >/dev/null 2>&1 || true
  docker network rm "${net}" >/dev/null 2>&1 || true
  rm -rf "${workdir}" 2>/dev/null || true
}
trap cleanup EXIT

log "Decrypting (${suffix})..."
case "${suffix}" in
  age)
    require_cmd age
    [ -n "${AGE_IDENTITY:-}" ] || die "AGE_IDENTITY must point to your age identity file for .age backups"
    age -d -i "${AGE_IDENTITY}" -o "${dump}" "${BACKUP_FILE}"
    ;;
  gpg)
    require_cmd gpg
    gpg --batch --yes --decrypt -o "${dump}" "${BACKUP_FILE}"
    ;;
  *)
    die "unknown backup suffix '.${suffix}' (expected .age or .gpg)"
    ;;
esac

log "Starting throwaway PostgreSQL 16 (isolated network ${net})..."
docker network create --internal "${net}" >/dev/null
docker run -d --name "${pg}" --network "${net}" \
  -e POSTGRES_USER=verify -e POSTGRES_PASSWORD="${pgpass}" -e POSTGRES_DB=verify \
  postgres:16 >/dev/null

log "Waiting for throwaway database..."
for _ in $(seq 1 30); do
  if docker exec "${pg}" pg_isready -U verify -d verify >/dev/null 2>&1; then break; fi
  sleep 1
done
docker exec "${pg}" pg_isready -U verify -d verify >/dev/null 2>&1 || die "throwaway database did not become ready"

log "Restoring dump..."
docker cp "${dump}" "${pg}:/tmp/restore.dump"
docker exec "${pg}" pg_restore --clean --if-exists --no-owner --no-privileges \
  -U verify -d verify /tmp/restore.dump || die "pg_restore reported errors"

log "Checking schema/revision with the app image..."
dsn="postgresql+asyncpg://verify:${pgpass}@${pg}:5432/verify"
docker run --rm --network "${net}" -e DATABASE_URL="${dsn}" "${IMAGE}" db-health \
  || die "db-health against restored database FAILED"
docker run --rm --network "${net}" -e DATABASE_URL="${dsn}" "${IMAGE}" \
  python -m polymarket_pair_bot.persistence.cli counts || true

log "RESTORE VERIFICATION PASSED for ${BACKUP_FILE}"
