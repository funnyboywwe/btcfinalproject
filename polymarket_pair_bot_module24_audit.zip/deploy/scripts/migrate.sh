#!/usr/bin/env bash
# Run database migrations to head as a one-shot job (idempotent).
#
# This is the migration STARTUP PROCEDURE: always run it (or let the compose
# `migrate` service / systemd ExecStartPre run it) BEFORE starting the bot.
# It never places an order and never touches trading state.
#
# Usage: deploy/scripts/migrate.sh
set -euo pipefail
. "$(dirname "$0")/_common.sh"

require_cmd docker
log "Applying database migrations to head..."
dc run --rm migrate
log "Migrations complete. Current revision:"
dc run --rm bot db-health || die "post-migration db-health check failed"
log "OK"
