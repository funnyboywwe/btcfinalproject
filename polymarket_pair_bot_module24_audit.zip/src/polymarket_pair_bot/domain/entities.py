"""Immutable domain entities composed from value objects.

Entities are frozen dataclasses with validation in ``__post_init__``. They hold
no behavior that touches networking, persistence or blockchain clients — this
module is pure. Units/precision are inherited from the value objects and noted
per field.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from polymarket_pair_bot.domain.enums import (
    CtfOperationStatus,
    CtfOperationType,
    OrderSide,
    OrderStatus,
    OutcomeSide,
    ReconciliationStatus,
    RiskVerdict,
    TimeInForce,
)
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ConditionId,
    FeeAmount,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)


@dataclass(frozen=True, slots=True)
class MarketWindow:
    """A single BTC 5-minute market window.

    Fields:
        market_id: identifier of the market.
        condition_id: CTF condition id backing the market.
        open_time: window open (UnixTimestamp, seconds UTC).
        close_time: window close (UnixTimestamp, seconds UTC).
    """

    market_id: MarketId
    condition_id: ConditionId
    open_time: UnixTimestamp
    close_time: UnixTimestamp

    def __post_init__(self) -> None:
        if self.close_time.value <= self.open_time.value:
            raise ValueError("close_time must be after open_time")

    @property
    def duration_seconds(self) -> int:
        """Window length in whole seconds."""
        return self.close_time.value - self.open_time.value


@dataclass(frozen=True, slots=True)
class OutcomeToken:
    """One outcome (Up or Down) token of a binary market.

    Fields:
        token_id: CLOB/ERC-1155 token id.
        side: OutcomeSide (UP/DOWN).
        market_id: owning market identifier.
        tick_size: minimum price increment for this token's book.
    """

    token_id: TokenId
    side: OutcomeSide
    market_id: MarketId
    tick_size: TickSize


@dataclass(frozen=True, slots=True)
class BinaryMarket:
    """A binary Up/Down BTC 5-minute market.

    Fields:
        market_id: identifier of the market.
        condition_id: CTF condition id.
        window: the market's time window.
        up_token: the Up outcome token.
        down_token: the Down outcome token.
    """

    market_id: MarketId
    condition_id: ConditionId
    window: MarketWindow
    up_token: OutcomeToken
    down_token: OutcomeToken

    def __post_init__(self) -> None:
        if self.up_token.side is not OutcomeSide.UP:
            raise ValueError("up_token must have side UP")
        if self.down_token.side is not OutcomeSide.DOWN:
            raise ValueError("down_token must have side DOWN")
        if self.up_token.token_id == self.down_token.token_id:
            raise ValueError("up and down tokens must differ")

    def token_for(self, side: OutcomeSide) -> OutcomeToken:
        return self.up_token if side is OutcomeSide.UP else self.down_token


@dataclass(frozen=True, slots=True)
class PriceLevel:
    """A single order-book level.

    Fields:
        price: level price (ProbabilityPrice, USD/share in [0, 1]).
        size: resting size at that price (Shares, > 0).
    """

    price: ProbabilityPrice
    size: Shares

    def __post_init__(self) -> None:
        self.size.require_positive()


@dataclass(frozen=True, slots=True)
class OrderBookSnapshot:
    """A point-in-time snapshot of one token's book.

    Fields:
        token_id: token the book belongs to.
        bids: descending-by-price price levels (best bid first).
        asks: ascending-by-price price levels (best ask first).
        as_of: capture time (UnixTimestamp).
        sequence: monotonic sequence number from the feed, if available.

    Freshness enforcement and reconnect resynchronization are handled by later
    market-data modules, not here.
    """

    token_id: TokenId
    bids: tuple[PriceLevel, ...]
    asks: tuple[PriceLevel, ...]
    as_of: UnixTimestamp
    sequence: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "bids", tuple(self.bids))
        object.__setattr__(self, "asks", tuple(self.asks))
        for i in range(1, len(self.bids)):
            if self.bids[i].price.value > self.bids[i - 1].price.value:
                raise ValueError("bids must be sorted descending by price")
        for i in range(1, len(self.asks)):
            if self.asks[i].price.value < self.asks[i - 1].price.value:
                raise ValueError("asks must be sorted ascending by price")

    @property
    def best_bid(self) -> ProbabilityPrice | None:
        return self.bids[0].price if self.bids else None

    @property
    def best_ask(self) -> ProbabilityPrice | None:
        return self.asks[0].price if self.asks else None


@dataclass(frozen=True, slots=True)
class OrderIntent:
    """A desired order prior to risk approval and submission.

    Fields:
        intent_id: client idempotency key (opaque, non-empty).
        market_id: target market.
        token_id: target token.
        side: OrderSide (the accumulation strategy buys to acquire).
        limit_price: worst acceptable price (ProbabilityPrice).
        size: desired quantity (Shares, strictly positive).
        time_in_force: TimeInForce policy.
        created_at: intent creation time (UnixTimestamp).
    """

    intent_id: str
    market_id: MarketId
    token_id: TokenId
    side: OrderSide
    limit_price: ProbabilityPrice
    size: Shares
    time_in_force: TimeInForce
    created_at: UnixTimestamp

    def __post_init__(self) -> None:
        if not self.intent_id.strip():
            raise ValueError("intent_id must not be empty")
        self.size.require_positive()


@dataclass(frozen=True, slots=True)
class ExchangeOrder:
    """An order as known on the exchange.

    A non-``FILLED`` status is NEVER treated as a matched pair. ``UNKNOWN``
    requires reconciliation before any further action.

    Fields:
        order_id: exchange order id.
        intent_id: originating intent idempotency key.
        token_id: token traded.
        side: OrderSide.
        limit_price: submitted limit price (ProbabilityPrice).
        original_size: submitted quantity (Shares, > 0).
        filled_size: confirmed filled quantity (Shares, >= 0, <= original).
        status: OrderStatus.
        created_at / updated_at: lifecycle timestamps (UnixTimestamp).
    """

    order_id: OrderId
    intent_id: str
    token_id: TokenId
    side: OrderSide
    limit_price: ProbabilityPrice
    original_size: Shares
    filled_size: Shares
    status: OrderStatus
    created_at: UnixTimestamp
    updated_at: UnixTimestamp

    def __post_init__(self) -> None:
        self.original_size.require_positive()
        if self.filled_size.value > self.original_size.value:
            raise ValueError("filled_size cannot exceed original_size")
        if self.updated_at.value < self.created_at.value:
            raise ValueError("updated_at cannot precede created_at")

    @property
    def remaining_size(self) -> Shares:
        return Shares(self.original_size.value - self.filled_size.value)

    @property
    def is_confirmed_complete(self) -> bool:
        """Only true when fully filled AND status confirms completion."""
        return (
            self.status.is_confirmed_complete
            and self.filled_size.value == self.original_size.value
        )


@dataclass(frozen=True, slots=True)
class Fill:
    """A single confirmed execution against an order.

    Fill messages are not assumed unique; de-duplicate by ``fill_id`` upstream.

    Fields:
        fill_id: execution id.
        order_id: parent order id.
        token_id: token traded.
        side: OrderSide.
        price: execution price (ProbabilityPrice).
        size: executed quantity (Shares, > 0).
        fee: taker fee charged (FeeAmount, USD).
        filled_at: execution time (UnixTimestamp).
    """

    fill_id: FillId
    order_id: OrderId
    token_id: TokenId
    side: OrderSide
    price: ProbabilityPrice
    size: Shares
    fee: FeeAmount
    filled_at: UnixTimestamp

    def __post_init__(self) -> None:
        self.size.require_positive()

    @property
    def notional(self) -> CollateralAmount:
        """price * size in USD collateral."""
        return CollateralAmount(self.price.value * self.size.value)


@dataclass(frozen=True, slots=True)
class Position:
    """Net long position in one outcome token (the bot only buys to acquire).

    Fields:
        token_id: token held.
        side: OutcomeSide of the token.
        quantity: shares held (Shares, >= 0).
        average_price: average acquisition price (ProbabilityPrice).
        fees_paid: cumulative fees attributable to the position (FeeAmount).
    """

    token_id: TokenId
    side: OutcomeSide
    quantity: Shares
    average_price: ProbabilityPrice
    fees_paid: FeeAmount

    @property
    def cost_basis(self) -> CollateralAmount:
        """quantity * average_price + fees_paid, in USD."""
        return CollateralAmount(
            self.quantity.value * self.average_price.value + self.fees_paid.value
        )


@dataclass(frozen=True, slots=True)
class InventorySnapshot:
    """Per-market inventory at a point in time.

    Fields:
        market_id: market the inventory belongs to.
        up_position / down_position: per-side positions.
        matched_pairs: confirmed complete Up/Down pairs (Shares).
        as_of: snapshot time (UnixTimestamp).

    ``unmatched_up`` / ``unmatched_down`` derive directional exposure that is
    NOT yet a matched pair.
    """

    market_id: MarketId
    up_position: Position
    down_position: Position
    matched_pairs: Shares
    as_of: UnixTimestamp

    def __post_init__(self) -> None:
        matched = self.matched_pairs.value
        if matched > self.up_position.quantity.value:
            raise ValueError("matched_pairs cannot exceed up quantity")
        if matched > self.down_position.quantity.value:
            raise ValueError("matched_pairs cannot exceed down quantity")

    @property
    def unmatched_up(self) -> Shares:
        return Shares(self.up_position.quantity.value - self.matched_pairs.value)

    @property
    def unmatched_down(self) -> Shares:
        return Shares(self.down_position.quantity.value - self.matched_pairs.value)


@dataclass(frozen=True, slots=True)
class PairOpportunity:
    """A detected candidate to acquire an Up/Down pair.

    This records a measured cost against a threshold. It makes NO profitability
    claim.

    Fields:
        market_id: target market.
        size: candidate pair size (Shares, > 0).
        up_price / down_price: executable prices used (ProbabilityPrice).
        effective_pair_cost: all-in modeled cost per pair (CollateralAmount).
        max_pair_cost: configured threshold used (CollateralAmount).
        as_of: detection time (UnixTimestamp).
    """

    market_id: MarketId
    size: Shares
    up_price: ProbabilityPrice
    down_price: ProbabilityPrice
    effective_pair_cost: CollateralAmount
    max_pair_cost: CollateralAmount
    as_of: UnixTimestamp

    def __post_init__(self) -> None:
        self.size.require_positive()

    @property
    def is_within_threshold(self) -> bool:
        """True when modeled cost is at or below the configured threshold."""
        return self.effective_pair_cost.value <= self.max_pair_cost.value


@dataclass(frozen=True, slots=True)
class MatchedPair:
    """A confirmed matched Up/Down pair built only from confirmed fills.

    Fields:
        market_id / condition_id: market identifiers.
        quantity: matched pair quantity (Shares, > 0).
        up_cost / down_cost: acquisition cost per side (CollateralAmount).
        fees: total fees for both sides (FeeAmount).
        locked_value: recoverable collateral via CTF merge (CollateralAmount,
            quantity * $1).
        net_profit: locked_value - all costs (ProfitAmount, may be negative).
        created_at: time the pair became confirmed (UnixTimestamp).
    """

    market_id: MarketId
    condition_id: ConditionId
    quantity: Shares
    up_cost: CollateralAmount
    down_cost: CollateralAmount
    fees: FeeAmount
    locked_value: CollateralAmount
    net_profit: ProfitAmount
    created_at: UnixTimestamp

    def __post_init__(self) -> None:
        self.quantity.require_positive()


@dataclass(frozen=True, slots=True)
class RiskDecision:
    """An outcome from the centralized risk engine.

    Fields:
        decision_id: idempotency/audit key (opaque, non-empty).
        verdict: RiskVerdict (APPROVE/REJECT).
        reason: human-readable justification (secret-free).
        decided_at: decision time (UnixTimestamp).
        approved_size: size permitted if approved (Shares, >= 0).
    """

    decision_id: str
    verdict: RiskVerdict
    reason: str
    decided_at: UnixTimestamp
    approved_size: Shares = field(default_factory=lambda: Shares(0))

    def __post_init__(self) -> None:
        if not self.decision_id.strip():
            raise ValueError("decision_id must not be empty")
        if self.verdict is RiskVerdict.REJECT and self.approved_size.value != 0:
            raise ValueError("rejected decision must have zero approved size")

    @property
    def approved(self) -> bool:
        return self.verdict is RiskVerdict.APPROVE


@dataclass(frozen=True, slots=True)
class CtfOperation:
    """A Conditional Token Framework split/merge/redeem operation record.

    A MERGE of a complete Up/Down pair recovers $1 of collateral per pair.

    Fields:
        operation_id: idempotency key (opaque, non-empty).
        operation_type: CtfOperationType.
        condition_id: CTF condition id.
        quantity: token quantity affected (Shares, > 0).
        collateral: collateral moved (CollateralAmount, USD).
        status: CtfOperationStatus.
        created_at: creation time (UnixTimestamp).
    """

    operation_id: str
    operation_type: CtfOperationType
    condition_id: ConditionId
    quantity: Shares
    collateral: CollateralAmount
    status: CtfOperationStatus
    created_at: UnixTimestamp

    def __post_init__(self) -> None:
        if not self.operation_id.strip():
            raise ValueError("operation_id must not be empty")
        self.quantity.require_positive()


@dataclass(frozen=True, slots=True)
class ReconciliationResult:
    """The outcome of reconciling local state against authoritative records.

    Fields:
        status: ReconciliationStatus.
        as_of: reconciliation time (UnixTimestamp).
        discrepancies: human-readable discrepancy descriptions (secret-free).
        recommended_actions: safe follow-up actions (secret-free).
    """

    status: ReconciliationStatus
    as_of: UnixTimestamp
    discrepancies: tuple[str, ...] = ()
    recommended_actions: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "discrepancies", tuple(self.discrepancies))
        object.__setattr__(self, "recommended_actions", tuple(self.recommended_actions))
        if self.status is ReconciliationStatus.CONSISTENT and self.discrepancies:
            raise ValueError("consistent result cannot list discrepancies")

    @property
    def is_consistent(self) -> bool:
        return self.status is ReconciliationStatus.CONSISTENT


# Keep Decimal import meaningful for type-checkers reading this module.
_ZERO: Decimal = Decimal(0)


__all__ = [
    "BinaryMarket",
    "CtfOperation",
    "ExchangeOrder",
    "Fill",
    "InventorySnapshot",
    "MarketWindow",
    "MatchedPair",
    "OrderBookSnapshot",
    "OrderIntent",
    "OutcomeToken",
    "PairOpportunity",
    "PriceLevel",
    "Position",
    "ReconciliationResult",
    "RiskDecision",
]
