"""Read-only market-data domain contracts (Module 6).

This module is part of the pure domain layer: it must not import HTTP or
WebSocket clients, SQLAlchemy, blockchain clients or environment access. It
defines the *read-only* view types and the ``OrderBookProvider`` protocol that
strategy/risk code depends on, so those layers never touch a concrete feed.

Monetary values (prices, sizes, spread, depth) are ``Decimal`` or domain value
objects, never binary floats. Time durations (book age) are expressed in
seconds as ``float`` -- durations are explicitly *not* in the list of values
that must avoid binary floating point, and are treated only as freshness
metadata, never as money.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import OrderBookSnapshot
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    ProbabilityPrice,
    Shares,
    TokenId,
)


class FeedStatus(str, Enum):
    """Availability of a single token's local order book.

    The feed is only ``LIVE`` when an authoritative snapshot has been received
    and the book is fresh, not crossed, and internally consistent. Any doubt
    downgrades the status (fail closed): a disconnect is ``UNAVAILABLE``, and a
    connected-but-not-yet-snapshotted book is ``AWAITING_SNAPSHOT``.
    """

    INITIALIZING = "initializing"
    AWAITING_SNAPSHOT = "awaiting_snapshot"
    LIVE = "live"
    STALE = "stale"
    UNAVAILABLE = "unavailable"

    @property
    def is_usable(self) -> bool:
        """True only when the book may be read for pricing decisions."""
        return self is FeedStatus.LIVE


@dataclass(frozen=True, slots=True)
class BookQuote:
    """An immutable, read-only top-of-book view for one outcome token.

    Fields:
        side: which outcome (UP/DOWN) this quote is for.
        token_id: the token whose book this summarizes.
        status: current :class:`FeedStatus` for the book.
        best_bid / best_ask: best prices (ProbabilityPrice) or ``None``.
        best_bid_size / best_ask_size: size at the best level (Shares) or None.
        bid_levels / ask_levels: number of distinct price levels held.
        bid_depth / ask_depth: summed resting size across all held levels.
        exchange_timestamp_ms: exchange-provided event time in integer
            milliseconds since the Unix epoch, when the feed supplies it.
        local_receipt_epoch / processed_epoch: wall-clock UTC seconds when the
            latest applied message was received / applied locally.
        age_seconds: seconds since the last applied update (freshness metadata,
            a duration -- never a monetary value), or ``None`` if never updated.
    """

    side: OutcomeSide
    token_id: TokenId
    status: FeedStatus
    best_bid: ProbabilityPrice | None
    best_ask: ProbabilityPrice | None
    best_bid_size: Shares | None
    best_ask_size: Shares | None
    bid_levels: int
    ask_levels: int
    bid_depth: Shares
    ask_depth: Shares
    exchange_timestamp_ms: int | None
    local_receipt_epoch: int | None
    processed_epoch: int | None
    age_seconds: float | None

    @property
    def spread(self) -> Decimal | None:
        """Best ask minus best bid, or ``None`` if either side is empty."""
        if self.best_bid is None or self.best_ask is None:
            return None
        return self.best_ask.value - self.best_bid.value

    @property
    def mid(self) -> Decimal | None:
        """Arithmetic midpoint of best bid/ask, or ``None`` if unavailable."""
        if self.best_bid is None or self.best_ask is None:
            return None
        return (self.best_ask.value + self.best_bid.value) / Decimal(2)

    @property
    def is_crossed(self) -> bool:
        """True when best bid >= best ask (an impossible, unusable book)."""
        if self.best_bid is None or self.best_ask is None:
            return False
        return self.best_bid.value >= self.best_ask.value


@runtime_checkable
class OrderBookProvider(Protocol):
    """Read-only access to the live Up/Down books and feed health.

    Consumers (strategy, risk, monitoring) depend only on this protocol and can
    never mutate the books or drive networking. Implementations must be safe to
    call from the event loop without performing I/O.
    """

    def feed_status(self, side: OutcomeSide) -> FeedStatus:
        """Return the current status of one token's book."""
        ...

    def quote(self, side: OutcomeSide) -> BookQuote:
        """Return an immutable top-of-book view for one token."""
        ...

    def snapshot(self, side: OutcomeSide) -> OrderBookSnapshot | None:
        """Return a full immutable L2 snapshot, or ``None`` if unavailable."""
        ...

    def is_fresh(self, side: OutcomeSide) -> bool:
        """True only when the book is LIVE and within the freshness bound."""
        ...

    @property
    def reconnect_count(self) -> int:
        """Total number of reconnects observed since start."""
        ...


__all__ = [
    "BookQuote",
    "FeedStatus",
    "OrderBookProvider",
]
