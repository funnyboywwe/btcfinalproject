"""Immutable domain value objects.

Every value object is a frozen dataclass. Monetary / quantity / price values
are stored as ``Decimal`` and are coerced through ``coerce_decimal`` so a
``Decimal`` can never be built from a binary float. Identifier value objects
wrap validated strings.

Unit and precision of every field is documented on the class docstring.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import ROUND_FLOOR, Decimal
from typing import Final

from polymarket_pair_bot.domain.precision import (
    PRICE_MAX,
    PRICE_MIN,
    USDC_BASE_UNITS_PER_USD,
    coerce_decimal,
)

_HEX_ADDRESS_RE: Final = re.compile(r"^0x[0-9a-fA-F]{40}$")
_HEX_BYTES32_RE: Final = re.compile(r"^0x[0-9a-fA-F]{64}$")
_UINT_STR_RE: Final = re.compile(r"^[0-9]+$")

_BPS_DENOMINATOR: Final = Decimal(10000)


# --------------------------------------------------------------------------- #
# Decimal-backed value objects
# --------------------------------------------------------------------------- #
@dataclass(frozen=True, slots=True)
class ProbabilityPrice:
    """A binary-outcome price / implied probability.

    Unit: USD per 1 share (equivalently the implied probability). Range: the
    inclusive interval [0, 1]. Precision: exact ``Decimal``; canonical display
    quantum 1e-6.
    """

    value: Decimal

    def __init__(self, value: Decimal | int | str) -> None:
        coerced = coerce_decimal(value)
        if coerced < PRICE_MIN or coerced > PRICE_MAX:
            raise ValueError(f"price {coerced} outside supported range [0, 1]")
        object.__setattr__(self, "value", coerced)

    def __str__(self) -> str:
        return format(self.value, "f")


@dataclass(frozen=True, slots=True)
class Shares:
    """A quantity of outcome tokens (shares).

    Unit: outcome-token shares. Precision: exact ``Decimal``; canonical quantum
    1e-6. Constraint: non-negative. Use ``require_positive`` where a strictly
    positive quantity is mandatory (e.g. an order size).
    """

    value: Decimal

    def __init__(self, value: Decimal | int | str) -> None:
        coerced = coerce_decimal(value)
        if coerced < 0:
            raise ValueError(f"shares must be non-negative, got {coerced}")
        object.__setattr__(self, "value", coerced)

    @property
    def is_positive(self) -> bool:
        return self.value > 0

    def require_positive(self) -> Shares:
        if self.value <= 0:
            raise ValueError("shares must be strictly positive")
        return self

    def __str__(self) -> str:
        return format(self.value, "f")


@dataclass(frozen=True, slots=True)
class CollateralAmount:
    """An amount of USDC collateral.

    Unit: USD (1 USD == 1e6 integer base units / micro-USDC). Precision: exact
    ``Decimal``; canonical quantum 1e-6. Constraint: non-negative.
    """

    value: Decimal

    def __init__(self, value: Decimal | int | str) -> None:
        coerced = coerce_decimal(value)
        if coerced < 0:
            raise ValueError(f"collateral must be non-negative, got {coerced}")
        object.__setattr__(self, "value", coerced)

    @property
    def base_units(self) -> int:
        """Integer micro-USDC (floored); use for on-chain base-unit math."""
        scaled = self.value * USDC_BASE_UNITS_PER_USD
        return int(scaled.to_integral_value(rounding=ROUND_FLOOR))

    def __str__(self) -> str:
        return format(self.value, "f")


@dataclass(frozen=True, slots=True)
class FeeAmount:
    """A fee expressed in USD.

    Unit: USD. Precision: exact ``Decimal``; canonical quantum 1e-6. Constraint:
    non-negative (fees are never credits in this domain).
    """

    value: Decimal

    def __init__(self, value: Decimal | int | str) -> None:
        coerced = coerce_decimal(value)
        if coerced < 0:
            raise ValueError(f"fee must be non-negative, got {coerced}")
        object.__setattr__(self, "value", coerced)

    def __str__(self) -> str:
        return format(self.value, "f")


@dataclass(frozen=True, slots=True)
class ProfitAmount:
    """A profit or loss expressed in USD.

    Unit: USD. Precision: exact ``Decimal``; canonical quantum 1e-6. May be
    negative (a loss). This type never asserts profitability.
    """

    value: Decimal

    def __init__(self, value: Decimal | int | str) -> None:
        object.__setattr__(self, "value", coerce_decimal(value))

    @property
    def is_loss(self) -> bool:
        return self.value < 0

    def __str__(self) -> str:
        return format(self.value, "f")


@dataclass(frozen=True, slots=True)
class BasisPoints:
    """A rate in basis points.

    Unit: basis points (1 bp == 1e-4 as a fraction). Precision: exact
    ``Decimal``; canonical quantum 1e-2. Constraint: non-negative.
    """

    value: Decimal

    def __init__(self, value: Decimal | int | str) -> None:
        coerced = coerce_decimal(value)
        if coerced < 0:
            raise ValueError(f"basis points must be non-negative, got {coerced}")
        object.__setattr__(self, "value", coerced)

    def as_fraction(self) -> Decimal:
        """Return the rate as a plain fraction (bps / 10_000)."""
        return self.value / _BPS_DENOMINATOR

    def __str__(self) -> str:
        return format(self.value, "f")


@dataclass(frozen=True, slots=True)
class TickSize:
    """The minimum price increment of a market.

    Unit: price (same units as :class:`ProbabilityPrice`). Precision: exact
    ``Decimal``. Constraint: strictly positive and no greater than 1.
    """

    value: Decimal

    def __init__(self, value: Decimal | int | str) -> None:
        coerced = coerce_decimal(value)
        if coerced <= 0 or coerced > 1:
            raise ValueError(f"tick size must be in (0, 1], got {coerced}")
        object.__setattr__(self, "value", coerced)

    def __str__(self) -> str:
        return format(self.value, "f")


@dataclass(frozen=True, slots=True)
class UnixTimestamp:
    """A UTC instant expressed as whole seconds since the Unix epoch.

    Unit: integer seconds (UTC). Precision: 1 second. Constraint: non-negative.
    """

    value: int

    def __init__(self, value: int) -> None:
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError("unix timestamp must be an int number of seconds")
        if value < 0:
            raise ValueError("unix timestamp must be non-negative")
        object.__setattr__(self, "value", value)

    @classmethod
    def from_datetime(cls, moment: datetime) -> UnixTimestamp:
        if moment.tzinfo is None:
            raise ValueError("datetime must be timezone-aware")
        return cls(int(moment.timestamp()))

    def to_datetime(self) -> datetime:
        return datetime.fromtimestamp(self.value, tz=UTC)

    def __str__(self) -> str:
        return str(self.value)


# --------------------------------------------------------------------------- #
# Identifier value objects
# --------------------------------------------------------------------------- #
def _require_nonempty(kind: str, value: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{kind} must be a string")
    stripped = value.strip()
    if not stripped:
        raise ValueError(f"{kind} must not be empty")
    return stripped


@dataclass(frozen=True, slots=True)
class TokenId:
    """A CLOB/ERC-1155 outcome-token id.

    Unit: opaque identifier; canonically the base-10 string of a uint256.
    """

    value: str

    def __init__(self, value: str) -> None:
        cleaned = _require_nonempty("token id", value)
        if not _UINT_STR_RE.match(cleaned):
            raise ValueError("token id must be a base-10 unsigned integer string")
        object.__setattr__(self, "value", cleaned)

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, slots=True)
class MarketId:
    """A Polymarket market identifier (opaque string)."""

    value: str

    def __init__(self, value: str) -> None:
        object.__setattr__(self, "value", _require_nonempty("market id", value))

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, slots=True)
class ConditionId:
    """A CTF condition id (bytes32, ``0x`` + 64 hex chars)."""

    value: str

    def __init__(self, value: str) -> None:
        cleaned = _require_nonempty("condition id", value)
        if not _HEX_BYTES32_RE.match(cleaned):
            raise ValueError("condition id must be 0x + 64 hex characters")
        object.__setattr__(self, "value", cleaned.lower())

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, slots=True)
class OrderId:
    """An exchange or client order identifier (opaque string)."""

    value: str

    def __init__(self, value: str) -> None:
        object.__setattr__(self, "value", _require_nonempty("order id", value))

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, slots=True)
class FillId:
    """A trade/fill identifier (opaque string).

    Fill messages are NOT assumed unique; de-duplication by this id is the
    caller's responsibility in later modules.
    """

    value: str

    def __init__(self, value: str) -> None:
        object.__setattr__(self, "value", _require_nonempty("fill id", value))

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, slots=True)
class WalletAddress:
    """An EVM wallet address (``0x`` + 40 hex chars).

    Stored lower-cased. Checksum validation is deferred to the blockchain
    module where an Ethereum library is available.
    """

    value: str

    def __init__(self, value: str) -> None:
        cleaned = _require_nonempty("wallet address", value)
        if not _HEX_ADDRESS_RE.match(cleaned):
            raise ValueError("wallet address must be 0x + 40 hex characters")
        object.__setattr__(self, "value", cleaned.lower())

    def __str__(self) -> str:
        return self.value


__all__ = [
    "BasisPoints",
    "CollateralAmount",
    "ConditionId",
    "FeeAmount",
    "FillId",
    "MarketId",
    "OrderId",
    "ProbabilityPrice",
    "ProfitAmount",
    "Shares",
    "TickSize",
    "TokenId",
    "UnixTimestamp",
    "WalletAddress",
]
