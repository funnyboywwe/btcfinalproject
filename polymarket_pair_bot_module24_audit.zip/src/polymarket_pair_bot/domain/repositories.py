"""Repository protocols (ports) for the persistence layer.

These Protocols live in the **domain** layer so that domain and strategy code
depends only on abstract interfaces -- never on SQLAlchemy, asyncpg, Alembic, or
any concrete persistence class (dependency inversion). Module 3 provides the
SQLAlchemy implementations in :mod:`polymarket_pair_bot.persistence`.

Every monetary / quantity value that crosses these interfaces is a domain value
object backed by ``Decimal`` (never a binary float). Timestamps are
:class:`UnixTimestamp` (integer seconds, UTC).

This module imports only the standard library and the pure domain package, so it
is safe to import from strategy code without pulling in infrastructure.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from types import TracebackType
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    CtfOperation,
    ExchangeOrder,
    Fill,
    InventorySnapshot,
    MarketWindow,
    MatchedPair,
    OrderIntent,
    PairOpportunity,
    ReconciliationResult,
    RiskDecision,
)
from polymarket_pair_bot.domain.value_objects import (
    ConditionId,
    FillId,
    MarketId,
    OrderId,
    UnixTimestamp,
)

# JSON-serializable audit payload values (secret-free by contract).
JsonScalar = str | int | bool | None
JsonValue = JsonScalar | Sequence["JsonValue"] | Mapping[str, "JsonValue"]


@runtime_checkable
class MarketRepository(Protocol):
    """Persist binary market definitions (idempotent upserts by market id)."""

    async def upsert_market(self, market: BinaryMarket) -> None: ...

    async def get_market(self, market_id: MarketId) -> BinaryMarket | None: ...


@runtime_checkable
class MarketWindowRepository(Protocol):
    """Persist BTC 5-minute market windows (idempotent by market id)."""

    async def upsert_window(self, window: MarketWindow) -> None: ...

    async def get_window(self, market_id: MarketId) -> MarketWindow | None: ...


@runtime_checkable
class OrderIntentRepository(Protocol):
    """Persist order intents keyed by their client idempotency key."""

    async def add(self, intent: OrderIntent) -> bool:
        """Insert an intent. Returns False if the idempotency key already exists."""
        ...

    async def get(self, intent_id: str) -> OrderIntent | None: ...


@runtime_checkable
class ExchangeOrderRepository(Protocol):
    """Persist exchange orders keyed by exchange order id."""

    async def upsert(self, order: ExchangeOrder) -> None: ...

    async def get(self, order_id: OrderId) -> ExchangeOrder | None: ...

    async def list_open(self, market_id: MarketId) -> Sequence[ExchangeOrder]: ...


@runtime_checkable
class FillRepository(Protocol):
    """Persist confirmed fills with idempotent insertion."""

    async def insert_idempotent(self, fill: Fill) -> bool:
        """Insert a fill. Returns True only when newly inserted (idempotent)."""
        ...

    async def get(self, fill_id: FillId) -> Fill | None: ...

    async def list_for_order(self, order_id: OrderId) -> Sequence[Fill]: ...


@runtime_checkable
class InventoryRepository(Protocol):
    """Append-only per-market inventory snapshots."""

    async def append_snapshot(self, snapshot: InventorySnapshot) -> int: ...

    async def get_latest(self, market_id: MarketId) -> InventorySnapshot | None: ...


@runtime_checkable
class PairOpportunityRepository(Protocol):
    """Append-only detected pair opportunities (high volume; retained)."""

    async def add(self, opportunity: PairOpportunity) -> int: ...

    async def list_recent(
        self, market_id: MarketId, *, limit: int = 100
    ) -> Sequence[PairOpportunity]: ...


@runtime_checkable
class MatchedPairRepository(Protocol):
    """Persist confirmed matched Up/Down pairs."""

    async def add(self, pair: MatchedPair) -> int: ...

    async def list_for_market(self, market_id: MarketId) -> Sequence[MatchedPair]: ...


@runtime_checkable
class CtfOperationRepository(Protocol):
    """Persist CTF split/merge/redeem operations (idempotent by operation id)."""

    async def upsert(self, operation: CtfOperation) -> None: ...

    async def get(self, operation_id: str) -> CtfOperation | None: ...


@runtime_checkable
class BlockchainTransactionRepository(Protocol):
    """Persist blockchain transactions keyed by a blockchain operation key.

    ``operation_key`` is the idempotency key for an on-chain action; a second
    call with the same key must not create a duplicate row.
    """

    async def record(
        self,
        *,
        operation_key: str,
        chain_id: int,
        status: str,
        created_at: UnixTimestamp,
        operation_id: str | None = None,
        tx_hash: str | None = None,
    ) -> bool:
        """Insert a transaction. Returns True only when newly inserted."""
        ...

    async def get(self, operation_key: str) -> Mapping[str, JsonValue] | None: ...


@runtime_checkable
class ReconciliationRepository(Protocol):
    """Persist reconciliation runs and their discrepancies."""

    async def record_run(self, result: ReconciliationResult) -> int:
        """Persist a run plus its discrepancies; returns the run id."""
        ...


@runtime_checkable
class RiskEventRepository(Protocol):
    """Persist risk-engine decisions (idempotent by decision id)."""

    async def record(self, decision: RiskDecision) -> bool:
        """Insert a decision. Returns False if the decision id already exists."""
        ...

    async def get(self, decision_id: str) -> RiskDecision | None: ...


@runtime_checkable
class KillSwitchEventRepository(Protocol):
    """Append-only journal of kill-switch state transitions."""

    async def record(
        self,
        *,
        key: str,
        active: bool,
        reason: str,
        created_at: UnixTimestamp,
        actor: str | None = None,
    ) -> int: ...


@runtime_checkable
class AuditJournal(Protocol):
    """Append-only, secret-free audit event journal (``system_events``)."""

    async def append_event(
        self,
        *,
        event_type: str,
        severity: str,
        created_at: UnixTimestamp,
        payload: Mapping[str, JsonValue] | None = None,
    ) -> int: ...


@runtime_checkable
class UnitOfWork(Protocol):
    """Transactional unit of work aggregating every repository.

    A unit of work owns a single database transaction. Repository mutations are
    staged and only become durable on :meth:`commit`; :meth:`rollback` (or an
    exception escaping the ``async with`` block) discards them. This is how
    order-state, fill and inventory changes commit atomically.
    """

    markets: MarketRepository
    windows: MarketWindowRepository
    intents: OrderIntentRepository
    orders: ExchangeOrderRepository
    fills: FillRepository
    inventory: InventoryRepository
    opportunities: PairOpportunityRepository
    matched_pairs: MatchedPairRepository
    ctf_operations: CtfOperationRepository
    blockchain: BlockchainTransactionRepository
    reconciliation: ReconciliationRepository
    risk_events: RiskEventRepository
    kill_switch: KillSwitchEventRepository
    audit: AuditJournal

    async def __aenter__(self) -> UnitOfWork: ...

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> bool | None: ...

    async def commit(self) -> None: ...

    async def rollback(self) -> None: ...

    async def record_fill_and_update_inventory(
        self,
        fill: Fill,
        resulting_inventory: InventorySnapshot,
        order: ExchangeOrder | None = None,
    ) -> bool:
        """Atomically record a fill and, only if it is new, apply inventory.

        Returns True when the fill was newly recorded (inventory snapshot and,
        if provided, the order state were persisted in the same transaction).
        Returns False when the ``fill_id`` was already present, in which case
        inventory is left unchanged -- duplicate fills never alter inventory
        twice.
        """
        ...


@runtime_checkable
class UnitOfWorkFactory(Protocol):
    """Factory that opens a fresh :class:`UnitOfWork` (and its transaction)."""

    def __call__(self) -> UnitOfWork: ...


__all__ = [
    "AuditJournal",
    "BlockchainTransactionRepository",
    "CtfOperationRepository",
    "ExchangeOrderRepository",
    "FillRepository",
    "InventoryRepository",
    "JsonScalar",
    "JsonValue",
    "KillSwitchEventRepository",
    "MarketRepository",
    "MarketWindowRepository",
    "MatchedPairRepository",
    "OrderIntentRepository",
    "PairOpportunityRepository",
    "ReconciliationRepository",
    "RiskEventRepository",
    "UnitOfWork",
    "UnitOfWorkFactory",
]

# Silence "imported but unused" for identifiers used only in annotations above
# when checked by tools that do not resolve string annotations.
_ANNOTATION_ONLY = (ConditionId,)
