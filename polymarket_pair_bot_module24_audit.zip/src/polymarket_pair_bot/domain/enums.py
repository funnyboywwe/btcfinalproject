"""Domain enumerations.

All values are stable string codes safe for serialization and persistence.
"""

from __future__ import annotations

from enum import Enum


class OutcomeSide(str, Enum):
    """Which side of a binary BTC 5-minute market a token represents."""

    UP = "up"
    DOWN = "down"


class OrderSide(str, Enum):
    """Order direction. The accumulation strategy only ever buys to acquire."""

    BUY = "buy"
    SELL = "sell"


class TimeInForce(str, Enum):
    """Supported time-in-force policies."""

    GTC = "gtc"
    IOC = "ioc"
    FOK = "fok"
    GTD = "gtd"


class OrderStatus(str, Enum):
    """Lifecycle status of an exchange order.

    Only ``FILLED`` means the full quantity is confirmed executed. A matched
    pair is NEVER inferred from ``SUBMITTED``, ``ACKNOWLEDGED``, ``OPEN`` or
    ``PARTIALLY_FILLED``. ``UNKNOWN`` requires reconciliation.
    """

    PENDING_SUBMIT = "pending_submit"
    SUBMITTED = "submitted"
    ACKNOWLEDGED = "acknowledged"
    OPEN = "open"
    PARTIALLY_FILLED = "partially_filled"
    FILLED = "filled"
    CANCELED = "canceled"
    REJECTED = "rejected"
    EXPIRED = "expired"
    UNKNOWN = "unknown"

    @property
    def is_terminal(self) -> bool:
        """True when no further state transitions are expected."""
        return self in {
            OrderStatus.FILLED,
            OrderStatus.CANCELED,
            OrderStatus.REJECTED,
            OrderStatus.EXPIRED,
        }

    @property
    def is_confirmed_complete(self) -> bool:
        """True only when the entire order quantity is confirmed filled."""
        return self is OrderStatus.FILLED


class RiskVerdict(str, Enum):
    """Outcome of a centralized risk-engine evaluation."""

    APPROVE = "approve"
    REJECT = "reject"


class CtfOperationType(str, Enum):
    """Conditional Token Framework collateral operations."""

    SPLIT = "split"
    MERGE = "merge"
    REDEEM = "redeem"


class CtfOperationStatus(str, Enum):
    """Lifecycle status of a CTF operation."""

    PENDING = "pending"
    SUBMITTED = "submitted"
    CONFIRMED = "confirmed"
    FAILED = "failed"
    UNKNOWN = "unknown"


class ReconciliationStatus(str, Enum):
    """Result classification for a reconciliation pass."""

    CONSISTENT = "consistent"
    DISCREPANCY = "discrepancy"
    UNKNOWN = "unknown"


__all__ = [
    "CtfOperationStatus",
    "CtfOperationType",
    "OrderSide",
    "OrderStatus",
    "OutcomeSide",
    "ReconciliationStatus",
    "RiskVerdict",
    "TimeInForce",
]
