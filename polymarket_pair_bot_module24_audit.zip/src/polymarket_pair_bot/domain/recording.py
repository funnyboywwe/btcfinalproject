"""Pure record types for the research-grade market-data recorder (Module 7).

This module is part of the pure domain layer: it must not import HTTP or
WebSocket clients, SQLAlchemy, blockchain clients, ``pyarrow`` or environment
access. It defines the immutable value types that the recorder produces and
the queryable summary DTO that crosses the persistence boundary.

Monetary values (prices, sizes, spreads, executable pair cost) are ``Decimal``
or ``None`` -- never binary floats. ``age_seconds`` is a freshness *duration*
(seconds), which is explicitly allowed to be a plain ``float`` and is never used
as money.

The recorder is a read-only research tool: it observes the local Up/Down books
and never derives an order, and none of these types assert profitability.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum


class SnapshotTrigger(str, Enum):
    """Why a book snapshot was captured.

    * ``PERIODIC`` -- the fixed one-second sampling cadence fired.
    * ``BEST_BID_CHANGE`` / ``BEST_ASK_CHANGE`` -- a top-of-book price moved.
    * ``SPREAD_CHANGE`` -- the best bid/ask spread changed on either side.
    * ``PAIR_COST_CROSS`` -- the executable pair cost crossed a configured
      level (in either direction).
    * ``FEED_STALE`` -- a side stopped being LIVE (stale/unavailable).
    * ``FEED_RECOVER`` -- a side returned to LIVE after not being LIVE.
    """

    PERIODIC = "periodic"
    BEST_BID_CHANGE = "best_bid_change"
    BEST_ASK_CHANGE = "best_ask_change"
    SPREAD_CHANGE = "spread_change"
    PAIR_COST_CROSS = "pair_cost_cross"
    FEED_STALE = "feed_stale"
    FEED_RECOVER = "feed_recover"


@dataclass(frozen=True, slots=True)
class DataQualityFlags:
    """Per-side data-quality markers captured alongside a snapshot.

    All fields are booleans describing the state of one token's local book at
    capture time. ``is_clean`` is a convenience roll-up: a usable, fresh,
    two-sided, uncrossed book with an exchange timestamp.
    """

    has_snapshot: bool
    is_live: bool
    is_stale: bool
    is_unavailable: bool
    is_crossed: bool
    is_empty: bool
    missing_best_bid: bool
    missing_best_ask: bool
    missing_exchange_timestamp: bool

    @property
    def is_clean(self) -> bool:
        """True only when nothing suspicious was observed for this side."""
        return (
            self.has_snapshot
            and self.is_live
            and not self.is_stale
            and not self.is_unavailable
            and not self.is_crossed
            and not self.is_empty
            and not self.missing_best_bid
            and not self.missing_best_ask
            and not self.missing_exchange_timestamp
        )


@dataclass(frozen=True, slots=True)
class RecordedLevel:
    """A single recorded order-book level.

    ``price`` and ``size`` are exact ``Decimal`` values (never binary floats).
    """

    price: Decimal
    size: Decimal


@dataclass(frozen=True, slots=True)
class RecordedBookSide:
    """One side (Up or Down) of a captured pair snapshot.

    Depth (``bids`` / ``asks``) is already truncated to the configured top-N
    levels by the recorder. ``bid_levels_count`` / ``ask_levels_count`` and the
    depth totals reflect the *full* book the manager held, so callers can tell
    when the recorded depth was truncated.
    """

    side: str
    token_id: str
    status: str
    best_bid: Decimal | None
    best_ask: Decimal | None
    best_bid_size: Decimal | None
    best_ask_size: Decimal | None
    spread: Decimal | None
    mid: Decimal | None
    bid_levels_count: int
    ask_levels_count: int
    bid_depth_total: Decimal
    ask_depth_total: Decimal
    bids: tuple[RecordedLevel, ...]
    asks: tuple[RecordedLevel, ...]
    exchange_timestamp_ms: int | None
    local_receipt_epoch: int | None
    processed_epoch: int | None
    age_seconds: float | None
    flags: DataQualityFlags


@dataclass(frozen=True, slots=True)
class RecordedPairSnapshot:
    """A single point-in-time capture of both the Up and Down books.

    Fields:
        window_id: identifier for the market window being recorded (typically
            the market id / slug); groups files and rows.
        market_slug: human-readable slug when known.
        sequence: monotonic per-recorder counter (starts at 0).
        capture_epoch: recorder wall-clock capture time (UTC seconds).
        triggers: non-empty ordered, de-duplicated tuple of reasons this
            snapshot was captured.
        up / down: the two recorded book sides.
        executable_pair_cost: top-of-book cost to acquire one Up+Down pair by
            taking the best asks (``up.best_ask + down.best_ask``) when both are
            present; ``None`` otherwise. This is a research-grade proxy that
            ignores fees, slippage and merge overhead -- it is NOT the
            strategy's ``effective_pair_cost`` and asserts nothing about
            profitability.
        pair_cost_level: the configured level that was crossed, when the
            capture was triggered by ``PAIR_COST_CROSS``.
        top_depth: the configured maximum number of levels recorded per side.
    """

    window_id: str
    market_slug: str | None
    sequence: int
    capture_epoch: int
    triggers: tuple[SnapshotTrigger, ...]
    up: RecordedBookSide
    down: RecordedBookSide
    executable_pair_cost: Decimal | None
    pair_cost_level: Decimal | None
    top_depth: int

    @property
    def trigger_reasons(self) -> str:
        """Comma-joined trigger reason string (stable order)."""
        return ",".join(trigger.value for trigger in self.triggers)


@dataclass(frozen=True, slots=True)
class RecordedSnapshotSummary:
    """A compact, queryable summary of a pair snapshot for PostgreSQL.

    Bulk research fidelity (full depth) lives in Parquet; this row holds only
    the columns useful for filtering/aggregation queries. Monetary fields are
    ``Decimal`` or ``None``.
    """

    window_id: str
    market_slug: str | None
    sequence: int
    capture_epoch: int
    trigger_reasons: str
    up_token_id: str
    down_token_id: str
    up_status: str
    down_status: str
    up_best_bid: Decimal | None
    up_best_ask: Decimal | None
    up_spread: Decimal | None
    down_best_bid: Decimal | None
    down_best_ask: Decimal | None
    down_spread: Decimal | None
    executable_pair_cost: Decimal | None
    pair_cost_level: Decimal | None
    up_is_live: bool
    down_is_live: bool
    any_stale: bool
    any_crossed: bool
    up_exchange_timestamp_ms: int | None
    down_exchange_timestamp_ms: int | None


def summary_from_snapshot(snapshot: RecordedPairSnapshot) -> RecordedSnapshotSummary:
    """Project a full :class:`RecordedPairSnapshot` into its queryable summary."""
    up = snapshot.up
    down = snapshot.down
    return RecordedSnapshotSummary(
        window_id=snapshot.window_id,
        market_slug=snapshot.market_slug,
        sequence=snapshot.sequence,
        capture_epoch=snapshot.capture_epoch,
        trigger_reasons=snapshot.trigger_reasons,
        up_token_id=up.token_id,
        down_token_id=down.token_id,
        up_status=up.status,
        down_status=down.status,
        up_best_bid=up.best_bid,
        up_best_ask=up.best_ask,
        up_spread=up.spread,
        down_best_bid=down.best_bid,
        down_best_ask=down.best_ask,
        down_spread=down.spread,
        executable_pair_cost=snapshot.executable_pair_cost,
        pair_cost_level=snapshot.pair_cost_level,
        up_is_live=up.flags.is_live,
        down_is_live=down.flags.is_live,
        any_stale=up.flags.is_stale or down.flags.is_stale,
        any_crossed=up.flags.is_crossed or down.flags.is_crossed,
        up_exchange_timestamp_ms=up.exchange_timestamp_ms,
        down_exchange_timestamp_ms=down.exchange_timestamp_ms,
    )


__all__ = [
    "DataQualityFlags",
    "RecordedBookSide",
    "RecordedLevel",
    "RecordedPairSnapshot",
    "RecordedSnapshotSummary",
    "SnapshotTrigger",
    "summary_from_snapshot",
]
