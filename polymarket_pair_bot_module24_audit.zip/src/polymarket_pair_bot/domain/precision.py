"""Fixed-point (Decimal) precision policy and safe arithmetic primitives.

Money, prices, probabilities, quantities, fees, slippage and P&L are ALWAYS
``Decimal`` — never binary floats. This module centralizes:

* the documented precision (quantums) of each quantity kind;
* a strict ``coerce_decimal`` that refuses to build a ``Decimal`` from a float;
* deterministic quantization and tick-size rounding;
* conservative rounding (fees UP, expected profit DOWN).

Precision / units (canonical quantums)
--------------------------------------
* Price / probability : 1e-6 (``PRICE_QUANTUM``), range [0, 1].
* Shares (outcome tokens): 1e-6 (``SHARES_QUANTUM``).
* USD collateral / fees / P&L: 1e-6 (``USD_QUANTUM``); USDC has 6 on-chain
  decimals, so 1e-6 USD == 1 integer base unit (micro-USDC).
* Basis points        : 1e-2 (``BPS_QUANTUM``); 1 bp == 1e-4 as a fraction.

Intermediate calculations run in a 50-significant-digit context and only the
final result is quantized, so rounding is applied exactly once and predictably.
"""

from __future__ import annotations

from decimal import (
    ROUND_CEILING,
    ROUND_DOWN,
    ROUND_FLOOR,
    ROUND_HALF_EVEN,
    ROUND_UP,
    Context,
    Decimal,
    InvalidOperation,
    localcontext,
)
from typing import Final

# Significant digits for intermediate math (not the number of decimal places).
DECIMAL_COMPUTATION_PRECISION: Final = 50

# Canonical quantums (documented decimal places per quantity kind).
PRICE_QUANTUM: Final = Decimal("0.000001")  # 1e-6
SHARES_QUANTUM: Final = Decimal("0.000001")  # 1e-6
USD_QUANTUM: Final = Decimal("0.000001")  # 1e-6 (== 1 micro-USDC)
BPS_QUANTUM: Final = Decimal("0.01")  # 1e-2 basis points

# Supported inclusive price range for a probability price.
PRICE_MIN: Final = Decimal(0)
PRICE_MAX: Final = Decimal(1)

# On-chain USDC precision. 1 USD == 10**USDC_DECIMALS integer base units.
USDC_DECIMALS: Final = 6
USDC_BASE_UNITS_PER_USD: Final = Decimal(10) ** USDC_DECIMALS

# One complete Up/Down pair merges to exactly $1 of collateral.
DOLLAR: Final = Decimal(1)


def computation_context() -> Context:
    """Return a fresh high-precision Decimal context for intermediate math."""
    return Context(prec=DECIMAL_COMPUTATION_PRECISION)


def coerce_decimal(value: Decimal | int | str) -> Decimal:
    """Coerce a value to ``Decimal`` without ever accepting a float.

    Accepts ``Decimal``, ``int`` or ``str`` (a base-10 decimal string). Floats
    and booleans are rejected to prevent silent binary-float imprecision.
    """
    if isinstance(value, bool):
        raise TypeError("bool is not a valid Decimal source")
    if isinstance(value, float):
        raise TypeError(
            "refusing to build Decimal from float; pass a str, int or Decimal"
        )
    if isinstance(value, Decimal):
        result = value
    elif isinstance(value, int):
        result = Decimal(value)
    elif isinstance(value, str):
        try:
            result = Decimal(value)
        except InvalidOperation as exc:
            raise ValueError(f"invalid decimal string: {value!r}") from exc
    else:
        raise TypeError(f"unsupported Decimal source type: {type(value)!r}")
    if not result.is_finite():
        raise ValueError("decimal value must be finite")
    return result


def quantize(value: Decimal, quantum: Decimal, rounding: str) -> Decimal:
    """Quantize ``value`` to ``quantum`` using an explicit rounding mode."""
    with localcontext(computation_context()):
        return value.quantize(quantum, rounding=rounding)


def round_price(value: Decimal, rounding: str = ROUND_HALF_EVEN) -> Decimal:
    """Quantize a price to the canonical price quantum."""
    return quantize(value, PRICE_QUANTUM, rounding)


def round_shares(value: Decimal, rounding: str = ROUND_DOWN) -> Decimal:
    """Quantize shares to the canonical share quantum (default rounds down)."""
    return quantize(value, SHARES_QUANTUM, rounding)


def round_usd(value: Decimal, rounding: str = ROUND_HALF_EVEN) -> Decimal:
    """Quantize a USD amount to the canonical USD quantum."""
    return quantize(value, USD_QUANTUM, rounding)


def round_fee_up(value: Decimal) -> Decimal:
    """Conservatively round a fee toward +infinity (never under-charge)."""
    return quantize(value, USD_QUANTUM, ROUND_CEILING)


def round_profit_down(value: Decimal) -> Decimal:
    """Conservatively round an expected profit toward -infinity."""
    return quantize(value, USD_QUANTUM, ROUND_FLOOR)


def round_to_tick(value: Decimal, tick: Decimal, rounding: str) -> Decimal:
    """Deterministically round ``value`` to a multiple of ``tick``.

    The result is ``round(value / tick) * tick`` under the given rounding mode,
    re-quantized to the tick's own exponent so the output is tick-aligned.
    """
    if tick <= 0:
        raise ValueError("tick must be positive")
    with localcontext(computation_context()):
        steps = (value / tick).quantize(Decimal(1), rounding=rounding)
        return (steps * tick).quantize(tick)


def round_down_to_tick(value: Decimal, tick: Decimal) -> Decimal:
    """Round a value down to the nearest tick (toward -infinity)."""
    return round_to_tick(value, tick, ROUND_FLOOR)


def round_up_to_tick(value: Decimal, tick: Decimal) -> Decimal:
    """Round a value up to the nearest tick (toward +infinity)."""
    return round_to_tick(value, tick, ROUND_CEILING)


def nearest_tick(value: Decimal, tick: Decimal) -> Decimal:
    """Round a value to the nearest tick, ties to even."""
    return round_to_tick(value, tick, ROUND_HALF_EVEN)


__all__ = [
    "BPS_QUANTUM",
    "DECIMAL_COMPUTATION_PRECISION",
    "DOLLAR",
    "PRICE_MAX",
    "PRICE_MIN",
    "PRICE_QUANTUM",
    "ROUND_CEILING",
    "ROUND_DOWN",
    "ROUND_FLOOR",
    "ROUND_HALF_EVEN",
    "ROUND_UP",
    "SHARES_QUANTUM",
    "USDC_BASE_UNITS_PER_USD",
    "USDC_DECIMALS",
    "USD_QUANTUM",
    "coerce_decimal",
    "computation_context",
    "nearest_tick",
    "quantize",
    "round_down_to_tick",
    "round_fee_up",
    "round_price",
    "round_profit_down",
    "round_shares",
    "round_to_tick",
    "round_up_to_tick",
    "round_usd",
]
