"""Serialization helpers for domain value objects and entities.

Rules:
* ``Decimal`` is serialized as a base-10 string (never a float) so no binary
  imprecision is introduced on the wire or on disk.
* ``Enum`` members serialize to their ``.value``.
* Dataclasses serialize recursively to plain JSON-safe dicts.

``to_jsonable`` / ``dumps`` cover every domain type generically. Explicit
round-trip constructors are provided for the Decimal-backed value objects,
which are the values later persistence/coordination modules exchange most.
"""

from __future__ import annotations

import dataclasses
import json
from decimal import Decimal
from enum import Enum
from typing import Any

from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    FeeAmount,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TickSize,
    UnixTimestamp,
)


def to_jsonable(value: Any) -> Any:
    """Recursively convert a domain object to JSON-safe primitives.

    Decimals become strings, enums become their values, dataclasses become
    dicts, and tuples/lists/sets become lists.
    """
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, Enum):
        return value.value
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return {
            f.name: to_jsonable(getattr(value, f.name))
            for f in dataclasses.fields(value)
        }
    if isinstance(value, (list, tuple, set)):
        return [to_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(k): to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (str, int, bool)) or value is None:
        return value
    raise TypeError(f"cannot serialize value of type {type(value)!r}")


def dumps(value: Any, *, sort_keys: bool = True) -> str:
    """Serialize a domain object to a deterministic JSON string."""
    return json.dumps(to_jsonable(value), sort_keys=sort_keys, separators=(",", ":"))


# --------------------------------------------------------------------------- #
# Explicit round-trip constructors for Decimal-backed value objects.
# --------------------------------------------------------------------------- #
def probability_price_from_str(raw: str) -> ProbabilityPrice:
    return ProbabilityPrice(Decimal(raw))


def shares_from_str(raw: str) -> Shares:
    return Shares(Decimal(raw))


def collateral_from_str(raw: str) -> CollateralAmount:
    return CollateralAmount(Decimal(raw))


def fee_from_str(raw: str) -> FeeAmount:
    return FeeAmount(Decimal(raw))


def profit_from_str(raw: str) -> ProfitAmount:
    return ProfitAmount(Decimal(raw))


def basis_points_from_str(raw: str) -> BasisPoints:
    return BasisPoints(Decimal(raw))


def tick_size_from_str(raw: str) -> TickSize:
    return TickSize(Decimal(raw))


def unix_timestamp_from_int(raw: int) -> UnixTimestamp:
    return UnixTimestamp(raw)


__all__ = [
    "basis_points_from_str",
    "collateral_from_str",
    "dumps",
    "fee_from_str",
    "probability_price_from_str",
    "profit_from_str",
    "shares_from_str",
    "tick_size_from_str",
    "to_jsonable",
    "unix_timestamp_from_int",
]
