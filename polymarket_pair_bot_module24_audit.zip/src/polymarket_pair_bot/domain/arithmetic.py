"""Pure fixed-point arithmetic for the pair-accumulation strategy.

Every function here is side-effect free and deterministic. Intermediate math
runs in a high-precision Decimal context (see :mod:`precision`); results are
quantized exactly once with conservative rounding:

* fees round UP (never under-charge);
* expected / locked profit rounds DOWN (never over-state).

Nothing in this module claims the strategy is profitable; the functions only
compute modeled costs and mark-to-executable values.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from decimal import Decimal, localcontext

from polymarket_pair_bot.domain.entities import Fill, PriceLevel
from polymarket_pair_bot.domain.precision import (
    DOLLAR,
    computation_context,
    round_fee_up,
    round_price,
    round_profit_down,
    round_shares,
)
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    FeeAmount,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
)


@dataclass(frozen=True, slots=True)
class ExecutableVwap:
    """Result of walking a book for a target quantity.

    Fields:
        average_price: size-weighted average price over the filled quantity
            (ProbabilityPrice); ``None`` when nothing could be filled.
        filled: quantity that could be filled up to the request (Shares).
        requested: the originally requested quantity (Shares).
        is_complete: True when ``filled == requested``.
    """

    average_price: ProbabilityPrice | None
    filled: Shares
    requested: Shares
    is_complete: bool


def executable_vwap(levels: Sequence[PriceLevel], quantity: Shares) -> ExecutableVwap:
    """Compute the executable VWAP to fill ``quantity`` by walking ``levels``.

    ``levels`` must already be ordered in execution priority (asks ascending to
    buy, bids descending to sell). Liquidity beyond ``quantity`` is ignored. If
    the book is too thin, ``is_complete`` is False and ``average_price`` is the
    VWAP over whatever could be filled (or ``None`` if nothing).
    """
    quantity.require_positive()
    with localcontext(computation_context()):
        target = quantity.value
        remaining = target
        notional = Decimal(0)
        filled = Decimal(0)
        for level in levels:
            if remaining <= 0:
                break
            take = level.size.value if level.size.value < remaining else remaining
            notional += take * level.price.value
            filled += take
            remaining -= take
        if filled <= 0:
            return ExecutableVwap(None, Shares(0), quantity, is_complete=False)
        average = round_price(notional / filled)
    return ExecutableVwap(
        ProbabilityPrice(average),
        Shares(round_shares(filled)),
        quantity,
        is_complete=filled >= target,
    )


def average_acquisition_price(fills: Sequence[Fill]) -> ProbabilityPrice:
    """Size-weighted average price across confirmed fills.

    Raises ``ValueError`` when there are no fills or total size is zero.
    """
    if not fills:
        raise ValueError("cannot average an empty fill sequence")
    with localcontext(computation_context()):
        notional = Decimal(0)
        total = Decimal(0)
        for fill in fills:
            notional += fill.price.value * fill.size.value
            total += fill.size.value
        if total <= 0:
            raise ValueError("total filled size must be positive")
        average = round_price(notional / total)
    return ProbabilityPrice(average)


def taker_fee(notional: CollateralAmount, fee_bps: BasisPoints) -> FeeAmount:
    """Taker fee on a notional, rounded UP (conservative)."""
    with localcontext(computation_context()):
        raw = notional.value * fee_bps.as_fraction()
    return FeeAmount(round_fee_up(raw))


def matched_quantity(up_shares: Shares, down_shares: Shares) -> Shares:
    """The matched pair quantity = min(up, down)."""
    smaller = up_shares.value if up_shares.value <= down_shares.value else down_shares.value
    return Shares(smaller)


def residual_quantity(up_shares: Shares, down_shares: Shares) -> Shares:
    """Unmatched residual = |up - down| (directional exposure not yet paired)."""
    diff = up_shares.value - down_shares.value
    return Shares(diff if diff >= 0 else -diff)


def effective_pair_cost(
    up_acquisition_cost: CollateralAmount,
    down_acquisition_cost: CollateralAmount,
    taker_fees: FeeAmount,
    expected_slippage: CollateralAmount,
    merge_or_gas_overhead: CollateralAmount,
    safety_reserve: CollateralAmount,
) -> CollateralAmount:
    """All-in modeled cost to acquire one matched pair.

    Sum of the strategy's documented cost components, rounded UP (conservative:
    never understate cost). Making no profitability claim.
    """
    with localcontext(computation_context()):
        total = (
            up_acquisition_cost.value
            + down_acquisition_cost.value
            + taker_fees.value
            + expected_slippage.value
            + merge_or_gas_overhead.value
            + safety_reserve.value
        )
    return CollateralAmount(round_fee_up(total))


def locked_pair_value(pairs: Shares) -> CollateralAmount:
    """Collateral recoverable by merging complete pairs: pairs * $1.

    Only meaningful for pairs built from confirmed fills.
    """
    with localcontext(computation_context()):
        value = pairs.value * DOLLAR
    return CollateralAmount(value)


def locked_net_profit(
    locked_value: CollateralAmount,
    total_cost: CollateralAmount,
) -> ProfitAmount:
    """Locked net profit = locked_value - total_cost, rounded DOWN.

    May be negative. This is a realized-once-merged figure, not a forecast, and
    is not an assertion that the strategy is profitable.
    """
    with localcontext(computation_context()):
        raw = locked_value.value - total_cost.value
    return ProfitAmount(round_profit_down(raw))


def mark_to_executable_bid_pnl(
    quantity: Shares,
    average_cost: ProbabilityPrice,
    executable_bid: ProbabilityPrice,
) -> ProfitAmount:
    """Conservative mark-to-market P&L against the executable bid.

    ``quantity * (executable_bid - average_cost)`` rounded DOWN. Uses the price
    at which the position could actually be sold, not the mid or last.
    """
    with localcontext(computation_context()):
        raw = quantity.value * (executable_bid.value - average_cost.value)
    return ProfitAmount(round_profit_down(raw))


__all__ = [
    "ExecutableVwap",
    "average_acquisition_price",
    "effective_pair_cost",
    "executable_vwap",
    "locked_net_profit",
    "locked_pair_value",
    "mark_to_executable_bid_pnl",
    "matched_quantity",
    "residual_quantity",
    "taker_fee",
]
