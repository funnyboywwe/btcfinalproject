"""Coordination ports (protocols) and pure value objects.

These abstractions live in the **domain** layer so that domain, strategy and
execution code depend only on interfaces -- never on Redis, redis-py, or any
concrete coordination client (dependency inversion). Module 4 provides the
Redis-backed implementations in :mod:`polymarket_pair_bot.coordination`.

Nothing here performs I/O or imports infrastructure. Monetary values are never
binary floats: risk counters use **integer base units** (documented per call
site, e.g. USDC micro-units) and cached tick sizes use ``Decimal``.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Protocol, runtime_checkable


class CoordinationError(RuntimeError):
    """Base class for coordination-layer failures."""


class RedisUnavailableError(CoordinationError):
    """Raised/translated when Redis is unreachable or times out.

    Losing Redis must fail closed: execution is disabled and live trading is
    suspended until leadership can be re-established against a healthy Redis.
    """


@dataclass(frozen=True, slots=True)
class ProcessIdentity:
    """Stable identity for a single bot process, used as a lease owner token.

    The token is intentionally human-readable (``host:pid:uuid``) and contains
    no secrets -- it is safe to log and to display via the operator CLI.
    """

    process_id: str
    hostname: str
    pid: int

    @property
    def token(self) -> str:
        return f"{self.hostname}:{self.pid}:{self.process_id}"


@dataclass(frozen=True, slots=True)
class LeaseStatus:
    """Point-in-time view of an execution-leader lease."""

    scope: str
    owner_token: str | None
    is_self: bool

    @property
    def is_held(self) -> bool:
        return self.owner_token is not None


@dataclass(frozen=True, slots=True)
class KillSwitchState:
    """Persistent kill-switch state (cached in Redis, journaled in Postgres).

    ``updated_at`` is UNIX seconds (UTC) or ``None`` when never set.
    """

    active: bool
    reason: str = ""
    actor: str | None = None
    updated_at: int | None = None


@dataclass(frozen=True, slots=True)
class MarketMetadata:
    """Small, short-lived market descriptor cached for fast lookup.

    This is a cache convenience only; the authoritative record lives in
    PostgreSQL. Tick sizes are ``Decimal`` (never binary floats). ``fetched_at``
    and ``close_time`` are UNIX seconds (UTC).
    """

    market_id: str
    condition_id: str
    up_token_id: str
    down_token_id: str
    up_tick_size: Decimal
    down_tick_size: Decimal
    close_time: int
    fetched_at: int


@runtime_checkable
class ExecutionGateView(Protocol):
    """Read-only view of whether this process may submit new live orders.

    A standby (non-leader) process must observe ``is_enabled is False`` and stay
    read-only. Only the confirmed execution leader enables the gate.
    """

    @property
    def is_enabled(self) -> bool: ...

    @property
    def reason(self) -> str: ...


@runtime_checkable
class LeaderElector(Protocol):
    """Distributed single-owner lease for controlling one wallet's execution."""

    @property
    def scope(self) -> str: ...

    @property
    def token(self) -> str: ...

    async def acquire(self) -> bool:
        """Attempt to acquire the lease. True only if this process now owns it."""
        ...

    async def renew(self) -> bool:
        """Extend the lease, verifying ownership first. False if not owner."""
        ...

    async def release(self) -> None:
        """Release the lease if (and only if) this process owns it."""
        ...

    async def current_owner(self) -> str | None:
        """Return the current owner token, or None if unheld."""
        ...


@runtime_checkable
class LeadershipObserver(Protocol):
    """Callbacks invoked as this process gains or loses execution leadership.

    ``on_demoted`` implementations must treat loss of leadership as unsafe:
    new-order submission is already disabled via the execution gate before this
    is called; implementations must additionally trigger safe cancellation of
    resting orders and a fresh reconciliation against authoritative records.
    """

    async def on_promoted(self) -> None: ...

    async def on_demoted(self, reason: str) -> None: ...


@runtime_checkable
class KillSwitchStore(Protocol):
    """Fast persistent cache of the global kill-switch state."""

    async def get_state(self) -> KillSwitchState: ...

    async def is_active(self) -> bool: ...

    async def activate(
        self, *, reason: str, actor: str | None, at: int
    ) -> KillSwitchState: ...

    async def deactivate(self, *, actor: str | None, at: int) -> KillSwitchState: ...


@runtime_checkable
class MarketMetadataCache(Protocol):
    """Short-lived cache of market metadata (never the source of truth)."""

    async def get(self, market_id: str) -> MarketMetadata | None: ...

    async def put(
        self, metadata: MarketMetadata, *, ttl_seconds: int | None = None
    ) -> None: ...


@runtime_checkable
class RiskCounterStore(Protocol):
    """Atomic counters for the risk engine.

    Counters are integers. Monetary counters MUST be expressed in integer base
    units (e.g. USDC micro-units); never pass binary floats.
    """

    async def increment(
        self, name: str, amount: int = 1, *, ttl_seconds: int | None = None
    ) -> int: ...

    async def get(self, name: str) -> int: ...

    async def reset(self, name: str) -> None: ...


@runtime_checkable
class IdempotencyStore(Protocol):
    """First-writer-wins idempotency keys with a bounded TTL."""

    async def claim(self, key: str, *, ttl_seconds: int) -> bool:
        """Claim a key. True only when newly claimed (idempotent guard)."""
        ...

    async def is_claimed(self, key: str) -> bool: ...


@runtime_checkable
class HeartbeatStore(Protocol):
    """Liveness heartbeats for application components (TTL-expiring)."""

    async def beat(
        self, component: str, *, ttl_seconds: int, detail: str = ""
    ) -> None: ...

    async def is_alive(self, component: str) -> bool: ...

    async def get_detail(self, component: str) -> str | None: ...


__all__ = [
    "CoordinationError",
    "ExecutionGateView",
    "HeartbeatStore",
    "IdempotencyStore",
    "KillSwitchState",
    "KillSwitchStore",
    "LeaderElector",
    "LeadershipObserver",
    "LeaseStatus",
    "MarketMetadata",
    "MarketMetadataCache",
    "ProcessIdentity",
    "RedisUnavailableError",
    "RiskCounterStore",
]
