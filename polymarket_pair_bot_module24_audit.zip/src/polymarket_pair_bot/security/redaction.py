"""Secret redaction utilities used by logging, config summaries and errors.

Safety posture: fail closed. When in doubt, redact. These helpers scrub:

* known-sensitive field **names** (secret, password, token, private_key, ...);
* secret-looking **values** (long hex blobs and opaque tokens); and
* any object exposing ``get_secret_value`` (e.g. pydantic ``SecretStr``).

Redaction is fully recursive over mappings, lists and tuples so nested
configuration structures are safe to log.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any, Final

REDACTED: Final = "***REDACTED***"

# Field-name fragments whose values must never be emitted.
_SECRET_KEY_FRAGMENTS: Final[tuple[str, ...]] = (
    "secret",
    "password",
    "passwd",
    "passphrase",
    "token",
    "api_key",
    "apikey",
    "private_key",
    "privatekey",
    "signature",
    "authorization",
    "mnemonic",
    "seed",
    "credential",
    "dsn",
    "database_url",
    "redis_url",
    "rpc",
    "webhook",
)

# Value patterns that look like secrets regardless of the field name.
_VALUE_PATTERNS: Final[tuple[re.Pattern[str], ...]] = (
    # 32-byte hex blobs: private keys, signature components, tx hashes.
    re.compile(r"0x[0-9a-fA-F]{64}"),
    # Long opaque tokens (base64/base64url/hex-ish) of 40+ characters,
    # including base64 padding/symbol characters (+ / =) so that secrets which
    # contain them are not split into short, unredacted fragments.
    re.compile(r"(?<![A-Za-z0-9_+/=-])[A-Za-z0-9_+/=-]{40,}(?![A-Za-z0-9_+/=-])"),
)


def _is_secret_object(value: Any) -> bool:
    """True for objects that wrap a secret (pydantic SecretStr/SecretBytes)."""
    getter = getattr(value, "get_secret_value", None)
    return callable(getter)


def is_secret_key(key: str) -> bool:
    """Return ``True`` if a mapping key names a sensitive value."""
    lowered = key.lower()
    return any(fragment in lowered for fragment in _SECRET_KEY_FRAGMENTS)


def redact_text(text: str) -> str:
    """Redact secret-looking substrings from arbitrary text."""
    result = text
    for pattern in _VALUE_PATTERNS:
        result = pattern.sub(REDACTED, result)
    return result


def redact_value(key: str | None, value: Any) -> Any:
    """Redact a single value, honoring the owning ``key`` when known."""
    if key is not None and is_secret_key(key):
        return REDACTED
    if _is_secret_object(value):
        return REDACTED
    if isinstance(value, Mapping):
        return redact_mapping(value)
    if isinstance(value, list):
        return [redact_value(None, item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_value(None, item) for item in value)
    if isinstance(value, (bytes, bytearray)):
        # Fail closed: raw bytes in logs are almost always key material or
        # signatures; never emit them verbatim.
        return REDACTED
    if isinstance(value, str):
        return redact_text(value)
    return value


def redact_mapping(mapping: Mapping[str, Any]) -> dict[str, Any]:
    """Return a new mapping with all sensitive keys and values redacted."""
    return {key: redact_value(key, val) for key, val in mapping.items()}
