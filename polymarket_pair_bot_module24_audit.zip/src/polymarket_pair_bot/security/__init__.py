"""Security helpers: secret redaction and related safeguards."""
