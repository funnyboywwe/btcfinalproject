"""Compressed-Parquet bulk sink for recorded snapshots (Module 7).

``pyarrow`` is imported lazily inside methods so that importing this module (or
the wider :mod:`recorder` package) does not require pyarrow to be installed --
only *writing* does. If pyarrow is missing a clear, actionable error is raised.

Blocking Parquet writes are executed via ``asyncio.to_thread`` so they never
run directly on the event loop. Files rotate when the market window changes or
after a configured wall-clock interval, whichever comes first. The Parquet
footer is only written when a file is closed, so ``aclose`` (called during
graceful shutdown) is what makes the current file readable; rotation bounds the
data at risk from a hard kill to a single interval, and ``validate`` detects a
file left without a footer.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import Any

from polymarket_pair_bot.domain.recording import RecordedPairSnapshot
from polymarket_pair_bot.recorder.metrics import RecorderMetrics
from polymarket_pair_bot.recorder.serialization import COLUMN_TYPES, snapshot_to_row

_MISSING_PYARROW = (
    "pyarrow is required for Parquet recording. Install it with "
    "'uv sync' (it is a declared project dependency) or 'uv pip install pyarrow'."
)


def _require_pyarrow() -> Any:
    try:
        import pyarrow as pa
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(_MISSING_PYARROW) from exc
    return pa


def _require_pyarrow_parquet() -> Any:
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(_MISSING_PYARROW) from exc
    return pq


def _arrow_schema(pa: Any) -> Any:
    type_map = {
        "string": pa.string(),
        "int64": pa.int64(),
        "double": pa.float64(),
        "bool": pa.bool_(),
    }
    return pa.schema([pa.field(name, type_map[kind]) for name, kind in COLUMN_TYPES])


def _group_by_window(
    snapshots: Sequence[RecordedPairSnapshot],
) -> Iterable[tuple[str, list[RecordedPairSnapshot]]]:
    group: list[RecordedPairSnapshot] = []
    current: str | None = None
    for snapshot in snapshots:
        if current is None:
            current = snapshot.window_id
        if snapshot.window_id != current:
            yield current, group
            group = []
            current = snapshot.window_id
        group.append(snapshot)
    if group and current is not None:
        yield current, group


class ParquetSnapshotSink:
    """Append-only, rotating, compressed Parquet writer.

    Only the recorder's single writer task calls these methods, and each call
    is awaited, so no additional locking is required.
    """

    def __init__(
        self,
        *,
        output_dir: str | Path,
        rotate_interval_seconds: float,
        compression: str = "zstd",
        metrics: RecorderMetrics | None = None,
        monotonic: Any = None,
    ) -> None:
        if rotate_interval_seconds <= 0:
            raise ValueError("rotate_interval_seconds must be positive")
        self._root = Path(output_dir)
        self._rotate_interval = rotate_interval_seconds
        self._compression = compression
        self._metrics = metrics or RecorderMetrics()
        self._monotonic = monotonic or time.monotonic
        self._writer: Any = None
        self._schema: Any = None
        self._current_window: str | None = None
        self._current_path: Path | None = None
        self._opened_monotonic: float | None = None
        self._file_seq = 0

    @property
    def current_path(self) -> Path | None:
        return self._current_path

    async def write_batch(self, snapshots: Sequence[RecordedPairSnapshot]) -> int:
        if not snapshots:
            return 0
        return await asyncio.to_thread(self._write_sync, list(snapshots))

    async def flush(self) -> None:
        # ParquetWriter streams row groups to the OS on every ``write_table``;
        # there is no partial-footer flush, so this is a no-op. Durability is
        # achieved by rotation + ``aclose``.
        return None

    async def aclose(self) -> None:
        await asyncio.to_thread(self._close_writer)

    def _write_sync(self, snapshots: list[RecordedPairSnapshot]) -> int:
        pa = _require_pyarrow()
        pq = _require_pyarrow_parquet()
        if self._schema is None:
            self._schema = _arrow_schema(pa)
        written = 0
        for window_id, group in _group_by_window(snapshots):
            self._maybe_rotate(window_id, pq)
            rows = [snapshot_to_row(item) for item in group]
            table = pa.Table.from_pylist(rows, schema=self._schema)
            self._writer.write_table(table)
            written += len(rows)
        return written

    def _maybe_rotate(self, window_id: str, pq: Any) -> None:
        now = self._monotonic()
        expired = (
            self._opened_monotonic is not None
            and now - self._opened_monotonic >= self._rotate_interval
        )
        if self._writer is None or window_id != self._current_window or expired:
            self._close_writer()
            self._open_writer(window_id, pq)
            self._opened_monotonic = now

    def _open_writer(self, window_id: str, pq: Any) -> None:
        window_dir = self._root / window_id
        window_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{window_id}__{self._file_seq:06d}.parquet"
        self._file_seq += 1
        path = window_dir / filename
        self._writer = pq.ParquetWriter(
            str(path), self._schema, compression=self._compression
        )
        self._current_window = window_id
        self._current_path = path
        self._metrics.files_rotated += 1

    def _close_writer(self) -> None:
        if self._writer is not None:
            self._writer.close()
            self._writer = None
            self._current_window = None
            self._current_path = None
            self._opened_monotonic = None


__all__ = ["ParquetSnapshotSink"]
