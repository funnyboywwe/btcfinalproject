"""Research-grade market-data recorder (Module 7).

The recorder is a read-only consumer of the local Up/Down order books exposed
by :class:`polymarket_pair_bot.domain.market_data.OrderBookProvider` (Module 6).
It captures periodic and event-driven snapshots, buffers them asynchronously so
it never blocks the WebSocket reader, writes bulk research data to compressed
Parquet files, and writes queryable summaries to PostgreSQL.

This package implements no order execution and derives no trading decisions.

Heavy optional dependencies are imported lazily inside the concrete sinks
(``pyarrow`` in :mod:`recorder.parquet_sink`, SQLAlchemy in
:mod:`recorder.summary_sink`) and by :func:`recorder.factory.build_recorder`, so
importing this package does not require those dependencies to be installed.
"""

from __future__ import annotations

from polymarket_pair_bot.recorder.buffer import BoundedSnapshotBuffer
from polymarket_pair_bot.recorder.config import RecorderRuntimeConfig
from polymarket_pair_bot.recorder.metrics import RecorderMetrics
from polymarket_pair_bot.recorder.ports import (
    SnapshotSink,
    SummarySink,
)
from polymarket_pair_bot.recorder.sampler import (
    SampleDecision,
    SideObservation,
    SnapshotSampler,
)
from polymarket_pair_bot.recorder.service import MarketDataRecorder

__all__ = [
    "BoundedSnapshotBuffer",
    "MarketDataRecorder",
    "RecorderMetrics",
    "RecorderRuntimeConfig",
    "SampleDecision",
    "SideObservation",
    "SnapshotSampler",
    "SnapshotSink",
    "SummarySink",
]
