"""In-process metrics for the market-data recorder (Module 7).

These are plain counters (mirroring ``market_data.FeedMetrics``). Prometheus
wiring is intentionally deferred to the monitoring module (Module 23) so this
package stays importable without the Prometheus client and so tests can assert
on exact counter values. The bounded-buffer overflow metric is
``buffer_overflows`` (with ``dropped_records`` counting records actually
discarded), as required by the module specification.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class RecorderMetrics:
    """Mutable counters describing recorder activity.

    Attributes:
        snapshots_captured: snapshots the sampler decided to record.
        snapshots_enqueued: snapshots accepted into the bounded buffer.
        snapshots_written: snapshots persisted to the Parquet sink.
        summaries_written: summary rows persisted to PostgreSQL.
        buffer_overflows: times the bounded buffer was full on ``put``.
        dropped_records: snapshots discarded due to the overflow policy.
        flushes: writer flush cycles completed.
        files_rotated: Parquet files rotated (opened).
        write_errors: batch write failures (records retained/logged).
    """

    snapshots_captured: int = 0
    snapshots_enqueued: int = 0
    snapshots_written: int = 0
    summaries_written: int = 0
    buffer_overflows: int = 0
    dropped_records: int = 0
    flushes: int = 0
    files_rotated: int = 0
    write_errors: int = 0

    def as_dict(self) -> dict[str, int]:
        """Return a plain mapping for logging / diagnostics."""
        return {
            "snapshots_captured": self.snapshots_captured,
            "snapshots_enqueued": self.snapshots_enqueued,
            "snapshots_written": self.snapshots_written,
            "summaries_written": self.summaries_written,
            "buffer_overflows": self.buffer_overflows,
            "dropped_records": self.dropped_records,
            "flushes": self.flushes,
            "files_rotated": self.files_rotated,
            "write_errors": self.write_errors,
        }


__all__ = ["RecorderMetrics"]
