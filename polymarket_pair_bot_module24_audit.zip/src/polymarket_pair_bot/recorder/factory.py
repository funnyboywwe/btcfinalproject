"""Composition root for the market-data recorder (Module 7).

This is the only recorder module that knows how to translate
:class:`~polymarket_pair_bot.config.settings.AppConfig` into concrete sinks and
wiring. Heavy/optional dependencies (pyarrow, SQLAlchemy) are imported lazily
inside this factory so importing the ``recorder`` package stays cheap and
offline-friendly; the pure service/sampler never touch them.

Mirrors the ``market_data.build_market_data_feed`` factory style. Nothing here
places or derives an order.
"""

from __future__ import annotations

from pathlib import Path

from polymarket_pair_bot.config.settings import AppConfig
from polymarket_pair_bot.domain.market_data import OrderBookProvider
from polymarket_pair_bot.recorder.buffer import BoundedSnapshotBuffer
from polymarket_pair_bot.recorder.config import RecorderRuntimeConfig
from polymarket_pair_bot.recorder.metrics import RecorderMetrics
from polymarket_pair_bot.recorder.ports import SnapshotSink, SummarySink
from polymarket_pair_bot.recorder.sampler import SnapshotSampler
from polymarket_pair_bot.recorder.service import MarketDataRecorder


def runtime_config_from_settings(config: AppConfig) -> RecorderRuntimeConfig:
    """Translate ``RecorderSettings`` into the pure runtime config dataclass."""
    recorder = config.recorder
    return RecorderRuntimeConfig(
        output_dir=Path(recorder.recorder_output_dir),
        poll_interval_seconds=recorder.recorder_poll_interval_seconds,
        periodic_interval_seconds=recorder.recorder_snapshot_interval_seconds,
        top_depth_levels=recorder.recorder_top_depth_levels,
        pair_cost_levels=recorder.pair_cost_levels,
        buffer_max_size=recorder.recorder_buffer_max_size,
        overflow_policy=recorder.recorder_overflow_policy,
        write_batch_size=recorder.recorder_write_batch_size,
        flush_interval_seconds=recorder.recorder_flush_interval_seconds,
        file_rotation_seconds=recorder.recorder_file_rotation_seconds,
        parquet_compression=recorder.recorder_parquet_compression,
        persist_summaries=recorder.recorder_persist_summaries,
    )


def build_snapshot_sink(
    runtime: RecorderRuntimeConfig,
    *,
    metrics: RecorderMetrics,
) -> SnapshotSink:
    """Build the bulk Parquet sink (pyarrow imported lazily on first write)."""
    from polymarket_pair_bot.recorder.parquet_sink import ParquetSnapshotSink

    return ParquetSnapshotSink(
        output_dir=runtime.output_dir,
        rotate_interval_seconds=runtime.file_rotation_seconds,
        compression=runtime.parquet_compression,
        metrics=metrics,
    )


def build_summary_sink(config: AppConfig, runtime: RecorderRuntimeConfig) -> SummarySink:
    """Build the PostgreSQL summary sink, or a no-op sink when disabled.

    SQLAlchemy is imported lazily so summary persistence can be turned off
    without the driver installed.
    """
    from polymarket_pair_bot.recorder.summary_sink import (
        NullSummarySink,
        PostgresSummarySink,
    )

    if not runtime.persist_summaries:
        return NullSummarySink()

    from polymarket_pair_bot.persistence.engine import (
        create_engine_from_dsn,
        create_session_factory,
    )

    engine = create_engine_from_dsn(
        config.postgres.dsn,
        echo=config.postgres.db_echo,
        pool_size=config.postgres.db_pool_size,
    )
    session_factory = create_session_factory(engine)
    return PostgresSummarySink(session_factory, engine=engine)


def build_recorder(
    config: AppConfig,
    provider: OrderBookProvider,
    *,
    window_id: str,
    market_slug: str | None = None,
    metrics: RecorderMetrics | None = None,
    snapshot_sink: SnapshotSink | None = None,
    summary_sink: SummarySink | None = None,
) -> MarketDataRecorder:
    """Build a fully-wired :class:`MarketDataRecorder`.

    ``snapshot_sink``/``summary_sink`` overrides exist for tests; production
    callers pass only ``config`` and ``provider``.
    """
    runtime = runtime_config_from_settings(config)
    recorder_metrics = metrics or RecorderMetrics()
    sink = snapshot_sink or build_snapshot_sink(runtime, metrics=recorder_metrics)
    summaries = summary_sink or build_summary_sink(config, runtime)
    sampler = SnapshotSampler(
        periodic_interval_seconds=runtime.periodic_interval_seconds,
        pair_cost_levels=runtime.pair_cost_levels,
    )
    buffer = BoundedSnapshotBuffer(
        max_size=runtime.buffer_max_size,
        policy=runtime.overflow_policy,
        metrics=recorder_metrics,
    )
    return MarketDataRecorder(
        provider=provider,
        sampler=sampler,
        buffer=buffer,
        snapshot_sink=sink,
        summary_sink=summaries,
        config=runtime,
        window_id=window_id,
        market_slug=market_slug,
        metrics=recorder_metrics,
    )


__all__ = [
    "build_recorder",
    "build_snapshot_sink",
    "build_summary_sink",
    "runtime_config_from_settings",
]
