"""Bounded, asynchronous snapshot buffer with an explicit overflow policy.

The recorder poll loop (producer) and the writer task (consumer) are decoupled
by this bounded buffer so that slow disk / database writes can never stall the
sampler -- and, crucially, can never stall the WebSocket reader, which runs in
an entirely separate task in :mod:`market_data`.

Overflow policy (``RecorderOverflowPolicy``):

* ``DROP_NEWEST`` -- discard the incoming snapshot (keep the backlog).
* ``DROP_OLDEST`` -- evict the oldest queued snapshot, enqueue the new one.
* ``BLOCK`` -- await space. This applies backpressure to the recorder poll
  loop *only*; it still cannot block the WebSocket reader because the reader
  does not depend on this buffer.

Every overflow increments ``RecorderMetrics.buffer_overflows``; every discarded
snapshot increments ``RecorderMetrics.dropped_records``.
"""

from __future__ import annotations

import asyncio

from polymarket_pair_bot.config.enums import RecorderOverflowPolicy
from polymarket_pair_bot.domain.recording import RecordedPairSnapshot
from polymarket_pair_bot.recorder.metrics import RecorderMetrics


class BoundedSnapshotBuffer:
    """An ``asyncio.Queue``-backed bounded buffer of pair snapshots."""

    def __init__(
        self,
        *,
        max_size: int,
        policy: RecorderOverflowPolicy,
        metrics: RecorderMetrics | None = None,
    ) -> None:
        if max_size < 1:
            raise ValueError("max_size must be >= 1")
        self._queue: asyncio.Queue[RecordedPairSnapshot] = asyncio.Queue(maxsize=max_size)
        self._policy = policy
        self._metrics = metrics or RecorderMetrics()
        self._max_size = max_size

    @property
    def max_size(self) -> int:
        return self._max_size

    def qsize(self) -> int:
        return self._queue.qsize()

    def empty(self) -> bool:
        return self._queue.empty()

    async def put(self, snapshot: RecordedPairSnapshot) -> bool:
        """Offer a snapshot to the buffer, applying the overflow policy.

        Returns ``True`` when the snapshot was enqueued, ``False`` when it was
        dropped. Only the ``BLOCK`` policy may suspend the caller.
        """
        try:
            self._queue.put_nowait(snapshot)
            self._metrics.snapshots_enqueued += 1
            return True
        except asyncio.QueueFull:
            self._metrics.buffer_overflows += 1

        if self._policy is RecorderOverflowPolicy.DROP_NEWEST:
            self._metrics.dropped_records += 1
            return False

        if self._policy is RecorderOverflowPolicy.DROP_OLDEST:
            try:
                self._queue.get_nowait()
                self._queue.task_done()
                self._metrics.dropped_records += 1
            except asyncio.QueueEmpty:  # pragma: no cover - drained concurrently
                pass
            try:
                self._queue.put_nowait(snapshot)
                self._metrics.snapshots_enqueued += 1
                return True
            except asyncio.QueueFull:  # pragma: no cover - refilled concurrently
                self._metrics.dropped_records += 1
                return False

        # BLOCK: apply backpressure to the recorder poll loop only.
        await self._queue.put(snapshot)
        self._metrics.snapshots_enqueued += 1
        return True

    async def drain(
        self,
        *,
        max_items: int,
        timeout: float,
    ) -> list[RecordedPairSnapshot]:
        """Drain up to ``max_items`` snapshots, waiting up to ``timeout`` seconds.

        Blocks (awaits) for the first item up to ``timeout``; once one item is
        available, greedily takes up to ``max_items`` without further waiting.
        Returns an empty list on timeout so the writer can loop and re-check
        shutdown state.
        """
        if max_items < 1:
            raise ValueError("max_items must be >= 1")
        batch: list[RecordedPairSnapshot] = []
        try:
            first = await asyncio.wait_for(self._queue.get(), timeout=timeout)
        except asyncio.TimeoutError:
            return batch
        batch.append(first)
        self._queue.task_done()
        while len(batch) < max_items:
            try:
                item = self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            batch.append(item)
            self._queue.task_done()
        return batch

    def drain_nowait(self) -> list[RecordedPairSnapshot]:
        """Immediately drain everything currently buffered (used at shutdown)."""
        batch: list[RecordedPairSnapshot] = []
        while True:
            try:
                item = self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            batch.append(item)
            self._queue.task_done()
        return batch


__all__ = ["BoundedSnapshotBuffer"]
