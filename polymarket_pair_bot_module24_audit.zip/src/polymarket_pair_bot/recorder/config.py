"""Runtime configuration for the market-data recorder (Module 7).

This is a plain, immutable dataclass -- not a settings model. It is translated
from :class:`polymarket_pair_bot.config.models.RecorderSettings` by
:mod:`recorder.factory`, mirroring how ``market_data.MarketDataFeedConfig`` is
built from settings. Keeping runtime config free of ``pydantic-settings`` means
the pure service and sampler never read environment variables.

All monetary levels are ``Decimal``; intervals are plain ``float`` seconds
(durations, never money).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

from polymarket_pair_bot.config.enums import RecorderOverflowPolicy


@dataclass(frozen=True, slots=True)
class RecorderRuntimeConfig:
    """Resolved knobs controlling recorder behavior.

    Attributes:
        output_dir: root directory for Parquet output (per-window subfolders).
        poll_interval_seconds: how often the recorder samples the in-memory
            books. Must be <= ``periodic_interval_seconds``.
        periodic_interval_seconds: cadence of the guaranteed periodic snapshot
            (the "one-second" snapshot by default).
        top_depth_levels: number of book levels recorded per side.
        pair_cost_levels: configured executable-pair-cost thresholds whose
            crossing triggers an event snapshot.
        buffer_max_size: bounded-buffer capacity.
        overflow_policy: what to do when the buffer is full.
        write_batch_size: max snapshots drained per writer flush.
        flush_interval_seconds: max time the writer waits before flushing a
            partial batch.
        file_rotation_seconds: Parquet files also rotate after this much
            wall-clock time even within a single window.
        parquet_compression: Parquet codec (e.g. ``zstd``, ``snappy``).
        persist_summaries: whether to write PostgreSQL summaries.
    """

    output_dir: Path
    poll_interval_seconds: float = 0.25
    periodic_interval_seconds: float = 1.0
    top_depth_levels: int = 10
    pair_cost_levels: tuple[Decimal, ...] = field(default_factory=tuple)
    buffer_max_size: int = 10_000
    overflow_policy: RecorderOverflowPolicy = RecorderOverflowPolicy.DROP_OLDEST
    write_batch_size: int = 500
    flush_interval_seconds: float = 2.0
    file_rotation_seconds: float = 300.0
    parquet_compression: str = "zstd"
    persist_summaries: bool = True

    def __post_init__(self) -> None:
        if self.poll_interval_seconds <= 0:
            raise ValueError("poll_interval_seconds must be positive")
        if self.periodic_interval_seconds <= 0:
            raise ValueError("periodic_interval_seconds must be positive")
        if self.poll_interval_seconds > self.periodic_interval_seconds:
            raise ValueError(
                "poll_interval_seconds must be <= periodic_interval_seconds so "
                "periodic snapshots are not missed"
            )
        if self.top_depth_levels < 1:
            raise ValueError("top_depth_levels must be >= 1")
        if self.buffer_max_size < 1:
            raise ValueError("buffer_max_size must be >= 1")
        if self.write_batch_size < 1:
            raise ValueError("write_batch_size must be >= 1")
        if self.flush_interval_seconds <= 0:
            raise ValueError("flush_interval_seconds must be positive")
        if self.file_rotation_seconds <= 0:
            raise ValueError("file_rotation_seconds must be positive")
        if any(level <= 0 for level in self.pair_cost_levels):
            raise ValueError("pair_cost_levels must be positive")


__all__ = ["RecorderRuntimeConfig"]
