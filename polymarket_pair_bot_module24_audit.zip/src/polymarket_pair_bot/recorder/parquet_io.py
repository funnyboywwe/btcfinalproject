"""Read-side Parquet utilities: validate, export and replay (Module 7).

All functions lazily import ``pyarrow`` so this module is importable without it.
They are synchronous (offline file operations) and used by the recorder CLI.
No trading logic lives here.
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from polymarket_pair_bot.domain.recording import RecordedPairSnapshot
from polymarket_pair_bot.recorder.serialization import (
    COLUMN_NAMES,
    row_to_snapshot,
)

_MISSING_PYARROW = (
    "pyarrow is required to read Parquet files. Install it with 'uv sync' "
    "(it is a declared project dependency) or 'uv pip install pyarrow'."
)


def _require_parquet() -> Any:
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RuntimeError(_MISSING_PYARROW) from exc
    return pq


@dataclass(frozen=True, slots=True)
class FileValidation:
    """Structural validation result for a single Parquet file."""

    path: str
    ok: bool
    row_count: int
    window_ids: tuple[str, ...]
    min_epoch: int | None
    max_epoch: int | None
    errors: tuple[str, ...]


def iter_parquet_files(root: str | Path) -> list[Path]:
    """Return all ``*.parquet`` files under ``root`` in a stable sorted order."""
    base = Path(root)
    if base.is_file():
        return [base]
    return sorted(base.rglob("*.parquet"))


def read_rows(path: str | Path) -> list[dict[str, object]]:
    """Read a Parquet file into a list of plain row mappings."""
    pq = _require_parquet()
    table = pq.read_table(str(path))
    rows: list[dict[str, object]] = table.to_pylist()
    return rows


def read_snapshots(path: str | Path) -> list[RecordedPairSnapshot]:
    """Read a Parquet file back into :class:`RecordedPairSnapshot` records."""
    return [row_to_snapshot(row) for row in read_rows(path)]


def validate_file(path: str | Path) -> FileValidation:
    """Validate one Parquet file's structure and basic ordering invariants."""
    errors: list[str] = []
    window_ids: set[str] = set()
    min_epoch: int | None = None
    max_epoch: int | None = None
    row_count = 0
    try:
        rows = read_rows(path)
    except Exception as exc:  # noqa: BLE001 - report unreadable/footerless files
        return FileValidation(
            path=str(path),
            ok=False,
            row_count=0,
            window_ids=(),
            min_epoch=None,
            max_epoch=None,
            errors=(f"unreadable: {exc}",),
        )

    missing_columns = [name for name in COLUMN_NAMES if rows and name not in rows[0]]
    if missing_columns:
        errors.append(f"missing columns: {sorted(missing_columns)}")

    last_epoch: int | None = None
    for index, row in enumerate(rows):
        row_count += 1
        try:
            snapshot = row_to_snapshot(row)
        except Exception as exc:  # noqa: BLE001 - collect per-row parse errors
            errors.append(f"row {index} parse error: {exc}")
            continue
        window_ids.add(snapshot.window_id)
        epoch = snapshot.capture_epoch
        min_epoch = epoch if min_epoch is None else min(min_epoch, epoch)
        max_epoch = epoch if max_epoch is None else max(max_epoch, epoch)
        if last_epoch is not None and epoch < last_epoch:
            errors.append(f"row {index} capture_epoch went backwards")
        last_epoch = epoch
        if not snapshot.triggers:
            errors.append(f"row {index} has no trigger reason")

    return FileValidation(
        path=str(path),
        ok=not errors,
        row_count=row_count,
        window_ids=tuple(sorted(window_ids)),
        min_epoch=min_epoch,
        max_epoch=max_epoch,
        errors=tuple(errors),
    )


def validate_tree(root: str | Path) -> list[FileValidation]:
    """Validate every Parquet file under ``root``."""
    return [validate_file(path) for path in iter_parquet_files(root)]


def replay_window(
    root: str | Path,
    window_id: str,
    *,
    start_epoch: int | None = None,
    end_epoch: int | None = None,
) -> Iterator[RecordedPairSnapshot]:
    """Yield snapshots for a window in (capture_epoch, sequence) order.

    This is a deterministic, side-effect-free replay of recorded data; it does
    not reconstruct or execute any trading behavior.
    """
    collected: list[RecordedPairSnapshot] = []
    for path in iter_parquet_files(root):
        for snapshot in read_snapshots(path):
            if snapshot.window_id != window_id:
                continue
            if start_epoch is not None and snapshot.capture_epoch < start_epoch:
                continue
            if end_epoch is not None and snapshot.capture_epoch > end_epoch:
                continue
            collected.append(snapshot)
    collected.sort(key=lambda item: (item.capture_epoch, item.sequence))
    yield from collected


def export_range(
    root: str | Path,
    *,
    start_epoch: int,
    end_epoch: int,
    out_path: str | Path,
    output_format: str = "parquet",
) -> int:
    """Export all rows whose ``capture_epoch`` is in ``[start_epoch, end_epoch]``.

    Returns the number of rows written. Supports ``parquet`` and ``csv``
    output. Rows are ordered by (window_id, capture_epoch, sequence).
    """
    if start_epoch > end_epoch:
        raise ValueError("start_epoch must be <= end_epoch")
    matched: list[dict[str, object]] = []
    for path in iter_parquet_files(root):
        for row in read_rows(path):
            epoch = int(row["capture_epoch"])  # type: ignore[arg-type]
            if start_epoch <= epoch <= end_epoch:
                matched.append(row)
    matched.sort(
        key=lambda row: (
            str(row["window_id"]),
            int(row["capture_epoch"]),  # type: ignore[arg-type]
            int(row["sequence"]),  # type: ignore[arg-type]
        )
    )
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    if output_format == "csv":
        _write_csv(out, matched)
    elif output_format == "parquet":
        _write_parquet(out, matched)
    else:
        raise ValueError(f"unsupported output_format: {output_format!r}")
    return len(matched)


def _write_csv(out: Path, rows: list[dict[str, object]]) -> None:
    import csv

    with out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(COLUMN_NAMES))
        writer.writeheader()
        for row in rows:
            writer.writerow({name: row.get(name) for name in COLUMN_NAMES})


def _write_parquet(out: Path, rows: list[dict[str, object]]) -> None:
    from polymarket_pair_bot.recorder.parquet_sink import _arrow_schema, _require_pyarrow

    pa = _require_pyarrow()
    pq = _require_parquet()
    schema = _arrow_schema(pa)
    table = pa.Table.from_pylist(rows, schema=schema)
    pq.write_table(table, str(out), compression="zstd")


__all__ = [
    "FileValidation",
    "export_range",
    "iter_parquet_files",
    "read_rows",
    "read_snapshots",
    "replay_window",
    "validate_file",
    "validate_tree",
]
