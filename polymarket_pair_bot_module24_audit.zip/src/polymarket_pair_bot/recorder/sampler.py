"""Pure snapshot-trigger logic for the recorder (Module 7).

The :class:`SnapshotSampler` is deterministic and side-effect free apart from
its own internal "last observed" state. It decides *whether* a snapshot should
be captured and *why*, given lightweight per-side observations plus the current
executable pair cost and a monotonic clock reading. It performs no I/O and
never touches the network, disk, database or environment, so it is trivially
unit-testable and cannot block the WebSocket reader.

Triggers implemented (see :class:`SnapshotTrigger`):

* ``PERIODIC`` -- ``periodic_interval_seconds`` elapsed (the one-second
  cadence by default). Always fires on the very first evaluation.
* ``BEST_BID_CHANGE`` / ``BEST_ASK_CHANGE`` -- top-of-book price moved on
  either side.
* ``SPREAD_CHANGE`` -- spread changed on either side.
* ``PAIR_COST_CROSS`` -- the executable pair cost moved across a configured
  level (in either direction).
* ``FEED_STALE`` / ``FEED_RECOVER`` -- a side left / re-entered the LIVE state.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from polymarket_pair_bot.domain.market_data import BookQuote, FeedStatus
from polymarket_pair_bot.domain.recording import SnapshotTrigger


@dataclass(frozen=True, slots=True)
class SideObservation:
    """The minimal per-side state the sampler compares between evaluations."""

    best_bid: Decimal | None
    best_ask: Decimal | None
    spread: Decimal | None
    is_live: bool

    @classmethod
    def from_quote(cls, quote: BookQuote) -> SideObservation:
        """Project a :class:`BookQuote` into a comparison observation."""
        return cls(
            best_bid=None if quote.best_bid is None else quote.best_bid.value,
            best_ask=None if quote.best_ask is None else quote.best_ask.value,
            spread=quote.spread,
            is_live=quote.status is FeedStatus.LIVE,
        )


@dataclass(frozen=True, slots=True)
class SampleDecision:
    """Result of one sampler evaluation."""

    triggers: tuple[SnapshotTrigger, ...]
    crossed_level: Decimal | None

    @property
    def should_record(self) -> bool:
        """True when at least one trigger fired."""
        return bool(self.triggers)


@dataclass(slots=True)
class _SideState:
    initialized: bool = False
    best_bid: Decimal | None = None
    best_ask: Decimal | None = None
    spread: Decimal | None = None
    is_live: bool = False


class SnapshotSampler:
    """Decide when to capture a snapshot. Not safe for concurrent use.

    A single sampler instance is owned by a single recorder poll loop, so no
    locking is required.
    """

    def __init__(
        self,
        *,
        periodic_interval_seconds: float,
        pair_cost_levels: tuple[Decimal, ...] = (),
    ) -> None:
        if periodic_interval_seconds <= 0:
            raise ValueError("periodic_interval_seconds must be positive")
        self._periodic_interval = periodic_interval_seconds
        self._levels = tuple(sorted(pair_cost_levels))
        self._last_periodic_monotonic: float | None = None
        self._last_pair_cost: Decimal | None = None
        self._up = _SideState()
        self._down = _SideState()

    def evaluate(
        self,
        *,
        up: SideObservation,
        down: SideObservation,
        pair_cost: Decimal | None,
        now_monotonic: float,
    ) -> SampleDecision:
        """Return the triggers (if any) firing for the current observation.

        This mutates the sampler's internal "last observed" state, so it must be
        called exactly once per poll tick, in order.
        """
        triggers: list[SnapshotTrigger] = []

        if (
            self._last_periodic_monotonic is None
            or now_monotonic - self._last_periodic_monotonic >= self._periodic_interval
        ):
            triggers.append(SnapshotTrigger.PERIODIC)
            self._last_periodic_monotonic = now_monotonic

        self._evaluate_side(self._up, up, triggers)
        self._evaluate_side(self._down, down, triggers)

        crossed_level = self._evaluate_pair_cost(pair_cost)
        if crossed_level is not None:
            triggers.append(SnapshotTrigger.PAIR_COST_CROSS)

        # De-duplicate while preserving first-seen order (both sides may raise
        # the same reason, e.g. BEST_BID_CHANGE).
        ordered = tuple(dict.fromkeys(triggers))
        return SampleDecision(triggers=ordered, crossed_level=crossed_level)

    def _evaluate_side(
        self,
        state: _SideState,
        obs: SideObservation,
        triggers: list[SnapshotTrigger],
    ) -> None:
        if state.initialized:
            if obs.best_bid != state.best_bid:
                triggers.append(SnapshotTrigger.BEST_BID_CHANGE)
            if obs.best_ask != state.best_ask:
                triggers.append(SnapshotTrigger.BEST_ASK_CHANGE)
            if obs.spread != state.spread:
                triggers.append(SnapshotTrigger.SPREAD_CHANGE)
            if obs.is_live and not state.is_live:
                triggers.append(SnapshotTrigger.FEED_RECOVER)
            elif not obs.is_live and state.is_live:
                triggers.append(SnapshotTrigger.FEED_STALE)
        state.initialized = True
        state.best_bid = obs.best_bid
        state.best_ask = obs.best_ask
        state.spread = obs.spread
        state.is_live = obs.is_live

    def _evaluate_pair_cost(self, pair_cost: Decimal | None) -> Decimal | None:
        crossed: Decimal | None = None
        previous = self._last_pair_cost
        if (
            pair_cost is not None
            and previous is not None
            and pair_cost != previous
            and self._levels
        ):
            low, high = sorted((previous, pair_cost))
            for level in self._levels:
                # A crossing occurs when a configured level lies within the
                # movement interval (inclusive of the new value).
                if low < level <= high or (level == low and level != previous):
                    crossed = level
                    break
        if pair_cost is not None:
            self._last_pair_cost = pair_cost
        return crossed


__all__ = [
    "SampleDecision",
    "SideObservation",
    "SnapshotSampler",
]
