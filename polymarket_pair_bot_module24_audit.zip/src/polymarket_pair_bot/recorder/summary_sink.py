"""Summary sinks for the recorder (Module 7).

:class:`PostgresSummarySink` persists queryable snapshot summaries to
PostgreSQL via a SQLAlchemy async session factory (infrastructure code, so it
may import SQLAlchemy). :class:`NullSummarySink` is used when summary
persistence is disabled -- notably in tests and in pure Parquet-only recording.
Both satisfy the :class:`~recorder.ports.SummarySink` protocol.

Each batch is written in its own short transaction; inserts are idempotent
(``ON CONFLICT DO NOTHING`` on ``(window_id, sequence)``) so retries or
re-processing never duplicate rows.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

from polymarket_pair_bot.domain.recording import RecordedSnapshotSummary
from polymarket_pair_bot.observability.logging import get_logger

if TYPE_CHECKING:  # pragma: no cover - typing only, avoids hard SQLAlchemy dep
    from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker

_LOGGER = get_logger("recorder.summary_sink")


class NullSummarySink:
    """A no-op summary sink (summary persistence disabled)."""

    async def write_batch(self, summaries: Sequence[RecordedSnapshotSummary]) -> int:
        return 0

    async def flush(self) -> None:
        return None

    async def aclose(self) -> None:
        return None


class PostgresSummarySink:
    """Persist snapshot summaries to PostgreSQL in short transactions."""

    def __init__(
        self,
        session_factory: async_sessionmaker,
        *,
        engine: AsyncEngine | None = None,
    ) -> None:
        self._session_factory = session_factory
        # Optional: when the sink owns the engine it disposes it on close.
        self._engine = engine

    async def write_batch(self, summaries: Sequence[RecordedSnapshotSummary]) -> int:
        if not summaries:
            return 0
        # Imported lazily so this module stays importable without SQLAlchemy.
        from polymarket_pair_bot.persistence.market_data_snapshots import (
            MarketDataSnapshotRepositoryImpl,
        )

        async with self._session_factory() as session:
            repository = MarketDataSnapshotRepositoryImpl(session)
            written = await repository.add_many(summaries)
            await session.commit()
        return written

    async def flush(self) -> None:
        # Each batch commits independently; nothing is buffered here.
        return None

    async def aclose(self) -> None:
        if self._engine is not None:
            await self._engine.dispose()
            self._engine = None


__all__ = ["NullSummarySink", "PostgresSummarySink"]
