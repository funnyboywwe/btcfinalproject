"""Operator CLI for the market-data recorder (Module 7).

Four read-only subcommands are exposed (none place or derive an order):

* ``record-market-data``   -- start the recorder against the live public feed;
* ``market-data-export``    -- export a UTC date range to Parquet or CSV;
* ``market-data-validate``  -- structurally validate recorded Parquet files;
* ``market-data-replay``    -- deterministically replay one recorded window.

Each command follows the project's ``add_arguments(parser)`` / ``run(args)``
convention so ``__main__`` can wire them as subcommands.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import sys
from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path

from polymarket_pair_bot.config import AppConfig, load_config
from polymarket_pair_bot.domain.value_objects import TokenId
from polymarket_pair_bot.market_data.factory import build_market_data_feed
from polymarket_pair_bot.market_discovery.errors import MarketDiscoveryError
from polymarket_pair_bot.market_discovery.factory import (
    build_market_discovery_service,
)
from polymarket_pair_bot.recorder.factory import build_recorder
from polymarket_pair_bot.recorder.parquet_io import (
    export_range,
    replay_window,
    validate_tree,
)


def _parse_epoch(value: str) -> int:
    """Parse an ISO-8601 date/datetime (UTC assumed) into epoch seconds."""
    text = value.strip()
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return int(parsed.timestamp())


# --------------------------------------------------------------------------- #
# record-market-data                                                          #
# --------------------------------------------------------------------------- #
def add_start_arguments(parser: argparse.ArgumentParser) -> None:
    """Register options for the ``record-market-data`` command."""
    parser.add_argument(
        "--slug",
        default=None,
        help="Explicit market slug (disables window matching); overrides template.",
    )
    parser.add_argument(
        "--up-token-id",
        default=None,
        help="Bypass discovery and record this explicit Up token id.",
    )
    parser.add_argument(
        "--down-token-id",
        default=None,
        help="Bypass discovery and record this explicit Down token id.",
    )
    parser.add_argument(
        "--window-id",
        default=None,
        help="Override the window identifier (defaults to the market slug).",
    )
    parser.add_argument(
        "--duration-seconds",
        type=float,
        default=0.0,
        help="Stop after this many seconds (default: 0 = run until Ctrl-C).",
    )


async def _resolve_tokens(
    config: AppConfig, args: argparse.Namespace
) -> tuple[TokenId, TokenId, str, str | None]:
    """Return (up_token, down_token, window_id, market_slug)."""
    if args.up_token_id and args.down_token_id:
        window_id = args.window_id or "explicit"
        return (
            TokenId(args.up_token_id),
            TokenId(args.down_token_id),
            window_id,
            None,
        )
    service = build_market_discovery_service(
        config,
        slug_override=args.slug,
        require_window_match=False if args.slug else None,
    )
    try:
        window = service.windows().current
        market = await service.discover_window(window)
    finally:
        source = getattr(service, "_source", None)
        aclose = getattr(source, "aclose", None)
        if aclose is not None:
            await aclose()
    window_id = args.window_id or market.slug
    return (
        TokenId(market.up_token_id),
        TokenId(market.down_token_id),
        window_id,
        market.slug,
    )


async def _run_start(config: AppConfig, args: argparse.Namespace) -> int:
    up_token, down_token, window_id, market_slug = await _resolve_tokens(config, args)
    feed, manager = build_market_data_feed(config, up_token, down_token)
    recorder = build_recorder(
        config,
        manager,
        window_id=window_id,
        market_slug=market_slug,
    )

    feed_task = asyncio.create_task(feed.run(), name="market-data-feed")
    recorder_task = asyncio.create_task(recorder.run(), name="market-data-recorder")
    loop = asyncio.get_running_loop()
    deadline = (
        loop.time() + args.duration_seconds if args.duration_seconds > 0 else None
    )
    try:
        while not recorder_task.done() and not feed_task.done():
            if deadline is not None and loop.time() >= deadline:
                break
            await asyncio.sleep(0.25)
    finally:
        # Graceful, ordered shutdown: stop capturing, flush, then stop the feed.
        recorder.request_stop()
        with contextlib.suppress(asyncio.CancelledError):
            await recorder_task
        feed.request_stop()
        feed_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await feed_task
    m = recorder.metrics
    print(
        "recorder metrics: "
        f"captured={m.snapshots_captured} enqueued={m.snapshots_enqueued} "
        f"written={m.snapshots_written} summaries={m.summaries_written} "
        f"overflows={m.buffer_overflows} dropped={m.dropped_records} "
        f"flushes={m.flushes} files_rotated={m.files_rotated} "
        f"write_errors={m.write_errors}"
    )
    return 0


def run_start(args: argparse.Namespace) -> int:
    """Execute ``record-market-data``; return an exit code."""
    config = load_config()
    try:
        return asyncio.run(_run_start(config, args))
    except MarketDiscoveryError as exc:
        print(
            f"record-market-data failed during discovery: "
            f"{type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 1
    except KeyboardInterrupt:  # pragma: no cover - interactive interrupt
        return 0


# --------------------------------------------------------------------------- #
# market-data-export                                                          #
# --------------------------------------------------------------------------- #
def add_export_arguments(parser: argparse.ArgumentParser) -> None:
    """Register options for the ``market-data-export`` command."""
    parser.add_argument(
        "--root",
        default=None,
        help="Recorded-data root (defaults to RECORDER_OUTPUT_DIR).",
    )
    parser.add_argument(
        "--start",
        required=True,
        help="Inclusive start (ISO-8601, UTC assumed), e.g. 2026-01-01.",
    )
    parser.add_argument(
        "--end",
        required=True,
        help="Inclusive end (ISO-8601, UTC assumed), e.g. 2026-01-02.",
    )
    parser.add_argument(
        "--out",
        required=True,
        help="Output file path.",
    )
    parser.add_argument(
        "--format",
        choices=("parquet", "csv"),
        default="parquet",
        help="Output format (default: parquet).",
    )


def run_export(args: argparse.Namespace) -> int:
    """Execute ``market-data-export``; return an exit code."""
    config = load_config()
    root = args.root or config.recorder.recorder_output_dir
    try:
        start_epoch = _parse_epoch(args.start)
        end_epoch = _parse_epoch(args.end)
    except ValueError as exc:
        print(f"invalid date range: {exc}", file=sys.stderr)
        return 2
    try:
        written = export_range(
            root,
            start_epoch=start_epoch,
            end_epoch=end_epoch,
            out_path=args.out,
            output_format=args.format,
        )
    except (ValueError, RuntimeError) as exc:
        print(f"export failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(f"exported {written} rows to {args.out} ({args.format})")
    return 0


# --------------------------------------------------------------------------- #
# market-data-validate                                                        #
# --------------------------------------------------------------------------- #
def add_validate_arguments(parser: argparse.ArgumentParser) -> None:
    """Register options for the ``market-data-validate`` command."""
    parser.add_argument(
        "--root",
        default=None,
        help="Recorded-data root (defaults to RECORDER_OUTPUT_DIR).",
    )


def run_validate(args: argparse.Namespace) -> int:
    """Execute ``market-data-validate``; nonzero exit if any file is invalid."""
    config = load_config()
    root = args.root or config.recorder.recorder_output_dir
    try:
        results = validate_tree(root)
    except RuntimeError as exc:
        print(f"validation failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    if not results:
        print(f"no Parquet files found under {root}")
        return 0
    failures = 0
    for result in results:
        status = "OK " if result.ok else "BAD"
        print(
            f"[{status}] {result.path} rows={result.row_count} "
            f"windows={list(result.window_ids)} "
            f"epochs=[{result.min_epoch}, {result.max_epoch}]"
        )
        for error in result.errors:
            failures += 1
            print(f"        - {error}")
    ok_count = sum(1 for result in results if result.ok)
    print(f"validated {len(results)} file(s): {ok_count} ok, {len(results) - ok_count} bad")
    return 0 if failures == 0 else 1


# --------------------------------------------------------------------------- #
# market-data-replay                                                          #
# --------------------------------------------------------------------------- #
def add_replay_arguments(parser: argparse.ArgumentParser) -> None:
    """Register options for the ``market-data-replay`` command."""
    parser.add_argument(
        "--root",
        default=None,
        help="Recorded-data root (defaults to RECORDER_OUTPUT_DIR).",
    )
    parser.add_argument(
        "--window-id",
        required=True,
        help="Window identifier to replay.",
    )
    parser.add_argument(
        "--start",
        default=None,
        help="Optional inclusive start (ISO-8601, UTC assumed).",
    )
    parser.add_argument(
        "--end",
        default=None,
        help="Optional inclusive end (ISO-8601, UTC assumed).",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=20,
        help="Max snapshots to print (default: 20; 0 = count only).",
    )


def run_replay(args: argparse.Namespace) -> int:
    """Execute ``market-data-replay``; return an exit code."""
    config = load_config()
    root = args.root or config.recorder.recorder_output_dir
    try:
        start_epoch = _parse_epoch(args.start) if args.start else None
        end_epoch = _parse_epoch(args.end) if args.end else None
    except ValueError as exc:
        print(f"invalid date range: {exc}", file=sys.stderr)
        return 2
    try:
        snapshots = list(
            replay_window(
                root,
                args.window_id,
                start_epoch=start_epoch,
                end_epoch=end_epoch,
            )
        )
    except RuntimeError as exc:
        print(f"replay failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(f"window {args.window_id!r}: {len(snapshots)} snapshot(s)")
    if args.limit:
        for snapshot in snapshots[: args.limit]:
            up_bid = snapshot.up.best_bid
            down_bid = snapshot.down.best_bid
            print(
                f"  seq={snapshot.sequence} epoch={snapshot.capture_epoch} "
                f"triggers={snapshot.trigger_reasons} "
                f"pair_cost={snapshot.executable_pair_cost} "
                f"up_bid={up_bid} down_bid={down_bid}"
            )
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-recorder",
        description="Research-grade market-data recorder (read-only).",
    )
    sub = parser.add_subparsers(dest="recorder_command", required=True)
    add_start_arguments(sub.add_parser("start", help="Start the recorder."))
    add_export_arguments(sub.add_parser("export", help="Export a date range."))
    add_validate_arguments(sub.add_parser("validate", help="Validate files."))
    add_replay_arguments(sub.add_parser("replay", help="Replay a window."))
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    dispatch = {
        "start": run_start,
        "export": run_export,
        "validate": run_validate,
        "replay": run_replay,
    }
    return dispatch[args.recorder_command](args)


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())


__all__ = [
    "add_export_arguments",
    "add_replay_arguments",
    "add_start_arguments",
    "add_validate_arguments",
    "main",
    "run_export",
    "run_replay",
    "run_start",
    "run_validate",
]
