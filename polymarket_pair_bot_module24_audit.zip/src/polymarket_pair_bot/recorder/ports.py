"""Typed ports (protocols) the recorder depends on.

The recorder service depends only on these abstract sinks, never on concrete
Parquet / PostgreSQL implementations. This satisfies dependency inversion:
bulk (Parquet) and summary (PostgreSQL) persistence are supplied at wiring
time by :mod:`recorder.factory`.

All sink methods are ``async`` and must be cancellation-safe. Implementations
must never perform blocking network or disk I/O directly on the event loop
(they offload to threads where appropriate).
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.recording import (
    RecordedPairSnapshot,
    RecordedSnapshotSummary,
)


@runtime_checkable
class SnapshotSink(Protocol):
    """Bulk research sink for full-fidelity snapshots (Parquet)."""

    async def write_batch(self, snapshots: Sequence[RecordedPairSnapshot]) -> int:
        """Persist a batch of snapshots; return the number written."""
        ...

    async def flush(self) -> None:
        """Flush any buffered data to durable storage."""
        ...

    async def aclose(self) -> None:
        """Flush and release all resources. Idempotent."""
        ...


@runtime_checkable
class SummarySink(Protocol):
    """Queryable summary sink (PostgreSQL)."""

    async def write_batch(self, summaries: Sequence[RecordedSnapshotSummary]) -> int:
        """Persist a batch of summaries; return the number written."""
        ...

    async def flush(self) -> None:
        """Flush any buffered data to durable storage."""
        ...

    async def aclose(self) -> None:
        """Flush and release all resources. Idempotent."""
        ...


__all__ = ["SnapshotSink", "SummarySink"]
