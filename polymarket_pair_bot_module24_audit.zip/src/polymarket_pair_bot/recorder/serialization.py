"""Pure (de)serialization between recorder records and flat Parquet rows.

These helpers contain no I/O and do not import ``pyarrow``; they translate a
:class:`RecordedPairSnapshot` to/from a flat mapping of primitive values
(``str`` / ``int`` / ``float`` / ``bool`` / ``None``). This keeps the Parquet
schema flat and queryable while remaining fully testable without pyarrow
installed.

Exactness rules:

* Every monetary ``Decimal`` (prices, sizes, spreads, pair cost) is stored as
  its canonical decimal **string** -- never a binary float -- so round-trips
  are exact.
* Depth levels are stored as JSON-string columns (``*_bids_json`` /
  ``*_asks_json``): a JSON array of ``[price_str, size_str]`` pairs.
* ``age_seconds`` is a freshness duration and is stored as ``float64``.
* Timestamps are stored as ``int64`` epoch seconds / milliseconds.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from decimal import Decimal

from polymarket_pair_bot.domain.recording import (
    DataQualityFlags,
    RecordedBookSide,
    RecordedLevel,
    RecordedPairSnapshot,
    SnapshotTrigger,
)

# Logical Parquet column types. The Parquet sink maps these to pyarrow types.
# Kept here (as plain strings) so this module stays pyarrow-free.
ArrowType = str  # one of: "string", "int64", "double", "bool"

_SCALAR_COLUMNS: tuple[tuple[str, ArrowType], ...] = (
    ("window_id", "string"),
    ("market_slug", "string"),
    ("sequence", "int64"),
    ("capture_epoch", "int64"),
    ("trigger_reasons", "string"),
    ("executable_pair_cost", "string"),
    ("pair_cost_level", "string"),
    ("top_depth", "int64"),
)

_SIDE_COLUMNS: tuple[tuple[str, ArrowType], ...] = (
    ("side", "string"),
    ("token_id", "string"),
    ("status", "string"),
    ("best_bid", "string"),
    ("best_ask", "string"),
    ("best_bid_size", "string"),
    ("best_ask_size", "string"),
    ("spread", "string"),
    ("mid", "string"),
    ("bid_levels_count", "int64"),
    ("ask_levels_count", "int64"),
    ("bid_depth_total", "string"),
    ("ask_depth_total", "string"),
    ("bids_json", "string"),
    ("asks_json", "string"),
    ("exchange_timestamp_ms", "int64"),
    ("local_receipt_epoch", "int64"),
    ("processed_epoch", "int64"),
    ("age_seconds", "double"),
)

_FLAG_FIELDS: tuple[str, ...] = (
    "has_snapshot",
    "is_live",
    "is_stale",
    "is_unavailable",
    "is_crossed",
    "is_empty",
    "missing_best_bid",
    "missing_best_ask",
    "missing_exchange_timestamp",
)


def _side_columns(prefix: str) -> tuple[tuple[str, ArrowType], ...]:
    cols: list[tuple[str, ArrowType]] = [
        (f"{prefix}_{name}", arrow_type) for name, arrow_type in _SIDE_COLUMNS
    ]
    cols.extend((f"{prefix}_flag_{flag}", "bool") for flag in _FLAG_FIELDS)
    return tuple(cols)


#: Ordered ``(column_name, logical_arrow_type)`` describing every Parquet column.
COLUMN_TYPES: tuple[tuple[str, ArrowType], ...] = (
    *_SCALAR_COLUMNS,
    *_side_columns("up"),
    *_side_columns("down"),
)

#: Ordered list of Parquet column names.
COLUMN_NAMES: tuple[str, ...] = tuple(name for name, _ in COLUMN_TYPES)


def _dec_to_str(value: Decimal | None) -> str | None:
    return None if value is None else str(value)


def _str_to_dec(value: object) -> Decimal | None:
    if value is None or value == "":
        return None
    return Decimal(str(value))


def _levels_to_json(levels: tuple[RecordedLevel, ...]) -> str:
    return json.dumps([[str(level.price), str(level.size)] for level in levels])


def _levels_from_json(raw: object) -> tuple[RecordedLevel, ...]:
    if raw is None or raw == "":
        return ()
    parsed = json.loads(str(raw))
    return tuple(
        RecordedLevel(price=Decimal(str(price)), size=Decimal(str(size)))
        for price, size in parsed
    )


def _int_or_none(value: object) -> int | None:
    return None if value is None else int(value)


def _float_or_none(value: object) -> float | None:
    return None if value is None else float(value)


def _side_to_row(prefix: str, side: RecordedBookSide) -> dict[str, object]:
    flags = side.flags
    row: dict[str, object] = {
        f"{prefix}_side": side.side,
        f"{prefix}_token_id": side.token_id,
        f"{prefix}_status": side.status,
        f"{prefix}_best_bid": _dec_to_str(side.best_bid),
        f"{prefix}_best_ask": _dec_to_str(side.best_ask),
        f"{prefix}_best_bid_size": _dec_to_str(side.best_bid_size),
        f"{prefix}_best_ask_size": _dec_to_str(side.best_ask_size),
        f"{prefix}_spread": _dec_to_str(side.spread),
        f"{prefix}_mid": _dec_to_str(side.mid),
        f"{prefix}_bid_levels_count": side.bid_levels_count,
        f"{prefix}_ask_levels_count": side.ask_levels_count,
        f"{prefix}_bid_depth_total": str(side.bid_depth_total),
        f"{prefix}_ask_depth_total": str(side.ask_depth_total),
        f"{prefix}_bids_json": _levels_to_json(side.bids),
        f"{prefix}_asks_json": _levels_to_json(side.asks),
        f"{prefix}_exchange_timestamp_ms": side.exchange_timestamp_ms,
        f"{prefix}_local_receipt_epoch": side.local_receipt_epoch,
        f"{prefix}_processed_epoch": side.processed_epoch,
        f"{prefix}_age_seconds": side.age_seconds,
    }
    for flag in _FLAG_FIELDS:
        row[f"{prefix}_flag_{flag}"] = getattr(flags, flag)
    return row


def _row_to_side(prefix: str, row: Mapping[str, object]) -> RecordedBookSide:
    flags = DataQualityFlags(
        **{flag: bool(row[f"{prefix}_flag_{flag}"]) for flag in _FLAG_FIELDS}
    )
    return RecordedBookSide(
        side=str(row[f"{prefix}_side"]),
        token_id=str(row[f"{prefix}_token_id"]),
        status=str(row[f"{prefix}_status"]),
        best_bid=_str_to_dec(row[f"{prefix}_best_bid"]),
        best_ask=_str_to_dec(row[f"{prefix}_best_ask"]),
        best_bid_size=_str_to_dec(row[f"{prefix}_best_bid_size"]),
        best_ask_size=_str_to_dec(row[f"{prefix}_best_ask_size"]),
        spread=_str_to_dec(row[f"{prefix}_spread"]),
        mid=_str_to_dec(row[f"{prefix}_mid"]),
        bid_levels_count=int(row[f"{prefix}_bid_levels_count"]),  # type: ignore[arg-type]
        ask_levels_count=int(row[f"{prefix}_ask_levels_count"]),  # type: ignore[arg-type]
        bid_depth_total=Decimal(str(row[f"{prefix}_bid_depth_total"])),
        ask_depth_total=Decimal(str(row[f"{prefix}_ask_depth_total"])),
        bids=_levels_from_json(row[f"{prefix}_bids_json"]),
        asks=_levels_from_json(row[f"{prefix}_asks_json"]),
        exchange_timestamp_ms=_int_or_none(row[f"{prefix}_exchange_timestamp_ms"]),
        local_receipt_epoch=_int_or_none(row[f"{prefix}_local_receipt_epoch"]),
        processed_epoch=_int_or_none(row[f"{prefix}_processed_epoch"]),
        age_seconds=_float_or_none(row[f"{prefix}_age_seconds"]),
        flags=flags,
    )


def snapshot_to_row(snapshot: RecordedPairSnapshot) -> dict[str, object]:
    """Flatten a snapshot into a single Parquet-friendly row mapping."""
    row: dict[str, object] = {
        "window_id": snapshot.window_id,
        "market_slug": snapshot.market_slug,
        "sequence": snapshot.sequence,
        "capture_epoch": snapshot.capture_epoch,
        "trigger_reasons": snapshot.trigger_reasons,
        "executable_pair_cost": _dec_to_str(snapshot.executable_pair_cost),
        "pair_cost_level": _dec_to_str(snapshot.pair_cost_level),
        "top_depth": snapshot.top_depth,
    }
    row.update(_side_to_row("up", snapshot.up))
    row.update(_side_to_row("down", snapshot.down))
    return row


def row_to_snapshot(row: Mapping[str, object]) -> RecordedPairSnapshot:
    """Reconstruct a snapshot from a flattened Parquet row mapping."""
    reasons = str(row["trigger_reasons"]) if row["trigger_reasons"] else ""
    triggers = tuple(
        SnapshotTrigger(part) for part in reasons.split(",") if part
    )
    return RecordedPairSnapshot(
        window_id=str(row["window_id"]),
        market_slug=None if row["market_slug"] is None else str(row["market_slug"]),
        sequence=int(row["sequence"]),  # type: ignore[arg-type]
        capture_epoch=int(row["capture_epoch"]),  # type: ignore[arg-type]
        triggers=triggers,
        up=_row_to_side("up", row),
        down=_row_to_side("down", row),
        executable_pair_cost=_str_to_dec(row["executable_pair_cost"]),
        pair_cost_level=_str_to_dec(row["pair_cost_level"]),
        top_depth=int(row["top_depth"]),  # type: ignore[arg-type]
    )


__all__ = [
    "COLUMN_NAMES",
    "COLUMN_TYPES",
    "row_to_snapshot",
    "snapshot_to_row",
]
