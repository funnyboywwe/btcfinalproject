"""The market-data recorder service (Module 7).

:class:`MarketDataRecorder` polls the in-memory Up/Down books exposed by an
:class:`OrderBookProvider`, decides via :class:`SnapshotSampler` whether to
capture a snapshot, and hands accepted snapshots to a bounded buffer. A
separate writer task drains the buffer in batches and fans out to the bulk
(Parquet) and summary (PostgreSQL) sinks.

Why this never blocks the WebSocket reader:

* The recorder only *reads* the already-parsed, in-memory books via the
  ``OrderBookProvider`` protocol; it issues no network calls and shares no
  lock with the feed reader.
* Slow disk/database writes happen on the writer task, decoupled by the bounded
  buffer. Even under the ``BLOCK`` overflow policy, only the recorder's own
  poll loop can be back-pressured -- never the feed's reader task.

The recorder implements no order execution and derives no trading decisions.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable, Sequence
from decimal import Decimal

from polymarket_pair_bot.domain.entities import OrderBookSnapshot
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.market_data import BookQuote, OrderBookProvider
from polymarket_pair_bot.domain.recording import (
    DataQualityFlags,
    RecordedBookSide,
    RecordedLevel,
    RecordedPairSnapshot,
    SnapshotTrigger,
    summary_from_snapshot,
)
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.recorder.buffer import BoundedSnapshotBuffer
from polymarket_pair_bot.recorder.config import RecorderRuntimeConfig
from polymarket_pair_bot.recorder.metrics import RecorderMetrics
from polymarket_pair_bot.recorder.ports import SnapshotSink, SummarySink
from polymarket_pair_bot.recorder.sampler import SideObservation, SnapshotSampler

_LOGGER = get_logger("recorder.service")

Sleeper = Callable[[float], Awaitable[None]]


def executable_pair_cost(up: BookQuote, down: BookQuote) -> Decimal | None:
    """Top-of-book cost to acquire one Up+Down pair by taking both best asks.

    Returns ``None`` when either side has no ask. This is a research-grade
    proxy that excludes fees, slippage and merge overhead, so it is NOT the
    strategy's ``effective_pair_cost`` and implies nothing about profitability.
    """
    if up.best_ask is None or down.best_ask is None:
        return None
    return up.best_ask.value + down.best_ask.value


class MarketDataRecorder:
    """Owns the recorder poll loop, bounded buffer and writer task."""

    def __init__(
        self,
        *,
        provider: OrderBookProvider,
        sampler: SnapshotSampler,
        buffer: BoundedSnapshotBuffer,
        snapshot_sink: SnapshotSink,
        summary_sink: SummarySink,
        config: RecorderRuntimeConfig,
        window_id: str,
        market_slug: str | None = None,
        metrics: RecorderMetrics | None = None,
        monotonic: Callable[[], float] | None = None,
        wall_clock: Callable[[], int] | None = None,
        sleep: Sleeper | None = None,
    ) -> None:
        self._provider = provider
        self._sampler = sampler
        self._buffer = buffer
        self._snapshot_sink = snapshot_sink
        self._summary_sink = summary_sink
        self._config = config
        self._window_id = window_id
        self._market_slug = market_slug
        self._metrics = metrics or RecorderMetrics()
        self._monotonic = monotonic or time.monotonic
        self._wall_clock = wall_clock or (lambda: int(time.time()))
        self._sleep = sleep or asyncio.sleep
        self._stop = asyncio.Event()
        self._poll_done = asyncio.Event()
        self._sequence = 0

    @property
    def metrics(self) -> RecorderMetrics:
        return self._metrics

    def request_stop(self) -> None:
        """Signal the recorder to stop after flushing buffered snapshots."""
        self._stop.set()

    async def run(self) -> None:
        """Run the poll and writer tasks until stopped, then flush and close.

        Structured supervision: the writer is always awaited (so buffered
        snapshots are flushed) and both sinks are always closed, even if the
        poll loop raises.
        """
        self._stop.clear()
        self._poll_done.clear()
        _LOGGER.info(
            "recorder_starting",
            extra={
                "window_id": self._window_id,
                "market_slug": self._market_slug,
                "top_depth_levels": self._config.top_depth_levels,
                "overflow_policy": self._config.overflow_policy.value,
                "buffer_max_size": self._config.buffer_max_size,
            },
        )
        writer_task = asyncio.create_task(self._writer_loop(), name="recorder-writer")
        try:
            await self._poll_loop()
        finally:
            self._poll_done.set()
            try:
                await writer_task
            finally:
                await self._close_sinks()
        _LOGGER.info("recorder_stopped", extra=self._metrics.as_dict())

    async def _poll_loop(self) -> None:
        try:
            while not self._stop.is_set():
                await self._capture_once()
                await self._sleep(self._config.poll_interval_seconds)
        except asyncio.CancelledError:  # pragma: no cover - cooperative cancel
            raise

    async def _capture_once(self) -> None:
        up_quote = self._provider.quote(OutcomeSide.UP)
        down_quote = self._provider.quote(OutcomeSide.DOWN)
        pair_cost = executable_pair_cost(up_quote, down_quote)
        decision = self._sampler.evaluate(
            up=SideObservation.from_quote(up_quote),
            down=SideObservation.from_quote(down_quote),
            pair_cost=pair_cost,
            now_monotonic=self._monotonic(),
        )
        if not decision.should_record:
            return
        self._sequence += 1
        snapshot = self._build_snapshot(
            up_quote,
            down_quote,
            pair_cost=pair_cost,
            crossed_level=decision.crossed_level,
            triggers=decision.triggers,
        )
        self._metrics.snapshots_captured += 1
        await self._buffer.put(snapshot)

    def _build_snapshot(
        self,
        up_quote: BookQuote,
        down_quote: BookQuote,
        *,
        pair_cost: Decimal | None,
        crossed_level: Decimal | None,
        triggers: tuple[SnapshotTrigger, ...],
    ) -> RecordedPairSnapshot:
        capture_epoch = self._wall_clock()
        up_side = self._build_side(up_quote, self._provider.snapshot(OutcomeSide.UP))
        down_side = self._build_side(down_quote, self._provider.snapshot(OutcomeSide.DOWN))
        return RecordedPairSnapshot(
            window_id=self._window_id,
            market_slug=self._market_slug,
            sequence=self._sequence,
            capture_epoch=capture_epoch,
            triggers=triggers,
            up=up_side,
            down=down_side,
            executable_pair_cost=pair_cost,
            pair_cost_level=crossed_level,
            top_depth=self._config.top_depth_levels,
        )

    def _build_side(
        self,
        quote: BookQuote,
        book: OrderBookSnapshot | None,
    ) -> RecordedBookSide:
        top = self._config.top_depth_levels
        bids = tuple(
            RecordedLevel(price=level.price.value, size=level.size.value)
            for level in (book.bids[:top] if book else ())
        )
        asks = tuple(
            RecordedLevel(price=level.price.value, size=level.size.value)
            for level in (book.asks[:top] if book else ())
        )
        flags = DataQualityFlags(
            has_snapshot=book is not None,
            is_live=quote.status.is_usable,
            is_stale=quote.status.value == "stale",
            is_unavailable=quote.status.value == "unavailable",
            is_crossed=quote.is_crossed,
            is_empty=quote.bid_levels == 0 or quote.ask_levels == 0,
            missing_best_bid=quote.best_bid is None,
            missing_best_ask=quote.best_ask is None,
            missing_exchange_timestamp=quote.exchange_timestamp_ms is None,
        )
        return RecordedBookSide(
            side=quote.side.value,
            token_id=quote.token_id.value,
            status=quote.status.value,
            best_bid=None if quote.best_bid is None else quote.best_bid.value,
            best_ask=None if quote.best_ask is None else quote.best_ask.value,
            best_bid_size=None if quote.best_bid_size is None else quote.best_bid_size.value,
            best_ask_size=None if quote.best_ask_size is None else quote.best_ask_size.value,
            spread=quote.spread,
            mid=quote.mid,
            bid_levels_count=quote.bid_levels,
            ask_levels_count=quote.ask_levels,
            bid_depth_total=quote.bid_depth.value,
            ask_depth_total=quote.ask_depth.value,
            bids=bids,
            asks=asks,
            exchange_timestamp_ms=quote.exchange_timestamp_ms,
            local_receipt_epoch=quote.local_receipt_epoch,
            processed_epoch=quote.processed_epoch,
            age_seconds=quote.age_seconds,
            flags=flags,
        )

    async def _writer_loop(self) -> None:
        while not (self._poll_done.is_set() and self._buffer.empty()):
            batch = await self._buffer.drain(
                max_items=self._config.write_batch_size,
                timeout=self._config.flush_interval_seconds,
            )
            if batch:
                await self._flush_batch(batch)
        remaining = self._buffer.drain_nowait()
        if remaining:
            await self._flush_batch(remaining)

    async def _flush_batch(self, batch: Sequence[RecordedPairSnapshot]) -> None:
        try:
            written = await self._snapshot_sink.write_batch(batch)
            self._metrics.snapshots_written += written
            if self._config.persist_summaries:
                summaries = [summary_from_snapshot(item) for item in batch]
                count = await self._summary_sink.write_batch(summaries)
                self._metrics.summaries_written += count
            self._metrics.flushes += 1
        except Exception:  # noqa: BLE001 - research recorder is best-effort
            self._metrics.write_errors += 1
            _LOGGER.exception(
                "recorder_write_failed",
                extra={"window_id": self._window_id, "batch_size": len(batch)},
            )

    async def _close_sinks(self) -> None:
        for sink in (self._snapshot_sink, self._summary_sink):
            try:
                await sink.aclose()
            except Exception:  # noqa: BLE001 - always attempt to close both
                _LOGGER.exception("recorder_sink_close_failed")


__all__ = ["MarketDataRecorder", "executable_pair_cost"]
