"""In-memory level-two order book for a single outcome token (Module 6).

Pure logic: no networking, no persistence. Price levels are keyed by
``Decimal`` price mapping to a ``Decimal`` resting size. Rules enforced:

* incremental changes are rejected until an authoritative snapshot is applied
  (:class:`UpdateBeforeSnapshotError`);
* negative sizes are impossible and rejected (:class:`NegativeSizeError`);
* zero-size levels are removed;
* a resulting crossed book (best_bid >= best_ask) is rejected
  (:class:`CrossedBookError`).

The book records exchange / receipt / processing timestamps and exposes an
immutable :class:`~polymarket_pair_bot.domain.entities.OrderBookSnapshot`.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.entities import OrderBookSnapshot, PriceLevel
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.market_data.errors import (
    CrossedBookError,
    NegativeSizeError,
    UpdateBeforeSnapshotError,
)
from polymarket_pair_bot.market_data.messages import BookSide, WireChange, WireLevel


class LocalOrderBook:
    """Mutable L2 book for one token. Not safe for concurrent mutation."""

    def __init__(self, token_id: TokenId, side: OutcomeSide) -> None:
        self._token_id = token_id
        self._side = side
        self._bids: dict[Decimal, Decimal] = {}
        self._asks: dict[Decimal, Decimal] = {}
        self._has_snapshot = False
        self._sequence: int | None = None
        self._exchange_ts_ms: int | None = None
        self._local_receipt_epoch: int | None = None
        self._processed_epoch: int | None = None
        self._last_update_monotonic: float | None = None

    # -- identity --------------------------------------------------------- #
    @property
    def token_id(self) -> TokenId:
        return self._token_id

    @property
    def side(self) -> OutcomeSide:
        return self._side

    @property
    def has_snapshot(self) -> bool:
        return self._has_snapshot

    # -- timestamps ------------------------------------------------------- #
    @property
    def exchange_timestamp_ms(self) -> int | None:
        return self._exchange_ts_ms

    @property
    def local_receipt_epoch(self) -> int | None:
        return self._local_receipt_epoch

    @property
    def processed_epoch(self) -> int | None:
        return self._processed_epoch

    @property
    def last_update_monotonic(self) -> float | None:
        return self._last_update_monotonic

    # -- lifecycle -------------------------------------------------------- #
    def reset(self) -> None:
        """Drop all state; the book again requires an authoritative snapshot."""
        self._bids.clear()
        self._asks.clear()
        self._has_snapshot = False
        self._sequence = None
        # Timestamps are intentionally retained for observability of the last
        # good data; freshness is driven by ``last_update_monotonic`` which is
        # left as-is so age keeps growing until a fresh snapshot arrives.

    @staticmethod
    def _validate_size(raw: Decimal) -> Decimal:
        if raw < 0:
            raise NegativeSizeError(f"negative size is impossible: {raw}")
        # Round-trips through the domain value object to enforce precision and
        # non-negativity invariants consistently.
        return Shares(raw).value

    @staticmethod
    def _validate_price(raw: Decimal) -> Decimal:
        # ProbabilityPrice enforces the inclusive [0, 1] range.
        return ProbabilityPrice(raw).value

    def _stamp(
        self,
        *,
        exchange_ts_ms: int | None,
        receipt_epoch: int,
        processed_epoch: int,
        monotonic: float,
        sequence: int | None,
    ) -> None:
        self._exchange_ts_ms = exchange_ts_ms
        self._local_receipt_epoch = receipt_epoch
        self._processed_epoch = processed_epoch
        self._last_update_monotonic = monotonic
        if sequence is not None:
            self._sequence = sequence

    def apply_snapshot(
        self,
        bids: tuple[WireLevel, ...],
        asks: tuple[WireLevel, ...],
        *,
        exchange_ts_ms: int | None,
        receipt_epoch: int,
        processed_epoch: int,
        monotonic: float,
        sequence: int | None = None,
    ) -> None:
        """Replace the entire book with an authoritative snapshot."""
        new_bids: dict[Decimal, Decimal] = {}
        new_asks: dict[Decimal, Decimal] = {}
        for level in bids:
            size = self._validate_size(level.size)
            price = self._validate_price(level.price)
            if size > 0:
                new_bids[price] = size
        for level in asks:
            size = self._validate_size(level.size)
            price = self._validate_price(level.price)
            if size > 0:
                new_asks[price] = size
        self._guard_not_crossed(new_bids, new_asks)
        self._bids = new_bids
        self._asks = new_asks
        self._has_snapshot = True
        self._stamp(
            exchange_ts_ms=exchange_ts_ms,
            receipt_epoch=receipt_epoch,
            processed_epoch=processed_epoch,
            monotonic=monotonic,
            sequence=sequence,
        )

    def apply_changes(
        self,
        changes: tuple[WireChange, ...],
        *,
        exchange_ts_ms: int | None,
        receipt_epoch: int,
        processed_epoch: int,
        monotonic: float,
        sequence: int | None = None,
    ) -> None:
        """Apply incremental level changes to an already-snapshotted book."""
        if not self._has_snapshot:
            raise UpdateBeforeSnapshotError(
                "received incremental change before an authoritative snapshot"
            )
        # Apply onto copies so a crossed/invalid update leaves the book intact.
        new_bids = dict(self._bids)
        new_asks = dict(self._asks)
        for change in changes:
            size = self._validate_size(change.size)
            price = self._validate_price(change.price)
            book = new_bids if change.side is BookSide.BID else new_asks
            if size == 0:
                book.pop(price, None)
            else:
                book[price] = size
        self._guard_not_crossed(new_bids, new_asks)
        self._bids = new_bids
        self._asks = new_asks
        self._stamp(
            exchange_ts_ms=exchange_ts_ms,
            receipt_epoch=receipt_epoch,
            processed_epoch=processed_epoch,
            monotonic=monotonic,
            sequence=sequence,
        )

    @staticmethod
    def _guard_not_crossed(
        bids: dict[Decimal, Decimal], asks: dict[Decimal, Decimal]
    ) -> None:
        if not bids or not asks:
            return
        if max(bids) >= min(asks):
            raise CrossedBookError(
                f"crossed book: best_bid {max(bids)} >= best_ask {min(asks)}"
            )

    # -- read views ------------------------------------------------------- #
    @property
    def best_bid(self) -> Decimal | None:
        return max(self._bids) if self._bids else None

    @property
    def best_ask(self) -> Decimal | None:
        return min(self._asks) if self._asks else None

    @property
    def bid_levels(self) -> int:
        return len(self._bids)

    @property
    def ask_levels(self) -> int:
        return len(self._asks)

    def bid_depth(self) -> Decimal:
        return sum(self._bids.values(), Decimal(0))

    def ask_depth(self) -> Decimal:
        return sum(self._asks.values(), Decimal(0))

    def to_snapshot(self, *, as_of_epoch: int) -> OrderBookSnapshot:
        """Return an immutable, correctly-sorted domain snapshot."""
        bids = tuple(
            PriceLevel(price=ProbabilityPrice(price), size=Shares(size))
            for price, size in sorted(self._bids.items(), reverse=True)
        )
        asks = tuple(
            PriceLevel(price=ProbabilityPrice(price), size=Shares(size))
            for price, size in sorted(self._asks.items())
        )
        return OrderBookSnapshot(
            token_id=self._token_id,
            bids=bids,
            asks=asks,
            as_of=UnixTimestamp(as_of_epoch),
            sequence=self._sequence,
        )


__all__ = ["LocalOrderBook"]
