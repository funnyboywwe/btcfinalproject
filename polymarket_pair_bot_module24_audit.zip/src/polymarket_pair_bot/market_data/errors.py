"""Market-data error hierarchy (Module 6).

These are raised by the message parser and local order book when external data
is malformed or logically impossible. The feed runner treats them as faults:
it logs, marks the affected book unavailable, and requires a fresh
authoritative snapshot (fail closed).
"""

from __future__ import annotations


class MarketDataError(Exception):
    """Base class for all market-data errors."""


class MalformedMessageError(MarketDataError):
    """A WebSocket message failed schema validation or could not be parsed."""


class UpdateBeforeSnapshotError(MarketDataError):
    """An incremental change arrived before an authoritative snapshot."""


class NegativeSizeError(MarketDataError):
    """A price level reported an impossible negative size."""


class CrossedBookError(MarketDataError):
    """Applying an update would leave best_bid >= best_ask (crossed)."""


class StaleBookError(MarketDataError):
    """A book was read (or checked) after exceeding its freshness bound."""


class FeedUnavailableError(MarketDataError):
    """The feed is not currently usable (disconnected / awaiting snapshot)."""


class MarketDataConfigurationError(MarketDataError):
    """The market-data feed was asked to run without required configuration."""


__all__ = [
    "CrossedBookError",
    "FeedUnavailableError",
    "MalformedMessageError",
    "MarketDataConfigurationError",
    "MarketDataError",
    "NegativeSizeError",
    "StaleBookError",
    "UpdateBeforeSnapshotError",
]
