"""Order-book manager: owns the Up and Down books and feed health (Module 6).

The manager is pure with respect to I/O: it consumes already-validated
messages and clock readings, mutates the two independent :class:`LocalOrderBook`
instances, tracks per-book timestamps and the reconnect count, and implements
the read-only :class:`OrderBookProvider` protocol. It never imports a
WebSocket/HTTP/DB client.

Freshness is measured with an injected monotonic clock (seconds). A book is
only ``LIVE`` when it has an authoritative snapshot, the connection is up, and
its age is within the configured bound; otherwise it degrades to
``AWAITING_SNAPSHOT``, ``STALE`` or ``UNAVAILABLE`` (fail closed).
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.entities import OrderBookSnapshot
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.market_data import (
    BookQuote,
    FeedStatus,
    OrderBookProvider,
)
from polymarket_pair_bot.domain.value_objects import (
    ProbabilityPrice,
    Shares,
    TokenId,
)
from polymarket_pair_bot.market_data.book import LocalOrderBook
from polymarket_pair_bot.market_data.messages import (
    BookSnapshotMessage,
    PriceChangeMessage,
    TickSizeChangeMessage,
    TradeMessage,
)
from polymarket_pair_bot.market_data.ports import MonotonicClock, WallClock
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("market_data.manager")


def _default_monotonic() -> float:
    import time

    return time.monotonic()


def _default_wall() -> int:
    import time

    return int(time.time())


class OrderBookManager(OrderBookProvider):
    """Maintains independent L2 books for the Up and Down tokens."""

    def __init__(
        self,
        up_token_id: TokenId,
        down_token_id: TokenId,
        *,
        stale_after_seconds: float = 5.0,
        monotonic: MonotonicClock | None = None,
        wall_clock: WallClock | None = None,
    ) -> None:
        if up_token_id == down_token_id:
            raise ValueError("up and down token ids must differ")
        if stale_after_seconds <= 0:
            raise ValueError("stale_after_seconds must be positive")
        self._stale_after = stale_after_seconds
        self._monotonic = monotonic or _default_monotonic
        self._wall = wall_clock or _default_wall
        self._books: dict[OutcomeSide, LocalOrderBook] = {
            OutcomeSide.UP: LocalOrderBook(up_token_id, OutcomeSide.UP),
            OutcomeSide.DOWN: LocalOrderBook(down_token_id, OutcomeSide.DOWN),
        }
        self._by_token: dict[str, OutcomeSide] = {
            up_token_id.value: OutcomeSide.UP,
            down_token_id.value: OutcomeSide.DOWN,
        }
        self._connected = False
        self._reconnect_count = 0
        # Latest tick size reported per side (observed, not trusted for pricing).
        self._tick_size: dict[OutcomeSide, Decimal] = {}
        # Last trade print per side (observability only; not order-book data).
        self._last_trade_price: dict[OutcomeSide, Decimal] = {}

    # -- connection lifecycle (called by the feed runner) ------------------ #
    def mark_connected(self) -> None:
        """Mark the transport connected; books still await fresh snapshots."""
        self._connected = True

    def mark_disconnected(self) -> None:
        """Mark the feed unavailable and require a fresh snapshot on reconnect.

        Called immediately on disconnection (requirement 8). Both books are
        reset so no stale levels survive a reconnect (requirement 9).
        """
        self._connected = False
        for book in self._books.values():
            book.reset()

    def note_reconnect(self) -> None:
        """Increment the reconnect counter (a reconnect just occurred)."""
        self._reconnect_count += 1

    # -- token routing ---------------------------------------------------- #
    def side_for_token(self, token_id: str) -> OutcomeSide | None:
        return self._by_token.get(token_id)

    @property
    def token_ids(self) -> tuple[str, str]:
        return (
            self._books[OutcomeSide.UP].token_id.value,
            self._books[OutcomeSide.DOWN].token_id.value,
        )

    # -- message application ---------------------------------------------- #
    def apply_message(
        self,
        message: BookSnapshotMessage
        | PriceChangeMessage
        | TickSizeChangeMessage
        | TradeMessage,
    ) -> None:
        """Route a validated message to the correct book.

        Raises the market-data faults from :mod:`market_data.errors` on
        impossible data (crossed book, negative size, update-before-snapshot).
        Messages for an unknown asset id are ignored (defensive; we only
        subscribed to two tokens).
        """
        side = self._by_token.get(message.asset_id)
        if side is None:
            _LOGGER.warning(
                "ignoring message for unsubscribed asset",
                extra={"event_type": message.event_type},
            )
            return
        monotonic = self._monotonic()
        receipt = self._wall()
        book = self._books[side]
        if isinstance(message, BookSnapshotMessage):
            book.apply_snapshot(
                message.bids,
                message.asks,
                exchange_ts_ms=message.timestamp,
                receipt_epoch=receipt,
                processed_epoch=self._wall(),
                monotonic=monotonic,
            )
        elif isinstance(message, PriceChangeMessage):
            book.apply_changes(
                message.changes,
                exchange_ts_ms=message.timestamp,
                receipt_epoch=receipt,
                processed_epoch=self._wall(),
                monotonic=monotonic,
            )
        elif isinstance(message, TickSizeChangeMessage):
            self._tick_size[side] = message.new_tick_size
        elif isinstance(message, TradeMessage):
            self._last_trade_price[side] = message.price

    # -- OrderBookProvider (read-only) ------------------------------------ #
    def _book(self, side: OutcomeSide) -> LocalOrderBook:
        return self._books[side]

    def _age_seconds(self, book: LocalOrderBook) -> float | None:
        last = book.last_update_monotonic
        if last is None:
            return None
        return max(0.0, self._monotonic() - last)

    def feed_status(self, side: OutcomeSide) -> FeedStatus:
        book = self._book(side)
        if not self._connected:
            return FeedStatus.UNAVAILABLE
        if not book.has_snapshot:
            return FeedStatus.AWAITING_SNAPSHOT
        age = self._age_seconds(book)
        if age is None or age > self._stale_after:
            return FeedStatus.STALE
        return FeedStatus.LIVE

    def is_fresh(self, side: OutcomeSide) -> bool:
        return self.feed_status(side) is FeedStatus.LIVE

    @property
    def reconnect_count(self) -> int:
        return self._reconnect_count

    def tick_size(self, side: OutcomeSide) -> Decimal | None:
        return self._tick_size.get(side)

    def last_trade_price(self, side: OutcomeSide) -> Decimal | None:
        return self._last_trade_price.get(side)

    def snapshot(self, side: OutcomeSide) -> OrderBookSnapshot | None:
        book = self._book(side)
        if not book.has_snapshot:
            return None
        return book.to_snapshot(as_of_epoch=book.processed_epoch or self._wall())

    def quote(self, side: OutcomeSide) -> BookQuote:
        book = self._book(side)
        best_bid = book.best_bid
        best_ask = book.best_ask
        bid_size = self._size_at(book, best_bid, is_bid=True)
        ask_size = self._size_at(book, best_ask, is_bid=False)
        return BookQuote(
            side=side,
            token_id=book.token_id,
            status=self.feed_status(side),
            best_bid=ProbabilityPrice(best_bid) if best_bid is not None else None,
            best_ask=ProbabilityPrice(best_ask) if best_ask is not None else None,
            best_bid_size=Shares(bid_size) if bid_size is not None else None,
            best_ask_size=Shares(ask_size) if ask_size is not None else None,
            bid_levels=book.bid_levels,
            ask_levels=book.ask_levels,
            bid_depth=Shares(book.bid_depth()),
            ask_depth=Shares(book.ask_depth()),
            exchange_timestamp_ms=book.exchange_timestamp_ms,
            local_receipt_epoch=book.local_receipt_epoch,
            processed_epoch=book.processed_epoch,
            age_seconds=self._age_seconds(book),
        )

    @staticmethod
    def _size_at(
        book: LocalOrderBook, price: Decimal | None, *, is_bid: bool
    ) -> Decimal | None:
        if price is None:
            return None
        snapshot = book.to_snapshot(as_of_epoch=0)
        levels = snapshot.bids if is_bid else snapshot.asks
        for level in levels:
            if level.price.value == price:
                return level.size.value
        return None


__all__ = ["OrderBookManager"]
