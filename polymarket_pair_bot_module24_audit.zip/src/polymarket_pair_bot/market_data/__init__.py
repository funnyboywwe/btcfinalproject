"""Public CLOB market-data WebSocket and local order books (Module 6).

Exposes the async feed runner, the order-book manager (which implements the
read-only ``OrderBookProvider`` domain protocol), the local L2 book, the
validated message schemas, and the transport ports. No order submission or
strategy logic lives here.
"""

from __future__ import annotations

from polymarket_pair_bot.market_data.book import LocalOrderBook
from polymarket_pair_bot.market_data.errors import (
    CrossedBookError,
    FeedUnavailableError,
    MalformedMessageError,
    MarketDataConfigurationError,
    MarketDataError,
    NegativeSizeError,
    StaleBookError,
    UpdateBeforeSnapshotError,
)
from polymarket_pair_bot.market_data.factory import (
    build_feed_config,
    build_market_data_feed,
    build_order_book_manager,
)
from polymarket_pair_bot.market_data.feed import (
    FeedMetrics,
    MarketDataFeed,
    MarketDataFeedConfig,
    build_subscribe_message,
)
from polymarket_pair_bot.market_data.manager import OrderBookManager
from polymarket_pair_bot.market_data.messages import (
    BookSide,
    BookSnapshotMessage,
    ParsedFrame,
    PriceChangeMessage,
    TickSizeChangeMessage,
    TradeMessage,
    parse_frame,
)
from polymarket_pair_bot.market_data.ports import (
    WebSocketConnection,
    WebSocketConnector,
)

__all__ = [
    "BookSide",
    "BookSnapshotMessage",
    "CrossedBookError",
    "FeedMetrics",
    "FeedUnavailableError",
    "LocalOrderBook",
    "MalformedMessageError",
    "MarketDataConfigurationError",
    "MarketDataError",
    "MarketDataFeed",
    "MarketDataFeedConfig",
    "NegativeSizeError",
    "OrderBookManager",
    "ParsedFrame",
    "PriceChangeMessage",
    "StaleBookError",
    "TickSizeChangeMessage",
    "TradeMessage",
    "UpdateBeforeSnapshotError",
    "WebSocketConnection",
    "WebSocketConnector",
    "build_feed_config",
    "build_market_data_feed",
    "build_order_book_manager",
    "build_subscribe_message",
    "parse_frame",
]
