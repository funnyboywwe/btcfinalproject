"""Composition helpers wiring config -> market-data feed (Module 6).

This wiring layer is allowed to import concrete adapters; the domain and the
manager are not. Nothing here submits orders.
"""

from __future__ import annotations

from polymarket_pair_bot.config import AppConfig
from polymarket_pair_bot.domain.value_objects import TokenId
from polymarket_pair_bot.market_data.feed import (
    MarketDataFeed,
    MarketDataFeedConfig,
)
from polymarket_pair_bot.market_data.manager import OrderBookManager
from polymarket_pair_bot.market_data.ports import WebSocketConnector
from polymarket_pair_bot.market_data.ws_client import WebsocketsConnector


def build_order_book_manager(
    config: AppConfig,
    up_token_id: TokenId,
    down_token_id: TokenId,
) -> OrderBookManager:
    """Create an :class:`OrderBookManager` for the two validated token ids."""
    md = config.market_data
    return OrderBookManager(
        up_token_id,
        down_token_id,
        stale_after_seconds=md.stale_after_seconds,
    )


def build_feed_config(config: AppConfig) -> MarketDataFeedConfig:
    """Translate settings into a :class:`MarketDataFeedConfig`."""
    md = config.market_data
    return MarketDataFeedConfig(
        url=config.polymarket_public.polymarket_market_ws_url,
        subscribe_type=md.subscribe_type,
        max_queue_size=md.max_queue_size,
        reconnect_base_seconds=md.reconnect_base_seconds,
        reconnect_max_seconds=md.reconnect_max_seconds,
        max_reconnect_attempts=md.max_reconnect_attempts,
    )


def build_market_data_feed(
    config: AppConfig,
    up_token_id: TokenId,
    down_token_id: TokenId,
    *,
    connector: WebSocketConnector | None = None,
    manager: OrderBookManager | None = None,
) -> tuple[MarketDataFeed, OrderBookManager]:
    """Build a feed + manager pair.

    A ``connector`` (and/or ``manager``) may be injected for tests; by default
    a real :class:`WebsocketsConnector` is created.
    """
    md = config.market_data
    book_manager = manager or build_order_book_manager(
        config, up_token_id, down_token_id
    )
    ws_connector = connector or WebsocketsConnector(
        open_timeout=md.connect_timeout_seconds,
        ping_interval=md.ping_interval_seconds,
        ping_timeout=md.ping_timeout_seconds,
    )
    feed = MarketDataFeed(ws_connector, book_manager, build_feed_config(config))
    return feed, book_manager


__all__ = [
    "build_feed_config",
    "build_market_data_feed",
    "build_order_book_manager",
]
