"""``market-data-monitor`` command: live Up/Down book viewer (Module 6).

Discovers the current BTC 5-minute market (safe GETs only), subscribes to both
validated token ids on the public market WebSocket, and periodically prints a
secret-free snapshot of:

* Up bid/ask, Down bid/ask;
* spread per side;
* depth (levels and summed size) per side;
* freshness (feed status + book age) and reconnect count.

This command reads market data only. It never submits an order and performs no
strategy logic.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import sys
from collections.abc import Sequence

from polymarket_pair_bot.config import AppConfig, load_config
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.market_data import BookQuote
from polymarket_pair_bot.domain.value_objects import TokenId
from polymarket_pair_bot.market_data.factory import build_market_data_feed
from polymarket_pair_bot.market_data.manager import OrderBookManager
from polymarket_pair_bot.market_discovery.errors import MarketDiscoveryError
from polymarket_pair_bot.market_discovery.factory import (
    build_market_discovery_service,
)


def add_arguments(parser: argparse.ArgumentParser) -> None:
    """Register ``market-data-monitor`` options on an existing parser."""
    parser.add_argument(
        "--slug",
        default=None,
        help="Explicit market slug (disables window matching); overrides template.",
    )
    parser.add_argument(
        "--refresh-seconds",
        type=float,
        default=1.0,
        help="How often to reprint the book view (default: 1.0).",
    )
    parser.add_argument(
        "--duration-seconds",
        type=float,
        default=30.0,
        help="Total run time before exiting (default: 30.0; 0 = run until Ctrl-C).",
    )
    parser.add_argument(
        "--up-token-id",
        default=None,
        help="Bypass discovery and monitor this explicit Up token id.",
    )
    parser.add_argument(
        "--down-token-id",
        default=None,
        help="Bypass discovery and monitor this explicit Down token id.",
    )


async def _resolve_tokens(
    config: AppConfig, args: argparse.Namespace
) -> tuple[TokenId, TokenId, str]:
    """Return (up_token, down_token, label), via override or safe discovery."""
    if args.up_token_id and args.down_token_id:
        return (
            TokenId(args.up_token_id),
            TokenId(args.down_token_id),
            "explicit token override",
        )
    service = build_market_discovery_service(
        config,
        slug_override=args.slug,
        require_window_match=False if args.slug else None,
    )
    try:
        window = service.windows().current
        market = await service.discover_window(window)
    finally:
        source = getattr(service, "_source", None)
        aclose = getattr(source, "aclose", None)
        if aclose is not None:
            await aclose()
    return (
        TokenId(market.up_token_id),
        TokenId(market.down_token_id),
        f"{market.slug} (market {market.market_id})",
    )


def _fmt_quote(quote: BookQuote) -> str:
    bid = str(quote.best_bid) if quote.best_bid is not None else "-"
    ask = str(quote.best_ask) if quote.best_ask is not None else "-"
    spread = str(quote.spread) if quote.spread is not None else "-"
    age = f"{quote.age_seconds:.3f}s" if quote.age_seconds is not None else "-"
    crossed = " CROSSED" if quote.is_crossed else ""
    return (
        f"{quote.side.value.upper():<4} "
        f"bid={bid:<10} ask={ask:<10} spread={spread:<10} "
        f"depth(bid/ask)={quote.bid_levels}/{quote.ask_levels} lvls "
        f"{quote.bid_depth}/{quote.ask_depth} sz "
        f"status={quote.status.value:<16} age={age}{crossed}"
    )


def _print_view(manager: OrderBookManager, label: str) -> None:
    up = manager.quote(OutcomeSide.UP)
    down = manager.quote(OutcomeSide.DOWN)
    print(f"\n=== {label} | reconnects={manager.reconnect_count} ===")
    print(_fmt_quote(up))
    print(_fmt_quote(down))


async def _run(config: AppConfig, args: argparse.Namespace) -> int:
    up_token, down_token, label = await _resolve_tokens(config, args)
    feed, manager = build_market_data_feed(config, up_token, down_token)

    runner = asyncio.create_task(feed.run(), name="market-data-feed")
    loop = asyncio.get_running_loop()
    deadline = (
        loop.time() + args.duration_seconds if args.duration_seconds > 0 else None
    )
    try:
        while not runner.done():
            _print_view(manager, label)
            if deadline is not None and loop.time() >= deadline:
                break
            await asyncio.sleep(max(0.05, args.refresh_seconds))
    finally:
        feed.request_stop()
        runner.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await runner
    m = feed.metrics
    print(
        "\nfeed metrics: "
        f"received={m.frames_received} applied={m.frames_applied} "
        f"heartbeats={m.heartbeats} malformed={m.malformed} "
        f"faults={m.faults} overflows={m.queue_overflows} "
        f"connect_attempts={m.connect_attempts}"
    )
    return 0


def run(args: argparse.Namespace) -> int:
    """Execute the ``market-data-monitor`` command; return an exit code."""
    config = load_config()
    try:
        return asyncio.run(_run(config, args))
    except MarketDiscoveryError as exc:
        print(
            f"market-data-monitor failed during discovery: "
            f"{type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 1
    except KeyboardInterrupt:  # pragma: no cover - interactive interrupt
        return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-market-data-monitor",
        description="Live Up/Down order-book monitor (read-only).",
    )
    add_arguments(parser)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    return run(_build_parser().parse_args(argv))


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
