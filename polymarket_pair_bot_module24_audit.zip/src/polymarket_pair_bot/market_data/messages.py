"""Pydantic validation of Polymarket public market-channel messages (Module 6).

Every inbound WebSocket frame is validated here before any book logic runs
(requirement: validate all external API responses at runtime). Prices and
sizes are parsed straight into ``Decimal`` -- the transport decodes JSON with
``parse_float=Decimal`` so numeric values never pass through a binary float.

Field mapping caveat
--------------------
The field names below follow Polymarket's *documented* public market channel
(``book``, ``price_change``, ``tick_size_change``, ``last_trade_price``). We do
NOT invent undocumented fields: unknown keys are ignored (``extra="ignore"``)
and never consumed. Because the exact wire schema can change and cannot be
verified offline here, the raw side/type strings are normalized in one place
(:func:`_side_from_wire`) so a correction is localized. Anything that fails
validation raises :class:`MalformedMessageError` and is treated as a fault.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, ValidationError

from polymarket_pair_bot.market_data.errors import MalformedMessageError


def _to_decimal(value: Any) -> Decimal:
    """Coerce a wire value to Decimal without ever going through a float."""
    if isinstance(value, Decimal):
        return value
    if isinstance(value, bool):  # bool is an int subclass; reject explicitly.
        raise ValueError("boolean is not a valid numeric value")
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, str):
        text = value.strip()
        if not text:
            raise ValueError("empty numeric string")
        try:
            return Decimal(text)
        except InvalidOperation as exc:
            raise ValueError(f"invalid decimal string: {value!r}") from exc
    # Floats are intentionally rejected: the transport must decode JSON numbers
    # with parse_float=Decimal so money never touches binary floating point.
    raise ValueError(f"unsupported numeric type: {type(value).__name__}")


DecimalField = Annotated[Decimal, BeforeValidator(_to_decimal)]


def _optional_int(value: Any) -> int | None:
    """Parse an optional integer millisecond timestamp from str/int."""
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("boolean is not a valid timestamp")
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            return int(text)
        except ValueError as exc:
            raise ValueError(f"invalid integer timestamp: {value!r}") from exc
    raise ValueError(f"unsupported timestamp type: {type(value).__name__}")


OptionalMsField = Annotated[int | None, BeforeValidator(_optional_int)]


class BookSide(str, Enum):
    """Normalized order-book side."""

    BID = "bid"
    ASK = "ask"


def _side_from_wire(value: Any) -> BookSide:
    """Map Polymarket's documented BUY/SELL side strings to bid/ask.

    Centralized so the (externally-defined, offline-unverifiable) convention is
    corrected in exactly one place. BUY => bid, SELL => ask.
    """
    if isinstance(value, str):
        token = value.strip().upper()
        if token in {"BUY", "BID"}:
            return BookSide.BID
        if token in {"SELL", "ASK"}:
            return BookSide.ASK
    raise ValueError(f"unknown book side: {value!r}")


WireSideField = Annotated[BookSide, BeforeValidator(_side_from_wire)]


class _StrictModel(BaseModel):
    # Ignore unknown/undocumented fields rather than consuming or trusting them.
    model_config = ConfigDict(extra="ignore", frozen=True)


class WireLevel(_StrictModel):
    """A single price level as sent on the wire."""

    price: DecimalField
    size: DecimalField


class WireChange(_StrictModel):
    """A single incremental level change."""

    price: DecimalField
    size: DecimalField
    side: WireSideField


class BookSnapshotMessage(_StrictModel):
    """Full L2 book snapshot for one asset (``event_type == "book"``)."""

    event_type: Literal["book"]
    asset_id: str = Field(min_length=1)
    market: str | None = None
    timestamp: OptionalMsField = None
    hash: str | None = None
    bids: tuple[WireLevel, ...] = ()
    asks: tuple[WireLevel, ...] = ()


class PriceChangeMessage(_StrictModel):
    """Incremental level changes (``event_type == "price_change"``)."""

    event_type: Literal["price_change"]
    asset_id: str = Field(min_length=1)
    market: str | None = None
    timestamp: OptionalMsField = None
    hash: str | None = None
    changes: tuple[WireChange, ...] = ()


class TickSizeChangeMessage(_StrictModel):
    """Tick-size change (``event_type == "tick_size_change"``)."""

    event_type: Literal["tick_size_change"]
    asset_id: str = Field(min_length=1)
    market: str | None = None
    timestamp: OptionalMsField = None
    old_tick_size: DecimalField | None = None
    new_tick_size: DecimalField


class TradeMessage(_StrictModel):
    """Last trade print (``event_type == "last_trade_price"``), where available."""

    event_type: Literal["last_trade_price"]
    asset_id: str = Field(min_length=1)
    market: str | None = None
    timestamp: OptionalMsField = None
    price: DecimalField
    size: DecimalField | None = None
    side: WireSideField | None = None


MarketMessage = (
    BookSnapshotMessage
    | PriceChangeMessage
    | TickSizeChangeMessage
    | TradeMessage
)

_PARSERS: dict[str, type[_StrictModel]] = {
    "book": BookSnapshotMessage,
    "price_change": PriceChangeMessage,
    "tick_size_change": TickSizeChangeMessage,
    "last_trade_price": TradeMessage,
}

# Control frames that are not book data. Polymarket may send "PONG"/"PING"
# heartbeat frames; these are acknowledged and ignored, not parsed as books.
_HEARTBEAT_TOKENS = frozenset({"pong", "ping", ""})


class ParsedFrame:
    """Result of parsing one raw frame: either a message, a heartbeat, or skip."""

    __slots__ = ("heartbeat", "message")

    def __init__(
        self, *, message: _StrictModel | None, heartbeat: bool
    ) -> None:
        self.message = message
        self.heartbeat = heartbeat


def parse_frame(payload: Any) -> ParsedFrame:
    """Validate a single decoded frame.

    ``payload`` is the already-JSON-decoded value (dict, list of dicts, or a
    bare string for heartbeats). Raises :class:`MalformedMessageError` on
    anything that is neither a valid documented message nor a heartbeat.

    Note: the market channel may batch several messages into a JSON array; the
    caller is responsible for iterating a list and calling this per element.
    """
    if isinstance(payload, str):
        if payload.strip().lower() in _HEARTBEAT_TOKENS:
            return ParsedFrame(message=None, heartbeat=True)
        raise MalformedMessageError(f"unexpected text frame: {payload!r}")
    if not isinstance(payload, dict):
        raise MalformedMessageError(
            f"expected a JSON object, got {type(payload).__name__}"
        )
    event_type = payload.get("event_type")
    if event_type is None:
        # Some heartbeat/control frames are objects without an event_type.
        if payload.get("type") in {"PONG", "PING"} or not payload:
            return ParsedFrame(message=None, heartbeat=True)
        raise MalformedMessageError("message is missing 'event_type'")
    model = _PARSERS.get(event_type)
    if model is None:
        raise MalformedMessageError(f"unsupported event_type: {event_type!r}")
    try:
        return ParsedFrame(message=model.model_validate(payload), heartbeat=False)
    except ValidationError as exc:
        raise MalformedMessageError(
            f"invalid {event_type} message: {exc.error_count()} error(s)"
        ) from exc


__all__ = [
    "BookSide",
    "BookSnapshotMessage",
    "MarketMessage",
    "ParsedFrame",
    "PriceChangeMessage",
    "TickSizeChangeMessage",
    "TradeMessage",
    "WireChange",
    "WireLevel",
    "parse_frame",
]
