"""Concrete ``websockets`` transport adapter (Module 6).

This is the ONLY module that imports the third-party ``websockets`` client, so
the rest of the package and the pure domain remain free of it. The import is
deferred to call time so simply importing this module (e.g. in unit tests that
use a fake connector) does not require the dependency to be installed.

The adapter isolates uncertain external behavior behind the
:class:`WebSocketConnector` / :class:`WebSocketConnection` protocols.
"""

from __future__ import annotations

from typing import Any

from polymarket_pair_bot.market_data.ports import (
    WebSocketConnection,
    WebSocketConnector,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("market_data.ws_client")


class _WebsocketsConnection(WebSocketConnection):
    """Adapts a ``websockets`` client connection to the transport protocol."""

    def __init__(self, connection: Any) -> None:
        self._connection = connection

    async def send(self, message: str) -> None:
        await self._connection.send(message)

    async def recv(self) -> str:
        data = await self._connection.recv()
        # ``websockets`` may yield str or bytes depending on the frame type.
        if isinstance(data, bytes):
            return data.decode("utf-8")
        return str(data)

    async def close(self) -> None:
        try:
            await self._connection.close()
        except Exception as exc:  # noqa: BLE001 - close must be idempotent/safe
            _LOGGER.debug("error closing connection", extra={"error": type(exc).__name__})


class WebsocketsConnector(WebSocketConnector):
    """Opens market-data connections using the ``websockets`` library."""

    def __init__(
        self,
        *,
        open_timeout: float = 10.0,
        ping_interval: float | None = 20.0,
        ping_timeout: float | None = 20.0,
        max_message_bytes: int = 4 * 1024 * 1024,
    ) -> None:
        self._open_timeout = open_timeout
        self._ping_interval = ping_interval
        self._ping_timeout = ping_timeout
        self._max_message_bytes = max_message_bytes

    async def connect(self, url: str) -> WebSocketConnection:
        try:
            import websockets
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise RuntimeError(
                "the 'websockets' package is required for the live market-data "
                "feed; install project dependencies with 'uv sync'"
            ) from exc
        connection = await websockets.connect(
            url,
            open_timeout=self._open_timeout,
            ping_interval=self._ping_interval,
            ping_timeout=self._ping_timeout,
            max_size=self._max_message_bytes,
        )
        return _WebsocketsConnection(connection)


__all__ = ["WebsocketsConnector"]
