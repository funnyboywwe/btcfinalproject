"""Async market-data feed runner (Module 6).

Ties a :class:`WebSocketConnector` to an :class:`OrderBookManager`:

* a **reader task** only receives raw frames and enqueues them on a *bounded*
  queue -- it never awaits book processing, so a slow processor can never block
  socket reads (requirement 12). If the queue is full the reader fails closed:
  it marks the feed unavailable and forces a reconnect + fresh snapshot rather
  than silently corrupting the book by dropping deltas;
* a **processor task** decodes JSON (numbers as ``Decimal``), validates each
  frame, and applies it to the manager;
* a **supervisor** runs one connection attempt at a time in a reconnect loop
  with bounded exponential backoff + jitter, marking the feed unavailable on
  every disconnect (requirement 8) and requiring a fresh snapshot afterwards
  (requirement 9).

All tasks are tracked and cancelled on shutdown (no untracked background
tasks); the runner is cancellation-safe.
"""

from __future__ import annotations

import asyncio
import json
import random
from collections.abc import Sequence
from dataclasses import dataclass, field
from decimal import Decimal

from polymarket_pair_bot.market_data.errors import (
    CrossedBookError,
    MalformedMessageError,
    MarketDataError,
)
from polymarket_pair_bot.market_data.manager import OrderBookManager
from polymarket_pair_bot.market_data.messages import parse_frame
from polymarket_pair_bot.market_data.ports import (
    Sleep,
    WebSocketConnection,
    WebSocketConnector,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("market_data.feed")


@dataclass(slots=True)
class FeedMetrics:
    """Lightweight in-process counters for observability (not money)."""

    frames_received: int = 0
    frames_applied: int = 0
    heartbeats: int = 0
    malformed: int = 0
    faults: int = 0
    queue_overflows: int = 0
    connect_attempts: int = 0


@dataclass(slots=True)
class _RawFrame:
    text: str


@dataclass(slots=True)
class MarketDataFeedConfig:
    """Runtime knobs for the feed runner (durations in seconds)."""

    url: str
    subscribe_type: str = "market"
    max_queue_size: int = 1000
    reconnect_base_seconds: float = 0.5
    reconnect_max_seconds: float = 30.0
    max_reconnect_attempts: int | None = None  # None => retry forever

    def __post_init__(self) -> None:
        if self.max_queue_size <= 0:
            raise ValueError("max_queue_size must be positive")
        if self.reconnect_base_seconds <= 0:
            raise ValueError("reconnect_base_seconds must be positive")
        if self.reconnect_max_seconds < self.reconnect_base_seconds:
            raise ValueError("reconnect_max_seconds must be >= base")


def build_subscribe_message(subscribe_type: str, token_ids: Sequence[str]) -> str:
    """Build the market-channel subscription frame.

    Follows Polymarket's documented market-channel subscription shape
    ``{"type": "market", "assets_ids": [...]}``. This external contract cannot
    be verified offline, so it is isolated here for a one-line correction.
    """
    return json.dumps({"type": subscribe_type, "assets_ids": list(token_ids)})


class MarketDataFeed:
    """Supervises the market-data WebSocket connection and book updates."""

    def __init__(
        self,
        connector: WebSocketConnector,
        manager: OrderBookManager,
        config: MarketDataFeedConfig,
        *,
        sleep: Sleep | None = None,
        rng: random.Random | None = None,
    ) -> None:
        self._connector = connector
        self._manager = manager
        self._config = config
        self._sleep = sleep or asyncio.sleep
        self._rng = rng or random.Random()
        self._queue: asyncio.Queue[_RawFrame] = asyncio.Queue(config.max_queue_size)
        self._metrics = FeedMetrics()
        self._stop = asyncio.Event()
        self._resync = asyncio.Event()
        self._had_first_connect = False

    @property
    def metrics(self) -> FeedMetrics:
        return self._metrics

    def request_stop(self) -> None:
        """Signal the runner to shut down gracefully."""
        self._stop.set()

    async def run(self) -> None:
        """Run the reconnect supervisor until stopped or attempts exhausted."""
        attempt = 0
        while not self._stop.is_set():
            self._metrics.connect_attempts += 1
            try:
                await self._run_one_connection()
                attempt = 0  # a clean session resets backoff
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - supervisor must not die
                _LOGGER.warning(
                    "market-data connection ended",
                    extra={"error": type(exc).__name__},
                )
            finally:
                self._manager.mark_disconnected()
            if self._stop.is_set():
                break
            attempt += 1
            if (
                self._config.max_reconnect_attempts is not None
                and attempt > self._config.max_reconnect_attempts
            ):
                _LOGGER.error("exhausted reconnect attempts; stopping feed")
                break
            await self._backoff(attempt)

    async def _backoff(self, attempt: int) -> None:
        capped = min(
            self._config.reconnect_max_seconds,
            self._config.reconnect_base_seconds * (2 ** (attempt - 1)),
        )
        delay = self._rng.random() * capped  # full jitter
        await self._sleep(delay)

    async def _run_one_connection(self) -> None:
        connection = await self._connector.connect(self._config.url)
        if self._had_first_connect:
            self._manager.note_reconnect()
        self._had_first_connect = True
        self._drain_queue()
        self._resync.clear()
        await connection.send(
            build_subscribe_message(
                self._config.subscribe_type, list(self._manager.token_ids)
            )
        )
        self._manager.mark_connected()
        reader = asyncio.create_task(
            self._reader_loop(connection), name="market-data-reader"
        )
        processor = asyncio.create_task(
            self._processor_loop(), name="market-data-processor"
        )
        # Watchers let a fault (resync) or a shutdown request proactively tear
        # the session down even while the reader is blocked in recv().
        resync_waiter = asyncio.create_task(
            self._resync.wait(), name="market-data-resync"
        )
        stop_waiter = asyncio.create_task(
            self._stop.wait(), name="market-data-stop"
        )
        work_tasks = (reader, processor)
        all_tasks = (reader, processor, resync_waiter, stop_waiter)
        try:
            await asyncio.wait(all_tasks, return_when=asyncio.FIRST_COMPLETED)
            # Only the work tasks can fail; re-raise their errors to trigger a
            # reconnect. Watcher completion is a normal control signal.
            for task in work_tasks:
                if task.done():
                    exc = task.exception()
                    if exc is not None and not isinstance(
                        exc, asyncio.CancelledError
                    ):
                        raise exc
        finally:
            for task in all_tasks:
                task.cancel()
            await asyncio.gather(*all_tasks, return_exceptions=True)
            await connection.close()

    def _drain_queue(self) -> None:
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except asyncio.QueueEmpty:  # pragma: no cover - race guard
                break

    async def _reader_loop(self, connection: WebSocketConnection) -> None:
        """Receive frames and enqueue them without ever awaiting processing."""
        while not self._stop.is_set():
            if self._resync.is_set():
                # A fault demanded a fresh snapshot; force a reconnect.
                raise MarketDataError("resynchronization required")
            text = await connection.recv()
            self._metrics.frames_received += 1
            try:
                self._queue.put_nowait(_RawFrame(text))
            except asyncio.QueueFull:
                self._metrics.queue_overflows += 1
                _LOGGER.error(
                    "market-data queue overflow; forcing resync",
                    extra={"max_queue_size": self._config.max_queue_size},
                )
                # Fail closed: a dropped delta corrupts the book, so require a
                # fresh authoritative snapshot instead of silently continuing.
                raise MarketDataError("queue overflow") from None

    async def _processor_loop(self) -> None:
        """Decode, validate and apply queued frames to the manager."""
        while not self._stop.is_set():
            frame = await self._queue.get()
            try:
                self._process_text(frame.text)
            finally:
                self._queue.task_done()

    def _process_text(self, text: str) -> None:
        try:
            # Decode numbers straight to Decimal so money never touches float.
            payload = json.loads(text, parse_float=Decimal)
        except (ValueError, TypeError) as exc:
            self._metrics.malformed += 1
            _LOGGER.warning("undecodable frame", extra={"error": type(exc).__name__})
            return
        items = payload if isinstance(payload, list) else [payload]
        for item in items:
            self._apply_item(item)

    def _apply_item(self, item: object) -> None:
        try:
            parsed = parse_frame(item)
        except MalformedMessageError as exc:
            self._metrics.malformed += 1
            _LOGGER.warning("malformed message", extra={"reason": str(exc)})
            return
        if parsed.heartbeat or parsed.message is None:
            self._metrics.heartbeats += 1
            return
        try:
            self._manager.apply_message(parsed.message)  # type: ignore[arg-type]
            self._metrics.frames_applied += 1
        except CrossedBookError as exc:
            self._metrics.faults += 1
            _LOGGER.error("crossed book; forcing resync", extra={"reason": str(exc)})
            self._resync.set()
        except MarketDataError as exc:
            self._metrics.faults += 1
            _LOGGER.error(
                "market-data fault; forcing resync",
                extra={"error": type(exc).__name__, "reason": str(exc)},
            )
            self._resync.set()


__all__ = [
    "FeedMetrics",
    "MarketDataFeed",
    "MarketDataFeedConfig",
    "build_subscribe_message",
]
