"""Typed transport protocols for the market-data WebSocket (Module 6).

The manager and feed runner depend only on these protocols, never on a
concrete WebSocket library. The concrete ``websockets`` adapter lives in
``ws_client.py`` and is the only place that imports the third-party client, so
the rest of the package (and the pure domain) stays free of it.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol


class WebSocketConnection(Protocol):
    """A minimal duplex text WebSocket connection.

    ``recv`` returns the next text frame. Implementations should raise on a
    closed/broken connection so the feed runner can reconnect and resynchronize.
    """

    async def send(self, message: str) -> None:
        """Send a single text frame."""
        ...

    async def recv(self) -> str:
        """Receive the next text frame (raises when the connection closes)."""
        ...

    async def close(self) -> None:
        """Close the connection; must be safe to call more than once."""
        ...


class WebSocketConnector(Protocol):
    """Opens :class:`WebSocketConnection` instances for a URL."""

    async def connect(self, url: str) -> WebSocketConnection:
        """Open a new connection. Raises on failure (retryable by the caller)."""
        ...


# A monotonic clock used only for freshness/age measurement (seconds, float).
# Time durations are not monetary values, so float is acceptable here.
MonotonicClock = Callable[[], float]

# A wall-clock source returning integer UTC seconds (used for receipt/processing
# timestamps surfaced to operators).
WallClock = Callable[[], int]

# An awaitable sleep, injectable for deterministic tests.
Sleep = Callable[[float], Awaitable[None]]


__all__ = [
    "MonotonicClock",
    "Sleep",
    "WallClock",
    "WebSocketConnection",
    "WebSocketConnector",
]
