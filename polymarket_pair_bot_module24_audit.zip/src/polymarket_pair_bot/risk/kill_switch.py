"""Persistent, multi-level kill switch (Module 14).

Four independent sources are combined so that the switch is active if ANY of
them reports active, and -- critically -- if any of them cannot be read the
composite fails closed (treats the switch as active):

* process level -- an in-memory flag tripped by this process;
* environment level -- an operator-set environment variable (survives restarts,
  cannot be cleared by the running process);
* Redis level -- a fast shared cache for cross-process propagation;
* PostgreSQL level -- the durable authoritative record (survives restarts).

The classes here are pure with respect to infrastructure: they depend only on
abstract readers/stores from :mod:`polymarket_pair_bot.risk.ports` and
:mod:`polymarket_pair_bot.domain.coordination`. Concrete wiring lives in
:mod:`polymarket_pair_bot.risk.adapters`.

No profitability is claimed or implied.
"""

from __future__ import annotations

import asyncio
import os
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.coordination import (
    KillSwitchStore,
    RedisUnavailableError,
)
from polymarket_pair_bot.domain.enums import ReconciliationStatus
from polymarket_pair_bot.risk.ports import (
    KillSwitchLatestReader,
    ReconciliationHealth,
)

_TRUTHY = frozenset({"1", "true", "yes", "on", "active"})


@dataclass(frozen=True, slots=True)
class KillSwitchSignal:
    """The reading from a single kill-switch source."""

    source: str
    active: bool
    reason: str = ""


@dataclass(frozen=True, slots=True)
class KillSwitchSnapshot:
    """Aggregate reading across all kill-switch sources."""

    active: bool
    signals: tuple[KillSwitchSignal, ...]

    def active_sources(self) -> tuple[str, ...]:
        return tuple(s.source for s in self.signals if s.active)

    def reason_summary(self) -> str:
        parts = [
            f"{s.source}: {s.reason or 'active'}" for s in self.signals if s.active
        ]
        return "; ".join(parts)


@runtime_checkable
class KillSwitchSource(Protocol):
    """A single readable kill-switch source."""

    @property
    def name(self) -> str: ...

    async def read(self) -> KillSwitchSignal: ...


class ProcessKillSwitch:
    """In-process kill switch flag."""

    def __init__(self) -> None:
        self._active = False
        self._reason = ""

    @property
    def name(self) -> str:
        return "process"

    def trip(self, reason: str) -> None:
        self._active = True
        self._reason = reason

    def reset(self) -> None:
        self._active = False
        self._reason = ""

    def is_active(self) -> bool:
        return self._active

    async def read(self) -> KillSwitchSignal:
        return KillSwitchSignal(self.name, self._active, self._reason)


class EnvKillSwitch:
    """Environment-variable kill switch; survives process restarts."""

    def __init__(
        self,
        var_name: str,
        *,
        env_reader: Callable[[str], str | None] = lambda key: os.environ.get(key),
    ) -> None:
        self._var_name = var_name
        self._env_reader = env_reader

    @property
    def name(self) -> str:
        return "environment"

    def is_active(self) -> bool:
        raw = self._env_reader(self._var_name)
        return raw is not None and raw.strip().lower() in _TRUTHY

    async def read(self) -> KillSwitchSignal:
        active = self.is_active()
        reason = (
            f"environment variable {self._var_name} is set" if active else ""
        )
        return KillSwitchSignal(self.name, active, reason)


class RedisKillSwitchSource:
    """Redis-backed kill switch; fails closed when Redis is unavailable."""

    def __init__(self, store: KillSwitchStore) -> None:
        self._store = store

    @property
    def name(self) -> str:
        return "redis"

    async def read(self) -> KillSwitchSignal:
        try:
            state = await self._store.get_state()
        except RedisUnavailableError:
            return KillSwitchSignal(
                self.name, True, "redis unavailable (fail closed)"
            )
        return KillSwitchSignal(self.name, state.active, state.reason)


class PostgresKillSwitchSource:
    """PostgreSQL-backed authoritative kill switch source."""

    def __init__(self, reader: KillSwitchLatestReader, *, key: str) -> None:
        self._reader = reader
        self._key = key

    @property
    def name(self) -> str:
        return "postgres"

    async def read(self) -> KillSwitchSignal:
        state = await self._reader.read_latest(self._key)
        if state is None:
            return KillSwitchSignal(self.name, False, "")
        return KillSwitchSignal(self.name, state.active, state.reason)


class CompositeKillSwitch:
    """Combine multiple sources; active if ANY is active or unreadable."""

    def __init__(self, sources: Iterable[KillSwitchSource]) -> None:
        self._sources = tuple(sources)

    async def snapshot(self) -> KillSwitchSnapshot:
        signals: list[KillSwitchSignal] = []
        for source in self._sources:
            try:
                signals.append(await source.read())
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - fail closed on any error
                signals.append(
                    KillSwitchSignal(
                        source.name, True, f"read failed (fail closed): {exc}"
                    )
                )
        active = any(s.active for s in signals)
        return KillSwitchSnapshot(active=active, signals=tuple(signals))


@dataclass(frozen=True, slots=True)
class ClearanceDecision:
    """Whether the operator is allowed to clear the kill switch."""

    allowed: bool
    reasons: tuple[str, ...]


def evaluate_clearance(
    *,
    reason: str,
    now: int,
    reconciliation: ReconciliationHealth | None,
    feeds_healthy: bool,
    max_reconciliation_age_seconds: int,
    env_switch_active: bool,
) -> ClearanceDecision:
    """Fail-closed evaluation of the clearing preconditions (requirement 8)."""
    blockers: list[str] = []
    if not reason or not reason.strip():
        blockers.append("an explicit operator reason is required")
    if reconciliation is None:
        blockers.append("no successful reconciliation on record")
    else:
        if reconciliation.status is not ReconciliationStatus.CONSISTENT:
            blockers.append(
                "most recent reconciliation is not consistent "
                f"(status={reconciliation.status.value})"
            )
        age = now - reconciliation.as_of
        if age > max_reconciliation_age_seconds:
            blockers.append(
                f"reconciliation is stale ({age}s > "
                f"{max_reconciliation_age_seconds}s)"
            )
    if not feeds_healthy:
        blockers.append("data feeds are not healthy")
    if env_switch_active:
        blockers.append(
            "environment kill switch is set; unset it before clearing"
        )
    return ClearanceDecision(allowed=not blockers, reasons=tuple(blockers))


__all__ = [
    "ClearanceDecision",
    "CompositeKillSwitch",
    "EnvKillSwitch",
    "KillSwitchSignal",
    "KillSwitchSnapshot",
    "KillSwitchSource",
    "PostgresKillSwitchSource",
    "ProcessKillSwitch",
    "RedisKillSwitchSource",
    "evaluate_clearance",
]
