"""Assemble the risk engine and kill-switch stack from configuration.

Composition boundary (imports SQLAlchemy-backed adapters). The pure risk core
never imports this module, so importing the engine/kill-switch/services never
requires SQLAlchemy or redis to be installed.
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from polymarket_pair_bot.config import AppConfig
from polymarket_pair_bot.domain.coordination import KillSwitchStore
from polymarket_pair_bot.domain.repositories import UnitOfWorkFactory
from polymarket_pair_bot.risk.adapters import (
    HealthCheckFeedProvider,
    PostgresKillSwitchLatestReader,
    PostgresReconciliationStatusProvider,
)
from polymarket_pair_bot.risk.engine import RiskEngine
from polymarket_pair_bot.risk.kill_switch import (
    CompositeKillSwitch,
    EnvKillSwitch,
    PostgresKillSwitchSource,
    ProcessKillSwitch,
    RedisKillSwitchSource,
)
from polymarket_pair_bot.risk.limits import RiskLimits
from polymarket_pair_bot.risk.service import KillSwitchService, RiskEngineService
from polymarket_pair_bot.shared.health import HealthCheck


def build_composite_kill_switch(
    config: AppConfig,
    *,
    redis_store: KillSwitchStore,
    session_factory: async_sessionmaker[AsyncSession],
    process_switch: ProcessKillSwitch | None = None,
    env_switch: EnvKillSwitch | None = None,
) -> tuple[ProcessKillSwitch, EnvKillSwitch, CompositeKillSwitch]:
    """Wire the four-level composite kill switch from configuration."""
    process = process_switch or ProcessKillSwitch()
    env = env_switch or EnvKillSwitch(config.risk.kill_switch_env_var)
    composite = CompositeKillSwitch(
        [
            process,
            env,
            RedisKillSwitchSource(redis_store),
            PostgresKillSwitchSource(
                PostgresKillSwitchLatestReader(session_factory),
                key=config.risk.kill_switch_key,
            ),
        ]
    )
    return process, env, composite


def build_risk_engine_service(
    config: AppConfig,
    *,
    redis_store: KillSwitchStore,
    session_factory: async_sessionmaker[AsyncSession],
    uow_factory: UnitOfWorkFactory,
) -> RiskEngineService:
    """Assemble the order/hedge/blockchain risk decision service."""
    _, _, composite = build_composite_kill_switch(
        config, redis_store=redis_store, session_factory=session_factory
    )
    engine = RiskEngine(RiskLimits.from_settings(config.risk))
    return RiskEngineService(engine, composite, uow_factory)


def build_kill_switch_service(
    config: AppConfig,
    *,
    redis_store: KillSwitchStore,
    session_factory: async_sessionmaker[AsyncSession],
    uow_factory: UnitOfWorkFactory,
    health_checks: Sequence[HealthCheck],
) -> KillSwitchService:
    """Assemble the operator kill-switch control service (Module 14)."""
    process, env, composite = build_composite_kill_switch(
        config, redis_store=redis_store, session_factory=session_factory
    )
    return KillSwitchService(
        key=config.risk.kill_switch_key,
        redis_store=redis_store,
        uow_factory=uow_factory,
        process_switch=process,
        composite=composite,
        env_switch=env,
        reconciliation_provider=PostgresReconciliationStatusProvider(session_factory),
        feed_provider=HealthCheckFeedProvider(tuple(health_checks)),
        max_reconciliation_age_seconds=config.risk.reconciliation_max_age_seconds,
    )


__all__ = [
    "build_composite_kill_switch",
    "build_kill_switch_service",
    "build_risk_engine_service",
]
