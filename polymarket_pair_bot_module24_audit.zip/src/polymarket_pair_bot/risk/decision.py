"""Risk decision result types (Module 13).

A :class:`RiskEvaluation` is the engine's rich output: the verdict, the approved
size, and the complete list of per-rule outcomes (every reason and the relevant
observed value and limit). It projects to the persisted domain
:class:`RiskDecision` and to a secret-free audit payload.
"""

from __future__ import annotations

from dataclasses import dataclass

from polymarket_pair_bot.domain.entities import RiskDecision
from polymarket_pair_bot.domain.enums import RiskVerdict
from polymarket_pair_bot.domain.repositories import JsonValue
from polymarket_pair_bot.domain.value_objects import Shares, UnixTimestamp
from polymarket_pair_bot.risk.context import OperationKind


@dataclass(frozen=True, slots=True)
class RuleOutcome:
    """Result of a single risk rule, including the values that produced it."""

    rule: str
    passed: bool
    reason: str
    observed: str | None = None
    limit: str | None = None

    def as_dict(self) -> dict[str, JsonValue]:
        return {
            "rule": self.rule,
            "passed": self.passed,
            "reason": self.reason,
            "observed": self.observed,
            "limit": self.limit,
        }


@dataclass(frozen=True, slots=True)
class RiskEvaluation:
    """Complete result of one risk evaluation."""

    decision_id: str
    kind: OperationKind
    verdict: RiskVerdict
    approved_size: Shares
    decided_at: UnixTimestamp
    outcomes: tuple[RuleOutcome, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "outcomes", tuple(self.outcomes))

    @property
    def approved(self) -> bool:
        return self.verdict is RiskVerdict.APPROVE

    def failures(self) -> tuple[RuleOutcome, ...]:
        return tuple(o for o in self.outcomes if not o.passed)

    def reason_summary(self) -> str:
        """Human-readable, secret-free summary of the decision."""
        failures = self.failures()
        if failures:
            return "; ".join(f"{o.rule}: {o.reason}" for o in failures)
        return f"approved: {len(self.outcomes)} checks passed"

    def to_decision(self) -> RiskDecision:
        """Project to the persisted domain :class:`RiskDecision`."""
        return RiskDecision(
            decision_id=self.decision_id,
            verdict=self.verdict,
            reason=self.reason_summary(),
            decided_at=self.decided_at,
            approved_size=self.approved_size,
        )

    def audit_payload(self) -> dict[str, JsonValue]:
        """Secret-free structured payload for the audit journal."""
        outcomes: list[JsonValue] = [o.as_dict() for o in self.outcomes]
        return {
            "decision_id": self.decision_id,
            "kind": self.kind.value,
            "verdict": self.verdict.value,
            "approved_size": str(self.approved_size),
            "decided_at": self.decided_at.value,
            "outcomes": outcomes,
        }


__all__ = ["RiskEvaluation", "RuleOutcome"]
