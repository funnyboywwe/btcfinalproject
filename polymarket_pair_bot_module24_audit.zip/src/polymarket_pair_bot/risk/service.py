"""Async orchestration for the risk engine and kill switch (Modules 13-14).

These services are the only place in the risk package that performs I/O. They
depend on abstract ports and a :class:`UnitOfWorkFactory`, never on concrete
infrastructure classes, so they remain unit-testable with in-memory fakes.

``RiskEngineService.evaluate`` reads the composite kill switch, injects its
state into the (otherwise pure) :class:`RiskContext`, runs the engine, and then
persists the decision and its failing rules (requirement 3) before returning.

``KillSwitchService`` implements the operator lifecycle: inspect, activate
(durable PostgreSQL record first, then Redis, then the in-process flag) and
safely clear (only when the fail-closed preconditions hold), plus
``trip_on_reconciliation`` for requirement 9.

No profitability is claimed or implied.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime

from polymarket_pair_bot.domain.coordination import KillSwitchStore
from polymarket_pair_bot.domain.entities import ReconciliationResult
from polymarket_pair_bot.domain.enums import ReconciliationStatus
from polymarket_pair_bot.domain.repositories import UnitOfWorkFactory
from polymarket_pair_bot.domain.value_objects import UnixTimestamp
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.risk.context import RiskContext
from polymarket_pair_bot.risk.decision import RiskEvaluation
from polymarket_pair_bot.risk.engine import RiskEngine
from polymarket_pair_bot.risk.kill_switch import (
    CompositeKillSwitch,
    EnvKillSwitch,
    KillSwitchSnapshot,
    ProcessKillSwitch,
    evaluate_clearance,
)
from polymarket_pair_bot.risk.ports import (
    FeedHealthProvider,
    ReconciliationStatusProvider,
)

_logger = get_logger(__name__)

Clock = Callable[[], int]


def _utc_now_seconds() -> int:
    return int(datetime.now(tz=UTC).timestamp())


class RiskEngineService:
    """Evaluate order/hedge/blockchain intents and persist the decision."""

    def __init__(
        self,
        engine: RiskEngine,
        kill_switch: CompositeKillSwitch,
        uow_factory: UnitOfWorkFactory,
        *,
        clock: Clock = _utc_now_seconds,
    ) -> None:
        self._engine = engine
        self._kill_switch = kill_switch
        self._uow_factory = uow_factory
        self._clock = clock

    async def evaluate(self, context: RiskContext) -> RiskEvaluation:
        snapshot = await self._kill_switch.snapshot()
        effective = context.with_kill_switch(
            active=snapshot.active, reason=snapshot.reason_summary()
        )
        evaluation = self._engine.evaluate(effective)
        await self._persist(evaluation)
        _logger.info(
            "risk_decision",
            extra={
                "decision_id": evaluation.decision_id,
                "kind": evaluation.kind.value,
                "verdict": evaluation.verdict.value,
                "approved_size": str(evaluation.approved_size.value),
                "kill_switch_active": snapshot.active,
                "failures": [o.rule for o in evaluation.failures()],
            },
        )
        return evaluation

    async def _persist(self, evaluation: RiskEvaluation) -> None:
        severity = "info" if evaluation.approved else "warning"
        async with self._uow_factory() as uow:
            await uow.risk_events.record(evaluation.to_decision())
            await uow.audit.append_event(
                event_type="risk.decision",
                severity=severity,
                created_at=evaluation.decided_at,
                payload=evaluation.audit_payload(),
            )
            await uow.commit()


@dataclass(frozen=True, slots=True)
class ClearResult:
    """Outcome of an attempt to clear the kill switch."""

    cleared: bool
    reasons: tuple[str, ...]
    snapshot: KillSwitchSnapshot


class KillSwitchService:
    """Operator lifecycle for the persistent multi-level kill switch."""

    def __init__(
        self,
        *,
        key: str,
        redis_store: KillSwitchStore,
        uow_factory: UnitOfWorkFactory,
        process_switch: ProcessKillSwitch,
        composite: CompositeKillSwitch,
        env_switch: EnvKillSwitch,
        reconciliation_provider: ReconciliationStatusProvider,
        feed_provider: FeedHealthProvider,
        max_reconciliation_age_seconds: int,
        clock: Clock = _utc_now_seconds,
    ) -> None:
        self._key = key
        self._redis_store = redis_store
        self._uow_factory = uow_factory
        self._process = process_switch
        self._composite = composite
        self._env = env_switch
        self._reconciliation_provider = reconciliation_provider
        self._feed_provider = feed_provider
        self._max_reconciliation_age_seconds = max_reconciliation_age_seconds
        self._clock = clock

    async def status(self) -> KillSwitchSnapshot:
        return await self._composite.snapshot()

    async def activate(self, *, reason: str, actor: str | None = None) -> KillSwitchSnapshot:
        """Activate durably (PostgreSQL) then Redis then in-process."""
        at = self._clock()
        async with self._uow_factory() as uow:
            await uow.kill_switch.record(
                key=self._key,
                active=True,
                reason=reason,
                created_at=UnixTimestamp(at),
                actor=actor,
            )
            await uow.commit()
        await self._redis_store.activate(reason=reason, actor=actor, at=at)
        self._process.trip(reason)
        _logger.warning(
            "kill_switch_activated", extra={"reason": reason, "actor": actor}
        )
        return await self._composite.snapshot()

    async def trip_on_reconciliation(
        self, result: ReconciliationResult, *, actor: str = "reconciliation"
    ) -> KillSwitchSnapshot | None:
        """Activate on a critical reconciliation difference (requirement 9)."""
        if result.status is ReconciliationStatus.CONSISTENT:
            return None
        detail = "; ".join(result.discrepancies) or result.status.value
        reason = f"reconciliation {result.status.value}: {detail}"
        return await self.activate(reason=reason, actor=actor)

    async def clear(self, *, reason: str, actor: str | None = None) -> ClearResult:
        """Clear only when all fail-closed preconditions hold (requirement 8)."""
        now = self._clock()
        reconciliation = await self._reconciliation_provider.latest_reconciliation()
        feeds_healthy = await self._feed_provider.feeds_healthy()
        decision = evaluate_clearance(
            reason=reason,
            now=now,
            reconciliation=reconciliation,
            feeds_healthy=feeds_healthy,
            max_reconciliation_age_seconds=self._max_reconciliation_age_seconds,
            env_switch_active=self._env.is_active(),
        )
        if not decision.allowed:
            _logger.warning(
                "kill_switch_clear_denied",
                extra={"reason": reason, "blockers": list(decision.reasons)},
            )
            snapshot = await self._composite.snapshot()
            return ClearResult(False, decision.reasons, snapshot)
        async with self._uow_factory() as uow:
            await uow.kill_switch.record(
                key=self._key,
                active=False,
                reason=reason,
                created_at=UnixTimestamp(now),
                actor=actor,
            )
            await uow.commit()
        await self._redis_store.deactivate(actor=actor, at=now)
        self._process.reset()
        _logger.warning(
            "kill_switch_cleared", extra={"reason": reason, "actor": actor}
        )
        snapshot = await self._composite.snapshot()
        return ClearResult(True, (), snapshot)


__all__ = ["ClearResult", "KillSwitchService", "RiskEngineService"]
