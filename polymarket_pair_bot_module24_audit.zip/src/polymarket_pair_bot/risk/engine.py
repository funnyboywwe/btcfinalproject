"""Centralized risk engine (Module 13).

Pure, synchronous, deterministic evaluation of a single :class:`RiskContext`
against a set of :class:`RiskLimits`. The engine performs no I/O and imports no
infrastructure; the async :mod:`polymarket_pair_bot.risk.service` populates the
authoritative kill-switch state and persists the result.

Safety posture:

* the default decision is DENY -- a verdict only becomes APPROVE when every
  applicable rule passes;
* a missing input that a rule requires is a fail-closed denial (never a guess);
* the kill switch and (when required) execution leadership are checked for every
  state-changing operation; cancellation and reconciliation are NOT routed
  through the engine and remain possible while the switch is active.

No profitability is claimed or implied.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Protocol

from polymarket_pair_bot.domain.enums import RiskVerdict
from polymarket_pair_bot.domain.precision import coerce_decimal
from polymarket_pair_bot.domain.value_objects import Shares
from polymarket_pair_bot.risk.context import OperationKind, RiskContext
from polymarket_pair_bot.risk.decision import RiskEvaluation, RuleOutcome
from polymarket_pair_bot.risk.limits import RiskLimits

_Number = Decimal | int


class _Valued(Protocol):
    @property
    def value(self) -> Decimal: ...


def _val(valued: _Valued | None) -> Decimal | None:
    return None if valued is None else valued.value


class RiskEngine:
    """Deterministic, side-effect-free evaluator of risk limits."""

    def __init__(self, limits: RiskLimits) -> None:
        self._limits = limits

    @property
    def limits(self) -> RiskLimits:
        return self._limits

    def evaluate(self, context: RiskContext) -> RiskEvaluation:
        """Evaluate ``context``; default DENY unless every rule passes."""
        outcomes: list[RuleOutcome] = [
            self._check_kill_switch(context),
            self._check_leader(context),
        ]
        if context.kind in (OperationKind.ORDER_INTENT, OperationKind.HEDGE):
            outcomes.extend(self._order_checks(context))
        elif context.kind is OperationKind.BLOCKCHAIN:
            outcomes.extend(self._blockchain_checks(context))
        else:  # pragma: no cover - enum is exhaustive
            outcomes.append(
                RuleOutcome("operation_kind", False, "unknown operation kind")
            )
        approved = bool(outcomes) and all(o.passed for o in outcomes)
        verdict = RiskVerdict.APPROVE if approved else RiskVerdict.REJECT
        return RiskEvaluation(
            decision_id=context.operation_id,
            kind=context.kind,
            verdict=verdict,
            approved_size=self._approved_size(context, approved=approved),
            decided_at=context.now,
            outcomes=tuple(outcomes),
        )

    # -- approved size ------------------------------------------------------
    @staticmethod
    def _approved_size(context: RiskContext, *, approved: bool) -> Shares:
        if not approved:
            return Shares(0)
        if context.kind is OperationKind.BLOCKCHAIN:
            return Shares(0)
        if context.order_quantity is None:
            return Shares(0)
        return context.order_quantity

    # -- always-on checks ---------------------------------------------------
    @staticmethod
    def _check_kill_switch(context: RiskContext) -> RuleOutcome:
        if context.kill_switch_active:
            return RuleOutcome(
                "kill_switch",
                False,
                context.kill_switch_reason or "kill switch active",
            )
        return RuleOutcome("kill_switch", True, "kill switch inactive")

    def _check_leader(self, context: RiskContext) -> RuleOutcome:
        if not self._limits.require_execution_leader:
            return RuleOutcome(
                "execution_leader", True, "leadership not required by policy"
            )
        if context.is_execution_leader is None:
            return RuleOutcome(
                "execution_leader", False, "leadership unknown (fail closed)"
            )
        if context.is_execution_leader:
            return RuleOutcome(
                "execution_leader", True, "process holds execution leadership"
            )
        return RuleOutcome(
            "execution_leader", False, "process is not the execution leader"
        )

    # -- order / hedge ------------------------------------------------------
    def _order_checks(self, context: RiskContext) -> list[RuleOutcome]:
        limits = self._limits
        outcomes: list[RuleOutcome] = [
            self._max(
                "max_order_quantity",
                _val(context.order_quantity),
                limits.max_order_quantity.value,
                "order quantity",
            ),
            self._max(
                "max_order_collateral",
                _val(context.order_collateral),
                limits.max_order_collateral.value,
                "order collateral",
            ),
            self._max(
                "max_position_per_market",
                _val(context.market_position_notional),
                limits.max_position_per_market.value,
                "market position",
            ),
            self._max(
                "max_unmatched_shares",
                _val(context.unmatched_shares),
                limits.max_unmatched_shares.value,
                "unmatched shares",
            ),
            self._max(
                "max_unmatched_collateral",
                _val(context.unmatched_collateral),
                limits.max_unmatched_collateral.value,
                "unmatched collateral",
            ),
            self._max(
                "max_unmatched_duration",
                context.oldest_unmatched_age_seconds,
                limits.max_unmatched_duration_seconds,
                "unmatched duration (s)",
            ),
            self._max(
                "max_deployed_capital",
                _val(context.deployed_capital),
                limits.max_deployed_capital.value,
                "deployed capital",
            ),
            self._max(
                "max_reserved_collateral",
                _val(context.reserved_collateral),
                limits.max_reserved_collateral.value,
                "reserved collateral",
            ),
            self._max(
                "max_open_orders",
                context.open_orders,
                limits.max_open_orders,
                "open orders",
            ),
            self._max(
                "max_loss_per_window",
                _val(context.window_loss),
                limits.max_loss_per_window.value,
                "window loss",
            ),
            self._max(
                "max_daily_loss",
                _val(context.daily_loss),
                limits.max_daily_loss.value,
                "daily loss",
            ),
            self._min(
                "min_expected_pair_edge",
                _val(context.expected_pair_edge),
                limits.min_expected_pair_edge.value,
                "expected pair edge",
            ),
            self._min(
                "min_hedge_depth",
                _val(context.hedge_depth),
                limits.min_hedge_depth.value,
                "hedge depth",
            ),
            self._max(
                "max_book_age",
                context.book_age_seconds,
                limits.max_book_age_seconds,
                "book age (s)",
            ),
            self._check_feed(context),
            self._check_mandatory_cancel_window(context),
            self._max(
                "max_api_failures",
                context.api_failures,
                limits.max_api_failures,
                "api failures",
            ),
            self._max(
                "max_ws_reconnects",
                context.ws_reconnects,
                limits.max_ws_reconnects,
                "websocket reconnects",
            ),
            self._min(
                "min_wallet_collateral",
                _val(context.wallet_collateral),
                limits.min_wallet_collateral.value,
                "wallet collateral",
            ),
            self._min(
                "min_polygon_gas",
                context.gas_balance_native,
                limits.min_polygon_gas_native,
                "polygon gas balance",
            ),
        ]
        if context.opening_first_leg:
            outcomes.append(self._check_first_leg_entry(context))
        return outcomes

    def _blockchain_checks(self, context: RiskContext) -> list[RuleOutcome]:
        limits = self._limits
        return [
            self._min(
                "min_polygon_gas",
                context.gas_balance_native,
                limits.min_polygon_gas_native,
                "polygon gas balance",
            ),
            self._max(
                "max_api_failures",
                context.api_failures,
                limits.max_api_failures,
                "api failures",
            ),
        ]

    # -- window / freshness helpers ----------------------------------------
    @staticmethod
    def _check_feed(context: RiskContext) -> RuleOutcome:
        if context.feed_live is None:
            return RuleOutcome(
                "feed_live", False, "feed liveness unknown (fail closed)"
            )
        if context.feed_live:
            return RuleOutcome("feed_live", True, "market-data feed is live")
        return RuleOutcome("feed_live", False, "market-data feed is not live")

    def _check_mandatory_cancel_window(self, context: RiskContext) -> RuleOutcome:
        limit = self._limits.mandatory_cancel_seconds_before_close
        if context.seconds_to_close is None:
            return RuleOutcome(
                "mandatory_cancel_window",
                False,
                "seconds-to-close unavailable (fail closed)",
                None,
                str(limit),
            )
        ok = context.seconds_to_close > limit
        reason = (
            "outside mandatory-cancel window"
            if ok
            else "inside mandatory-cancel window; no new orders"
        )
        return RuleOutcome(
            "mandatory_cancel_window",
            ok,
            reason,
            str(context.seconds_to_close),
            str(limit),
        )

    def _check_first_leg_entry(self, context: RiskContext) -> RuleOutcome:
        limit = self._limits.entry_min_seconds_before_close
        if context.seconds_to_close is None:
            return RuleOutcome(
                "latest_first_leg_entry",
                False,
                "seconds-to-close unavailable (fail closed)",
                None,
                str(limit),
            )
        ok = context.seconds_to_close >= limit
        reason = (
            "sufficient time to complete pair"
            if ok
            else "too late to open a new first leg"
        )
        return RuleOutcome(
            "latest_first_leg_entry",
            ok,
            reason,
            str(context.seconds_to_close),
            str(limit),
        )

    # -- numeric comparison helpers (fail closed on missing input) ---------
    @staticmethod
    def _max(
        rule: str, observed: _Number | None, limit: _Number, label: str
    ) -> RuleOutcome:
        if observed is None:
            return RuleOutcome(
                rule, False, f"{label} unavailable (fail closed)", None, str(limit)
            )
        ok = coerce_decimal(observed) <= coerce_decimal(limit)
        reason = f"{label} within maximum" if ok else f"{label} exceeds maximum"
        return RuleOutcome(rule, ok, reason, str(observed), str(limit))

    @staticmethod
    def _min(
        rule: str, observed: _Number | None, limit: _Number, label: str
    ) -> RuleOutcome:
        if observed is None:
            return RuleOutcome(
                rule, False, f"{label} unavailable (fail closed)", None, str(limit)
            )
        ok = coerce_decimal(observed) >= coerce_decimal(limit)
        reason = f"{label} meets minimum" if ok else f"{label} below minimum"
        return RuleOutcome(rule, ok, reason, str(observed), str(limit))


__all__ = ["RiskEngine"]
