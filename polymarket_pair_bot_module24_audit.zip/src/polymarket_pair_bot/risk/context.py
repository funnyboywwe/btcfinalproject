"""Inputs to the centralized risk engine (Module 13).

A :class:`RiskContext` is an immutable, fully-populated snapshot of everything a
single risk decision needs. It is pure data (domain value objects and plain
scalars); the engine that consumes it performs no I/O. Optional fields are
``None`` when a value is unavailable; the engine treats a missing value that a
rule requires as a **fail-closed** denial rather than guessing.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Decimal
from enum import Enum

from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ProfitAmount,
    Shares,
    UnixTimestamp,
)


class OperationKind(str, Enum):
    """The kind of state-changing operation being risk-checked.

    Cancellation and reconciliation are intentionally NOT represented: they are
    never routed through the risk engine and remain possible while the kill
    switch is active.
    """

    ORDER_INTENT = "order_intent"
    HEDGE = "hedge"
    BLOCKCHAIN = "blockchain"


@dataclass(frozen=True, slots=True)
class RiskContext:
    """Fully-populated inputs for one risk decision.

    ``kill_switch_active`` / ``kill_switch_reason`` are populated by the async
    service from the authoritative :class:`CompositeKillSwitch`; callers should
    not attempt to set them directly (use :meth:`with_kill_switch`).
    """

    operation_id: str
    kind: OperationKind
    now: UnixTimestamp
    kill_switch_active: bool = False
    kill_switch_reason: str = ""
    is_execution_leader: bool | None = None
    # order / hedge inputs
    order_quantity: Shares | None = None
    order_collateral: CollateralAmount | None = None
    market_position_notional: CollateralAmount | None = None
    unmatched_shares: Shares | None = None
    unmatched_collateral: CollateralAmount | None = None
    oldest_unmatched_age_seconds: int | None = None
    deployed_capital: CollateralAmount | None = None
    reserved_collateral: CollateralAmount | None = None
    open_orders: int | None = None
    window_loss: CollateralAmount | None = None
    daily_loss: CollateralAmount | None = None
    expected_pair_edge: ProfitAmount | None = None
    hedge_depth: Shares | None = None
    book_age_seconds: int | None = None
    feed_live: bool | None = None
    seconds_to_close: int | None = None
    opening_first_leg: bool = False
    api_failures: int | None = None
    ws_reconnects: int | None = None
    wallet_collateral: CollateralAmount | None = None
    gas_balance_native: Decimal | None = None

    def __post_init__(self) -> None:
        if not self.operation_id.strip():
            raise ValueError("operation_id must not be empty")

    def with_kill_switch(self, *, active: bool, reason: str) -> RiskContext:
        """Return a copy with the authoritative kill-switch state populated."""
        return replace(self, kill_switch_active=active, kill_switch_reason=reason)


__all__ = ["OperationKind", "RiskContext"]
