"""Typed, Decimal-safe risk limits for the centralized risk engine (Module 13).

This module is pure: it imports only the standard library and domain value
objects. It never imports pydantic-settings, SQLAlchemy, redis, HTTP/WebSocket
or blockchain clients. The ``from_settings`` adapter accepts a validated
``RiskSettings`` (typed only under ``TYPE_CHECKING`` so importing this module
never requires pydantic-settings to be installed).

Every monetary / quantity limit is a Decimal-backed domain value object -- never
a binary float. Durations and counts are integer seconds / counts. The minimum
Polygon gas balance is expressed in the chain's native token units (POL/MATIC)
as a ``Decimal`` (documented), never a float.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING

from polymarket_pair_bot.domain.value_objects import CollateralAmount, Shares

if TYPE_CHECKING:  # pragma: no cover - typing only, avoids pydantic-settings import
    from polymarket_pair_bot.config.models import RiskSettings


@dataclass(frozen=True, slots=True)
class RiskLimits:
    """Immutable set of centralized risk limits.

    Monetary values are USD ``CollateralAmount``; share quantities are
    ``Shares``; the minimum gas balance is a ``Decimal`` in native Polygon
    token units. Durations/counts are integers.
    """

    max_order_quantity: Shares
    max_order_collateral: CollateralAmount
    max_position_per_market: CollateralAmount
    max_unmatched_shares: Shares
    max_unmatched_collateral: CollateralAmount
    max_unmatched_duration_seconds: int
    max_deployed_capital: CollateralAmount
    max_reserved_collateral: CollateralAmount
    max_open_orders: int
    max_loss_per_window: CollateralAmount
    max_daily_loss: CollateralAmount
    min_expected_pair_edge: CollateralAmount
    min_hedge_depth: Shares
    max_book_age_seconds: int
    entry_min_seconds_before_close: int
    mandatory_cancel_seconds_before_close: int
    max_api_failures: int
    max_ws_reconnects: int
    min_wallet_collateral: CollateralAmount
    min_polygon_gas_native: Decimal
    require_execution_leader: bool

    @classmethod
    def from_settings(cls, settings: RiskSettings) -> RiskLimits:
        """Build limits from validated ``RiskSettings`` (pydantic-settings)."""
        return cls(
            max_order_quantity=Shares(settings.max_order_quantity_shares),
            max_order_collateral=CollateralAmount(settings.max_order_collateral_usd),
            max_position_per_market=CollateralAmount(
                settings.max_total_position_notional_usd
            ),
            max_unmatched_shares=Shares(settings.max_unmatched_shares),
            max_unmatched_collateral=CollateralAmount(
                settings.max_unmatched_notional_usd
            ),
            max_unmatched_duration_seconds=settings.max_unmatched_duration_seconds,
            max_deployed_capital=CollateralAmount(settings.max_deployed_capital_usd),
            max_reserved_collateral=CollateralAmount(
                settings.max_reserved_collateral_usd
            ),
            max_open_orders=settings.max_open_orders,
            max_loss_per_window=CollateralAmount(settings.max_loss_per_window_usd),
            max_daily_loss=CollateralAmount(settings.daily_loss_limit_usd),
            min_expected_pair_edge=CollateralAmount(
                settings.min_expected_pair_edge_usd
            ),
            min_hedge_depth=Shares(settings.min_hedge_depth_shares),
            max_book_age_seconds=settings.max_book_age_seconds,
            entry_min_seconds_before_close=settings.entry_min_seconds_before_close,
            mandatory_cancel_seconds_before_close=(
                settings.mandatory_cancel_seconds_before_close
            ),
            max_api_failures=settings.max_api_failures,
            max_ws_reconnects=settings.max_ws_reconnects,
            min_wallet_collateral=CollateralAmount(settings.min_wallet_collateral_usd),
            min_polygon_gas_native=settings.min_polygon_gas_native,
            require_execution_leader=settings.require_execution_leader,
        )


__all__ = ["RiskLimits"]
