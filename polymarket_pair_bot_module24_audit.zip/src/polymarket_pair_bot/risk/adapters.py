"""Infrastructure adapters wiring the risk ports to concrete infra (Module 14).

Composition-layer module (like ``coordination/factory.py``): this is the only
part of the risk package that imports SQLAlchemy-backed code. The pure risk
engine, kill-switch composite and services never import it, so they stay
infrastructure-free and unit-testable.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from polymarket_pair_bot.domain.coordination import KillSwitchState
from polymarket_pair_bot.domain.enums import ReconciliationStatus
from polymarket_pair_bot.persistence.models import (
    KillSwitchEventRow,
    ReconciliationRunRow,
)
from polymarket_pair_bot.risk.ports import ReconciliationHealth
from polymarket_pair_bot.shared.health import HealthCheck


class PostgresKillSwitchLatestReader:
    """Read the latest authoritative kill-switch state from PostgreSQL."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def read_latest(self, key: str) -> KillSwitchState | None:
        async with self._session_factory() as session:
            stmt = (
                select(KillSwitchEventRow)
                .where(KillSwitchEventRow.key == key)
                .order_by(
                    KillSwitchEventRow.created_at.desc(),
                    KillSwitchEventRow.id.desc(),
                )
                .limit(1)
            )
            row = (await session.execute(stmt)).scalars().first()
        if row is None:
            return None
        return KillSwitchState(
            active=row.active,
            reason=row.reason,
            actor=row.actor,
            updated_at=row.created_at,
        )


class PostgresReconciliationStatusProvider:
    """Provide the most recent reconciliation run from PostgreSQL."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def latest_reconciliation(self) -> ReconciliationHealth | None:
        async with self._session_factory() as session:
            stmt = (
                select(ReconciliationRunRow)
                .order_by(
                    ReconciliationRunRow.as_of.desc(),
                    ReconciliationRunRow.id.desc(),
                )
                .limit(1)
            )
            row = (await session.execute(stmt)).scalars().first()
        if row is None:
            return None
        return ReconciliationHealth(
            status=ReconciliationStatus(row.status), as_of=row.as_of
        )


class HealthCheckFeedProvider:
    """Feeds are healthy only when every injected health check passes.

    An empty check set is treated as unhealthy (fail closed).
    """

    def __init__(self, checks: tuple[HealthCheck, ...]) -> None:
        self._checks = checks

    async def feeds_healthy(self) -> bool:
        if not self._checks:
            return False
        for check in self._checks:
            result = await check.check()
            if not result.healthy:
                return False
        return True


__all__ = [
    "HealthCheckFeedProvider",
    "PostgresKillSwitchLatestReader",
    "PostgresReconciliationStatusProvider",
]
