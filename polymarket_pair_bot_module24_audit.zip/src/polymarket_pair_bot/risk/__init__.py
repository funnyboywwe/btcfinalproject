"""Centralized risk engine and persistent kill switches (Modules 13-14).

All order intents, hedges and blockchain operations must obtain a
:class:`RiskDecision` from the risk engine before proceeding. The engine's
default decision is DENY: a verdict only becomes APPROVE when every applicable
rule passes, and any missing required input fails closed.

The kill switch is persistent and multi-level (process / environment / Redis /
PostgreSQL); it is active if ANY source is active or unreadable. Activation
blocks new orders immediately, survives restarts, and can only be cleared with
an explicit operator reason, a recent successful reconciliation, and healthy
feeds. Cancellation and reconciliation are never routed through the engine and
remain possible while the switch is active.

This package's public surface is pure (standard library + domain value objects
+ abstract ports), so importing it never requires SQLAlchemy or redis. The
SQLAlchemy/redis-backed wiring lives in :mod:`polymarket_pair_bot.risk.adapters`
and :mod:`polymarket_pair_bot.risk.factory`, imported only by the composition
layer and the CLI.

No profitability is claimed or implied.
"""

from __future__ import annotations

from polymarket_pair_bot.risk.context import OperationKind, RiskContext
from polymarket_pair_bot.risk.decision import RiskEvaluation, RuleOutcome
from polymarket_pair_bot.risk.engine import RiskEngine
from polymarket_pair_bot.risk.kill_switch import (
    ClearanceDecision,
    CompositeKillSwitch,
    EnvKillSwitch,
    KillSwitchSignal,
    KillSwitchSnapshot,
    KillSwitchSource,
    PostgresKillSwitchSource,
    ProcessKillSwitch,
    RedisKillSwitchSource,
    evaluate_clearance,
)
from polymarket_pair_bot.risk.limits import RiskLimits
from polymarket_pair_bot.risk.ports import (
    FeedHealthProvider,
    KillSwitchLatestReader,
    ReconciliationHealth,
    ReconciliationStatusProvider,
)
from polymarket_pair_bot.risk.service import (
    ClearResult,
    KillSwitchService,
    RiskEngineService,
)

__all__ = [
    "ClearResult",
    "ClearanceDecision",
    "CompositeKillSwitch",
    "EnvKillSwitch",
    "FeedHealthProvider",
    "KillSwitchLatestReader",
    "KillSwitchService",
    "KillSwitchSignal",
    "KillSwitchSnapshot",
    "KillSwitchSource",
    "OperationKind",
    "PostgresKillSwitchSource",
    "ProcessKillSwitch",
    "ReconciliationHealth",
    "ReconciliationStatusProvider",
    "RedisKillSwitchSource",
    "RiskContext",
    "RiskEngine",
    "RiskEngineService",
    "RiskEvaluation",
    "RiskLimits",
    "RuleOutcome",
    "evaluate_clearance",
]
