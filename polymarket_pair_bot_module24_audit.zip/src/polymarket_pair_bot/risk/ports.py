"""Typed ports for the risk engine and kill switch (Modules 13-14).

These abstract interfaces let the pure risk core and the async services depend
on behavior, not on concrete infrastructure. Concrete SQLAlchemy / redis /
health-check implementations live in ``risk.adapters`` (the composition layer),
so the engine, kill-switch composite and services stay infrastructure-free and
unit-testable (dependency inversion).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.coordination import KillSwitchState
from polymarket_pair_bot.domain.enums import ReconciliationStatus


@runtime_checkable
class KillSwitchLatestReader(Protocol):
    """Reads the latest authoritative (PostgreSQL) kill-switch state."""

    async def read_latest(self, key: str) -> KillSwitchState | None: ...


@dataclass(frozen=True, slots=True)
class ReconciliationHealth:
    """Summary of the most recent reconciliation run."""

    status: ReconciliationStatus
    as_of: int  # unix seconds


@runtime_checkable
class ReconciliationStatusProvider(Protocol):
    """Provides the most recent reconciliation result for clearing checks."""

    async def latest_reconciliation(self) -> ReconciliationHealth | None: ...


@runtime_checkable
class FeedHealthProvider(Protocol):
    """Reports whether the bot's data feeds are currently healthy."""

    async def feeds_healthy(self) -> bool: ...


__all__ = [
    "FeedHealthProvider",
    "KillSwitchLatestReader",
    "ReconciliationHealth",
    "ReconciliationStatusProvider",
]
