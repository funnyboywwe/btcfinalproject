"""Operator CLI for the centralized kill switch (Modules 13-14).

Usage::

    python -m polymarket_pair_bot.risk.cli status
    python -m polymarket_pair_bot.risk.cli activate --reason "manual halt" \
        --actor ops
    python -m polymarket_pair_bot.risk.cli clear --reason "resolved" --actor ops

``status`` inspects every kill-switch source (process / environment / Redis /
PostgreSQL). ``activate`` writes the authoritative PostgreSQL record first, then
the Redis fast-cache, then trips the in-process switch. ``clear`` only succeeds
when the safety preconditions hold (explicit reason, recent successful
reconciliation, healthy feeds, and the environment switch is not set); otherwise
it prints the blocking reasons and exits non-zero.

This CLI never places orders and never prints secrets, DSNs or connection URLs.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from collections.abc import Sequence

from polymarket_pair_bot.config import AppConfig, load_config
from polymarket_pair_bot.coordination.factory import build_redis_coordination
from polymarket_pair_bot.observability.health_checks import (
    PostgresHealthCheck,
    RedisHealthCheck,
)
from polymarket_pair_bot.persistence.engine import (
    create_engine_from_dsn,
    create_session_factory,
)
from polymarket_pair_bot.persistence.repositories import create_unit_of_work_factory
from polymarket_pair_bot.risk.factory import build_kill_switch_service
from polymarket_pair_bot.risk.kill_switch import KillSwitchSnapshot


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-risk",
        description="Inspect, activate and safely clear the kill switch.",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status", help="Show every kill-switch source")
    activate = sub.add_parser("activate", help="Activate the kill switch")
    activate.add_argument("--reason", required=True, help="Why it is being set")
    activate.add_argument("--actor", default=None, help="Who is setting it")
    clear = sub.add_parser("clear", help="Safely clear the kill switch")
    clear.add_argument("--reason", required=True, help="Operator justification")
    clear.add_argument("--actor", default=None, help="Who is clearing it")
    return parser


def _print_snapshot(snapshot: KillSwitchSnapshot) -> None:
    print(f"kill_switch active={snapshot.active}")
    for signal in snapshot.signals:
        print(f"  - {signal.source}: active={signal.active} reason={signal.reason!r}")


async def _run(config: AppConfig, args: argparse.Namespace) -> int:
    coordination = build_redis_coordination(config)
    engine = create_engine_from_dsn(
        config.postgres.dsn,
        echo=False,
        pool_size=config.postgres.db_pool_size,
    )
    try:
        session_factory = create_session_factory(engine)
        uow_factory = create_unit_of_work_factory(session_factory)
        health_checks = (
            PostgresHealthCheck(config.postgres.dsn),
            RedisHealthCheck(config.redis.url),
        )
        service = build_kill_switch_service(
            config,
            redis_store=coordination.kill_switch,
            session_factory=session_factory,
            uow_factory=uow_factory,
            health_checks=health_checks,
        )
        if args.command == "status":
            _print_snapshot(await service.status())
            return 0
        if args.command == "activate":
            _print_snapshot(
                await service.activate(reason=args.reason, actor=args.actor)
            )
            return 0
        if args.command == "clear":
            result = await service.clear(reason=args.reason, actor=args.actor)
            _print_snapshot(result.snapshot)
            if not result.cleared:
                print("clear DENIED; unresolved preconditions:")
                for reason in result.reasons:
                    print(f"  - {reason}")
                return 1
            print("kill switch cleared")
            return 0
        return 2
    finally:
        await coordination.aclose()
        await engine.dispose()


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    config = load_config()
    return asyncio.run(_run(config, args))


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
