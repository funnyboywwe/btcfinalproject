"""polymarket_pair_bot: production-oriented BTC 5-minute pair-accumulation bot.

Module 0 provides only the engineering scaffold: configuration, logging,
lifecycle management, health state, and local infrastructure. No Polymarket
networking or trading logic lives here yet.
"""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.0.0"
