"""Typed provider ports for reconciliation (Module 15).

Dependency inversion: the service depends only on these Protocols. Concrete
adapters over SQLAlchemy, the authenticated account reader, the execution
adapter and the kill switch live in :mod:`.adapters`. Domain/strategy code
never imports those adapters.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import ExchangeOrder, Fill, ReconciliationResult
from polymarket_pair_bot.domain.value_objects import MarketId, OrderId, TokenId

from .models import (
    ChainState,
    FillImportOutcome,
    LocalState,
    RemoteAccountState,
)


@runtime_checkable
class LocalStateProvider(Protocol):
    """Loads authoritative local records for the given markets."""

    async def load(self, markets: Sequence[MarketId]) -> LocalState: ...


@runtime_checkable
class RemoteAccountProvider(Protocol):
    """Loads authoritative remote account state (read-only authenticated)."""

    async def load(self, markets: Sequence[MarketId]) -> RemoteAccountState: ...


@runtime_checkable
class ChainStateProvider(Protocol):
    """Loads on-chain state. May raise UnsupportedReconciliationOperationError
    while Modules 20-21 are unimplemented; the service treats that as
    'unavailable' rather than crashing."""

    async def load(self, tokens: Sequence[TokenId]) -> ChainState: ...


@runtime_checkable
class ConfirmedFillImporter(Protocol):
    """Idempotently imports confirmed fills missing locally (requirement 7)."""

    async def import_missing_fills(
        self, fills: Sequence[Fill]
    ) -> FillImportOutcome: ...


@runtime_checkable
class RemoteOrderCanceller(Protocol):
    """Cancels a remote order. Cancellation must remain possible with the kill
    switch engaged (requirement 9 auto-cancel of unknown remote orders)."""

    async def cancel_order(self, order_id: OrderId) -> None: ...


@runtime_checkable
class TradingHalt(Protocol):
    """Stops NEW trading (e.g. engages the kill switch) on balance mismatch or
    any halting classification (requirement 10, fail closed)."""

    async def halt_new_trading(self, *, reason: str) -> None: ...


@runtime_checkable
class ReconciliationReportSink(Protocol):
    """Persists the complete reconciliation report (requirement 11)."""

    async def persist(self, result: ReconciliationResult) -> int: ...


@runtime_checkable
class MarketScope(Protocol):
    """Supplies the markets in scope for a reconciliation pass."""

    async def markets(self) -> tuple[MarketId, ...]: ...


@runtime_checkable
class OpenOrderEnumerator(Protocol):
    """Narrow capability: enumerate ALL non-terminal local orders across every
    market. Satisfied structurally by the SQLAlchemy exchange-order repository
    (additive ``list_open_all``); the shared domain repository Protocol is left
    unchanged."""

    async def list_open_all(self) -> Sequence[ExchangeOrder]: ...


__all__ = [
    "LocalStateProvider",
    "RemoteAccountProvider",
    "ChainStateProvider",
    "ConfirmedFillImporter",
    "RemoteOrderCanceller",
    "TradingHalt",
    "ReconciliationReportSink",
    "MarketScope",
    "OpenOrderEnumerator",
]
