"""Reconciliation classification taxonomy (Module 15).

The reconciliation package owns a *rich* six-way classification. The shared
domain keeps its coarse :class:`ReconciliationStatus` enum unchanged; every
rich class maps back to it via :meth:`ReconciliationClass.to_status` so the
persisted :class:`~polymarket_pair_bot.domain.entities.ReconciliationResult`
stays compatible with prior modules (risk engine, kill switch).
"""

from __future__ import annotations

from collections.abc import Iterable
from enum import Enum

from polymarket_pair_bot.domain.enums import ReconciliationStatus


class ReconciliationClass(str, Enum):
    CONSISTENT = "consistent"
    AUTOMATICALLY_RECOVERABLE = "automatically_recoverable"
    LOCAL_REPAIR_REQUIRED = "local_repair_required"
    CANCELLATION_REQUIRED = "cancellation_required"
    MANUAL_REVIEW = "manual_review"
    CRITICAL_STOP = "critical_stop"

    @property
    def severity(self) -> int:
        return _SEVERITY[self]

    @property
    def is_consistent(self) -> bool:
        return self is ReconciliationClass.CONSISTENT

    @property
    def halts_new_trading(self) -> bool:
        """Whether this class must stop *new* trading (fail closed).

        Only a clean state, or a state whose only issues are confirmed fills we
        can import automatically, may keep trading. Everything else stops new
        trading while leaving existing-order cancellation available.
        """
        return self not in (
            ReconciliationClass.CONSISTENT,
            ReconciliationClass.AUTOMATICALLY_RECOVERABLE,
        )

    def to_status(self) -> ReconciliationStatus:
        return _STATUS_MAP[self]


_SEVERITY: dict[ReconciliationClass, int] = {
    ReconciliationClass.CONSISTENT: 0,
    ReconciliationClass.AUTOMATICALLY_RECOVERABLE: 1,
    ReconciliationClass.LOCAL_REPAIR_REQUIRED: 2,
    ReconciliationClass.CANCELLATION_REQUIRED: 3,
    ReconciliationClass.MANUAL_REVIEW: 4,
    ReconciliationClass.CRITICAL_STOP: 5,
}

# CONSISTENT stays consistent. MANUAL_REVIEW maps to UNKNOWN because it means
# the run could not be auto-classified and needs a human. Every other
# non-consistent class is a known DISCREPANCY.
_STATUS_MAP: dict[ReconciliationClass, ReconciliationStatus] = {
    ReconciliationClass.CONSISTENT: ReconciliationStatus.CONSISTENT,
    ReconciliationClass.AUTOMATICALLY_RECOVERABLE: ReconciliationStatus.DISCREPANCY,
    ReconciliationClass.LOCAL_REPAIR_REQUIRED: ReconciliationStatus.DISCREPANCY,
    ReconciliationClass.CANCELLATION_REQUIRED: ReconciliationStatus.DISCREPANCY,
    ReconciliationClass.MANUAL_REVIEW: ReconciliationStatus.UNKNOWN,
    ReconciliationClass.CRITICAL_STOP: ReconciliationStatus.DISCREPANCY,
}


def escalate(
    left: ReconciliationClass, right: ReconciliationClass
) -> ReconciliationClass:
    """Return the more severe of two classes."""
    return left if left.severity >= right.severity else right


def combine(classes: Iterable[ReconciliationClass]) -> ReconciliationClass:
    """Fold a collection of classes into the single most-severe class."""
    result = ReconciliationClass.CONSISTENT
    for item in classes:
        result = escalate(result, item)
    return result


__all__ = ["ReconciliationClass", "escalate", "combine"]
