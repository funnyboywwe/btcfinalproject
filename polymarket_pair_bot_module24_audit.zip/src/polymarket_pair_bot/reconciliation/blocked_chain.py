"""Blocked on-chain state provider (Module 15).

Wallet outcome-token balances, collateral, pending Polygon transactions and
completed merge/redeem confirmations are on-chain concerns owned by the Polygon
balance/allowance service (Module 20) and the CTF split/merge/redeem service
(Module 21). Those modules are not implemented yet, and this project's safety
rules forbid guessing an on-chain client's API.

Rather than fabricate balances, this provider raises a typed, explanatory
``UnsupportedReconciliationOperationError``. The reconciliation service catches
it and records an 'on-chain verification unavailable' note; when
``require_chain_verification`` is enabled it escalates to manual review (fail
closed) instead of assuming consistency.
"""

from __future__ import annotations

from collections.abc import Sequence

from polymarket_pair_bot.domain.value_objects import TokenId

from .errors import UnsupportedReconciliationOperationError
from .models import ChainState


class BlockedChainStateProvider:
    """A :class:`ChainStateProvider` that is intentionally not implemented."""

    async def load(self, tokens: Sequence[TokenId]) -> ChainState:
        raise UnsupportedReconciliationOperationError(
            "load_chain_state",
            detail=(
                "wallet token balances, collateral, pending Polygon "
                "transactions and completed merge/redeem confirmations require "
                "Modules 20-21"
            ),
        )


class EmptyChainStateProvider:
    """A benign provider that reports 'unavailable' without raising.

    Useful for paper mode and tests where no on-chain source exists but the
    caller does not want the blocked-operation error path exercised.
    """

    def __init__(self, note: str = "on-chain verification not configured") -> None:
        self._note = note

    async def load(self, tokens: Sequence[TokenId]) -> ChainState:
        return ChainState(available=False, note=self._note)


__all__ = ["BlockedChainStateProvider", "EmptyChainStateProvider"]
