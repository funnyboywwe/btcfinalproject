"""Reconciliation snapshots and reports (Module 15).

These are pure, framework-free value types. External payloads are validated by
the already-existing Pydantic view models in :mod:`polymarket_pair_bot.auth`
and the domain value objects; the reconciliation layer only composes them, so
plain frozen dataclasses are used here.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum

from polymarket_pair_bot.auth.models import (
    AllowanceView,
    BalanceView,
    OpenOrderView,
    TradeFillView,
)
from polymarket_pair_bot.domain.entities import (
    CtfOperation,
    ExchangeOrder,
    Fill,
    InventorySnapshot,
    ReconciliationResult,
)
from polymarket_pair_bot.domain.value_objects import UnixTimestamp

from .classification import ReconciliationClass
from .triggers import ReconciliationTrigger


class DiscrepancyKind(str, Enum):
    """Every discrepancy the comparator can emit."""

    UNKNOWN_REMOTE_ORDER = "unknown_remote_order"
    LOCAL_OPEN_NOT_ON_REMOTE = "local_open_not_on_remote"
    ORDER_STATE_MISMATCH = "order_state_mismatch"
    MISSING_LOCAL_FILL = "missing_local_fill"
    MISSING_REMOTE_FILL = "missing_remote_fill"
    FILL_FIELD_MISMATCH = "fill_field_mismatch"
    INVENTORY_MISMATCH = "inventory_mismatch"
    TOKEN_BALANCE_MISMATCH = "token_balance_mismatch"
    COLLATERAL_MISMATCH = "collateral_mismatch"
    ALLOWANCE_SHORTFALL = "allowance_shortfall"
    ALLOWANCE_UNVERIFIED = "allowance_unverified"
    PENDING_CHAIN_TX = "pending_chain_tx"
    CHAIN_STATE_UNVERIFIED = "chain_state_unverified"
    REMOTE_STATE_UNVERIFIED = "remote_state_unverified"


@dataclass(frozen=True, slots=True)
class ChainTransactionRecord:
    """A Polygon transaction the bot knows about (merge/redeem/split/etc.)."""

    operation_key: str
    kind: str
    status: str
    tx_hash: str | None = None


@dataclass(frozen=True, slots=True)
class LocalState:
    """Authoritative *local* records to reconcile."""

    open_orders: tuple[ExchangeOrder, ...] = ()
    fills: tuple[Fill, ...] = ()
    inventory: Mapping[str, InventorySnapshot] = field(default_factory=dict)
    pending_chain_txs: tuple[ChainTransactionRecord, ...] = ()
    completed_ctf_ops: tuple[CtfOperation, ...] = ()


@dataclass(frozen=True, slots=True)
class RemoteAccountState:
    """Authoritative *remote* account view (read-only authenticated reads)."""

    open_orders: tuple[OpenOrderView, ...] = ()
    fills: tuple[TradeFillView, ...] = ()
    balances: tuple[BalanceView, ...] = ()
    allowances: tuple[AllowanceView, ...] = ()
    allowances_supported: bool = True
    available: bool = True
    note: str | None = None


@dataclass(frozen=True, slots=True)
class ChainState:
    """On-chain view (blocked until Modules 20-21). ``available`` is False when
    the on-chain adapter cannot yet report."""

    token_balances: Mapping[str, Decimal] = field(default_factory=dict)
    collateral_balance: Decimal | None = None
    pending_txs: tuple[ChainTransactionRecord, ...] = ()
    available: bool = False
    note: str | None = None


@dataclass(frozen=True, slots=True)
class Discrepancy:
    """One classified, secret-free discrepancy."""

    kind: DiscrepancyKind
    classification: ReconciliationClass
    summary: str
    recommended_action: str
    identifier: str | None = None

    def describe(self) -> str:
        base = f"[{self.kind.value}] {self.summary}"
        return f"{base} (id={self.identifier})" if self.identifier else base


@dataclass(frozen=True, slots=True)
class FillImportOutcome:
    """Result of an idempotent confirmed-fill import."""

    imported: int = 0
    duplicates: int = 0


@dataclass(frozen=True, slots=True)
class ReconciliationReport:
    """The rich outcome of a reconciliation pass."""

    trigger: ReconciliationTrigger
    classification: ReconciliationClass
    as_of: UnixTimestamp
    discrepancies: tuple[Discrepancy, ...] = ()
    fills_to_import: tuple[Fill, ...] = ()
    unknown_remote_order_ids: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()

    @property
    def is_consistent(self) -> bool:
        return self.classification.is_consistent

    @property
    def halts_new_trading(self) -> bool:
        return self.classification.halts_new_trading

    def to_domain_result(self) -> ReconciliationResult:
        """Project onto the coarse, previously-defined domain result.

        Only real discrepancies populate ``discrepancies`` (notes are omitted)
        so a CONSISTENT result never carries discrepancy strings.
        """
        descriptions = tuple(d.describe() for d in self.discrepancies)
        actions = tuple(
            dict.fromkeys(d.recommended_action for d in self.discrepancies)
        )
        return ReconciliationResult(
            status=self.classification.to_status(),
            as_of=self.as_of,
            discrepancies=descriptions,
            recommended_actions=actions,
        )


__all__ = [
    "DiscrepancyKind",
    "ChainTransactionRecord",
    "LocalState",
    "RemoteAccountState",
    "ChainState",
    "Discrepancy",
    "FillImportOutcome",
    "ReconciliationReport",
]
