"""Reconciliation trigger points (Module 15).

The service runs at startup, after user-WebSocket reconnect, after an unknown
submission status, before and after a merge, periodically, during graceful
shutdown, and on-demand from the operator CLI.
"""

from __future__ import annotations

from enum import Enum


class ReconciliationTrigger(str, Enum):
    MANUAL = "manual"
    STARTUP = "startup"
    USER_STREAM_RECONNECT = "user_stream_reconnect"
    UNKNOWN_SUBMISSION = "unknown_submission"
    PRE_MERGE = "pre_merge"
    POST_MERGE = "post_merge"
    PERIODIC = "periodic"
    SHUTDOWN = "shutdown"

    @property
    def is_merge_boundary(self) -> bool:
        return self in (
            ReconciliationTrigger.PRE_MERGE,
            ReconciliationTrigger.POST_MERGE,
        )


__all__ = ["ReconciliationTrigger"]
