"""Authoritative reconciliation service (Module 15, architecture item 19).

Unknown order status requires reconciliation; a user-stream reconnect requires
a fresh authoritative synchronization; uncertain state means cancel where safe,
reconcile, and stop (fail closed).

Only import-safe symbols (stdlib + pydantic + domain) are re-exported at package
import time. Concrete adapters and the CLI pull in SQLAlchemy / auth / risk
composition and are imported lazily by callers (``from .adapters import ...``)
so importing this package never requires infrastructure packages.
"""

from __future__ import annotations

from polymarket_pair_bot.reconciliation.classification import (
    ReconciliationClass,
    combine,
    escalate,
)
from polymarket_pair_bot.reconciliation.comparator import reconcile_states
from polymarket_pair_bot.reconciliation.errors import (
    ReconciliationDataUnavailableError,
    ReconciliationError,
    UnsupportedReconciliationOperationError,
)
from polymarket_pair_bot.reconciliation.models import (
    ChainState,
    ChainTransactionRecord,
    Discrepancy,
    DiscrepancyKind,
    FillImportOutcome,
    LocalState,
    ReconciliationReport,
    RemoteAccountState,
)
from polymarket_pair_bot.reconciliation.ports import (
    ChainStateProvider,
    ConfirmedFillImporter,
    LocalStateProvider,
    MarketScope,
    OpenOrderEnumerator,
    ReconciliationReportSink,
    RemoteAccountProvider,
    RemoteOrderCanceller,
    TradingHalt,
)
from polymarket_pair_bot.reconciliation.service import (
    ReconciliationService,
    ReconciliationTuning,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger

__all__ = [
    "ChainState",
    "ChainStateProvider",
    "ChainTransactionRecord",
    "ConfirmedFillImporter",
    "Discrepancy",
    "DiscrepancyKind",
    "FillImportOutcome",
    "LocalState",
    "LocalStateProvider",
    "MarketScope",
    "OpenOrderEnumerator",
    "ReconciliationClass",
    "ReconciliationDataUnavailableError",
    "ReconciliationError",
    "ReconciliationReport",
    "ReconciliationReportSink",
    "ReconciliationService",
    "ReconciliationTrigger",
    "ReconciliationTuning",
    "RemoteAccountProvider",
    "RemoteAccountState",
    "RemoteOrderCanceller",
    "TradingHalt",
    "UnsupportedReconciliationOperationError",
    "combine",
    "escalate",
    "reconcile_states",
]
