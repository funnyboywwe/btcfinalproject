"""Operator CLI for authoritative reconciliation (Module 15).

Usage::

    uv run polymarket-pair-bot reconcile [--market MARKET_ID ...] \
        [--report-only] [--json]

Runs a single authoritative reconciliation pass: it loads local records, the
read-only authenticated account view and (when available) on-chain state,
classifies the result, imports any missing confirmed fills idempotently,
persists the complete report, and -- unless ``--report-only`` -- stops new
trading (engages the kill switch) on any halting classification.

The CLI never submits orders and never prints secrets, DSNs or connection URLs.
Unknown remote orders are reported for critical review here; the running
application wires an execution-adapter canceller to auto-cancel them.

Exit code is ``0`` when the run is consistent or fully auto-recoverable, and
``1`` when it halts new trading or needs review, so operator scripts can gate.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Sequence

from polymarket_pair_bot.auth.factory import build_account_reader
from polymarket_pair_bot.config import AppConfig, load_config
from polymarket_pair_bot.coordination.factory import build_redis_coordination
from polymarket_pair_bot.observability.health_checks import (
    PostgresHealthCheck,
    RedisHealthCheck,
)
from polymarket_pair_bot.persistence.engine import (
    create_engine_from_dsn,
    create_session_factory,
)
from polymarket_pair_bot.persistence.repositories import create_unit_of_work_factory
from polymarket_pair_bot.risk.factory import build_kill_switch_service

from .adapters import (
    AuthReaderRemoteAccountProvider,
    KillSwitchTradingHalt,
    StaticMarketScope,
    UnitOfWorkFillImporter,
    UnitOfWorkLocalStateProvider,
    UnitOfWorkReconciliationSink,
)
from .blocked_chain import BlockedChainStateProvider
from .models import ReconciliationReport
from .service import ReconciliationService, ReconciliationTuning
from .triggers import ReconciliationTrigger


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--market",
        action="append",
        default=None,
        dest="markets",
        help="Market id to include in inventory reconciliation (repeatable).",
    )
    parser.add_argument(
        "--report-only",
        action="store_true",
        help="Persist the report but do not engage the kill switch.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="Emit the report as JSON.",
    )


def _tuning_from(config: AppConfig) -> ReconciliationTuning:
    rc = config.reconciliation
    return ReconciliationTuning(
        share_tolerance=rc.reconciliation_share_tolerance,
        price_tolerance=rc.reconciliation_price_tolerance,
        collateral_tolerance=rc.reconciliation_collateral_tolerance_usd,
        auto_cancel_unknown_orders=rc.reconciliation_auto_cancel_unknown_orders,
        halt_on_halting_class=rc.reconciliation_halt_on_balance_mismatch,
        require_chain_verification=rc.reconciliation_require_chain_verification,
        expected_allowance_spender=rc.reconciliation_expected_allowance_spender,
    )


def _print_report(report: ReconciliationReport, *, as_json: bool) -> None:
    if as_json:
        payload = {
            "trigger": report.trigger.value,
            "classification": report.classification.value,
            "as_of": report.as_of.value,
            "halts_new_trading": report.halts_new_trading,
            "fills_to_import": len(report.fills_to_import),
            "unknown_remote_order_ids": list(report.unknown_remote_order_ids),
            "discrepancies": [
                {
                    "kind": d.kind.value,
                    "classification": d.classification.value,
                    "summary": d.summary,
                    "recommended_action": d.recommended_action,
                    "identifier": d.identifier,
                }
                for d in report.discrepancies
            ],
            "notes": list(report.notes),
        }
        print(json.dumps(payload, indent=2))
        return
    print(f"reconciliation trigger={report.trigger.value}")
    print(f"  classification   : {report.classification.value}")
    print(f"  halts_new_trading: {report.halts_new_trading}")
    print(f"  fills_to_import  : {len(report.fills_to_import)}")
    print(f"  discrepancies    : {len(report.discrepancies)}")
    for d in report.discrepancies:
        ident = f" id={d.identifier}" if d.identifier else ""
        print(f"    - [{d.classification.value}] {d.kind.value}{ident}: {d.summary}")
        print(f"        action: {d.recommended_action}")
    for note in report.notes:
        print(f"  note: {note}")


async def _run(config: AppConfig, args: argparse.Namespace) -> int:
    coordination = build_redis_coordination(config)
    engine = create_engine_from_dsn(
        config.postgres.dsn,
        echo=False,
        pool_size=config.postgres.db_pool_size,
    )
    reader = build_account_reader(config)
    try:
        session_factory = create_session_factory(engine)
        uow_factory = create_unit_of_work_factory(session_factory)
        halt = None
        if not args.report_only:
            health_checks = (
                PostgresHealthCheck(config.postgres.dsn),
                RedisHealthCheck(config.redis.url),
            )
            kill_switch = build_kill_switch_service(
                config,
                redis_store=coordination.kill_switch,
                session_factory=session_factory,
                uow_factory=uow_factory,
                health_checks=health_checks,
            )
            halt = KillSwitchTradingHalt(kill_switch)

        markets = tuple(
            __import__(
                "polymarket_pair_bot.domain.value_objects",
                fromlist=["MarketId"],
            ).MarketId(m)
            for m in (args.markets or ())
        )
        service = ReconciliationService(
            local=UnitOfWorkLocalStateProvider(uow_factory),
            remote=AuthReaderRemoteAccountProvider(reader),
            chain=BlockedChainStateProvider(),
            sink=UnitOfWorkReconciliationSink(uow_factory),
            market_scope=StaticMarketScope(markets),
            importer=UnitOfWorkFillImporter(uow_factory),
            canceller=None,
            halt=halt,
            tuning=_tuning_from(config),
        )
        report = await service.reconcile(ReconciliationTrigger.MANUAL)
        _print_report(report, as_json=args.as_json)
        return 0 if not report.halts_new_trading else 1
    finally:
        await reader.aclose()
        await coordination.aclose()
        await engine.dispose()


def run(args: argparse.Namespace) -> int:
    config = load_config()
    return asyncio.run(_run(config, args))


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-reconcile",
        description="Run one authoritative reconciliation pass.",
    )
    add_arguments(parser)
    return run(parser.parse_args(argv))


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
