"""Concrete reconciliation adapters (Module 15).

These wire real infrastructure behind the reconciliation ports:

* local state  -> the SQLAlchemy unit of work (read-only usage);
* remote state -> the read-only ``AuthenticatedAccountReader`` (Module 15 auth);
* fill import  -> ``UnitOfWork.fills.insert_idempotent`` + audit event;
* cancellation -> ``ExecutionAdapter.cancel_order`` (allowed with kill switch on);
* trading halt -> ``KillSwitchService.activate``;
* report sink  -> ``ReconciliationRepository.record_run`` + audit event.

These adapters require live infrastructure (PostgreSQL, authenticated CLOB
reads) and are therefore exercised by integration tests, not the offline unit
suite. The unit/crash-recovery tests drive the service with in-memory fakes
that honour the same Protocols.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import cast

from polymarket_pair_bot.auth.errors import UnsupportedAuthOperationError
from polymarket_pair_bot.auth.ports import AuthenticatedAccountReader
from polymarket_pair_bot.domain.entities import Fill, ReconciliationResult
from polymarket_pair_bot.domain.repositories import UnitOfWorkFactory
from polymarket_pair_bot.domain.value_objects import (
    MarketId,
    OrderId,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.ports import ExecutionAdapter
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.risk.service import KillSwitchService

from .models import FillImportOutcome, LocalState, RemoteAccountState
from .ports import OpenOrderEnumerator

_LOG = get_logger("reconciliation.adapters")


class UnitOfWorkLocalStateProvider:
    """Loads authoritative local records via the SQLAlchemy unit of work.

    Uses the additive ``list_open_all`` capability to enumerate every open
    order regardless of market. Pending-transaction and completed-CTF
    enumeration is deferred to Modules 20-21 (the repositories expose
    keyed ``get`` but no list yet), so those tuples are left empty here.
    """

    def __init__(self, uow_factory: UnitOfWorkFactory, *, clock=None) -> None:
        self._uow_factory = uow_factory
        import time

        self._clock = clock or (lambda: int(time.time()))

    async def load(self, markets: Sequence[MarketId]) -> LocalState:
        async with self._uow_factory() as uow:
            enumerator = cast(OpenOrderEnumerator, uow.orders)
            open_orders = tuple(await enumerator.list_open_all())
            fills: list[Fill] = []
            for order in open_orders:
                fills.extend(await uow.fills.list_for_order(order.order_id))
            inventory = {}
            for market in markets:
                snapshot = await uow.inventory.get_latest(market)
                if snapshot is not None:
                    inventory[market.value] = snapshot
            return LocalState(
                open_orders=open_orders,
                fills=tuple(fills),
                inventory=inventory,
            )


class AuthReaderRemoteAccountProvider:
    """Loads authoritative remote account state via read-only auth reads."""

    def __init__(self, reader: AuthenticatedAccountReader) -> None:
        self._reader = reader

    async def load(self, markets: Sequence[MarketId]) -> RemoteAccountState:
        open_orders = await self._reader.get_open_orders()
        trades = await self._reader.get_trades()
        balances = await self._reader.get_balances()
        allowances_supported = True
        allowances: tuple = ()
        try:
            allowances = await self._reader.get_allowances()
        except UnsupportedAuthOperationError as exc:
            allowances_supported = False
            _LOG.warning(
                "reconciliation_allowances_unsupported",
                extra={"detail": str(exc)},
            )
        return RemoteAccountState(
            open_orders=tuple(open_orders),
            fills=tuple(trades),
            balances=tuple(balances),
            allowances=tuple(allowances),
            allowances_supported=allowances_supported,
            available=True,
        )


class ExecutionAdapterCanceller:
    """Cancels unknown remote orders via the execution adapter.

    Cancellation remains available while the kill switch is engaged (the
    execution adapter's cancel path never gates on the kill switch).
    """

    def __init__(self, adapter: ExecutionAdapter) -> None:
        self._adapter = adapter

    async def cancel_order(self, order_id: OrderId) -> None:
        await self._adapter.cancel_order(order_id)


class KillSwitchTradingHalt:
    """Stops new trading by durably engaging the persistent kill switch."""

    def __init__(
        self, kill_switch: KillSwitchService, *, actor: str = "reconciliation"
    ) -> None:
        self._kill_switch = kill_switch
        self._actor = actor

    async def halt_new_trading(self, *, reason: str) -> None:
        await self._kill_switch.activate(reason=reason, actor=self._actor)


class UnitOfWorkFillImporter:
    """Imports confirmed fills idempotently (requirement 7).

    Uses ``fills.insert_idempotent`` inside a single transaction and appends a
    secret-free audit event. Fills already present are counted as duplicates
    and never re-applied (fill messages are not assumed unique).
    """

    def __init__(self, uow_factory: UnitOfWorkFactory, *, clock=None) -> None:
        self._uow_factory = uow_factory
        import time

        self._clock = clock or (lambda: int(time.time()))

    async def import_missing_fills(
        self, fills: Sequence[Fill]
    ) -> FillImportOutcome:
        imported = 0
        duplicates = 0
        async with self._uow_factory() as uow:
            for fill in fills:
                newly = await uow.fills.insert_idempotent(fill)
                if newly:
                    imported += 1
                else:
                    duplicates += 1
            await uow.audit.append_event(
                event_type="reconciliation.fill_import",
                severity="info",
                created_at=UnixTimestamp(self._clock()),
                payload={"imported": imported, "duplicates": duplicates},
            )
            await uow.commit()
        return FillImportOutcome(imported=imported, duplicates=duplicates)


class UnitOfWorkReconciliationSink:
    """Persists the complete reconciliation report (requirement 11)."""

    def __init__(self, uow_factory: UnitOfWorkFactory, *, clock=None) -> None:
        self._uow_factory = uow_factory
        import time

        self._clock = clock or (lambda: int(time.time()))

    async def persist(self, result: ReconciliationResult) -> int:
        async with self._uow_factory() as uow:
            run_id = await uow.reconciliation.record_run(result)
            await uow.audit.append_event(
                event_type="reconciliation.run",
                severity="warning"
                if not result.is_consistent
                else "info",
                created_at=UnixTimestamp(self._clock()),
                payload={
                    "run_id": run_id,
                    "status": result.status.value,
                    "discrepancies": len(result.discrepancies),
                },
            )
            await uow.commit()
        return run_id


class StaticMarketScope:
    """A fixed market scope (e.g. the currently-active BTC 5-minute market)."""

    def __init__(self, markets: Sequence[MarketId] = ()) -> None:
        self._markets = tuple(markets)

    async def markets(self) -> tuple[MarketId, ...]:
        return self._markets


__all__ = [
    "UnitOfWorkLocalStateProvider",
    "AuthReaderRemoteAccountProvider",
    "ExecutionAdapterCanceller",
    "KillSwitchTradingHalt",
    "UnitOfWorkFillImporter",
    "UnitOfWorkReconciliationSink",
    "StaticMarketScope",
]
