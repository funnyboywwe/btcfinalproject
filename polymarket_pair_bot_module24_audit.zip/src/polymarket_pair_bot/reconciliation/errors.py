"""Typed errors for the authoritative reconciliation service (Module 15)."""

from __future__ import annotations


class ReconciliationError(Exception):
    """Base class for reconciliation-module errors."""


class ReconciliationDataUnavailableError(ReconciliationError):
    """Authoritative data required for reconciliation could not be read.

    The service fails closed: an unavailable authoritative source degrades the
    run to a non-consistent classification instead of assuming consistency.
    """

    def __init__(self, source: str, detail: str = "") -> None:
        self.source = source
        message = f"Authoritative reconciliation source {source!r} is unavailable"
        if detail:
            message = f"{message}: {detail}"
        super().__init__(message)


class UnsupportedReconciliationOperationError(ReconciliationError):
    """A blocked adapter method whose behaviour is not verified locally.

    On-chain reconciliation (wallet token balances, collateral, pending Polygon
    transactions and completed merge/redeem confirmations) depends on the
    Polygon balance/allowance and CTF services (Modules 20-21), which are not
    implemented yet. Rather than guessing an on-chain client's API, the blocked
    provider raises this typed error naming the operation still to implement.
    """

    def __init__(self, operation: str, detail: str = "") -> None:
        self.operation = operation
        message = (
            f"Reconciliation operation {operation!r} is not implemented: the "
            "Polygon balance/allowance and CTF services (Modules 20-21) are not "
            "available yet. Implement the on-chain adapter before enabling it."
        )
        if detail:
            message = f"{message} ({detail})"
        super().__init__(message)


__all__ = [
    "ReconciliationError",
    "ReconciliationDataUnavailableError",
    "UnsupportedReconciliationOperationError",
]
