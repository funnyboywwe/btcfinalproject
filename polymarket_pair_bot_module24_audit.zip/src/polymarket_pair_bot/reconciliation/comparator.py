"""Pure reconciliation comparator (Module 15).

No I/O, no clocks, no globals: given normalized local/remote/chain snapshots it
deterministically produces a :class:`ReconciliationReport`. All monetary and
quantity comparisons use :class:`~decimal.Decimal` with explicit tolerances and
are deliberately conservative (any unexplained difference escalates).
"""

from __future__ import annotations

from collections.abc import Iterable
from decimal import Decimal

from polymarket_pair_bot.auth.models import TradeFillView
from polymarket_pair_bot.domain.entities import Fill
from polymarket_pair_bot.domain.enums import OrderSide
from polymarket_pair_bot.domain.value_objects import (
    FeeAmount,
    FillId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)

from .classification import ReconciliationClass, combine
from .models import (
    ChainState,
    Discrepancy,
    DiscrepancyKind,
    LocalState,
    ReconciliationReport,
    RemoteAccountState,
)
from .triggers import ReconciliationTrigger


def _to_domain_fill(view: TradeFillView, fallback: UnixTimestamp) -> Fill:
    """Convert a validated remote fill view into a domain Fill."""
    if view.matched_at is not None:
        filled_at = UnixTimestamp(int(view.matched_at.timestamp()))
    else:
        filled_at = fallback
    return Fill(
        fill_id=FillId(view.fill_id),
        order_id=OrderId(view.order_id),
        token_id=TokenId(view.token_id),
        side=view.side,
        price=ProbabilityPrice(view.price),
        size=Shares(view.size),
        fee=FeeAmount(view.fee_paid),
        filled_at=filled_at,
    )


def _net_shares_by_token(fills: Iterable[Fill]) -> dict[str, Decimal]:
    """Net acquired shares per token from confirmed fills (BUY - SELL)."""
    out: dict[str, Decimal] = {}
    for fill in fills:
        delta = fill.size.value
        if fill.side is OrderSide.SELL:
            delta = -delta
        out[fill.token_id.value] = out.get(fill.token_id.value, Decimal(0)) + delta
    return out


def reconcile_states(
    *,
    trigger: ReconciliationTrigger,
    local: LocalState,
    remote: RemoteAccountState,
    chain: ChainState,
    now: UnixTimestamp,
    share_tolerance: Decimal = Decimal("0.000001"),
    price_tolerance: Decimal = Decimal("0.000001"),
    collateral_tolerance: Decimal = Decimal("0.01"),
    auto_cancel_unknown_orders: bool = True,
    require_chain_verification: bool = False,
    expected_allowance_spender: str = "",
    collateral_asset: str = "USDC",
) -> ReconciliationReport:
    """Compare all authoritative sources and classify the result."""
    discrepancies: list[Discrepancy] = []
    notes: list[str] = []
    fills_to_import: list[Fill] = []
    unknown_remote_order_ids: list[str] = []

    # ---- Fail closed if authoritative remote state is unavailable ----
    if not remote.available:
        notes.append(remote.note or "remote account state unavailable")
        discrepancies.append(
            Discrepancy(
                kind=DiscrepancyKind.REMOTE_STATE_UNVERIFIED,
                classification=ReconciliationClass.CRITICAL_STOP,
                summary="authoritative remote account state could not be read",
                recommended_action=(
                    "stop new trading; restore authenticated read access; "
                    "re-run reconciliation before resuming"
                ),
            )
        )
        classification = combine(d.classification for d in discrepancies)
        return ReconciliationReport(
            trigger=trigger,
            classification=classification,
            as_of=now,
            discrepancies=tuple(discrepancies),
            notes=tuple(notes),
        )

    # ---- Orders: local open vs remote open ----
    local_open = {o.order_id.value: o for o in local.open_orders}
    remote_open = {o.order_id: o for o in remote.open_orders}

    for order_id, remote_order in remote_open.items():
        if order_id not in local_open:
            cls = (
                ReconciliationClass.CANCELLATION_REQUIRED
                if auto_cancel_unknown_orders
                else ReconciliationClass.CRITICAL_STOP
            )
            action = (
                "cancel unknown remote order (safe with kill switch on)"
                if auto_cancel_unknown_orders
                else "escalate unknown remote order for critical manual review"
            )
            unknown_remote_order_ids.append(order_id)
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.UNKNOWN_REMOTE_ORDER,
                    classification=cls,
                    summary="remote open order has no local record",
                    recommended_action=action,
                    identifier=order_id,
                )
            )

    for order_id, local_order in local_open.items():
        remote_order = remote_open.get(order_id)
        if remote_order is None:
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.LOCAL_OPEN_NOT_ON_REMOTE,
                    classification=ReconciliationClass.LOCAL_REPAIR_REQUIRED,
                    summary="local open order absent from remote open orders",
                    recommended_action=(
                        "refresh authoritative order status; do not assume "
                        "filled or cancelled"
                    ),
                    identifier=order_id,
                )
            )
            continue
        status_mismatch = local_order.status is not remote_order.status
        size_mismatch = (
            abs(local_order.filled_size.value - remote_order.size_matched)
            > share_tolerance
        )
        if status_mismatch or size_mismatch:
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.ORDER_STATE_MISMATCH,
                    classification=ReconciliationClass.LOCAL_REPAIR_REQUIRED,
                    summary=(
                        "local order state disagrees with authoritative "
                        "remote order state"
                    ),
                    recommended_action=(
                        "update local order from authoritative record"
                    ),
                    identifier=order_id,
                )
            )

    # ---- Fills: remote vs local (import missing; never delete) ----
    local_fills = {f.fill_id.value: f for f in local.fills}
    remote_fills = {f.fill_id: f for f in remote.fills}

    for fill_id, remote_fill in remote_fills.items():
        local_fill = local_fills.get(fill_id)
        if local_fill is None:
            fills_to_import.append(_to_domain_fill(remote_fill, now))
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.MISSING_LOCAL_FILL,
                    classification=ReconciliationClass.AUTOMATICALLY_RECOVERABLE,
                    summary="confirmed remote fill missing locally",
                    recommended_action="import confirmed fill idempotently",
                    identifier=fill_id,
                )
            )
            continue
        price_mismatch = (
            abs(local_fill.price.value - remote_fill.price) > price_tolerance
        )
        size_mismatch = abs(local_fill.size.value - remote_fill.size) > share_tolerance
        side_mismatch = local_fill.side is not remote_fill.side
        token_mismatch = local_fill.token_id.value != remote_fill.token_id
        if price_mismatch or size_mismatch or side_mismatch or token_mismatch:
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.FILL_FIELD_MISMATCH,
                    classification=ReconciliationClass.MANUAL_REVIEW,
                    summary="local and remote fill records disagree",
                    recommended_action=(
                        "manually review conflicting fill; never overwrite "
                        "or delete silently"
                    ),
                    identifier=fill_id,
                )
            )

    for fill_id in local_fills:
        if fill_id not in remote_fills:
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.MISSING_REMOTE_FILL,
                    classification=ReconciliationClass.MANUAL_REVIEW,
                    summary="local fill not reported by authoritative source",
                    recommended_action=(
                        "investigate local-only fill before any deletion; "
                        "never silently delete unexplained data"
                    ),
                    identifier=fill_id,
                )
            )

    # ---- Inventory: recompute from confirmed fills (local + importable) ----
    net_shares = _net_shares_by_token(list(local.fills) + fills_to_import)
    for market_id, snapshot in local.inventory.items():
        for position in (snapshot.up_position, snapshot.down_position):
            expected = net_shares.get(position.token_id.value, Decimal(0))
            if abs(position.quantity.value - expected) > share_tolerance:
                discrepancies.append(
                    Discrepancy(
                        kind=DiscrepancyKind.INVENTORY_MISMATCH,
                        classification=ReconciliationClass.LOCAL_REPAIR_REQUIRED,
                        summary=(
                            "stored inventory disagrees with confirmed fills"
                        ),
                        recommended_action=(
                            "rebuild inventory from authoritative fills"
                        ),
                        identifier=f"{market_id}:{position.token_id.value}",
                    )
                )

    # ---- Wallet outcome-token balances (balance mismatch stops trading) ----
    balances_by_asset = {b.asset: b for b in remote.balances}
    balances_reported = bool(remote.balances)
    if not balances_reported:
        notes.append(
            "wallet balances not reported this pass; balance "
            "verification skipped (no fabricated mismatch)"
        )
    for token_id, expected in net_shares.items():
        remote_balance = balances_by_asset.get(token_id)
        if remote_balance is None:
            if balances_reported and expected > share_tolerance:
                discrepancies.append(
                    Discrepancy(
                        kind=DiscrepancyKind.TOKEN_BALANCE_MISMATCH,
                        classification=ReconciliationClass.CRITICAL_STOP,
                        summary=(
                            "expected token holdings not reported by wallet"
                        ),
                        recommended_action=(
                            "stop new trading; investigate wallet balance "
                            "before resuming"
                        ),
                        identifier=token_id,
                    )
                )
        elif abs(remote_balance.total - expected) > share_tolerance:
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.TOKEN_BALANCE_MISMATCH,
                    classification=ReconciliationClass.CRITICAL_STOP,
                    summary="wallet token balance disagrees with expected",
                    recommended_action=(
                        "stop new trading; reconcile wallet balance before "
                        "resuming"
                    ),
                    identifier=token_id,
                )
            )
        if chain.available:
            chain_balance = chain.token_balances.get(token_id)
            if (
                chain_balance is not None
                and abs(chain_balance - expected) > share_tolerance
            ):
                discrepancies.append(
                    Discrepancy(
                        kind=DiscrepancyKind.TOKEN_BALANCE_MISMATCH,
                        classification=ReconciliationClass.CRITICAL_STOP,
                        summary="on-chain token balance disagrees with expected",
                        recommended_action=(
                            "stop new trading; reconcile on-chain balance"
                        ),
                        identifier=token_id,
                    )
                )

    # ---- Collateral balance (compare two authoritative sources if present) ----
    remote_collateral = balances_by_asset.get(collateral_asset)
    if remote_collateral is not None:
        notes.append(f"collateral {collateral_asset} total reported by account")
        if chain.available and chain.collateral_balance is not None:
            if (
                abs(remote_collateral.total - chain.collateral_balance)
                > collateral_tolerance
            ):
                discrepancies.append(
                    Discrepancy(
                        kind=DiscrepancyKind.COLLATERAL_MISMATCH,
                        classification=ReconciliationClass.CRITICAL_STOP,
                        summary=(
                            "account and on-chain collateral balances differ"
                        ),
                        recommended_action=(
                            "stop new trading; reconcile collateral balance"
                        ),
                        identifier=collateral_asset,
                    )
                )

    # ---- Allowances ----
    if not remote.allowances_supported:
        notes.append("allowances not reported by the account adapter")
        if require_chain_verification:
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.ALLOWANCE_UNVERIFIED,
                    classification=ReconciliationClass.MANUAL_REVIEW,
                    summary="token allowances could not be verified",
                    recommended_action=(
                        "verify allowances manually before live trading"
                    ),
                )
            )
    elif expected_allowance_spender:
        matching = [
            a
            for a in remote.allowances
            if a.spender == expected_allowance_spender
        ]
        if not matching or all(a.amount <= 0 for a in matching):
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.ALLOWANCE_SHORTFALL,
                    classification=ReconciliationClass.MANUAL_REVIEW,
                    summary="required spender allowance is missing or zero",
                    recommended_action=(
                        "grant/refresh the spender allowance before live "
                        "trading"
                    ),
                    identifier=expected_allowance_spender,
                )
            )

    # ---- Pending Polygon transactions ----
    pending = list(local.pending_chain_txs)
    if chain.available:
        pending.extend(chain.pending_txs)
    for tx in pending:
        discrepancies.append(
            Discrepancy(
                kind=DiscrepancyKind.PENDING_CHAIN_TX,
                classification=ReconciliationClass.MANUAL_REVIEW,
                summary=f"pending {tx.kind} Polygon transaction in flight",
                recommended_action=(
                    "await settlement and re-run reconciliation before new "
                    "trading"
                ),
                identifier=tx.operation_key,
            )
        )

    # ---- Completed merge/redeem transactions + chain availability ----
    if local.completed_ctf_ops:
        notes.append(
            f"{len(local.completed_ctf_ops)} completed CTF operation(s) on record"
        )
    if not chain.available:
        note = chain.note or "on-chain verification unavailable (Modules 20-21)"
        notes.append(note)
        if require_chain_verification:
            discrepancies.append(
                Discrepancy(
                    kind=DiscrepancyKind.CHAIN_STATE_UNVERIFIED,
                    classification=ReconciliationClass.MANUAL_REVIEW,
                    summary="on-chain balances/transactions could not be verified",
                    recommended_action=(
                        "enable the Polygon/CTF services and re-run before live "
                        "trading"
                    ),
                )
            )

    classification = combine(d.classification for d in discrepancies)
    return ReconciliationReport(
        trigger=trigger,
        classification=classification,
        as_of=now,
        discrepancies=tuple(discrepancies),
        fills_to_import=tuple(fills_to_import),
        unknown_remote_order_ids=tuple(unknown_remote_order_ids),
        notes=tuple(notes),
    )


__all__ = ["reconcile_states"]
