"""Reconciliation service orchestration (Module 15).

Loads authoritative local/remote/on-chain state, runs the pure comparator,
then applies bounded, idempotent, cancellation-safe side effects: import
missing confirmed fills, cancel unknown remote orders, stop new trading on any
halting classification, and persist the complete report.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from dataclasses import dataclass
from decimal import Decimal
from typing import Callable

from polymarket_pair_bot.domain.entities import Fill
from polymarket_pair_bot.domain.value_objects import MarketId, OrderId, TokenId, UnixTimestamp
from polymarket_pair_bot.observability.logging import get_logger

from .comparator import reconcile_states
from .errors import (
    ReconciliationDataUnavailableError,
    UnsupportedReconciliationOperationError,
)
from .models import (
    ChainState,
    LocalState,
    ReconciliationReport,
    RemoteAccountState,
)
from .ports import (
    ChainStateProvider,
    ConfirmedFillImporter,
    LocalStateProvider,
    MarketScope,
    RemoteAccountProvider,
    RemoteOrderCanceller,
    ReconciliationReportSink,
    TradingHalt,
)
from .triggers import ReconciliationTrigger

_LOG = get_logger("reconciliation.service")


@dataclass(frozen=True, slots=True)
class ReconciliationTuning:
    """Comparator tolerances and policy flags (all Decimal, never float)."""

    share_tolerance: Decimal = Decimal("0.000001")
    price_tolerance: Decimal = Decimal("0.000001")
    collateral_tolerance: Decimal = Decimal("0.01")
    auto_cancel_unknown_orders: bool = True
    halt_on_halting_class: bool = True
    require_chain_verification: bool = False
    expected_allowance_spender: str = ""
    collateral_asset: str = "USDC"


class ReconciliationService:
    """Coordinates a single authoritative reconciliation pass and its effects."""

    def __init__(
        self,
        *,
        local: LocalStateProvider,
        remote: RemoteAccountProvider,
        chain: ChainStateProvider,
        sink: ReconciliationReportSink,
        market_scope: MarketScope,
        importer: ConfirmedFillImporter | None = None,
        canceller: RemoteOrderCanceller | None = None,
        halt: TradingHalt | None = None,
        tuning: ReconciliationTuning | None = None,
        clock: Callable[[], int] | None = None,
    ) -> None:
        self._local = local
        self._remote = remote
        self._chain = chain
        self._sink = sink
        self._market_scope = market_scope
        self._importer = importer
        self._canceller = canceller
        self._halt = halt
        self._tuning = tuning or ReconciliationTuning()
        self._clock = clock or _default_clock

    @property
    def _effective_auto_cancel(self) -> bool:
        """Auto-cancel unknown remote orders only when a canceller exists;
        otherwise they escalate to critical review (requirement 9)."""
        return (
            self._tuning.auto_cancel_unknown_orders
            and self._canceller is not None
        )

    async def reconcile(self, trigger: ReconciliationTrigger) -> ReconciliationReport:
        """Run one full reconciliation pass and apply its side effects."""
        now = UnixTimestamp(self._clock())
        markets = await self._market_scope.markets()
        remote = await self._safe_load_remote(markets)
        local = await self._safe_load_local(markets)
        tokens = _tokens_in_scope(local, remote)
        chain = await self._safe_load_chain(tokens)

        report = reconcile_states(
            trigger=trigger,
            local=local,
            remote=remote,
            chain=chain,
            now=now,
            share_tolerance=self._tuning.share_tolerance,
            price_tolerance=self._tuning.price_tolerance,
            collateral_tolerance=self._tuning.collateral_tolerance,
            auto_cancel_unknown_orders=self._effective_auto_cancel,
            require_chain_verification=self._tuning.require_chain_verification,
            expected_allowance_spender=self._tuning.expected_allowance_spender,
            collateral_asset=self._tuning.collateral_asset,
        )

        await self._apply_effects(report)
        await self._persist(report)
        _LOG.info(
            "reconciliation_complete",
            extra={
                "trigger": trigger.value,
                "classification": report.classification.value,
                "discrepancies": len(report.discrepancies),
                "fills_imported": len(report.fills_to_import),
                "unknown_remote_orders": len(report.unknown_remote_order_ids),
                "halts_new_trading": report.halts_new_trading,
            },
        )
        return report

    # -- trigger entry points (requirements 1-6) --
    async def on_startup(self) -> ReconciliationReport:
        return await self.reconcile(ReconciliationTrigger.STARTUP)

    async def on_user_stream_reconnect(self) -> ReconciliationReport:
        return await self.reconcile(ReconciliationTrigger.USER_STREAM_RECONNECT)

    async def on_unknown_submission(self, order_id: OrderId) -> ReconciliationReport:
        _LOG.warning(
            "reconcile_unknown_submission", extra={"order_id": order_id.value}
        )
        return await self.reconcile(ReconciliationTrigger.UNKNOWN_SUBMISSION)

    async def before_merge(self) -> ReconciliationReport:
        return await self.reconcile(ReconciliationTrigger.PRE_MERGE)

    async def after_merge(self) -> ReconciliationReport:
        return await self.reconcile(ReconciliationTrigger.POST_MERGE)

    async def periodic(self) -> ReconciliationReport:
        return await self.reconcile(ReconciliationTrigger.PERIODIC)

    async def on_shutdown(self) -> ReconciliationReport:
        return await self.reconcile(ReconciliationTrigger.SHUTDOWN)

    async def run_periodic(
        self,
        *,
        interval_seconds: float,
        stop_event: asyncio.Event,
    ) -> None:
        """Bounded, cancellation-safe periodic loop (requirement 5).

        A single pass failure is logged and never crashes the loop; cancellation
        propagates for graceful shutdown.
        """
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        while not stop_event.is_set():
            try:
                await self.periodic()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 - loop must survive one bad pass
                _LOG.exception("reconciliation_periodic_pass_failed")
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=interval_seconds)
            except asyncio.TimeoutError:
                continue

    # -- side effects --
    async def _apply_effects(self, report: ReconciliationReport) -> None:
        if report.fills_to_import and self._importer is not None:
            outcome = await self._importer.import_missing_fills(
                report.fills_to_import
            )
            _LOG.info(
                "reconciliation_fills_imported",
                extra={
                    "imported": outcome.imported,
                    "duplicates": outcome.duplicates,
                },
            )
        elif report.fills_to_import:
            _LOG.warning(
                "reconciliation_fills_pending_no_importer",
                extra={"count": len(report.fills_to_import)},
            )

        if (
            report.unknown_remote_order_ids
            and self._tuning.auto_cancel_unknown_orders
            and self._canceller is not None
        ):
            for raw_id in report.unknown_remote_order_ids:
                await self._safe_cancel(raw_id)

        if (
            report.halts_new_trading
            and self._tuning.halt_on_halting_class
            and self._halt is not None
        ):
            reason = _halt_reason(report)
            await self._halt.halt_new_trading(reason=reason)
            _LOG.error(
                "reconciliation_halted_new_trading",
                extra={"classification": report.classification.value},
            )

    async def _persist(self, report: ReconciliationReport) -> None:
        await self._sink.persist(report.to_domain_result())

    async def _safe_cancel(self, raw_id: str) -> None:
        if self._canceller is None:
            return
        try:
            await self._canceller.cancel_order(OrderId(raw_id))
            _LOG.info(
                "reconciliation_cancelled_unknown_order",
                extra={"order_id": raw_id},
            )
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            _LOG.exception(
                "reconciliation_cancel_failed", extra={"order_id": raw_id}
            )

    async def _safe_load_remote(
        self, markets: Sequence[MarketId]
    ) -> RemoteAccountState:
        try:
            return await self._remote.load(markets)
        except asyncio.CancelledError:
            raise
        except (
            ReconciliationDataUnavailableError,
            UnsupportedReconciliationOperationError,
        ) as exc:
            _LOG.error(
                "reconciliation_remote_unavailable", extra={"error": str(exc)}
            )
            return RemoteAccountState(available=False, note=str(exc))
        except Exception as exc:  # noqa: BLE001 - fail closed on any read error
            _LOG.exception("reconciliation_remote_load_failed")
            return RemoteAccountState(
                available=False, note=f"remote load failed: {type(exc).__name__}"
            )

    async def _safe_load_local(self, markets: Sequence[MarketId]) -> LocalState:
        return await self._local.load(markets)

    async def _safe_load_chain(self, tokens: Sequence[TokenId]) -> ChainState:
        try:
            return await self._chain.load(tokens)
        except asyncio.CancelledError:
            raise
        except UnsupportedReconciliationOperationError as exc:
            return ChainState(available=False, note=str(exc))
        except Exception as exc:  # noqa: BLE001
            _LOG.exception("reconciliation_chain_load_failed")
            return ChainState(
                available=False, note=f"chain load failed: {type(exc).__name__}"
            )


def _default_clock() -> int:
    import time

    return int(time.time())


def _tokens_in_scope(
    local: LocalState, remote: RemoteAccountState
) -> tuple[TokenId, ...]:
    seen: dict[str, TokenId] = {}
    for order in local.open_orders:
        seen.setdefault(order.token_id.value, order.token_id)
    for fill in local.fills:
        seen.setdefault(fill.token_id.value, fill.token_id)
    for snapshot in local.inventory.values():
        for position in (snapshot.up_position, snapshot.down_position):
            seen.setdefault(position.token_id.value, position.token_id)
    for order_view in remote.open_orders:
        seen.setdefault(order_view.token_id, TokenId(order_view.token_id))
    for fill_view in remote.fills:
        seen.setdefault(fill_view.token_id, TokenId(fill_view.token_id))
    return tuple(seen.values())


def _halt_reason(report: ReconciliationReport) -> str:
    kinds = sorted({d.kind.value for d in report.discrepancies})
    joined = ", ".join(kinds) if kinds else "unclassified"
    return (
        f"reconciliation classified {report.classification.value}: {joined}"
    )


__all__ = ["ReconciliationService", "ReconciliationTuning"]
