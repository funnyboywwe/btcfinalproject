"""Production startup gates.

Gates are evaluated before a production deployment is allowed to run (and in
particular before any live trading). They combine pure configuration checks
with infrastructure liveness checks. Infrastructure checks are injected as
``HealthCheck`` protocols so this module never imports concrete DB/Redis
clients (dependency inversion).

Gate results never contain secret values.
"""

from __future__ import annotations

from dataclasses import dataclass

from polymarket_pair_bot.config.settings import AppConfig
from polymarket_pair_bot.shared.health import HealthCheck


@dataclass(frozen=True)
class GateResult:
    """Outcome of a single startup gate."""

    name: str
    passed: bool
    detail: str


@dataclass(frozen=True)
class GateReport:
    """Aggregate of all startup gate results."""

    results: list[GateResult]

    @property
    def passed(self) -> bool:
        return all(result.passed for result in self.results)

    def failures(self) -> list[GateResult]:
        return [result for result in self.results if not result.passed]


def evaluate_config_gates(config: AppConfig) -> list[GateResult]:
    """Evaluate the synchronous, configuration-only production gates."""
    risk = config.risk
    positive_risk = (
        risk.max_unmatched_notional_usd > 0
        and risk.max_total_position_notional_usd > 0
        and risk.daily_loss_limit_usd > 0
        and risk.max_open_orders > 0
        and risk.max_unmatched_duration_seconds > 0
    )
    kill_switch_ok = risk.kill_switch_enabled and bool(risk.kill_switch_key.strip())
    dual_rpc = (
        config.polygon.polygon_rpc_primary is not None
        and config.polygon.polygon_rpc_secondary is not None
    )
    return [
        GateResult(
            name="dedicated_wallet_ack",
            passed=config.wallet.wallet_is_dedicated_ack,
            detail="WALLET_IS_DEDICATED_ACK must be true for a dedicated wallet",
        ),
        GateResult(
            name="positive_risk_limits",
            passed=positive_risk,
            detail="all risk limits must be strictly positive",
        ),
        GateResult(
            name="kill_switch_configured",
            passed=kill_switch_ok,
            detail="kill switch must be enabled with a non-empty key",
        ),
        GateResult(
            name="dual_rpc_endpoints",
            passed=dual_rpc,
            detail="primary and secondary Polygon RPC endpoints are required",
        ),
        GateResult(
            name="monitoring_enabled",
            passed=config.monitoring.monitoring_enabled,
            detail="monitoring must be enabled in production",
        ),
    ]


async def evaluate_infra_gates(
    *, postgres_check: HealthCheck, redis_check: HealthCheck
) -> list[GateResult]:
    """Evaluate infrastructure liveness gates via injected health checks."""
    postgres = await postgres_check.check()
    redis = await redis_check.check()
    return [
        GateResult(
            name="postgres_available",
            passed=postgres.healthy,
            detail=postgres.detail,
        ),
        GateResult(
            name="redis_available",
            passed=redis.healthy,
            detail=redis.detail,
        ),
    ]


async def run_production_gates(
    config: AppConfig,
    *,
    postgres_check: HealthCheck,
    redis_check: HealthCheck,
) -> GateReport:
    """Run all production startup gates and return an aggregate report."""
    results = list(evaluate_config_gates(config))
    results.extend(
        await evaluate_infra_gates(
            postgres_check=postgres_check, redis_check=redis_check
        )
    )
    return GateReport(results=results)
