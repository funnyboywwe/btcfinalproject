"""Shared configuration enums and supported constants.

Standard-library only so it is safe to import from validators, models, and
domain code without pulling in third-party dependencies.
"""

from __future__ import annotations

from enum import Enum, IntEnum
from typing import Final, Literal

LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
AlertSeverity = Literal["info", "warning", "error", "critical"]


class AppEnv(str, Enum):
    """Deployment environment."""

    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class RunMode(str, Enum):
    """Derived operating mode based on the trading safety switches.

    * ``RECORDER`` — neither paper nor live; market-data only, no wallet needed.
    * ``PAPER`` — simulated execution, no wallet needed.
    * ``LIVE`` — real execution; full authenticated configuration required.
    """

    RECORDER = "recorder"
    PAPER = "paper"
    LIVE = "live"


class RecorderOverflowPolicy(str, Enum):
    """Bounded-buffer overflow policy for the market-data recorder (Module 7).

    * ``DROP_NEWEST`` -- discard the incoming snapshot when the buffer is full.
    * ``DROP_OLDEST`` -- evict the oldest buffered snapshot to make room.
    * ``BLOCK`` -- apply backpressure to the recorder poll loop only (never to
      the WebSocket reader, which does not depend on the buffer).
    """

    DROP_NEWEST = "drop_newest"
    DROP_OLDEST = "drop_oldest"
    BLOCK = "block"


class SignatureType(IntEnum):
    """Polymarket order signature types.

    Values follow Polymarket's documented signature-type scheme:
    ``0`` EOA, ``1`` POLY_PROXY (email/magic proxy), ``2`` POLY_GNOSIS_SAFE.
    """

    EOA = 0
    POLY_PROXY = 1
    POLY_GNOSIS_SAFE = 2


# Only Polygon mainnet and the Amoy testnet are supported.
SUPPORTED_CHAIN_IDS: Final[dict[int, str]] = {
    137: "polygon-mainnet",
    80002: "polygon-amoy",
}
