"""Typed configuration and secret management (Module 1)."""

from __future__ import annotations

from polymarket_pair_bot.config.enums import (
    AppEnv,
    LogLevel,
    RunMode,
    SignatureType,
    SUPPORTED_CHAIN_IDS,
)
from polymarket_pair_bot.config.gates import (
    GateReport,
    GateResult,
    evaluate_config_gates,
    evaluate_infra_gates,
    run_production_gates,
)
from polymarket_pair_bot.config.settings import AppConfig, Settings, load_config

__all__ = [
    "AppConfig",
    "AppEnv",
    "GateReport",
    "GateResult",
    "LogLevel",
    "RunMode",
    "Settings",
    "SignatureType",
    "SUPPORTED_CHAIN_IDS",
    "evaluate_config_gates",
    "evaluate_infra_gates",
    "load_config",
    "run_production_gates",
]
