"""Pure, dependency-free validation helpers used by the settings models.

Keeping these functions free of pydantic (and of any secret material in error
messages) makes them independently unit-testable and safe to reuse. None of
these helpers ever include the validated value in an exception message when the
value could be sensitive (private keys, RPC URLs with embedded API keys).
"""

from __future__ import annotations

import re
from urllib.parse import urlsplit

from polymarket_pair_bot.config.enums import SUPPORTED_CHAIN_IDS

_EVM_ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
_PRIVATE_KEY_RE = re.compile(r"^0x[0-9a-fA-F]{64}$")


def ensure_supported_chain_id(chain_id: int) -> int:
    """Return ``chain_id`` if supported, else raise ``ValueError``."""
    if chain_id not in SUPPORTED_CHAIN_IDS:
        supported = ", ".join(str(c) for c in sorted(SUPPORTED_CHAIN_IDS))
        raise ValueError(
            f"Unsupported POLYGON_CHAIN_ID {chain_id!r}; supported: {supported}"
        )
    return chain_id


def ensure_valid_evm_address(value: str) -> str:
    """Validate a 20-byte hex EVM address (0x + 40 hex chars)."""
    candidate = value.strip()
    if not _EVM_ADDRESS_RE.fullmatch(candidate):
        raise ValueError(
            "Invalid EVM address; expected 0x followed by 40 hexadecimal characters"
        )
    return candidate


def normalize_private_key(raw: str) -> str:
    """Normalize a 32-byte hex private key to 0x-prefixed lowercase-safe form.

    The key material is never echoed in error messages.
    """
    candidate = raw.strip()
    if not candidate.startswith("0x"):
        candidate = "0x" + candidate
    if not _PRIVATE_KEY_RE.fullmatch(candidate):
        raise ValueError(
            "Malformed private key; expected 32-byte hex (0x followed by 64 hex chars)"
        )
    return candidate


def normalize_http_url(value: str) -> str:
    """Validate an http(s) URL and strip a trailing slash."""
    return _normalize_url(value, {"http", "https"}, "HTTP(S)")


def normalize_ws_url(value: str) -> str:
    """Validate a ws(s) URL and strip a trailing slash."""
    return _normalize_url(value, {"ws", "wss"}, "WebSocket")


def _normalize_url(value: str, allowed_schemes: set[str], label: str) -> str:
    candidate = value.strip()
    parts = urlsplit(candidate)
    if parts.scheme not in allowed_schemes or not parts.netloc:
        schemes = ", ".join(sorted(allowed_schemes))
        raise ValueError(f"Invalid {label} URL: scheme must be one of [{schemes}]")
    return candidate.rstrip("/")
