"""Optional gasless relayer adapter (Module 17, requirements 15/16).

Gasless relaying is a *separate optional adapter*. The default implementation
assumes NO gasless credentials exist and always fails closed. A real relayer
(e.g. a meta-transaction/relayer API) can be added later behind the
:class:`polymarket_pair_bot.ctf.ports.GaslessRelayer` protocol without touching
the self-funded gas path.
"""

from __future__ import annotations

from polymarket_pair_bot.ctf.errors import GaslessUnavailableError
from polymarket_pair_bot.ctf.models import UnsignedCtfTransaction


class NullGaslessRelayer:
    """A :class:`GaslessRelayer` that is always unavailable.

    ``available`` is ``False`` and :meth:`relay` raises
    :class:`GaslessUnavailableError`. No credentials are read or assumed.
    """

    @property
    def available(self) -> bool:
        return False

    async def relay(
        self, unsigned: UnsignedCtfTransaction, *, operation_id: str
    ) -> str:
        raise GaslessUnavailableError(
            "gasless relaying is not configured; no gasless credentials are "
            "assumed. Use self-funded gas or configure a gasless relayer adapter."
        )


__all__ = ["NullGaslessRelayer"]
