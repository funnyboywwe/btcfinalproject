"""Typed errors for Conditional Token Framework (CTF) operations (Module 17).

These errors deliberately never carry secrets (private keys, signed
transactions, API secrets). Messages describe *what* failed, not sensitive
material. The blocked-adapter errors reuse the blockchain module's
``UnsupportedChainOperationError`` semantics: an operation is intentionally not
performed here because its external behavior cannot be verified offline, and
guessing would violate the project's safety rules.
"""

from __future__ import annotations

from polymarket_pair_bot.blockchain.errors import (
    ChainError,
    UnsupportedChainOperationError,
)


class CtfError(ChainError):
    """Base class for all CTF-operation errors."""


class CtfConfigurationError(CtfError):
    """Missing/invalid CTF configuration (addresses, gates, mapping)."""


class CtfValidationError(CtfError):
    """An input (condition id, outcome mapping, quantity) failed validation."""


class CtfRiskRejectedError(CtfError):
    """No approving RiskDecision was supplied for a state-changing operation."""


class CtfDuplicateOperationError(CtfError):
    """An operation with the same idempotency key already exists.

    Raised to prevent duplicate splits/merges/redeems after a timeout or a
    restart (requirement 12).
    """


class CtfSimulationError(CtfError):
    """Pre-sign simulation reverted or could not be verified (requirement 6)."""


class CtfKillSwitchError(CtfError):
    """A state-changing CTF operation was blocked by the global kill switch."""


class CtfWritesDisabledError(CtfError):
    """State-changing CTF writes are not manually enabled (requirement 18)."""


class GaslessUnavailableError(CtfError):
    """Gasless relaying was requested but no relayer/credentials are available.

    Requirements 15/16: gasless support is a separate optional adapter and no
    gasless credentials are ever assumed to exist.
    """


__all__ = [
    "ChainError",
    "CtfConfigurationError",
    "CtfDuplicateOperationError",
    "CtfError",
    "CtfKillSwitchError",
    "CtfRiskRejectedError",
    "CtfSimulationError",
    "CtfValidationError",
    "CtfWritesDisabledError",
    "GaslessUnavailableError",
    "UnsupportedChainOperationError",
]
