"""Typed ports (protocols) for CTF operations -- dependency inversion (Module 17).

The service depends only on these structural protocols, never on concrete
blockchain/HTTP clients. The read-side protocol :class:`ChainStateReader` is a
subset of :class:`polymarket_pair_bot.blockchain.service.WalletStateService`,
which satisfies it structurally. The write-side protocols are implemented by
blocked adapters in this package (behavior unverifiable offline) and by fakes in
tests -- no real order/transaction is ever produced in tests or dev.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from polymarket_pair_bot.blockchain.models import (
    ChainIdentity,
    GasEstimate,
    SimulationResult,
    TokenAmount,
    TransactionOutcome,
)
from polymarket_pair_bot.ctf.models import UnsignedCtfTransaction


@runtime_checkable
class ChainStateReader(Protocol):
    """Read-only chain access needed for CTF validation/simulation/receipts."""

    async def verify_chain_id(self) -> ChainIdentity: ...

    async def get_collateral_balance(self) -> TokenAmount: ...

    async def get_token_balance(self, token_id: str) -> TokenAmount: ...

    async def get_allowance(
        self, *, spender: str, token_address: str | None = None
    ) -> TokenAmount: ...

    async def get_nonce(self, *, pending: bool = False) -> int: ...

    async def simulate(
        self, *, to: str, data: str, block: str = "latest"
    ) -> SimulationResult: ...

    async def estimate_gas(
        self, *, to: str, data: str, value: int = 0, sender: str | None = None
    ) -> GasEstimate: ...

    async def wait_for_receipt(
        self,
        tx_hash: str,
        *,
        expected_nonce: int | None = None,
        timeout_seconds: float | None = None,
        poll_interval_seconds: float | None = None,
    ) -> TransactionOutcome: ...

    async def get_transaction_status(
        self, tx_hash: str, *, expected_nonce: int | None = None
    ) -> TransactionOutcome: ...


@runtime_checkable
class CtfTransactionPreparer(Protocol):
    """Builds unsigned CTF calldata (split/merge/redeem) and approvals.

    Implementations must never guess ABI selectors: full calldata assembly
    requires a verified keccak/ABI library. Where that cannot be verified, the
    implementation raises a blocked-operation error rather than guessing.
    """

    async def prepare_split(
        self, *, condition_id: str, partition: tuple[int, ...], amount_base_units: int
    ) -> UnsignedCtfTransaction: ...

    async def prepare_merge(
        self, *, condition_id: str, partition: tuple[int, ...], amount_base_units: int
    ) -> UnsignedCtfTransaction: ...

    async def prepare_redeem(
        self, *, condition_id: str, index_sets: tuple[int, ...]
    ) -> UnsignedCtfTransaction: ...

    async def prepare_erc20_approval(
        self, *, token_address: str, spender: str, amount_base_units: int
    ) -> UnsignedCtfTransaction: ...


@runtime_checkable
class CtfChainWriter(Protocol):
    """Signs and broadcasts an unsigned transaction, returning its hash.

    Implementations MUST NOT return or log the private key or the complete
    signed transaction. Self-funded gas parameters are passed explicitly.
    """

    async def sign_and_broadcast(
        self,
        unsigned: UnsignedCtfTransaction,
        *,
        nonce: int,
        gas_limit: int,
        max_fee_per_gas_wei: int,
        max_priority_fee_per_gas_wei: int,
    ) -> str: ...


@runtime_checkable
class GaslessRelayer(Protocol):
    """Optional gasless relayer (separate adapter; no credentials assumed)."""

    @property
    def available(self) -> bool: ...

    async def relay(
        self, unsigned: UnsignedCtfTransaction, *, operation_id: str
    ) -> str: ...


__all__ = [
    "ChainStateReader",
    "CtfChainWriter",
    "CtfTransactionPreparer",
    "GaslessRelayer",
]
