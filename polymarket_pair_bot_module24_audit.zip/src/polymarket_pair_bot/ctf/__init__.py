"""Conditional Token Framework (CTF) split/merge/redeem operations (Module 17).

The public surface is the :class:`CtfOperationService` orchestrator plus its
typed ports, models, errors and the composition-root factory. Concrete signing,
broadcasting and calldata assembly are isolated behind blocked adapters because
their behavior cannot be verified in this offline environment; guessing is
forbidden by the project's safety rules.
"""

from __future__ import annotations

from polymarket_pair_bot.ctf.errors import (
    CtfConfigurationError,
    CtfDuplicateOperationError,
    CtfError,
    CtfKillSwitchError,
    CtfRiskRejectedError,
    CtfSimulationError,
    CtfValidationError,
    CtfWritesDisabledError,
    GaslessUnavailableError,
)
from polymarket_pair_bot.ctf.factory import (
    build_ctf_operation_service,
    resolve_ctf_contracts,
    resolve_outcome_mapping,
)
from polymarket_pair_bot.ctf.models import (
    CtfContracts,
    CtfExecutionResult,
    CtfOperationRequest,
    MergeableQuantity,
    OutcomeMapping,
    PreparedCtfOperation,
    UnsignedCtfTransaction,
    WalletBalances,
)
from polymarket_pair_bot.ctf.ports import (
    ChainStateReader,
    CtfChainWriter,
    CtfTransactionPreparer,
    GaslessRelayer,
)
from polymarket_pair_bot.ctf.service import CtfOperationService

__all__ = [
    "ChainStateReader",
    "CtfChainWriter",
    "CtfConfigurationError",
    "CtfContracts",
    "CtfDuplicateOperationError",
    "CtfError",
    "CtfExecutionResult",
    "CtfKillSwitchError",
    "CtfOperationRequest",
    "CtfOperationService",
    "CtfRiskRejectedError",
    "CtfSimulationError",
    "CtfTransactionPreparer",
    "CtfValidationError",
    "CtfWritesDisabledError",
    "GaslessRelayer",
    "GaslessUnavailableError",
    "MergeableQuantity",
    "OutcomeMapping",
    "PreparedCtfOperation",
    "UnsignedCtfTransaction",
    "WalletBalances",
    "build_ctf_operation_service",
    "resolve_ctf_contracts",
    "resolve_outcome_mapping",
]
