"""Pure validation helpers for CTF operations (Module 17).

These functions have no I/O and are fully unit-tested. They enforce the
safety-critical invariants: valid condition id, valid binary outcome mapping,
the merge-quantity cap ``min(confirmed_up, confirmed_down)``, and the
requirement that a state-changing operation carries an approving RiskDecision
bound to the operation's idempotency key.
"""

from __future__ import annotations

from polymarket_pair_bot.ctf.encoding import validate_binary_index_sets
from polymarket_pair_bot.ctf.errors import (
    CtfRiskRejectedError,
    CtfValidationError,
)
from polymarket_pair_bot.ctf.models import OutcomeMapping
from polymarket_pair_bot.domain.entities import RiskDecision
from polymarket_pair_bot.domain.value_objects import ConditionId, Shares


def validate_condition_id(value: str | ConditionId) -> ConditionId:
    """Coerce and validate a bytes32 condition id (requirement 4)."""
    if isinstance(value, ConditionId):
        return value
    try:
        return ConditionId(value)
    except (ValueError, TypeError) as exc:
        raise CtfValidationError(f"invalid condition id: {exc}") from exc


def validate_outcome_mapping(mapping: OutcomeMapping) -> tuple[int, ...]:
    """Validate the binary Up/Down index-set mapping (requirement 5).

    Returns the sorted partition ``(1, 2)`` on success.
    """
    partition = validate_binary_index_sets(
        mapping.up_index_set, mapping.down_index_set
    )
    body = mapping.parent_collection.strip().lower()
    candidate = body[2:] if body.startswith("0x") else body
    if len(candidate) != 64 or any(c not in "0123456789abcdef" for c in candidate):
        raise CtfValidationError(
            "parent collection id must be 0x + 64 hex characters (bytes32)"
        )
    return partition


def cap_merge_quantity(
    requested: Shares, *, confirmed_up: Shares, confirmed_down: Shares
) -> Shares:
    """Return the mergeable quantity, never exceeding either confirmed balance.

    Enforces requirement 11: never merge more than
    ``min(confirmed_up_balance, confirmed_down_balance)``. Also never exceeds the
    requested amount. Conservative: uses the domain :class:`Shares` value object.
    """
    cap = min(confirmed_up.value, confirmed_down.value)
    effective = min(requested.value, cap)
    if effective < 0:
        effective = requested.value * 0
    return Shares(effective)


def require_risk_approval(decision: RiskDecision, *, operation_id: str) -> None:
    """Ensure an approving RiskDecision is bound to this operation (req 7/8).

    The decision must be an approval and its ``decision_id`` must equal the
    operation's idempotency key, so an approval cannot be replayed against a
    different operation.
    """
    if not operation_id or not operation_id.strip():
        raise CtfValidationError("operation_id (idempotency key) is required")
    if not isinstance(decision, RiskDecision):
        raise CtfRiskRejectedError("a RiskDecision is required")
    if not decision.approved:
        raise CtfRiskRejectedError(
            f"risk decision {decision.decision_id!r} did not approve the operation"
        )
    if decision.decision_id != operation_id:
        raise CtfRiskRejectedError(
            "risk decision is not bound to this operation's idempotency key"
        )


__all__ = [
    "cap_merge_quantity",
    "require_risk_approval",
    "validate_condition_id",
    "validate_outcome_mapping",
]
