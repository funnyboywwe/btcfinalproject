"""CtfOperationService -- orchestrates split/merge/redeem safely (Module 17).

This service contains the real, fully tested logic. It depends only on typed
ports (dependency inversion) and the domain/persistence protocols, never on
concrete blockchain/HTTP clients. The concrete signing/broadcast/calldata
adapters are blocked offline; tests drive the full path with fakes.

Safety ordering for a state-changing operation (execute):
  1. writes manually enabled (req 18) and kill switch not active (fail closed);
  2. validate condition id (4), outcome mapping (5), idempotency key (8);
  3. require an approving RiskDecision bound to the key (7);
  4. verify chain id (3);
  5. reject duplicates by idempotency key (12);
  6. reconcile balances before (13); cap merge at min(up, down) (11);
  7. build unsigned calldata; simulate before signing (6); estimate gas (14);
  8. persist a PENDING operation BEFORE broadcasting (9);
  9. broadcast (self-funded gas, or optional gasless adapter);
 10. persist the tx hash immediately (10);
 11. monitor the receipt; unknown/timeout -> reconcile, never blind-retry;
 12. reconcile balances after (13) and persist the terminal status.

The read-only :meth:`mergeable_quantity` needs no writes and never consults the
kill switch or the write gate (req 17).
"""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable
from decimal import ROUND_FLOOR, Decimal

from polymarket_pair_bot.blockchain.errors import (
    ChainError,
    ReceiptTimeoutError,
)
from polymarket_pair_bot.blockchain.models import TokenAmount, TransactionStatus
from polymarket_pair_bot.ctf.errors import (
    CtfConfigurationError,
    CtfDuplicateOperationError,
    CtfKillSwitchError,
    CtfSimulationError,
    CtfValidationError,
    CtfWritesDisabledError,
)
from polymarket_pair_bot.ctf.models import (
    CtfContracts,
    CtfExecutionResult,
    CtfOperationRequest,
    MergeableQuantity,
    OutcomeMapping,
    UnsignedCtfTransaction,
    WalletBalances,
)
from polymarket_pair_bot.ctf.ports import (
    ChainStateReader,
    CtfChainWriter,
    CtfTransactionPreparer,
    GaslessRelayer,
)
from polymarket_pair_bot.ctf.validation import (
    cap_merge_quantity,
    require_risk_approval,
    validate_condition_id,
    validate_outcome_mapping,
)
from polymarket_pair_bot.domain.entities import CtfOperation, RiskDecision
from polymarket_pair_bot.domain.enums import CtfOperationStatus, CtfOperationType
from polymarket_pair_bot.domain.repositories import UnitOfWorkFactory
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ConditionId,
    Shares,
    UnixTimestamp,
)
from polymarket_pair_bot.observability.logging import get_logger

_logger = get_logger(__name__)

Monotonic = Callable[[], float]


class KillSwitchProbe:
    """Minimal structural type: something with ``async is_active() -> bool``."""

    async def is_active(self) -> bool:  # pragma: no cover - protocol shape
        raise NotImplementedError


class CtfOperationService:
    """Safe orchestration of CTF split/merge/redeem operations."""

    def __init__(
        self,
        *,
        reader: ChainStateReader,
        preparer: CtfTransactionPreparer,
        writer: CtfChainWriter,
        contracts: CtfContracts,
        mapping: OutcomeMapping,
        gasless: GaslessRelayer,
        uow_factory: UnitOfWorkFactory | None = None,
        kill_switch: KillSwitchProbe | None = None,
        enable_writes: bool = False,
        use_gasless: bool = False,
        receipt_timeout_seconds: float | None = None,
        receipt_poll_interval_seconds: float | None = None,
        clock: Callable[[], int] = lambda: int(time.time()),
    ) -> None:
        self._reader = reader
        self._preparer = preparer
        self._writer = writer
        self._contracts = contracts
        self._mapping = mapping
        self._gasless = gasless
        self._uow_factory = uow_factory
        self._kill_switch = kill_switch
        self._enable_writes = enable_writes
        self._use_gasless = use_gasless
        self._receipt_timeout = receipt_timeout_seconds
        self._receipt_poll = receipt_poll_interval_seconds
        self._clock = clock

    # ---- read-only -----------------------------------------------------

    async def mergeable_quantity(
        self, *, condition_id: str | ConditionId, up_token_id: str, down_token_id: str
    ) -> MergeableQuantity:
        """Return min(confirmed_up, confirmed_down) as mergeable pairs (req 11/17).

        Read-only: verifies the chain id then reads *confirmed* on-chain
        balances. Never treats open/partial orders as pairs; never writes.
        """
        cid = validate_condition_id(condition_id)
        await self._reader.verify_chain_id()
        up = await self._reader.get_token_balance(up_token_id)
        down = await self._reader.get_token_balance(down_token_id)
        up_shares = Shares(up.amount)
        down_shares = Shares(down.amount)
        mergeable = Shares(min(up.amount, down.amount))
        _logger.info(
            "ctf.mergeable",
            extra={
                "condition_id": cid.value,
                "up": str(up.amount),
                "down": str(down.amount),
                "mergeable": str(mergeable.value),
            },
        )
        return MergeableQuantity(
            condition_id=cid,
            up_confirmed=up_shares,
            down_confirmed=down_shares,
            mergeable=mergeable,
        )

    # ---- state-changing ------------------------------------------------

    async def execute(
        self, request: CtfOperationRequest, risk_decision: RiskDecision
    ) -> CtfExecutionResult:
        """Validate, simulate, persist, broadcast and monitor a CTF operation."""
        notes: list[str] = []

        # (1) manual write gate + kill switch (fail closed).
        if not self._enable_writes:
            raise CtfWritesDisabledError(
                "CTF writes are disabled; enable ctf_enable_writes to proceed"
            )
        if self._uow_factory is None:
            raise CtfConfigurationError(
                "a unit-of-work factory is required for state-changing operations"
            )
        if self._kill_switch is not None and await self._kill_switch.is_active():
            raise CtfKillSwitchError(
                "global kill switch is active; CTF writes are blocked"
            )

        # (2/3) validate inputs + require an approving, bound RiskDecision.
        cid = validate_condition_id(request.condition_id)
        partition = validate_outcome_mapping(self._mapping)
        require_risk_approval(risk_decision, operation_id=request.operation_id)

        # (4) verify chain id.
        await self._reader.verify_chain_id()

        # (5) duplicate guard by idempotency key (before any broadcast).
        await self._reject_if_duplicate(request.operation_id)

        # (6) reconcile balances BEFORE.
        before = await self._read_balances(request.up_token_id, request.down_token_id)

        # (7) determine effective quantity (merge cap = min(up, down)).
        effective = self._effective_quantity(request, before, notes)
        if request.operation_type is CtfOperationType.MERGE and effective.value <= 0:
            raise CtfValidationError(
                "no complete Up/Down pairs are confirmed; nothing to merge"
            )

        # (8) build unsigned calldata for the operation.
        unsigned = await self._build_unsigned(request, cid, partition, effective)

        # (9) simulate BEFORE signing.
        await self._simulate(unsigned)

        # (10) estimate gas (self-funded default).
        gas = await self._reader.estimate_gas(to=unsigned.to, data=unsigned.data)

        # (11) persist PENDING operation BEFORE broadcasting.
        op = self._build_operation(request, cid, effective, CtfOperationStatus.PENDING)
        newly = await self._persist_pending(op, request.operation_id)
        if not newly:
            raise CtfDuplicateOperationError(
                f"operation {request.operation_id!r} already recorded; not rebroadcasting"
            )

        # (12) broadcast (optional gasless, else self-funded).
        tx_hash = await self._broadcast(unsigned, gas, request.operation_id)

        # (13) persist the tx hash IMMEDIATELY.
        await self._persist_tx_hash(request, tx_hash)

        # (14) monitor the receipt.
        outcome, status, monitor_notes = await self._monitor(tx_hash, gas)
        notes.extend(monitor_notes)

        # (15) reconcile balances AFTER + persist terminal status.
        after = await self._read_balances(request.up_token_id, request.down_token_id)
        await self._persist_terminal(request, cid, effective, status, tx_hash)

        return CtfExecutionResult(
            operation_id=request.operation_id,
            operation_type=request.operation_type,
            status=status.value,
            effective_quantity=effective,
            tx_hash=tx_hash,
            outcome=outcome,
            before=before,
            after=after,
            detail=outcome.detail or "" if outcome else "",
            notes=tuple(notes),
        )

    # ---- helpers -------------------------------------------------------

    def _effective_quantity(
        self,
        request: CtfOperationRequest,
        before: WalletBalances,
        notes: list[str],
    ) -> Shares:
        if request.operation_type is CtfOperationType.MERGE:
            capped = cap_merge_quantity(
                request.quantity,
                confirmed_up=before.up,
                confirmed_down=before.down,
            )
            if capped.value < request.quantity.value:
                notes.append(
                    "merge quantity capped to min(confirmed_up, confirmed_down)"
                )
            return capped
        return request.quantity

    async def _build_unsigned(
        self,
        request: CtfOperationRequest,
        cid: ConditionId,
        partition: tuple[int, ...],
        effective: Shares,
    ) -> UnsignedCtfTransaction:
        amount_base_units = self._to_base_units(effective)
        if request.operation_type is CtfOperationType.SPLIT:
            return await self._preparer.prepare_split(
                condition_id=cid.value,
                partition=partition,
                amount_base_units=amount_base_units,
            )
        if request.operation_type is CtfOperationType.MERGE:
            return await self._preparer.prepare_merge(
                condition_id=cid.value,
                partition=partition,
                amount_base_units=amount_base_units,
            )
        if request.operation_type is CtfOperationType.REDEEM:
            return await self._preparer.prepare_redeem(
                condition_id=cid.value,
                index_sets=partition,
            )
        raise CtfValidationError(
            f"unsupported operation type: {request.operation_type!r}"
        )

    def _to_base_units(self, shares: Shares) -> int:
        # Convert a Decimal share amount to integer on-chain base units.
        # Round DOWN (floor) so a conversion can NEVER request more base units
        # than are actually held: rounding up here could try to merge/split more
        # than the confirmed balance and revert on-chain (wasted gas / stuck
        # state). Shares are already quantized to 1e-6 and USDC has 6 decimals,
        # so this is normally exact; the explicit floor only guards misconfigured
        # collateral decimals or sub-quantum dust.
        decimals = self._contracts.collateral_decimals
        scaled = shares.value * (Decimal(10) ** decimals)
        return int(scaled.to_integral_value(rounding=ROUND_FLOOR))

    async def _simulate(self, unsigned: UnsignedCtfTransaction) -> None:
        result = await self._reader.simulate(to=unsigned.to, data=unsigned.data)
        if not result.success:
            raise CtfSimulationError(
                "pre-sign simulation failed: "
                + (result.revert_reason or "reverted without reason")
            )

    async def _read_balances(
        self, up_token_id: str, down_token_id: str
    ) -> WalletBalances:
        up = await self._reader.get_token_balance(up_token_id)
        down = await self._reader.get_token_balance(down_token_id)
        collateral = await self._reader.get_collateral_balance()
        return WalletBalances(
            up=Shares(up.amount),
            down=Shares(down.amount),
            collateral=CollateralAmount(collateral.amount),
        )

    async def _reject_if_duplicate(self, operation_id: str) -> None:
        assert self._uow_factory is not None
        async with self._uow_factory() as uow:
            existing = await uow.blockchain.get(operation_id)
        if existing is not None:
            raise CtfDuplicateOperationError(
                f"operation {operation_id!r} already exists; refusing to duplicate"
            )

    def _build_operation(
        self,
        request: CtfOperationRequest,
        cid: ConditionId,
        effective: Shares,
        status: CtfOperationStatus,
    ) -> CtfOperation:
        collateral = CollateralAmount(effective.value)
        return CtfOperation(
            operation_id=request.operation_id,
            operation_type=request.operation_type,
            condition_id=cid,
            quantity=effective,
            collateral=collateral,
            status=status,
            created_at=UnixTimestamp(self._clock()),
        )

    async def _persist_pending(
        self, op: CtfOperation, operation_id: str
    ) -> bool:
        assert self._uow_factory is not None
        async with self._uow_factory() as uow:
            await uow.ctf_operations.upsert(op)
            newly = await uow.blockchain.record(
                operation_key=operation_id,
                chain_id=await self._chain_id(),
                status=CtfOperationStatus.PENDING.value,
                created_at=op.created_at,
                operation_id=operation_id,
                tx_hash=None,
            )
            await uow.audit.append_event(
                event_type="ctf.pending",
                severity="info",
                created_at=op.created_at,
                payload={
                    "operation_id": operation_id,
                    "operation_type": op.operation_type.value,
                    "quantity": str(op.quantity.value),
                },
            )
            await uow.commit()
        return newly

    async def _broadcast(
        self, unsigned: UnsignedCtfTransaction, gas: object, operation_id: str
    ) -> str:
        if self._use_gasless:
            if not self._gasless.available:
                # Fail closed rather than silently self-funding.
                raise CtfConfigurationError(
                    "gasless requested but no gasless relayer is available"
                )
            return await self._gasless.relay(unsigned, operation_id=operation_id)
        nonce = await self._reader.get_nonce(pending=True)
        gas_limit = getattr(gas, "buffered_gas_limit", 0) or 0
        gas_price = getattr(gas, "gas_price_wei", None) or 0
        return await self._writer.sign_and_broadcast(
            unsigned,
            nonce=nonce,
            gas_limit=int(gas_limit),
            max_fee_per_gas_wei=int(gas_price),
            max_priority_fee_per_gas_wei=int(gas_price),
        )

    async def _persist_tx_hash(
        self, request: CtfOperationRequest, tx_hash: str
    ) -> None:
        assert self._uow_factory is not None
        now = UnixTimestamp(self._clock())
        async with self._uow_factory() as uow:
            # Insert-only, hash-keyed row records the broadcast immediately and
            # is idempotent under re-entry (same hash -> no duplicate row).
            await uow.blockchain.record(
                operation_key=tx_hash,
                chain_id=await self._chain_id(),
                status=CtfOperationStatus.SUBMITTED.value,
                created_at=now,
                operation_id=request.operation_id,
                tx_hash=tx_hash,
            )
            await uow.audit.append_event(
                event_type="ctf.submitted",
                severity="info",
                created_at=now,
                payload={"operation_id": request.operation_id, "tx_hash": tx_hash},
            )
            await uow.commit()

    async def _monitor(
        self, tx_hash: str, gas: object
    ) -> tuple[object | None, CtfOperationStatus, list[str]]:
        notes: list[str] = []
        nonce_hint = None
        try:
            outcome = await self._reader.wait_for_receipt(
                tx_hash,
                expected_nonce=nonce_hint,
                timeout_seconds=self._receipt_timeout,
                poll_interval_seconds=self._receipt_poll,
            )
        except ReceiptTimeoutError:
            notes.append(
                "receipt timed out; status UNKNOWN -- reconcile before any retry"
            )
            return None, CtfOperationStatus.UNKNOWN, notes
        except ChainError as exc:
            notes.append(f"receipt monitoring failed: {exc}; reconcile required")
            return None, CtfOperationStatus.UNKNOWN, notes
        status = self._classify(outcome.status)
        if status is CtfOperationStatus.UNKNOWN:
            notes.append("non-terminal/ambiguous receipt; reconcile required")
        return outcome, status, notes

    @staticmethod
    def _classify(status: TransactionStatus) -> CtfOperationStatus:
        if status is TransactionStatus.SUCCESS:
            return CtfOperationStatus.CONFIRMED
        if status is TransactionStatus.REVERTED:
            return CtfOperationStatus.FAILED
        return CtfOperationStatus.UNKNOWN

    async def _persist_terminal(
        self,
        request: CtfOperationRequest,
        cid: ConditionId,
        effective: Shares,
        status: CtfOperationStatus,
        tx_hash: str,
    ) -> None:
        assert self._uow_factory is not None
        op = self._build_operation(request, cid, effective, status)
        async with self._uow_factory() as uow:
            await uow.ctf_operations.upsert(op)
            await uow.audit.append_event(
                event_type="ctf.terminal",
                severity="info" if status is CtfOperationStatus.CONFIRMED else "warning",
                created_at=op.created_at,
                payload={
                    "operation_id": request.operation_id,
                    "tx_hash": tx_hash,
                    "status": status.value,
                },
            )
            await uow.commit()

    async def _chain_id(self) -> int:
        identity = await self._reader.verify_chain_id()
        return identity.chain_id


__all__ = ["CtfOperationService", "KillSwitchProbe"]
