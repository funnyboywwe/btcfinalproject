"""Composition root for CTF operations (Module 17).

Builds a :class:`CtfOperationService` from :class:`AppConfig`. Contract
addresses come exclusively from trusted configuration (``ChainReadSettings``);
nothing is hard-coded (requirements 1/2). The read side reuses the Module 16
:class:`WalletStateService` (which structurally satisfies
:class:`ChainStateReader`). The write side uses the blocked preparer/writer and
the null gasless relayer -- fail-closed adapters that never guess unverifiable
behavior. A unit-of-work factory and kill switch may be injected for the
state-changing path; the read-only mergeable path needs neither.
"""

from __future__ import annotations

import time

from polymarket_pair_bot.blockchain.factory import build_wallet_state_service
from polymarket_pair_bot.config import AppConfig
from polymarket_pair_bot.ctf.chain_writer import BlockedCtfChainWriter
from polymarket_pair_bot.ctf.errors import CtfConfigurationError
from polymarket_pair_bot.ctf.models import CtfContracts, OutcomeMapping
from polymarket_pair_bot.ctf.ports import ChainStateReader
from polymarket_pair_bot.ctf.preparer import BlockedCtfTransactionPreparer
from polymarket_pair_bot.ctf.relayer import NullGaslessRelayer
from polymarket_pair_bot.ctf.service import CtfOperationService, KillSwitchProbe
from polymarket_pair_bot.domain.repositories import UnitOfWorkFactory


def resolve_ctf_contracts(config: AppConfig) -> CtfContracts:
    """Resolve trusted CTF contract addresses from configuration."""
    chain = config.chain
    conditional = chain.polygon_conditional_tokens_address
    collateral = chain.polygon_usdc_address
    if not conditional:
        raise CtfConfigurationError(
            "polygon_conditional_tokens_address is not configured"
        )
    if not collateral:
        raise CtfConfigurationError("polygon_usdc_address is not configured")
    return CtfContracts(
        conditional_tokens=conditional.strip().lower(),
        collateral=collateral.strip().lower(),
        collateral_decimals=chain.polygon_usdc_decimals,
    )


def resolve_outcome_mapping(config: AppConfig) -> OutcomeMapping:
    """Resolve and return the binary Up/Down index-set mapping."""
    ctf = config.ctf
    return OutcomeMapping(
        up_index_set=ctf.ctf_up_index_set,
        down_index_set=ctf.ctf_down_index_set,
        parent_collection=ctf.ctf_parent_collection_id,
    )


def build_ctf_operation_service(
    config: AppConfig,
    *,
    reader: ChainStateReader | None = None,
    uow_factory: UnitOfWorkFactory | None = None,
    kill_switch: KillSwitchProbe | None = None,
    clock: object = None,
) -> CtfOperationService:
    """Build a :class:`CtfOperationService` from configuration.

    ``reader`` defaults to a live :class:`WalletStateService`. ``uow_factory``
    and ``kill_switch`` are only required for state-changing operations; the
    read-only mergeable-quantity command works without them.
    """
    contracts = resolve_ctf_contracts(config)
    mapping = resolve_outcome_mapping(config)
    chain_reader: ChainStateReader = (
        reader if reader is not None else build_wallet_state_service(config)
    )
    ctf = config.ctf
    return CtfOperationService(
        reader=chain_reader,
        preparer=BlockedCtfTransactionPreparer(contracts),
        writer=BlockedCtfChainWriter(),
        contracts=contracts,
        mapping=mapping,
        gasless=NullGaslessRelayer(),
        uow_factory=uow_factory,
        kill_switch=kill_switch,
        enable_writes=ctf.ctf_enable_writes,
        use_gasless=ctf.ctf_gasless_enabled,
        receipt_timeout_seconds=ctf.ctf_receipt_timeout_seconds,
        receipt_poll_interval_seconds=ctf.ctf_receipt_poll_interval_seconds,
        clock=(clock if callable(clock) else (lambda: int(time.time()))),
    )


__all__ = [
    "build_ctf_operation_service",
    "resolve_ctf_contracts",
    "resolve_outcome_mapping",
]
