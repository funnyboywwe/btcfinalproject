"""Blocked CTF chain writer (Module 17).

Signing requires eth-account and broadcasting requires a verified web3 client;
neither is importable in this offline environment and their behavior cannot be
verified here. Rather than guess how to sign/serialize/broadcast a transaction
(which could produce an invalid or unsafe signed payload), this adapter is
BLOCKED: :meth:`sign_and_broadcast` raises
:class:`UnsupportedChainOperationError` with a clear explanation.

Safety: this class never reads, stores, returns, or logs a private key or a
complete signed transaction. When a verified signing/broadcast stack is
installed, this is the single place to implement real signing -- and it must
continue to keep secrets out of logs, exceptions and return values.
"""

from __future__ import annotations

from polymarket_pair_bot.ctf.errors import UnsupportedChainOperationError
from polymarket_pair_bot.ctf.models import UnsignedCtfTransaction
from polymarket_pair_bot.observability.logging import get_logger

_logger = get_logger(__name__)

_BLOCKED_DETAIL = (
    "signing requires eth-account and broadcasting requires a verified web3 "
    "client; neither is available offline and their behavior must not be "
    "guessed. No private key is ever read or logged. Install and verify a "
    "signing/broadcast stack, then implement signing here."
)


def _signing_stack_available() -> bool:
    try:  # pragma: no cover - depends on optional deps not present offline
        import eth_account  # type: ignore  # noqa: F401
        import web3  # type: ignore  # noqa: F401
    except Exception:
        return False
    return True


class BlockedCtfChainWriter:
    """A :class:`CtfChainWriter` that fails closed (never signs/broadcasts)."""

    async def sign_and_broadcast(
        self,
        unsigned: UnsignedCtfTransaction,
        *,
        nonce: int,
        gas_limit: int,
        max_fee_per_gas_wei: int,
        max_priority_fee_per_gas_wei: int,
    ) -> str:
        # Log only non-sensitive routing metadata -- never the key or signature.
        _logger.warning(
            "ctf.chain_writer.blocked",
            extra={
                "to": unsigned.to,
                "nonce": nonce,
                "signing_stack": _signing_stack_available(),
            },
        )
        raise UnsupportedChainOperationError(
            "ctf.sign_and_broadcast", detail=_BLOCKED_DETAIL
        )


__all__ = ["BlockedCtfChainWriter"]
