"""Read-only CTF mergeable-quantity CLI (Module 17, requirements 17/18).

Usage::

    uv run polymarket-pair-bot ctf-mergeable \\
        --condition-id 0x... --up-token TOKEN_ID --down-token TOKEN_ID [--json]

This command is READ-ONLY: it verifies the chain id and reads *confirmed*
on-chain Up/Down balances, then reports ``min(up, down)`` -- the number of
complete pairs that could be merged. It never signs, never broadcasts, never
requests or prints the private key, and never treats an open/partial order as a
pair. State-changing split/merge/redeem operations are intentionally NOT exposed
as a CLI here; they remain manually gated behind configuration and the risk
engine (requirement 18).

Exit code is ``0`` on a clean read and ``1`` on any chain/config error.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Sequence

from polymarket_pair_bot.config import AppConfig, load_config
from polymarket_pair_bot.ctf.errors import ChainError
from polymarket_pair_bot.ctf.factory import build_ctf_operation_service
from polymarket_pair_bot.ctf.models import MergeableQuantity


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--condition-id",
        dest="condition_id",
        required=True,
        help="CTF condition id (0x + 64 hex).",
    )
    parser.add_argument(
        "--up-token",
        dest="up_token",
        required=True,
        help="Up outcome-token id (base-10 uint string).",
    )
    parser.add_argument(
        "--down-token",
        dest="down_token",
        required=True,
        help="Down outcome-token id (base-10 uint string).",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="Emit the result as JSON.",
    )


def _print(result: MergeableQuantity, *, as_json: bool) -> None:
    if as_json:
        print(
            json.dumps(
                {
                    "condition_id": result.condition_id.value,
                    "up_confirmed": str(result.up_confirmed.value),
                    "down_confirmed": str(result.down_confirmed.value),
                    "mergeable": str(result.mergeable.value),
                },
                indent=2,
            )
        )
        return
    print(f"condition   : {result.condition_id.value}")
    print(f"up (confirmed)  : {result.up_confirmed.value}")
    print(f"down (confirmed): {result.down_confirmed.value}")
    print(f"mergeable pairs : {result.mergeable.value}")


async def _run(config: AppConfig, args: argparse.Namespace) -> int:
    service = build_ctf_operation_service(config)
    try:
        result = await service.mergeable_quantity(
            condition_id=str(args.condition_id),
            up_token_id=str(args.up_token),
            down_token_id=str(args.down_token),
        )
    except ChainError as exc:
        print(
            f"ctf-mergeable failed: {type(exc).__name__}: {exc}", file=sys.stderr
        )
        return 1
    finally:
        aclose = getattr(service, "_reader", None)
        closer = getattr(aclose, "aclose", None)
        if callable(closer):
            await closer()
    _print(result, as_json=args.as_json)
    return 0


def run(args: argparse.Namespace) -> int:
    config = load_config()
    return asyncio.run(_run(config, args))


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-ctf-mergeable",
        description="Read-only CTF mergeable-quantity report.",
    )
    add_arguments(parser)
    return run(parser.parse_args(argv))


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
