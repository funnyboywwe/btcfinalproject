"""Pure, verifiable ABI *argument-region* encoding for CTF calldata.

This module encodes the head/tail argument regions of the standard Gnosis
Conditional Token Framework functions (address, bytes32, uint256, uint256[]).
It is deterministic, has no I/O, and is fully unit-tested.

IMPORTANT -- what this module intentionally does NOT do:

It does NOT compute the 4-byte function *selector*. The selector is the first
four bytes of the Ethereum keccak-256 hash of the function signature. Keccak-256
is NOT available in the Python standard library (``hashlib.sha3_256`` is NIST
SHA3, which produces different digests than Ethereum keccak), and no verified
keccak/eth-hash dependency is importable in this offline environment.
Guessing a selector would violate the project's "do not invent / do not guess"
safety rule. Selector derivation and full-calldata assembly therefore live only
in the blocked live preparer (:mod:`polymarket_pair_bot.ctf.preparer`), which
lazily imports a verified ABI/keccak library at runtime.

The helpers here let that adapter (once a verified library is present) build the
argument region, and let tests assert the encoding is correct without needing
keccak.
"""

from __future__ import annotations

from polymarket_pair_bot.ctf.errors import CtfValidationError

_WORD = 32
_UINT256_MAX = (1 << 256) - 1


def _clean_hex(value: str, *, label: str, nibbles: int) -> str:
    text = value.strip().lower()
    body = text[2:] if text.startswith("0x") else text
    if len(body) != nibbles or any(c not in "0123456789abcdef" for c in body):
        raise CtfValidationError(
            f"{label} must be 0x + {nibbles} hex characters"
        )
    return body


def encode_address(value: str) -> str:
    """Left-pad a 20-byte address to a 32-byte word (64 hex chars)."""
    body = _clean_hex(value, label="address", nibbles=40)
    return body.rjust(_WORD * 2, "0")


def encode_bytes32(value: str) -> str:
    """Encode a 32-byte value (already word-sized)."""
    return _clean_hex(value, label="bytes32", nibbles=64)


def encode_uint256(value: int) -> str:
    """Encode a non-negative integer that fits in 256 bits."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise CtfValidationError("uint256 value must be a non-bool int")
    if value < 0 or value > _UINT256_MAX:
        raise CtfValidationError("uint256 value out of range")
    return format(value, "064x")


def encode_uint256_array(values: tuple[int, ...]) -> str:
    """Encode a dynamic ``uint256[]`` tail region (length word + elements).

    The caller is responsible for placing the head offset word; this returns the
    tail: the length word followed by each element word.
    """
    parts = [encode_uint256(len(values))]
    parts.extend(encode_uint256(v) for v in values)
    return "".join(parts)


def validate_binary_index_sets(up_index_set: int, down_index_set: int) -> tuple[int, ...]:
    """Validate a binary condition's Up/Down index sets and return the partition.

    For a binary outcome the two index sets must be exactly the complementary
    bitmasks 1 (0b01) and 2 (0b10). They must be distinct and their union must
    cover the full outcome slot count (1 | 2 == 3). Returns the sorted partition
    tuple ``(1, 2)``.
    """
    for name, value in (("up", up_index_set), ("down", down_index_set)):
        if isinstance(value, bool) or not isinstance(value, int):
            raise CtfValidationError(f"{name} index set must be an int")
        if value < 1:
            raise CtfValidationError(f"{name} index set must be >= 1")
    if up_index_set == down_index_set:
        raise CtfValidationError("up and down index sets must differ")
    partition = tuple(sorted((up_index_set, down_index_set)))
    if partition != (1, 2):
        raise CtfValidationError(
            "binary outcome mapping must use complementary index sets {1, 2}; "
            f"got {partition}"
        )
    return partition


__all__ = [
    "encode_address",
    "encode_bytes32",
    "encode_uint256",
    "encode_uint256_array",
    "validate_binary_index_sets",
]
