"""Blocked CTF transaction preparer (Module 17).

Building full CTF calldata requires the 4-byte function selector, which is the
first four bytes of the Ethereum keccak-256 hash of each function signature
(``splitPosition(address,bytes32,bytes32,uint256[],uint256)`` etc.). Keccak-256
is not available in the Python standard library and no verified keccak/ABI
library (eth-hash, eth-abi, web3) is importable in this offline environment.

Guessing a selector or the exact Polymarket CTF calldata layout (plain CTF vs
NegRiskAdapter, collection-id derivation) would violate the project's
"do not invent / do not guess" safety rule. Therefore this adapter is BLOCKED:
every preparation method raises :class:`UnsupportedChainOperationError` with a
clear explanation. It lazily attempts to import a verified ABI library so that,
once such a dependency is installed and its behavior verified, this class is the
single place to implement real calldata assembly using
:mod:`polymarket_pair_bot.ctf.encoding` for the argument region.

The pure argument-region encoding in :mod:`polymarket_pair_bot.ctf.encoding` is
verifiable and tested; only selector derivation + final assembly are blocked.
"""

from __future__ import annotations

from polymarket_pair_bot.ctf.errors import UnsupportedChainOperationError
from polymarket_pair_bot.ctf.models import CtfContracts, UnsignedCtfTransaction
from polymarket_pair_bot.observability.logging import get_logger

_logger = get_logger(__name__)

_BLOCKED_DETAIL = (
    "CTF calldata assembly requires a verified keccak-256 / ABI library to "
    "derive function selectors; none is available offline and selectors must "
    "not be guessed. Install and verify a keccak/ABI dependency, then implement "
    "assembly here using ctf.encoding for the argument region."
)


def _abi_library_available() -> bool:
    """Best-effort check for a verified ABI/keccak library (never raises)."""
    try:  # pragma: no cover - depends on optional deps not present offline
        import eth_abi  # type: ignore  # noqa: F401
        import eth_utils  # type: ignore  # noqa: F401
    except Exception:
        return False
    return True


class BlockedCtfTransactionPreparer:
    """A :class:`CtfTransactionPreparer` that fails closed (never guesses)."""

    def __init__(self, contracts: CtfContracts) -> None:
        self._contracts = contracts

    def _blocked(self, operation: str) -> UnsignedCtfTransaction:
        _logger.warning(
            "ctf.preparer.blocked",
            extra={"operation": operation, "abi_library": _abi_library_available()},
        )
        raise UnsupportedChainOperationError(operation, detail=_BLOCKED_DETAIL)

    async def prepare_split(
        self, *, condition_id: str, partition: tuple[int, ...], amount_base_units: int
    ) -> UnsignedCtfTransaction:
        return self._blocked("ctf.splitPosition")

    async def prepare_merge(
        self, *, condition_id: str, partition: tuple[int, ...], amount_base_units: int
    ) -> UnsignedCtfTransaction:
        return self._blocked("ctf.mergePositions")

    async def prepare_redeem(
        self, *, condition_id: str, index_sets: tuple[int, ...]
    ) -> UnsignedCtfTransaction:
        return self._blocked("ctf.redeemPositions")

    async def prepare_erc20_approval(
        self, *, token_address: str, spender: str, amount_base_units: int
    ) -> UnsignedCtfTransaction:
        return self._blocked("erc20.approve")


__all__ = ["BlockedCtfTransactionPreparer"]
