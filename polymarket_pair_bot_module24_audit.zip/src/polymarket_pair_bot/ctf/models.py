"""Value objects and result models for CTF operations (Module 17).

All models are immutable dataclasses. Monetary/quantity values use the domain
value objects (:class:`Shares`, :class:`CollateralAmount`) or explicitly
documented integer base units -- never binary floats. Nothing here holds a
secret: an :class:`UnsignedCtfTransaction` carries only public calldata (the
``to`` address, hex ``data`` and integer ``value``), never a signature or key.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from polymarket_pair_bot.blockchain.models import (
    GasEstimate,
    TransactionOutcome,
)
from polymarket_pair_bot.domain.enums import CtfOperationType
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ConditionId,
    Shares,
)


@dataclass(frozen=True, slots=True)
class CtfContracts:
    """Trusted contract addresses + collateral decimals for CTF operations.

    Addresses originate from :class:`ChainReadSettings` (trusted configuration),
    never hard-coded in strategy code (requirements 1/2). Addresses are stored
    lower-cased 0x-hex strings.
    """

    conditional_tokens: str
    collateral: str
    collateral_decimals: int


@dataclass(frozen=True, slots=True)
class OutcomeMapping:
    """Binary Up/Down -> CTF index-set mapping (requirement 5).

    For a binary condition the two complementary index sets are 1 and 2; the
    full partition used by split/merge is the sorted pair. ``parent_collection``
    is a bytes32 hex string (root collateral collection is the zero hash).
    """

    up_index_set: int
    down_index_set: int
    parent_collection: str

    @property
    def partition(self) -> tuple[int, ...]:
        """The split/merge partition (sorted, deterministic)."""
        return tuple(sorted((self.up_index_set, self.down_index_set)))


@dataclass(frozen=True, slots=True)
class CtfOperationRequest:
    """A requested CTF operation. ``operation_id`` is the idempotency key."""

    operation_id: str
    operation_type: CtfOperationType
    condition_id: ConditionId
    up_token_id: str
    down_token_id: str
    quantity: Shares


@dataclass(frozen=True, slots=True)
class UnsignedCtfTransaction:
    """An unsigned transaction request. Carries only public calldata.

    ``to`` is the target contract, ``data`` is 0x-hex calldata, ``value`` is the
    integer wei value (0 for CTF operations). This object never holds a
    signature or private key.
    """

    to: str
    data: str
    value: int
    description: str


@dataclass(frozen=True, slots=True)
class ApprovalRequirement:
    """A required token approval discovered during preparation."""

    token_address: str
    spender: str
    kind: str  # "erc20" | "erc1155"
    reason: str
    unsigned: UnsignedCtfTransaction


@dataclass(frozen=True, slots=True)
class WalletBalances:
    """A snapshot of the balances relevant to a CTF operation."""

    up: Shares
    down: Shares
    collateral: CollateralAmount


@dataclass(frozen=True, slots=True)
class MergeableQuantity:
    """Read-only mergeable-quantity result (requirements 11/17).

    ``mergeable`` is exactly ``min(up_confirmed, down_confirmed)`` -- the most
    complete Up/Down pairs that could be merged. Only *confirmed* on-chain
    balances are used; nothing here treats an open or partially filled order as
    a matched pair.
    """

    condition_id: ConditionId
    up_confirmed: Shares
    down_confirmed: Shares
    mergeable: Shares


@dataclass(frozen=True, slots=True)
class PreparedCtfOperation:
    """Everything assembled prior to signing/broadcasting."""

    request: CtfOperationRequest
    unsigned: UnsignedCtfTransaction
    approvals: tuple[ApprovalRequirement, ...] = ()
    gas: GasEstimate | None = None


@dataclass(frozen=True, slots=True)
class CtfExecutionResult:
    """Outcome of an attempted CTF operation."""

    operation_id: str
    operation_type: CtfOperationType
    status: str
    effective_quantity: Shares
    tx_hash: str | None = None
    outcome: TransactionOutcome | None = None
    before: WalletBalances | None = None
    after: WalletBalances | None = None
    detail: str = ""
    notes: tuple[str, ...] = field(default_factory=tuple)


def zero_shares() -> Shares:
    return Shares(Decimal(0))


__all__ = [
    "ApprovalRequirement",
    "CtfContracts",
    "CtfExecutionResult",
    "CtfOperationRequest",
    "MergeableQuantity",
    "OutcomeMapping",
    "PreparedCtfOperation",
    "UnsignedCtfTransaction",
    "WalletBalances",
    "zero_shares",
]
