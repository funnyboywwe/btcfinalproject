"""Authentication for the private operator dashboard (Module 21).

The dashboard is bound to a private interface by default (requirement 4). As a
defence-in-depth second factor it supports an OPTIONAL shared bearer token
(requirement 5). When no token is configured the dashboard relies purely on
network isolation (loopback / VPN / SSH tunnel) and logs a warning so the
operator makes that choice deliberately -- see ``docs/dashboard.md``.

The token is compared in constant time and is NEVER logged, rendered, or echoed
in any response (requirement 3).
"""

from __future__ import annotations

import hmac

from polymarket_pair_bot.observability.logging import get_logger

_log = get_logger(__name__)

_BEARER_PREFIX = "bearer "


class DashboardAuthenticator:
    """Optional constant-time bearer-token gate for the dashboard.

    Args:
        token: the shared secret. ``None`` or empty disables token auth and
            falls back to network-isolation-only access.
    """

    def __init__(self, token: str | None) -> None:
        self._token = token or None
        if self._token is None:
            _log.warning("dashboard_auth_disabled_network_isolation_only")

    @property
    def enabled(self) -> bool:
        """Whether a shared token is configured and enforced."""
        return self._token is not None

    @staticmethod
    def _extract(authorization: str | None, query_token: str | None) -> str | None:
        """Pull a candidate token from an Authorization header or ?token=."""
        if authorization:
            value = authorization.strip()
            if value.lower().startswith(_BEARER_PREFIX):
                return value[len(_BEARER_PREFIX) :].strip()
            return value
        if query_token:
            return query_token
        return None

    def authorize(
        self,
        *,
        authorization: str | None = None,
        query_token: str | None = None,
    ) -> bool:
        """Return True if the request may view the dashboard.

        Disabled auth always authorizes (private binding is the control). When
        enabled, a candidate token must be present and match in constant time.
        """
        if self._token is None:
            return True
        candidate = self._extract(authorization, query_token)
        if not candidate:
            return False
        return hmac.compare_digest(candidate, self._token)


__all__ = ["DashboardAuthenticator"]
