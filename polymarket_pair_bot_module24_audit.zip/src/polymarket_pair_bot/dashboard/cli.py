"""Read-only CLI for the operator dashboard (Module 21).

``render-dashboard`` materialises the current (placeholder) dashboard snapshot
and writes the rendered HTML to a file or stdout. It performs no network I/O,
starts no server, and never places an order -- it only renders the read-only
view so operators can preview or archive it.
"""

from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

from polymarket_pair_bot.config.settings import load_config
from polymarket_pair_bot.dashboard.factory import build_dashboard_provider
from polymarket_pair_bot.dashboard.render import render_dashboard_html


def add_arguments(parser: argparse.ArgumentParser) -> None:
    """Register CLI arguments for ``render-dashboard``."""
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        default=None,
        help="Write rendered HTML to this path instead of stdout.",
    )


def run(args: argparse.Namespace) -> int:
    """Render the dashboard HTML from the placeholder provider. Returns exit code."""
    config = load_config()
    provider = build_dashboard_provider(config)
    snapshot = asyncio.run(provider.snapshot())
    html = render_dashboard_html(
        snapshot,
        refresh_seconds=config.dashboard.dashboard_refresh_seconds,
        title=config.dashboard.dashboard_title,
    )
    output: Path | None = args.output
    if output is None:
        print(html)
        return 0
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html, encoding="utf-8")
    print(f"Wrote dashboard HTML to {output}")
    return 0


__all__ = ["add_arguments", "run"]
