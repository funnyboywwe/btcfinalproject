"""Read-only dashboard data providers (Module 21).

Module 21 ships the dashboard surface itself. The authoritative aggregator that
reads live inventory, kill-switch state, reconciliation results, RPC health, and
P&L from persistence is a later-module concern; wiring it here would prematurely
implement other modules. Until then :class:`PlaceholderDashboardProvider`
returns a well-formed but empty, non-secret snapshot so the dashboard renders a
read-only skeleton with a clear "awaiting live data" banner.

Any real provider added later must implement the same
:class:`~polymarket_pair_bot.dashboard.ports.DashboardDataProvider` protocol and
remain strictly read-only.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime

from polymarket_pair_bot.dashboard.models import DashboardSnapshot


class PlaceholderDashboardProvider:
    """Return an empty, read-only snapshot until a live aggregator is wired in."""

    def __init__(
        self,
        *,
        run_mode: str,
        now: Callable[[], datetime] | None = None,
        message: str | None = None,
    ) -> None:
        self._run_mode = run_mode
        self._now = now or (lambda: datetime.now(UTC))
        self._message = message or (
            "Live data providers are wired in by later modules; showing an empty "
            "read-only skeleton."
        )

    async def snapshot(self) -> DashboardSnapshot:
        """Produce an empty non-secret snapshot (no side effects)."""
        return DashboardSnapshot(
            generated_at=self._now(),
            run_mode=self._run_mode,
            data_available=False,
            message=self._message,
        )


__all__ = ["PlaceholderDashboardProvider"]
