"""Private read-only operator dashboard FastAPI app (Module 21).

Routes (all GET, read-only -- requirements 1 & 2):

* ``GET /``            -- HTML dashboard (auth-gated when a token is configured).
* ``GET /dashboard``   -- alias of ``/``.
* ``GET /api/snapshot``-- JSON of the same non-secret snapshot (auth-gated).
* ``GET /healthz``     -- trivial liveness for the dashboard process (no auth).

There are intentionally NO POST/PUT/PATCH/DELETE routes and NO trade controls.
FastAPI is imported lazily inside the factory so importing this module never
requires the web stack. Displayed external data is HTML-escaped by the renderer
(requirement 6); the JSON payload is additionally passed through the redaction
filter as defence in depth so no secret can ever leak (requirement 3).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polymarket_pair_bot.dashboard.auth import DashboardAuthenticator
from polymarket_pair_bot.dashboard.ports import DashboardDataProvider
from polymarket_pair_bot.dashboard.render import render_dashboard_html
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.security.redaction import redact_mapping

if TYPE_CHECKING:  # pragma: no cover - typing only
    from fastapi import FastAPI

_log = get_logger(__name__)

_UNAUTHORIZED_HTML = (
    "<!doctype html><html><head><meta charset='utf-8'><title>401</title></head>"
    "<body><h1>401 Unauthorized</h1><p>A valid dashboard token is required.</p>"
    "</body></html>"
)


def create_dashboard_app(
    *,
    provider: DashboardDataProvider,
    authenticator: DashboardAuthenticator,
    refresh_seconds: int = 5,
    title: str = "Operator dashboard",
) -> FastAPI:
    """Build the private read-only dashboard :class:`fastapi.FastAPI` app.

    Args:
        provider: async, read-only snapshot source.
        authenticator: optional bearer-token gate (private binding is primary).
        refresh_seconds: HTML auto-refresh cadence.
        title: page title.
    """
    from fastapi import FastAPI, Header, Query, Response
    from fastapi.responses import HTMLResponse, JSONResponse

    app = FastAPI(title=title, docs_url=None, redoc_url=None, openapi_url=None)

    def _authorized(authorization: str | None, token: str | None) -> bool:
        return authenticator.authorize(authorization=authorization, query_token=token)

    @app.get("/healthz")
    async def healthz() -> JSONResponse:
        # Liveness only: no data, no secrets, no auth required.
        return JSONResponse(status_code=200, content={"status": "ok"})

    @app.get("/", response_class=HTMLResponse)
    @app.get("/dashboard", response_class=HTMLResponse)
    async def dashboard(
        authorization: str | None = Header(default=None),
        token: str | None = Query(default=None),
    ) -> Response:
        if not _authorized(authorization, token):
            return HTMLResponse(
                status_code=401,
                content=_UNAUTHORIZED_HTML,
                headers={"WWW-Authenticate": "Bearer"},
            )
        snapshot = await provider.snapshot()
        html = render_dashboard_html(
            snapshot, refresh_seconds=refresh_seconds, title=title
        )
        return HTMLResponse(status_code=200, content=html)

    @app.get("/api/snapshot")
    async def api_snapshot(
        authorization: str | None = Header(default=None),
        token: str | None = Query(default=None),
    ) -> JSONResponse:
        if not _authorized(authorization, token):
            return JSONResponse(
                status_code=401,
                content={"error": "unauthorized"},
                headers={"WWW-Authenticate": "Bearer"},
            )
        snapshot = await provider.snapshot()
        payload = redact_mapping(snapshot.model_dump(mode="json"))
        return JSONResponse(status_code=200, content=payload)

    _log.info(
        "dashboard_app_created",
        extra={"auth_enabled": authenticator.enabled, "refresh": refresh_seconds},
    )
    return app


__all__ = ["create_dashboard_app"]
