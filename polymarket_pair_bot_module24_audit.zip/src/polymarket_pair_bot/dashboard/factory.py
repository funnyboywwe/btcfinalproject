"""Composition helpers that wire the operator dashboard from ``AppConfig`` (Module 21).

The thin composition layer: it may know about ``AppConfig`` and assemble the
authenticator, provider, FastAPI app, and lifecycle service. Lower-level modules
(``models``, ``render``, ``auth``, ``api``, ``ports``, ``provider``) stay
decoupled and depend only on small protocols. FastAPI/uvicorn imports remain lazy
inside the components, so importing this module is cheap and side-effect free.

The uvicorn lifecycle wrapper is reused from Module 20
(:class:`~polymarket_pair_bot.observability.server.OperatorApiService`), which is
a generic ``Service`` around any FastAPI app bound to a private interface.
"""

from __future__ import annotations

from polymarket_pair_bot.config.settings import AppConfig
from polymarket_pair_bot.dashboard.auth import DashboardAuthenticator
from polymarket_pair_bot.dashboard.provider import PlaceholderDashboardProvider
from polymarket_pair_bot.dashboard.ports import DashboardDataProvider
from polymarket_pair_bot.observability.server import OperatorApiService


def build_dashboard_provider(config: AppConfig) -> PlaceholderDashboardProvider:
    """Build the default read-only provider (placeholder until later modules)."""
    return PlaceholderDashboardProvider(run_mode=config.run_mode.value)


def build_dashboard_authenticator(config: AppConfig) -> DashboardAuthenticator:
    """Build the optional bearer-token authenticator from config.

    The token is read from ``SecretStr`` only to compare it; it is never logged
    or rendered.
    """
    secret = config.dashboard.dashboard_auth_token
    token = secret.get_secret_value() if secret is not None else None
    return DashboardAuthenticator(token)


def build_dashboard_service(
    config: AppConfig,
    *,
    provider: DashboardDataProvider | None = None,
) -> OperatorApiService:
    """Assemble the private read-only dashboard service (health + HTML + JSON).

    FastAPI is imported lazily by ``create_dashboard_app`` so the rest of the
    composition stays importable without the web stack.
    """
    from polymarket_pair_bot.dashboard.api import create_dashboard_app

    resolved = provider or build_dashboard_provider(config)
    authenticator = build_dashboard_authenticator(config)
    app = create_dashboard_app(
        provider=resolved,
        authenticator=authenticator,
        refresh_seconds=config.dashboard.dashboard_refresh_seconds,
        title=config.dashboard.dashboard_title,
    )
    return OperatorApiService(
        app=app,
        host=config.dashboard.dashboard_host,
        port=config.dashboard.dashboard_port,
        shutdown_timeout=config.application.shutdown_timeout_seconds,
        name="operator-dashboard",
    )


__all__ = [
    "build_dashboard_authenticator",
    "build_dashboard_provider",
    "build_dashboard_service",
]
