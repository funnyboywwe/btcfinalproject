"""Module 21 -- private, read-only operator dashboard.

A FastAPI-served, server-side-rendered HTML view (plus a JSON snapshot endpoint)
of operator-relevant state: active market, books/depth, freshness, pair cost,
opportunity decision, inventory, matched/unmatched, open orders, recent fills,
merge status, risk, kill switch, reconciliation, daily P&L, and API/RPC health.

Design highlights:

* Read-only and side-effect free: no trade buttons, no write routes.
* Private by default (loopback binding) with optional bearer-token auth.
* No secrets are ever rendered or returned; external strings are HTML-escaped.
* Dependency inversion: the dashboard consumes a ``DashboardDataProvider``
  protocol, so the live aggregator can be supplied by later modules without the
  dashboard importing persistence / HTTP / websocket / blockchain classes.

Third-party deps (FastAPI, uvicorn) are imported lazily inside the components, so
importing this package is cheap. ``factory`` and ``cli`` additionally depend on
``AppConfig`` and should be imported directly when needed.
"""

from polymarket_pair_bot.dashboard.auth import DashboardAuthenticator
from polymarket_pair_bot.dashboard.models import DashboardSnapshot
from polymarket_pair_bot.dashboard.ports import DashboardDataProvider
from polymarket_pair_bot.dashboard.provider import PlaceholderDashboardProvider
from polymarket_pair_bot.dashboard.render import render_dashboard_html

__all__ = [
    "DashboardAuthenticator",
    "DashboardDataProvider",
    "DashboardSnapshot",
    "PlaceholderDashboardProvider",
    "render_dashboard_html",
]
