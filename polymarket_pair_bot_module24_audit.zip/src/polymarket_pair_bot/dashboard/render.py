"""Server-side HTML rendering for the operator dashboard (Module 21).

A deliberately dependency-free renderer: it produces a self-contained HTML page
from a :class:`~polymarket_pair_bot.dashboard.models.DashboardSnapshot` using
only the standard library. Every dynamic value -- especially external strings
such as the market question, order ids, tx hashes, and free-text reasons -- is
passed through :func:`html.escape` (requirement 6). The page contains NO forms,
NO buttons, and NO write actions (requirements 1 & 2), and NO secrets
(requirement 3).

Choosing a stdlib renderer over Jinja2 keeps the dashboard testable without any
extra third-party dependency and makes the escaping guarantee explicit and
auditable in one place.
"""

from __future__ import annotations

import html
from datetime import datetime
from decimal import Decimal

from polymarket_pair_bot.dashboard.models import (
    DashboardSnapshot,
    TopOfBookView,
)

_DASH = "\u2014"  # em dash used for missing values


def _esc(value: object) -> str:
    """Escape any value for safe HTML text/attribute interpolation.

    ``None`` renders as an em dash. ``Decimal`` and ``datetime`` are stringified
    losslessly before escaping. Booleans render as Yes/No. Everything else is
    ``str()``-ed and HTML-escaped (quotes included).
    """
    if value is None:
        return _DASH
    if isinstance(value, bool):
        text = "Yes" if value else "No"
    elif isinstance(value, Decimal):
        text = format(value, "f")
    elif isinstance(value, datetime):
        text = value.isoformat()
    else:
        text = str(value)
    return html.escape(text, quote=True)


def _seconds(value: float | None) -> str:
    if value is None:
        return _DASH
    return html.escape(f"{value:.1f}s")


def _row(label: str, value: str) -> str:
    # label is a trusted literal; value is already escaped by the caller.
    return f"<tr><th>{html.escape(label)}</th><td>{value}</td></tr>"


def _section(title: str, inner: str) -> str:
    return (
        f'<section class="card"><h2>{html.escape(title)}</h2>{inner}</section>'
    )


def _book_table(book: TopOfBookView | None, label: str) -> str:
    if book is None:
        return _section(label, f"<p class='muted'>{_DASH}</p>")
    rows = "".join(
        [
            _row("Best bid", _esc(book.best_bid)),
            _row("Bid size", _esc(book.best_bid_size)),
            _row("Best ask", _esc(book.best_ask)),
            _row("Ask size", _esc(book.best_ask_size)),
            _row("Bid depth", _esc(book.bid_depth)),
            _row("Ask depth", _esc(book.ask_depth)),
            _row("Depth levels", _esc(book.depth_levels)),
        ]
    )
    return _section(label, f"<table>{rows}</table>")


def _market_section(snapshot: DashboardSnapshot) -> str:
    market = snapshot.market
    if market is None:
        return _section("Active BTC market", f"<p class='muted'>{_DASH}</p>")
    rows = "".join(
        [
            _row("Slug", _esc(market.slug)),
            _row("Question", _esc(market.question)),
            _row("Condition id", _esc(market.condition_id)),
            _row("Up token", _esc(market.up_token_id)),
            _row("Down token", _esc(market.down_token_id)),
            _row("Opens", _esc(market.opens_at)),
            _row("Closes", _esc(market.closes_at)),
            _row("Time remaining", _seconds(market.time_remaining_seconds)),
        ]
    )
    return _section("Active BTC market", f"<table>{rows}</table>")


def _freshness_section(snapshot: DashboardSnapshot) -> str:
    f = snapshot.freshness
    badge = (
        "<span class='badge bad'>STALE</span>"
        if f.is_stale
        else "<span class='badge ok'>fresh</span>"
    )
    rows = "".join(
        [
            _row("Status", badge),
            _row("Market WS age", _seconds(f.market_ws_age_seconds)),
            _row("User WS age", _seconds(f.user_ws_age_seconds)),
            _row("Up book age", _seconds(f.up_book_age_seconds)),
            _row("Down book age", _seconds(f.down_book_age_seconds)),
            _row("Stale threshold", _seconds(f.stale_threshold_seconds)),
        ]
    )
    return _section("Data freshness", f"<table>{rows}</table>")


def _pair_cost_section(snapshot: DashboardSnapshot) -> str:
    pc = snapshot.pair_cost
    if pc is None:
        return _section("Pair-cost calculation", f"<p class='muted'>{_DASH}</p>")
    rows = "".join(
        [
            _row("Up acquisition", _esc(pc.up_acquisition_cost)),
            _row("Down acquisition", _esc(pc.down_acquisition_cost)),
            _row("Taker fees", _esc(pc.taker_fees)),
            _row("Expected slippage", _esc(pc.expected_slippage)),
            _row("Merge/gas overhead", _esc(pc.merge_or_gas_overhead)),
            _row("Safety reserve", _esc(pc.safety_reserve)),
            _row("Effective pair cost", f"<strong>{_esc(pc.effective_pair_cost)}</strong>"),
            _row("Threshold", _esc(pc.threshold)),
        ]
    )
    note = (
        "<p class='muted'>Cost identity only; below-threshold is a necessary "
        "condition, not a profit forecast.</p>"
    )
    return _section("Pair-cost calculation", f"<table>{rows}</table>{note}")


def _opportunity_section(snapshot: DashboardSnapshot) -> str:
    op = snapshot.opportunity
    if op is None:
        return _section("Opportunity decision", f"<p class='muted'>{_DASH}</p>")
    rows = "".join(
        [
            _row("Decision", _esc(op.decision)),
            _row("Cost margin", _esc(op.cost_margin)),
            _row("Reason", _esc(op.reason)),
            _row("Evaluated at", _esc(op.evaluated_at)),
        ]
    )
    return _section("Opportunity decision", f"<table>{rows}</table>")


def _inventory_section(snapshot: DashboardSnapshot) -> str:
    inv = snapshot.inventory
    rows = "".join(
        [
            _row("Up quantity", _esc(inv.up_quantity)),
            _row("Down quantity", _esc(inv.down_quantity)),
            _row("Matched (confirmed)", f"<strong>{_esc(inv.matched_quantity)}</strong>"),
            _row("Unmatched up", _esc(inv.unmatched_up_quantity)),
            _row("Unmatched down", _esc(inv.unmatched_down_quantity)),
            _row("Oldest unmatched age", _seconds(inv.oldest_unmatched_age_seconds)),
            _row("Unmatched age limit", _seconds(inv.unmatched_age_limit_seconds)),
            _row("Unmatched size limit", _esc(inv.unmatched_size_limit)),
        ]
    )
    note = (
        "<p class='muted'>Matched quantity counts confirmed fills only, never "
        "submitted/acknowledged/open/partially-filled orders.</p>"
    )
    return _section("Inventory & matched/unmatched", f"<table>{rows}</table>{note}")


def _open_orders_section(snapshot: DashboardSnapshot) -> str:
    if not snapshot.open_orders:
        return _section("Open orders", "<p class='muted'>None</p>")
    header = (
        "<tr><th>Order</th><th>Outcome</th><th>Side</th><th>Status</th>"
        "<th>Price</th><th>Qty</th><th>Filled</th><th>Created</th></tr>"
    )
    body = "".join(
        "<tr>"
        f"<td>{_esc(o.order_id)}</td>"
        f"<td>{_esc(o.outcome.value)}</td>"
        f"<td>{_esc(o.side.value)}</td>"
        f"<td>{_esc(o.status.value)}</td>"
        f"<td>{_esc(o.price)}</td>"
        f"<td>{_esc(o.quantity)}</td>"
        f"<td>{_esc(o.filled_quantity)}</td>"
        f"<td>{_esc(o.created_at)}</td>"
        "</tr>"
        for o in snapshot.open_orders
    )
    return _section("Open orders", f"<table class='grid'>{header}{body}</table>")


def _fills_section(snapshot: DashboardSnapshot) -> str:
    if not snapshot.recent_fills:
        return _section("Recent fills", "<p class='muted'>None</p>")
    header = (
        "<tr><th>Fill</th><th>Order</th><th>Outcome</th><th>Price</th>"
        "<th>Qty</th><th>Fee</th><th>Liquidity</th><th>At</th></tr>"
    )
    body = "".join(
        "<tr>"
        f"<td>{_esc(fl.fill_id)}</td>"
        f"<td>{_esc(fl.order_id)}</td>"
        f"<td>{_esc(fl.outcome.value)}</td>"
        f"<td>{_esc(fl.price)}</td>"
        f"<td>{_esc(fl.quantity)}</td>"
        f"<td>{_esc(fl.fee)}</td>"
        f"<td>{_esc(fl.liquidity)}</td>"
        f"<td>{_esc(fl.filled_at)}</td>"
        "</tr>"
        for fl in snapshot.recent_fills
    )
    return _section("Recent fills", f"<table class='grid'>{header}{body}</table>")


def _merges_section(snapshot: DashboardSnapshot) -> str:
    if not snapshot.merges:
        return _section("Merge status", "<p class='muted'>None</p>")
    header = (
        "<tr><th>Operation</th><th>Status</th><th>Pair qty</th>"
        "<th>Collateral</th><th>Tx</th><th>Updated</th></tr>"
    )
    body = "".join(
        "<tr>"
        f"<td>{_esc(m.operation_id)}</td>"
        f"<td>{_esc(m.status.value)}</td>"
        f"<td>{_esc(m.pair_quantity)}</td>"
        f"<td>{_esc(m.collateral_recovered)}</td>"
        f"<td>{_esc(m.tx_hash)}</td>"
        f"<td>{_esc(m.updated_at)}</td>"
        "</tr>"
        for m in snapshot.merges
    )
    return _section("Merge status", f"<table class='grid'>{header}{body}</table>")


def _risk_section(snapshot: DashboardSnapshot) -> str:
    r = snapshot.risk
    badge = (
        "<span class='badge bad'>BLOCKED</span>"
        if r.blocked
        else "<span class='badge ok'>ok</span>"
    )
    reasons = "; ".join(r.reasons) if r.reasons else None
    rows = "".join(
        [
            _row("State", badge),
            _row("Verdict", _esc(r.verdict.value if r.verdict else None)),
            _row("Reasons", _esc(reasons)),
            _row("Daily loss limit", _esc(r.daily_loss_limit)),
            _row("Rejections today", _esc(r.rejections_today)),
        ]
    )
    return _section("Risk status", f"<table>{rows}</table>")


def _kill_switch_section(snapshot: DashboardSnapshot) -> str:
    k = snapshot.kill_switch
    badge = (
        "<span class='badge bad'>ACTIVE</span>"
        if k.active
        else "<span class='badge ok'>inactive</span>"
    )
    rows = "".join(
        [
            _row("State", badge),
            _row("Reason", _esc(k.reason)),
            _row("Actor", _esc(k.actor)),
            _row("Since", _esc(k.since)),
        ]
    )
    return _section("Kill switch", f"<table>{rows}</table>")


def _reconciliation_section(snapshot: DashboardSnapshot) -> str:
    rc = snapshot.reconciliation
    rows = "".join(
        [
            _row("Status", _esc(rc.status.value)),
            _row("Last run", _esc(rc.last_run_at)),
            _row("Differences", _esc(rc.differences)),
            _row("Unknown orders", _esc(rc.unknown_orders)),
            _row("Detail", _esc(rc.detail)),
        ]
    )
    return _section("Reconciliation status", f"<table>{rows}</table>")


def _pnl_section(snapshot: DashboardSnapshot) -> str:
    p = snapshot.pnl
    rows = "".join(
        [
            _row("Day", _esc(p.day)),
            _row("Realized gross", _esc(p.realized_gross)),
            _row("Fees", _esc(p.fees)),
            _row("Slippage", _esc(p.slippage)),
            _row("Realized net", f"<strong>{_esc(p.realized_net)}</strong>"),
            _row("As of", _esc(p.as_of)),
        ]
    )
    return _section("Daily P&L", f"<table>{rows}</table>")


def _connectivity_section(snapshot: DashboardSnapshot) -> str:
    c = snapshot.connectivity
    rows = "".join(
        [
            _row("API healthy", _esc(c.api_healthy)),
            _row("API detail", _esc(c.api_detail)),
            _row("RPC primary", _esc(c.rpc_primary_healthy)),
            _row("RPC secondary", _esc(c.rpc_secondary_healthy)),
            _row("RPC agreement", _esc(c.rpc_in_agreement)),
            _row("RPC detail", _esc(c.rpc_detail)),
        ]
    )
    return _section("API & RPC health", f"<table>{rows}</table>")


_STYLE = """
:root{color-scheme:dark light}
body{font-family:system-ui,Segoe UI,Roboto,sans-serif;margin:0;padding:1rem;
 background:#0f1115;color:#e6e6e6}
header{display:flex;flex-wrap:wrap;gap:1rem;align-items:baseline;
 justify-content:space-between;border-bottom:1px solid #2a2f3a;padding-bottom:.5rem}
h1{font-size:1.1rem;margin:0}
.meta{color:#9aa4b2;font-size:.85rem}
.grid-wrap{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));
 gap:1rem;margin-top:1rem}
.card{background:#171a21;border:1px solid #2a2f3a;border-radius:10px;padding:.75rem 1rem}
.card h2{font-size:.95rem;margin:.2rem 0 .6rem;color:#c7d0dd}
table{width:100%;border-collapse:collapse;font-size:.85rem}
th,td{text-align:left;padding:.2rem .35rem;vertical-align:top}
table:not(.grid) th{color:#9aa4b2;font-weight:500;width:45%}
table.grid th{color:#9aa4b2;border-bottom:1px solid #2a2f3a}
table.grid td{border-bottom:1px solid #20242e;font-variant-numeric:tabular-nums}
.badge{padding:.05rem .4rem;border-radius:6px;font-size:.75rem;font-weight:600}
.badge.ok{background:#12351f;color:#7ee2a4}
.badge.bad{background:#3a1620;color:#ff9db0}
.muted{color:#9aa4b2}
.banner{background:#2a2410;color:#f2d98a;border:1px solid #4a3f16;border-radius:8px;
 padding:.5rem .75rem;margin-top:.75rem;font-size:.85rem}
footer{margin-top:1.5rem;color:#6b7280;font-size:.75rem}
"""


def render_dashboard_html(
    snapshot: DashboardSnapshot,
    *,
    refresh_seconds: int = 5,
    title: str = "Operator dashboard",
) -> str:
    """Render the full read-only dashboard page as an HTML string.

    Args:
        snapshot: the non-secret state to display.
        refresh_seconds: auto-refresh cadence via a ``<meta http-equiv>`` tag
            (no JavaScript required; read-only).
        title: page/browser title.
    """
    refresh = max(1, int(refresh_seconds))
    banner = ""
    if not snapshot.data_available:
        msg = snapshot.message or (
            "Live data providers are wired in by later modules; showing an empty "
            "read-only skeleton."
        )
        banner = f"<div class='banner'>{_esc(msg)}</div>"
    cards = "".join(
        [
            _market_section(snapshot),
            _book_table(snapshot.books.up, "Up top-of-book"),
            _book_table(snapshot.books.down, "Down top-of-book"),
            _freshness_section(snapshot),
            _pair_cost_section(snapshot),
            _opportunity_section(snapshot),
            _inventory_section(snapshot),
            _open_orders_section(snapshot),
            _fills_section(snapshot),
            _merges_section(snapshot),
            _risk_section(snapshot),
            _kill_switch_section(snapshot),
            _reconciliation_section(snapshot),
            _pnl_section(snapshot),
            _connectivity_section(snapshot),
        ]
    )
    return (
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<meta http-equiv='refresh' content='{refresh}'>"
        "<meta name='robots' content='noindex,nofollow'>"
        f"<title>{_esc(title)}</title><style>{_STYLE}</style></head><body>"
        "<header><h1>Polymarket pair-bot &middot; read-only operator view</h1>"
        f"<div class='meta'>mode: {_esc(snapshot.run_mode)} &middot; "
        f"generated: {_esc(snapshot.generated_at)} &middot; "
        f"refresh: {refresh}s</div></header>"
        f"{banner}"
        f"<div class='grid-wrap'>{cards}</div>"
        "<footer>Read-only. No trade actions are exposed. "
        "This view is informational and does not assert profitability.</footer>"
        "</body></html>"
    )


__all__ = ["render_dashboard_html"]
