"""Typed read-models for the private operator dashboard (Module 21).

These Pydantic v2 models are the *view contract* consumed by the dashboard. They
are deliberately decoupled from persistence / HTTP / websocket / blockchain
classes: later modules aggregate authoritative state into a
:class:`DashboardSnapshot` and hand it to the dashboard through the
:class:`~polymarket_pair_bot.dashboard.ports.DashboardDataProvider` protocol
(dependency inversion).

Safety / correctness:

* All monetary values, prices, and token quantities use ``Decimal`` -- never
  binary floats. Only durations (ages, time-remaining) use ``float`` seconds.
* The models contain **no secret fields** (no keys, DSNs, tokens, signatures).
* ``matched_quantity`` reflects ONLY confirmed-filled pairs. A pair is never
  inferred from submitted / acknowledged / open / partially-filled orders; the
  aggregator that populates these models is responsible for honouring that
  invariant, and the field docs restate it so the dashboard never misleads.
* Nothing here asserts or implies the strategy is profitable; the "cost margin"
  is a descriptive distance from the $1 break-even identity, not a P&L forecast.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from polymarket_pair_bot.domain.enums import (
    CtfOperationStatus,
    OrderSide,
    OrderStatus,
    OutcomeSide,
    ReconciliationStatus,
    RiskVerdict,
)


class _View(BaseModel):
    """Base read-model: frozen and forbidding unknown fields."""

    model_config = ConfigDict(frozen=True, extra="forbid")


class MarketView(_View):
    """The currently active BTC 5-minute market."""

    slug: str
    question: str | None = None
    condition_id: str | None = None
    up_token_id: str | None = None
    down_token_id: str | None = None
    opens_at: datetime | None = None
    closes_at: datetime | None = None
    # Duration, not money: plain seconds are acceptable. None when unknown.
    time_remaining_seconds: float | None = None


class TopOfBookView(_View):
    """Top-of-book and aggregated depth for a single outcome."""

    outcome: OutcomeSide
    best_bid: Decimal | None = None
    best_bid_size: Decimal | None = None
    best_ask: Decimal | None = None
    best_ask_size: Decimal | None = None
    # Aggregated size across the sampled depth levels (Decimal token units).
    bid_depth: Decimal | None = None
    ask_depth: Decimal | None = None
    depth_levels: int | None = None


class BooksView(_View):
    """Up and Down books side by side."""

    up: TopOfBookView | None = None
    down: TopOfBookView | None = None


class FreshnessView(_View):
    """Data-freshness ages (seconds) and staleness verdict."""

    market_ws_age_seconds: float | None = None
    user_ws_age_seconds: float | None = None
    up_book_age_seconds: float | None = None
    down_book_age_seconds: float | None = None
    stale_threshold_seconds: float | None = None
    is_stale: bool = True


class PairCostView(_View):
    """Break-down of the effective all-in pair-acquisition cost (all Decimal).

    ``effective_pair_cost`` is the conservative sum of every component; the
    strategy only considers acquiring a pair when it is below ``threshold``
    (nominally $1). This is a cost identity, not a profitability claim.
    """

    up_acquisition_cost: Decimal | None = None
    down_acquisition_cost: Decimal | None = None
    taker_fees: Decimal | None = None
    expected_slippage: Decimal | None = None
    merge_or_gas_overhead: Decimal | None = None
    safety_reserve: Decimal | None = None
    effective_pair_cost: Decimal | None = None
    threshold: Decimal = Decimal("1")


class OpportunityView(_View):
    """The detector's most recent decision (descriptive, not a profit forecast)."""

    decision: str = "unknown"
    # threshold - effective_pair_cost; a positive value is a cost margin below
    # break-even, NOT an expected profit.
    cost_margin: Decimal | None = None
    reason: str | None = None
    evaluated_at: datetime | None = None


class InventoryView(_View):
    """Confirmed inventory and matched / unmatched accounting."""

    up_quantity: Decimal = Decimal("0")
    down_quantity: Decimal = Decimal("0")
    # min(confirmed_up, confirmed_down) -- confirmed fills ONLY.
    matched_quantity: Decimal = Decimal("0")
    unmatched_up_quantity: Decimal = Decimal("0")
    unmatched_down_quantity: Decimal = Decimal("0")
    oldest_unmatched_age_seconds: float | None = None
    unmatched_age_limit_seconds: float | None = None
    unmatched_size_limit: Decimal | None = None


class OpenOrderView(_View):
    """A single open (non-terminal) order."""

    order_id: str
    outcome: OutcomeSide
    side: OrderSide
    status: OrderStatus
    price: Decimal | None = None
    quantity: Decimal | None = None
    filled_quantity: Decimal = Decimal("0")
    created_at: datetime | None = None


class FillView(_View):
    """A single recent fill (confirmed execution of some quantity)."""

    fill_id: str
    order_id: str | None = None
    outcome: OutcomeSide
    price: Decimal | None = None
    quantity: Decimal | None = None
    fee: Decimal | None = None
    liquidity: str | None = None  # "maker" / "taker" when known
    filled_at: datetime | None = None


class MergeView(_View):
    """A CTF merge operation and its confirmation status."""

    operation_id: str
    status: CtfOperationStatus
    pair_quantity: Decimal | None = None
    collateral_recovered: Decimal | None = None
    tx_hash: str | None = None
    updated_at: datetime | None = None


class RiskView(_View):
    """Centralized risk-engine status summary."""

    verdict: RiskVerdict | None = None
    blocked: bool = True
    reasons: tuple[str, ...] = ()
    daily_loss_limit: Decimal | None = None
    rejections_today: int = 0


class KillSwitchView(_View):
    """Persistent kill-switch status (non-secret fields only)."""

    active: bool = True
    reason: str | None = None
    actor: str | None = None
    since: datetime | None = None


class ReconciliationView(_View):
    """Latest reconciliation-pass result."""

    status: ReconciliationStatus = ReconciliationStatus.UNKNOWN
    last_run_at: datetime | None = None
    differences: int = 0
    unknown_orders: int = 0
    detail: str | None = None


class PnlView(_View):
    """Daily P&L accounting (all Decimal). Not a profitability guarantee."""

    day: str | None = None
    realized_gross: Decimal | None = None
    fees: Decimal | None = None
    slippage: Decimal | None = None
    realized_net: Decimal | None = None
    as_of: datetime | None = None


class ConnectivityView(_View):
    """External API and RPC health (booleans + short non-secret detail)."""

    api_healthy: bool | None = None
    api_detail: str | None = None
    rpc_primary_healthy: bool | None = None
    rpc_secondary_healthy: bool | None = None
    rpc_in_agreement: bool | None = None
    rpc_detail: str | None = None


class DashboardSnapshot(_View):
    """Complete, non-secret, point-in-time view of operator-relevant state."""

    generated_at: datetime
    run_mode: str
    # False until a real aggregator is wired in by later modules.
    data_available: bool = False
    message: str | None = None
    market: MarketView | None = None
    books: BooksView = Field(default_factory=BooksView)
    freshness: FreshnessView = Field(default_factory=FreshnessView)
    pair_cost: PairCostView | None = None
    opportunity: OpportunityView | None = None
    inventory: InventoryView = Field(default_factory=InventoryView)
    open_orders: tuple[OpenOrderView, ...] = ()
    recent_fills: tuple[FillView, ...] = ()
    merges: tuple[MergeView, ...] = ()
    risk: RiskView = Field(default_factory=RiskView)
    kill_switch: KillSwitchView = Field(default_factory=KillSwitchView)
    reconciliation: ReconciliationView = Field(default_factory=ReconciliationView)
    pnl: PnlView = Field(default_factory=PnlView)
    connectivity: ConnectivityView = Field(default_factory=ConnectivityView)


__all__ = [
    "BooksView",
    "ConnectivityView",
    "DashboardSnapshot",
    "FillView",
    "FreshnessView",
    "InventoryView",
    "KillSwitchView",
    "MarketView",
    "MergeView",
    "OpenOrderView",
    "OpportunityView",
    "PairCostView",
    "PnlView",
    "ReconciliationView",
    "RiskView",
    "TopOfBookView",
]
