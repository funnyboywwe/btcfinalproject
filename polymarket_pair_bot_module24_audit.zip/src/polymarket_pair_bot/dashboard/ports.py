"""Dependency-inversion port for the operator dashboard (Module 21).

The dashboard depends only on this small structural protocol, never on
persistence / HTTP / websocket / blockchain classes. Later modules provide a
concrete aggregator that reads authoritative records (Postgres inventory,
kill-switch state, reconciliation results, RPC health, ...) and returns a
:class:`~polymarket_pair_bot.dashboard.models.DashboardSnapshot`.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from polymarket_pair_bot.dashboard.models import DashboardSnapshot


@runtime_checkable
class DashboardDataProvider(Protocol):
    """Async source of read-only dashboard snapshots.

    Implementations MUST be read-only and side-effect free: producing a snapshot
    must never place, cancel, or mutate an order or any other state. They must
    also never include secrets in the returned model.
    """

    async def snapshot(self) -> DashboardSnapshot: ...


__all__ = ["DashboardDataProvider"]
