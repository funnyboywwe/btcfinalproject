"""Degraded-mode procedure and fail-closed helpers (Module 19, requirement 5).

When a critical task fails -- or any orchestrator-level uncertainty is detected
-- the bot must fail closed: disable new orders, enter degraded health, cancel
where it is safe, reconcile, and stop if uncertainty remains. This module holds
that procedure so it can be unit-tested in isolation and reused by both the
critical-failure path and (parts of) graceful shutdown.

Cancellation of resting orders stays possible even with the kill switch active;
``ExecutionControl.cancel_open_orders`` is defined to remain callable in that
state.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable

from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.orchestrator.ports import (
    ExecutionControl,
    MetricsSink,
    ReconcilerPort,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.shared.health import HealthState, HealthTracker

_log = get_logger(__name__)


class DegradedModeController:
    """Runs the fail-closed degraded procedure exactly once per activation."""

    def __init__(
        self,
        *,
        execution: ExecutionControl,
        reconciler: ReconcilerPort,
        health: HealthTracker,
        metrics: MetricsSink,
        request_stop: Callable[[str], None],
    ) -> None:
        self._execution = execution
        self._reconciler = reconciler
        self._health = health
        self._metrics = metrics
        self._request_stop = request_stop
        self._active = False

    @property
    def active(self) -> bool:
        return self._active

    async def enter(
        self,
        reason: str,
        *,
        trigger: ReconciliationTrigger = ReconciliationTrigger.UNKNOWN_SUBMISSION,
    ) -> None:
        """Execute the degraded procedure (idempotent per controller).

        Order (requirement 5):
          1. disable new orders (local execution block);
          2. mark health DEGRADED;
          3. cancel where safe (kill-switch-safe cancellation);
          4. reconcile authoritatively;
          5. stop if any uncertainty remains.
        """
        if self._active:
            _log.info("degraded_already_active", extra={"reason": reason})
            return
        self._active = True
        self._metrics.incr("orchestrator_degraded_total")
        _log.error("degraded_mode_entering", extra={"reason": reason})

        # 1. disable new orders
        await self._safe(self._execution.block_new_orders(reason), "block_new_orders")
        # 2. degraded health
        await self._health.set(HealthState.DEGRADED, f"degraded: {reason}")
        # 3. cancel where safe
        cancelled = await self._safe_int(
            self._execution.cancel_open_orders(), "cancel_open_orders"
        )
        _log.info("degraded_cancel_done", extra={"cancelled": cancelled})
        # 4. reconcile
        consistent = await self._reconcile(trigger)
        # 5. stop if uncertainty remains
        if not consistent:
            _log.error("degraded_uncertain_stopping", extra={"reason": reason})
            self._request_stop(f"degraded-uncertain:{reason}")
        else:
            _log.warning("degraded_reconciled_consistent", extra={"reason": reason})
            self._request_stop(f"degraded:{reason}")

    async def _reconcile(self, trigger: ReconciliationTrigger) -> bool:
        try:
            result = await self._reconciler.reconcile(trigger)
        except Exception as exc:  # noqa: BLE001 - fail closed on reconcile error
            _log.exception("degraded_reconcile_failed")
            self._metrics.incr("orchestrator_reconcile_error_total")
            _ = exc
            return False
        return bool(result.is_consistent)

    async def _safe(self, awaitable: Awaitable[None], op: str) -> None:
        try:
            await awaitable
        except Exception:  # noqa: BLE001 - degraded path must not raise
            _log.exception("degraded_step_failed", extra={"op": op})

    async def _safe_int(self, awaitable: Awaitable[int], op: str) -> int:
        try:
            return await awaitable
        except Exception:  # noqa: BLE001 - degraded path must not raise
            _log.exception("degraded_step_failed", extra={"op": op})
            return 0


__all__ = ["DegradedModeController"]
