"""Application orchestrator (Module 19, architecture item 18).

Coordinates the whole pipeline -- market discovery, market-data feed, detector,
risk engine, execution adapter, inventory, reconciliation, CTF operations,
persistence and metrics -- behind abstract ports, with structured asyncio task
supervision, bounded queues, fail-closed degraded mode, a strict graceful
shutdown ordering and readiness checks.

Only import-safe symbols (stdlib + domain/strategy/reconciliation protocols)
are re-exported here; no infrastructure (HTTP/WS/blockchain/SQLAlchemy/redis)
is imported at package-import time.
"""

from __future__ import annotations

from polymarket_pair_bot.orchestrator.config import OrchestratorConfig
from polymarket_pair_bot.orchestrator.degraded import DegradedModeController
from polymarket_pair_bot.orchestrator.orchestrator import (
    ApplicationOrchestrator,
    OrchestratorComponents,
)
from polymarket_pair_bot.orchestrator.ports import (
    AsyncResource,
    Clock,
    EventProducer,
    EventSink,
    ExecutionControl,
    FreshnessSource,
    KillSwitchPort,
    MarketDiscoveryPort,
    MetricsSink,
    NullMetricsSink,
    PersistenceControl,
    ReconcilerPort,
    SessionMachine,
    SystemClock,
)
from polymarket_pair_bot.orchestrator.readiness import ReadinessProbe, ReadinessReport
from polymarket_pair_bot.orchestrator.supervisor import TaskFailure, TaskSupervisor

__all__ = [
    "ApplicationOrchestrator",
    "AsyncResource",
    "Clock",
    "DegradedModeController",
    "EventProducer",
    "EventSink",
    "ExecutionControl",
    "FreshnessSource",
    "KillSwitchPort",
    "MarketDiscoveryPort",
    "MetricsSink",
    "NullMetricsSink",
    "OrchestratorComponents",
    "OrchestratorConfig",
    "PersistenceControl",
    "ReadinessProbe",
    "ReadinessReport",
    "ReconcilerPort",
    "SessionMachine",
    "SystemClock",
    "TaskFailure",
    "TaskSupervisor",
]
