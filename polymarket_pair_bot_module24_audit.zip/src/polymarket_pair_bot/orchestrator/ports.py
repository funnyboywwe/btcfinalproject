"""Typed ports the orchestrator depends on (Module 19, dependency inversion).

The orchestrator coordinates market discovery, market data, the opportunity
detector, the risk engine, the execution adapter, inventory, reconciliation,
CTF operations, persistence and metrics -- but it must not import any concrete
infrastructure (HTTP/WS/blockchain/SQLAlchemy/redis) or environment access.
Instead it talks only to the abstract :class:`typing.Protocol` interfaces here.
The composition layer binds paper or live adapters to these ports; because both
adapters implement the SAME interfaces, the orchestrator behaves identically in
paper and live mode (safety requirement: shared interfaces).

We re-use the strategy layer's already-defined ports where they fit
(``KillSwitchPort``) and its event / outcome types, rather than duplicating
them.
"""

from __future__ import annotations

import time
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import BinaryMarket, ReconciliationResult
from polymarket_pair_bot.domain.value_objects import MarketId, UnixTimestamp
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.strategy.session_events import SessionEvent
from polymarket_pair_bot.strategy.session_models import (
    PairSessionSnapshot,
    TransitionOutcome,
)
from polymarket_pair_bot.strategy.session_ports import KillSwitchPort

__all__ = [
    "AsyncResource",
    "Clock",
    "EventProducer",
    "EventSink",
    "ExecutionControl",
    "FreshnessSource",
    "KillSwitchPort",
    "MarketDiscoveryPort",
    "MetricsSink",
    "NullMetricsSink",
    "PersistenceControl",
    "ReconcilerPort",
    "SessionMachine",
    "SystemClock",
]


@runtime_checkable
class Clock(Protocol):
    """Injectable time source so tests are deterministic (no wall-clock)."""

    def now(self) -> UnixTimestamp: ...


class SystemClock:
    """Default wall-clock implementation (UTC seconds)."""

    def now(self) -> UnixTimestamp:
        return UnixTimestamp(int(time.time()))


@runtime_checkable
class MetricsSink(Protocol):
    """Prometheus-compatible counters/gauges/histograms (never secrets).

    Implementations must never raise: metrics are non-critical and must not be
    able to take down a trading task.
    """

    def incr(self, name: str, value: float = 1.0, **labels: str) -> None: ...

    def gauge(self, name: str, value: float, **labels: str) -> None: ...

    def observe(self, name: str, value: float, **labels: str) -> None: ...


class NullMetricsSink:
    """No-op metrics sink used as a safe default and in tests."""

    def incr(self, name: str, value: float = 1.0, **labels: str) -> None:
        return None

    def gauge(self, name: str, value: float, **labels: str) -> None:
        return None

    def observe(self, name: str, value: float, **labels: str) -> None:
        return None


@runtime_checkable
class MarketDiscoveryPort(Protocol):
    """Discover and validate the current BTC 5-minute market (requirement 5).

    Returns ``None`` when no valid market is currently tradable; the
    orchestrator then waits/retries rather than trading on an unvalidated
    market (fail closed).
    """

    async def discover(self) -> BinaryMarket | None: ...


@runtime_checkable
class EventSink(Protocol):
    """Bounded channel a producer emits validated session events into."""

    async def emit(self, event: SessionEvent) -> None: ...


@runtime_checkable
class EventProducer(Protocol):
    """A supervised source of session events (market data, fills, timers).

    ``critical`` marks producers whose failure must trigger degraded mode
    (requirement 4). ``run`` must be cancellation-safe and must return when the
    producer is exhausted (finite/paper-batch) or run until cancelled
    (continuous). ``aclose`` releases transport resources (e.g. a WebSocket).
    """

    @property
    def name(self) -> str: ...

    @property
    def critical(self) -> bool: ...

    async def run(self, sink: EventSink) -> None: ...

    async def aclose(self) -> None: ...


@runtime_checkable
class FreshnessSource(Protocol):
    """Optional transport-liveness probe for the freshness watchdog.

    ``seconds_since_data`` returns whole seconds since the last authoritative
    message, or ``None`` if no data has ever been seen yet.
    """

    @property
    def name(self) -> str: ...

    def seconds_since_data(self, now: UnixTimestamp) -> float | None: ...


@runtime_checkable
class ExecutionControl(Protocol):
    """Local execution gate + safe cancellation over the execution adapter.

    ``cancel_open_orders`` MUST remain callable while the kill switch is active
    (existing-order cancellation must always be possible). ``block_new_orders``
    is the local execution block used by degraded mode and graceful shutdown.
    """

    @property
    def new_orders_blocked(self) -> bool: ...

    async def block_new_orders(self, reason: str) -> None: ...

    async def allow_new_orders(self) -> None: ...

    async def cancel_open_orders(self, market_id: MarketId | None = None) -> int: ...


@runtime_checkable
class SessionMachine(Protocol):
    """Structural view of the Module 18 pair-accumulation state machine."""

    async def restore(self, market_id: MarketId) -> PairSessionSnapshot | None: ...

    async def process(self, event: SessionEvent) -> TransitionOutcome: ...


@runtime_checkable
class ReconcilerPort(Protocol):
    """Authoritative reconciliation trigger (requirement 13 / fail closed)."""

    async def reconcile(self, trigger: ReconciliationTrigger) -> ReconciliationResult: ...


@runtime_checkable
class PersistenceControl(Protocol):
    """Flush buffered authoritative records during graceful shutdown."""

    async def flush(self) -> None: ...


@runtime_checkable
class AsyncResource(Protocol):
    """A named closable resource (WebSocket, DB engine, Redis client)."""

    @property
    def name(self) -> str: ...

    async def aclose(self) -> None: ...
