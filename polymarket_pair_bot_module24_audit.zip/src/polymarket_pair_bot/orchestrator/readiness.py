"""Readiness checks for the orchestrator (Module 19, requirement 7).

Readiness is stricter than liveness: the bot is *ready* only when the whole
pipeline is safe to trade. That means health is READY, the global kill switch
is NOT active (fail closed if it cannot be read), every injected dependency
probe passes, a validated market session has been restored, and the local
execution block is not engaged. Readiness never enables live trading; it only
reports.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass

from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.orchestrator.ports import ExecutionControl, KillSwitchPort
from polymarket_pair_bot.shared.health import HealthCheck, HealthState, HealthTracker

_log = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class ReadinessReport:
    """Aggregated readiness result; ``detail`` values carry no secrets."""

    ready: bool
    checks: dict[str, bool]
    detail: dict[str, str]


class ReadinessProbe:
    """Aggregates health, kill switch, dependency probes and session state."""

    def __init__(
        self,
        *,
        health: HealthTracker,
        kill_switch: KillSwitchPort,
        execution: ExecutionControl,
        dependency_checks: Sequence[HealthCheck] = (),
        session_ready: Callable[[], bool] | None = None,
    ) -> None:
        self._health = health
        self._kill_switch = kill_switch
        self._execution = execution
        self._checks = list(dependency_checks)
        self._session_ready = session_ready or (lambda: True)

    async def evaluate(self) -> ReadinessReport:
        checks: dict[str, bool] = {}
        detail: dict[str, str] = {}

        health_ok = self._health.state is HealthState.READY
        checks["health"] = health_ok
        detail["health"] = self._health.state.value

        # Fail closed: if the kill switch cannot be read, treat as active.
        try:
            active = await self._kill_switch.is_active()
        except Exception as exc:  # noqa: BLE001
            active = True
            detail["kill_switch"] = f"unreadable:{type(exc).__name__}"
        else:
            detail["kill_switch"] = "active" if active else "inactive"
        checks["kill_switch_inactive"] = not active

        orders_open = not self._execution.new_orders_blocked
        checks["execution_unblocked"] = orders_open
        detail["execution"] = "open" if orders_open else "blocked"

        session_ok = bool(self._session_ready())
        checks["session_ready"] = session_ok
        detail["session"] = "ready" if session_ok else "not-ready"

        for check in self._checks:
            try:
                result = await check.check()
            except Exception as exc:  # noqa: BLE001 - probe failure => not ready
                checks[check.name] = False
                detail[check.name] = f"error:{type(exc).__name__}"
                continue
            checks[check.name] = result.healthy
            detail[check.name] = result.detail

        ready = all(checks.values())
        _log.info("readiness_evaluated", extra={"ready": ready, "checks": checks})
        return ReadinessReport(ready=ready, checks=checks, detail=detail)


__all__ = ["ReadinessProbe", "ReadinessReport"]
