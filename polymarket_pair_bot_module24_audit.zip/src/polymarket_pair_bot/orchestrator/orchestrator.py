"""The application orchestrator (Module 19, architecture item 18).

Coordinates market discovery, WebSocket market data, the opportunity detector,
the risk engine, the execution adapter, inventory, reconciliation, CTF
operations, persistence and metrics -- entirely through abstract ports so paper
and live modes share one code path (safety requirement: shared interfaces).

Key properties:

* Structured task supervision; no untracked tasks (requirements 1, 2).
* A single bounded session-event queue with backpressure (requirement 3).
* Critical vs noncritical task classification (requirement 4).
* Fail-closed degraded mode on critical failure (requirement 5).
* A strict graceful-shutdown ordering (requirement 6).
* Readiness checks (requirement 7).
* Never auto-enables live trading (requirement 9): it only reads ``run_mode``
  and drives whatever adapters the composition layer injected.

The orchestrator implements the existing :class:`Service` protocol so it can be
placed in the application ``LifecycleManager`` unchanged, and also exposes
``run`` for standalone use.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from dataclasses import dataclass, field

from polymarket_pair_bot.config.enums import RunMode
from polymarket_pair_bot.domain.entities import BinaryMarket
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.orchestrator.config import OrchestratorConfig
from polymarket_pair_bot.orchestrator.degraded import DegradedModeController
from polymarket_pair_bot.orchestrator.ports import (
    AsyncResource,
    Clock,
    EventProducer,
    ExecutionControl,
    FreshnessSource,
    KillSwitchPort,
    MarketDiscoveryPort,
    MetricsSink,
    NullMetricsSink,
    PersistenceControl,
    ReconcilerPort,
    SessionMachine,
    SystemClock,
)
from polymarket_pair_bot.orchestrator.readiness import ReadinessProbe, ReadinessReport
from polymarket_pair_bot.orchestrator.supervisor import TaskSupervisor
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.shared.health import HealthCheck, HealthState, HealthTracker
from polymarket_pair_bot.strategy.session_events import (
    MarketValidatedEvent,
    SessionEvent,
    UncertainEvent,
    WindowClosingEvent,
)
from polymarket_pair_bot.strategy.session_models import SessionState, TransitionOutcome

_log = get_logger(__name__)

# States that require the orchestrator to lock down new order flow.
_LOCKDOWN_STATES = frozenset(
    {
        SessionState.UNWIND_REQUIRED,
        SessionState.RECONCILIATION_REQUIRED,
        SessionState.HALTED,
    }
)
_TERMINAL_STATES = frozenset({SessionState.CLOSED})


class _BoundedEventSink:
    """Bounded queue put with backpressure; the only channel into the machine."""

    def __init__(self, queue: asyncio.Queue[SessionEvent]) -> None:
        self._queue = queue

    async def emit(self, event: SessionEvent) -> None:
        await self._queue.put(event)


@dataclass(slots=True)
class OrchestratorComponents:
    """Everything the orchestrator coordinates, all as abstract ports.

    The composition layer builds this with paper adapters (default/safe) or,
    only when explicitly configured, live adapters. Both satisfy the same
    protocols so the orchestrator code path is identical.
    """

    run_mode: RunMode
    discovery: MarketDiscoveryPort
    machine: SessionMachine
    execution: ExecutionControl
    reconciler: ReconcilerPort
    kill_switch: KillSwitchPort
    persistence: PersistenceControl
    producers: Sequence[EventProducer]
    freshness_sources: Sequence[FreshnessSource] = ()
    websockets: Sequence[AsyncResource] = ()
    datastores: Sequence[AsyncResource] = ()
    dependency_checks: Sequence[HealthCheck] = ()
    metrics: MetricsSink = field(default_factory=NullMetricsSink)
    clock: Clock = field(default_factory=SystemClock)


class ApplicationOrchestrator:
    """Long-lived component wiring the whole pipeline together."""

    def __init__(
        self,
        components: OrchestratorComponents,
        *,
        config: OrchestratorConfig,
        health: HealthTracker | None = None,
    ) -> None:
        self._c = components
        self._config = config
        self._health = health or HealthTracker()
        self._queue: asyncio.Queue[SessionEvent] = asyncio.Queue(
            maxsize=config.event_queue_maxsize
        )
        self._sink = _BoundedEventSink(self._queue)
        self._supervisor = TaskSupervisor()
        self._stop_event = asyncio.Event()
        self._stop_reason = ""
        self._market: BinaryMarket | None = None
        self._session_restored = False
        self._started = False
        self._shutting_down = False
        self._degraded = DegradedModeController(
            execution=components.execution,
            reconciler=components.reconciler,
            health=self._health,
            metrics=components.metrics,
            request_stop=self.request_stop,
        )
        self._readiness = ReadinessProbe(
            health=self._health,
            kill_switch=components.kill_switch,
            execution=components.execution,
            dependency_checks=components.dependency_checks,
            session_ready=lambda: self._session_restored,
        )

    # -- Service protocol -------------------------------------------------

    @property
    def name(self) -> str:
        return "application-orchestrator"

    @property
    def health(self) -> HealthTracker:
        return self._health

    def request_stop(self, reason: str = "manual") -> None:
        """Request a single graceful shutdown (idempotent)."""
        if not self._stop_event.is_set():
            self._stop_reason = reason
            _log.info("orchestrator_stop_requested", extra={"reason": reason})
            self._stop_event.set()

    async def readiness(self) -> ReadinessReport:
        """Evaluate readiness (requirement 7)."""
        return await self._readiness.evaluate()

    async def start(self) -> None:
        """Discover + restore + launch supervised tasks (requirements 4, 5, 9)."""
        if self._started:
            return
        await self._health.set(HealthState.STARTING, "orchestrator starting")
        # Requirement 9: never auto-enable live trading. We only observe the
        # mode the composition layer configured and never mutate it.
        _log.info("orchestrator_run_mode", extra={"run_mode": self._c.run_mode.value})
        if self._c.run_mode is RunMode.LIVE:
            _log.warning(
                "orchestrator_live_mode",
                extra={"note": "live adapters are injected by composition, not here"},
            )

        market = await self._discover_with_timeout()
        if market is None:
            # Fail closed: no validated market -> do not trade.
            await self._health.set(HealthState.DEGRADED, "no validated market")
            self.request_stop("no-validated-market")
            self._started = True
            return
        self._market = market

        # Requirement 4 (restart): rebuild authoritative session state first.
        await self._c.machine.restore(market.market_id)
        self._session_restored = True

        if self._config.run_until_producers_complete:
            self._supervisor.expect_completion = True

        # Seed the pipeline: the machine validates the market and begins book
        # sync. This is the first supervised, idempotent event.
        await self._sink.emit(
            MarketValidatedEvent(
                event_id=f"market-validated:{market.market_id.value}",
                market_id=market.market_id,
                occurred_at=self._c.clock.now(),
                market=market,
            )
        )

        # Consumer is critical: it drives the state machine.
        self._supervisor.start("event-consumer", self._consume_loop(), critical=True)
        # Producers: each declares its own criticality.
        for producer in self._c.producers:
            self._supervisor.start(
                f"producer:{producer.name}",
                self._run_producer(producer),
                critical=producer.critical,
                is_producer=True,
            )
        # Freshness watchdog is noncritical: it reacts by entering degraded mode
        # itself rather than by crashing.
        if self._c.freshness_sources:
            self._supervisor.start(
                "freshness-watchdog", self._freshness_loop(), critical=False
            )

        await self._health.set(HealthState.READY, "orchestrator ready")
        self._started = True
        _log.info("orchestrator_ready", extra={"market": market.market_id.value})

    async def stop(self) -> None:
        """Idempotent graceful shutdown (requirement 6)."""
        if self._shutting_down:
            return
        self._shutting_down = True
        await self._graceful_shutdown(self._stop_reason or "stop")

    async def run(self) -> None:
        """Standalone run: start, wait for exit condition, then stop."""
        await self.start()
        if not self._stop_event.is_set():
            if self._config.run_until_producers_complete and self._c.producers:
                await self._run_batch()
            else:
                await self._wait_for_exit()
        await self.stop()

    # -- Core loops -------------------------------------------------------

    async def _run_batch(self) -> None:
        """Deterministic paper-batch: finish when producers drain (requirement 8)."""
        done_task = asyncio.ensure_future(self._supervisor.wait_producers_done())
        fail_task = asyncio.ensure_future(self._supervisor.wait_for_critical_failure())
        stop_task = asyncio.ensure_future(self._stop_event.wait())
        waiters = {done_task, fail_task, stop_task}
        try:
            done, _pending = await asyncio.wait(
                waiters, return_when=asyncio.FIRST_COMPLETED
            )
        finally:
            for task in waiters:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*waiters, return_exceptions=True)
        if fail_task in done and stop_task not in done and done_task not in done:
            await self._handle_critical_failure()
            return
        if done_task in done:
            # Let the consumer finish processing every queued event.
            await self._queue.join()

    async def _wait_for_exit(self) -> None:
        """Continuous mode: block until stop signal or critical failure."""
        stop_task = asyncio.ensure_future(self._stop_event.wait())
        fail_task = asyncio.ensure_future(self._supervisor.wait_for_critical_failure())
        waiters = {stop_task, fail_task}
        try:
            done, _pending = await asyncio.wait(
                waiters, return_when=asyncio.FIRST_COMPLETED
            )
        finally:
            for task in waiters:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*waiters, return_exceptions=True)
        if fail_task in done and stop_task not in done:
            await self._handle_critical_failure()

    async def _handle_critical_failure(self) -> None:
        failure = self._supervisor.first_failure
        reason = failure.name if failure else "critical-failure"
        _log.error("orchestrator_critical_failure", extra={"task": reason})
        self._c.metrics.incr("orchestrator_critical_failure_total")
        await self._degraded.enter(
            f"critical-task-failed:{reason}",
            trigger=ReconciliationTrigger.UNKNOWN_SUBMISSION,
        )

    async def _consume_loop(self) -> None:
        """Drain the bounded queue and drive the machine (idempotent process)."""
        while True:
            event = await self._queue.get()
            try:
                outcome = await self._c.machine.process(event)
                await self._react(outcome)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 - a processing error is uncertain
                _log.exception(
                    "event_processing_failed", extra={"event": type(event).__name__}
                )
                self._c.metrics.incr("orchestrator_event_error_total")
                await self._emit_uncertain("event-processing-error")
            finally:
                self._queue.task_done()

    async def _react(self, outcome: TransitionOutcome) -> None:
        """React to a machine transition at the orchestrator level."""
        state = outcome.state
        self._c.metrics.gauge("orchestrator_session_state", 1.0, state=state.value)
        if state in _LOCKDOWN_STATES:
            _log.warning("orchestrator_lockdown_state", extra={"state": state.value})
            self._c.metrics.incr("orchestrator_lockdown_total", state=state.value)
            if not self._c.execution.new_orders_blocked:
                await self._c.execution.block_new_orders(f"state:{state.value}")
            if state is SessionState.HALTED:
                await self._degraded.enter(
                    "machine-halted", trigger=ReconciliationTrigger.UNKNOWN_SUBMISSION
                )
        elif state in _TERMINAL_STATES:
            _log.info("orchestrator_session_closed", extra={"state": state.value})

    async def _run_producer(self, producer: EventProducer) -> None:
        try:
            await producer.run(self._sink)
        except asyncio.CancelledError:
            raise
        # Non-cancellation exceptions propagate to the supervisor, which decides
        # critical vs noncritical handling.

    async def _freshness_loop(self) -> None:
        """Fail closed if a transport goes silent past the staleness budget."""
        threshold = self._config.feed_staleness_seconds
        poll = min(1.0, threshold)
        while True:
            await asyncio.sleep(poll)
            now = self._c.clock.now()
            for source in self._c.freshness_sources:
                age = source.seconds_since_data(now)
                if age is not None and age > threshold:
                    _log.error(
                        "feed_stale", extra={"source": source.name, "age_seconds": age}
                    )
                    self._c.metrics.incr("orchestrator_feed_stale_total")
                    await self._degraded.enter(
                        f"stale-feed:{source.name}",
                        trigger=ReconciliationTrigger.USER_STREAM_RECONNECT,
                    )
                    return

    async def _emit_uncertain(self, reason: str) -> None:
        if self._market is None:
            return
        now = self._c.clock.now()
        await self._sink.emit(
            UncertainEvent(
                event_id=f"uncertain:{reason}:{now.value}",
                market_id=self._market.market_id,
                occurred_at=now,
                reason=reason,
                trigger=ReconciliationTrigger.UNKNOWN_SUBMISSION,
            )
        )

    async def _discover_with_timeout(self) -> BinaryMarket | None:
        try:
            async with asyncio.timeout(self._config.startup_timeout_seconds):
                return await self._c.discovery.discover()
        except TimeoutError:
            _log.error("market_discovery_timeout")
            return None
        except Exception:  # noqa: BLE001 - discovery failure => fail closed
            _log.exception("market_discovery_failed")
            return None

    # -- Graceful shutdown (requirement 6) --------------------------------

    async def _graceful_shutdown(self, reason: str) -> None:
        """Strict shutdown ordering; every step is bounded and fail-closed."""
        _log.info("graceful_shutdown_begin", extra={"reason": reason})
        await self._health.set(HealthState.STOPPING, f"stopping: {reason}")

        # 1. disable new strategy actions + 2. activate local execution block.
        await self._safe(
            self._c.execution.block_new_orders(f"shutdown:{reason}"), "block_new_orders"
        )
        if self._market is not None:
            now = self._c.clock.now()
            await self._safe(
                self._sink.emit(
                    WindowClosingEvent(
                        event_id=f"shutdown-window:{now.value}",
                        market_id=self._market.market_id,
                        occurred_at=now,
                        market=self._market,
                        seconds_to_close=0,
                    )
                ),
                "emit_window_closing",
            )

        # 3. cancel open orders (kill-switch-safe).
        cancelled = await self._safe_int(
            self._c.execution.cancel_open_orders(), "cancel_open_orders"
        )
        _log.info("shutdown_orders_cancelled", extra={"cancelled": cancelled})

        # 4. wait for authoritative updates (keep consumer draining fills).
        await self._drain_authoritative()

        # Stop consumer/producers/watchdog now that draining is done.
        await self._supervisor.cancel_all(self._config.cancel_grace_seconds)

        # 5. reconcile authoritatively.
        await self._reconcile_on_shutdown()

        # 6. flush persistence.
        await self._safe(self._c.persistence.flush(), "persistence_flush")

        # 7. close WebSockets (producers + explicit ws resources).
        for producer in self._c.producers:
            await self._safe(producer.aclose(), f"aclose_producer:{producer.name}")
        for ws in self._c.websockets:
            await self._safe(ws.aclose(), f"aclose_ws:{ws.name}")

        # 8. close database and Redis.
        for store in self._c.datastores:
            await self._safe(store.aclose(), f"aclose_store:{store.name}")

        _log.info("graceful_shutdown_complete", extra={"reason": reason})

    async def _drain_authoritative(self) -> None:
        wait = self._config.authoritative_wait_seconds
        if wait <= 0:
            return
        try:
            async with asyncio.timeout(wait):
                await self._queue.join()
        except TimeoutError:
            _log.warning("authoritative_drain_timeout", extra={"wait": wait})

    async def _reconcile_on_shutdown(self) -> None:
        try:
            result = await self._c.reconciler.reconcile(ReconciliationTrigger.SHUTDOWN)
        except Exception:  # noqa: BLE001 - never raise during shutdown
            _log.exception("shutdown_reconcile_failed")
            self._c.metrics.incr("orchestrator_reconcile_error_total")
            return
        _log.info(
            "shutdown_reconciled", extra={"consistent": bool(result.is_consistent)}
        )

    async def _safe(self, awaitable: object, op: str) -> None:
        try:
            await awaitable  # type: ignore[misc]
        except Exception:  # noqa: BLE001 - shutdown must not raise
            _log.exception("shutdown_step_failed", extra={"op": op})

    async def _safe_int(self, awaitable: object, op: str) -> int:
        try:
            return await awaitable  # type: ignore[misc, no-any-return]
        except Exception:  # noqa: BLE001 - shutdown must not raise
            _log.exception("shutdown_step_failed", extra={"op": op})
            return 0


__all__ = ["ApplicationOrchestrator", "OrchestratorComponents"]
