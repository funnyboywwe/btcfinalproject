"""Structured asyncio task supervision (Module 19, requirements 1, 2, 4).

Every long-lived coroutine the orchestrator runs is owned by a
:class:`TaskSupervisor`. There are NO untracked ``asyncio.create_task`` calls
anywhere in the orchestrator -- creating a task always goes through the
supervisor, which keeps a handle, logs terminal outcomes, and distinguishes
*critical* from *noncritical* tasks.

Because a done-callback runs synchronously and must not itself spawn untracked
work, a critical failure (and batch producer completion) are surfaced through
:class:`asyncio.Event` objects that the orchestrator's main loop awaits. The
orchestrator then runs its reactions on a properly supervised code path.
"""

from __future__ import annotations

import asyncio
from collections.abc import Coroutine
from dataclasses import dataclass
from typing import Any

from polymarket_pair_bot.observability.logging import get_logger

_log = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class TaskFailure:
    """Describes why a supervised task terminated unexpectedly."""

    name: str
    critical: bool
    # ``None`` means the task returned instead of raising (unexpected for a
    # long-lived task, expected for a finite/paper-batch producer).
    error: BaseException | None


class TaskSupervisor:
    """Owns every background task; classifies critical vs noncritical failures.

    ``expect_completion`` marks the phase where producers finishing normally is
    expected (deterministic paper batch / graceful drain), so a normal return
    is not treated as a critical failure.
    """

    def __init__(self) -> None:
        self._tasks: dict[asyncio.Task[Any], tuple[str, bool]] = {}
        self._critical_failure: asyncio.Event = asyncio.Event()
        self._producers_done: asyncio.Event = asyncio.Event()
        self._first_failure: TaskFailure | None = None
        self._completed: set[str] = set()
        self._expected_producers: set[str] = set()
        self.expect_completion: bool = False

    def start(
        self,
        name: str,
        coro: Coroutine[Any, Any, Any],
        *,
        critical: bool,
        is_producer: bool = False,
    ) -> asyncio.Task[Any]:
        """Schedule and track a task. All orchestrator tasks go through here."""
        task = asyncio.create_task(coro, name=name)
        self._tasks[task] = (name, critical)
        if is_producer:
            self._expected_producers.add(name)
        task.add_done_callback(self._on_done)
        _log.info("task_started", extra={"task": name, "critical": critical})
        return task

    def _on_done(self, task: asyncio.Task[Any]) -> None:
        name, critical = self._tasks.pop(task, ("<unknown>", False))
        if task.cancelled():
            _log.info("task_cancelled", extra={"task": name})
            return
        error = task.exception()
        if error is None:
            self._completed.add(name)
            _log.info("task_completed", extra={"task": name})
            if critical and not self.expect_completion:
                # A long-lived critical task returning is unexpected unless we
                # are intentionally draining to completion.
                self._record_failure(TaskFailure(name, True, None))
            self._maybe_mark_producers_done()
            return
        _log.error(
            "task_failed",
            extra={"task": name, "critical": critical, "error": type(error).__name__},
        )
        if critical:
            self._record_failure(TaskFailure(name, True, error))

    def _record_failure(self, failure: TaskFailure) -> None:
        if self._first_failure is None:
            self._first_failure = failure
            self._critical_failure.set()

    def _maybe_mark_producers_done(self) -> None:
        if self.all_producers_done():
            self._producers_done.set()

    @property
    def active_count(self) -> int:
        return len(self._tasks)

    @property
    def first_failure(self) -> TaskFailure | None:
        return self._first_failure

    def all_producers_done(self) -> bool:
        """True once every producer registered with ``is_producer`` has ended."""
        return bool(self._expected_producers) and self._expected_producers.issubset(
            self._completed
        )

    async def wait_for_critical_failure(self) -> TaskFailure:
        """Block until a critical task fails; returns the first failure."""
        await self._critical_failure.wait()
        assert self._first_failure is not None  # noqa: S101
        return self._first_failure

    async def wait_producers_done(self) -> None:
        """Block until every registered producer has finished (batch mode)."""
        await self._producers_done.wait()

    async def cancel_all(self, timeout: float) -> None:
        """Cancel and await every tracked task within ``timeout`` seconds."""
        tasks = list(self._tasks)
        if not tasks:
            return
        for task in tasks:
            task.cancel()
        _done, pending = await asyncio.wait(set(tasks), timeout=timeout)
        if pending:
            _log.error(
                "task_cancel_timeout", extra={"pending": len(pending), "timeout": timeout}
            )


__all__ = ["TaskFailure", "TaskSupervisor"]
