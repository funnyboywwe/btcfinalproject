"""Configuration for the application orchestrator (Module 19).

These are pure, validated, dependency-light settings. They intentionally do NOT
read environment variables here: the composition layer builds this object from
the global :class:`AppConfig` (or from test defaults). Keeping this a frozen
dataclass means importing the orchestrator never pulls in pydantic-settings or
touches the process environment (dependency inversion / module boundaries).

No monetary values live here, so no ``Decimal`` fields are required; all values
are timeouts (seconds) or bounded queue sizes (counts).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class OrchestratorConfig:
    """Bounded-queue sizes and lifecycle timeouts for the orchestrator.

    Attributes:
        event_queue_maxsize: hard upper bound on the in-flight session-event
            queue. Bounded (requirement 3): producers block (backpressure) when
            full rather than growing memory without limit.
        startup_timeout_seconds: max time market discovery + restore may take.
        shutdown_timeout_seconds: overall budget for the graceful shutdown
            sequence; individual steps are additionally bounded.
        cancel_grace_seconds: budget for cancelling resting orders.
        authoritative_wait_seconds: after cancelling, how long to keep draining
            authoritative fill/ack updates before reconciling (requirement 6).
        feed_staleness_seconds: transport silence beyond this triggers a
            fail-closed degraded transition (freshness check).
        run_until_producers_complete: when True (deterministic paper batch /
            tests) the orchestrator stops once every producer has finished and
            the queue is drained. When False (continuous live/paper operation)
            it runs until a shutdown signal or critical failure.
    """

    event_queue_maxsize: int = 256
    startup_timeout_seconds: float = 30.0
    shutdown_timeout_seconds: float = 20.0
    cancel_grace_seconds: float = 5.0
    authoritative_wait_seconds: float = 3.0
    feed_staleness_seconds: float = 5.0
    run_until_producers_complete: bool = False

    def __post_init__(self) -> None:
        for name in (
            "event_queue_maxsize",
            "startup_timeout_seconds",
            "shutdown_timeout_seconds",
            "cancel_grace_seconds",
            "feed_staleness_seconds",
        ):
            value = getattr(self, name)
            if value <= 0:
                raise ValueError(f"{name} must be positive, got {value!r}")
        if self.authoritative_wait_seconds < 0:
            raise ValueError("authoritative_wait_seconds must be >= 0")


__all__ = ["OrchestratorConfig"]
