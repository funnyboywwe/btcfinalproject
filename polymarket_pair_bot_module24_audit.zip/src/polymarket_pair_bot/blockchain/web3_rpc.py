"""web3.py-backed implementation of the :class:`EthereumRpc` port (Module 16).

This is the ONLY file in the blockchain module that talks to a real Polygon
node. It is an adapter: everything above it depends on the
:class:`~polymarket_pair_bot.blockchain.ports.EthereumRpc` Protocol, so
domain/service/strategy code never imports web3.py.

Safety / boundary characteristics:

* web3.py is imported *lazily* inside the constructor. Importing this module
  never requires web3 to be installed, so the rest of the package (and its
  unit tests, which use in-memory fakes) works in a minimal environment. If
  web3 is unavailable, construction fails closed with a clear
  :class:`ChainConfigurationError`.
* Only read-only JSON-RPC calls are issued (``eth_chainId``,
  ``eth_getBalance``, ``eth_call``, ``eth_estimateGas``, ``eth_gasPrice``,
  ``eth_getTransactionByHash``, ``eth_getTransactionReceipt``,
  ``eth_getTransactionCount``, ``eth_blockNumber``). No transaction is ever
  signed or broadcast here -- that is the CTF write path (Module 21).
* The RPC URL is a secret (it may embed a provider API key). It is stored
  privately, never logged, and never included in an exception message. Only
  the opaque ``label`` ('primary'/'secondary') is exposed.
* Any behaviour that could not be verified offline is isolated here and, where
  a web3 call surface is uncertain, raised as a blocked
  :class:`UnsupportedChainOperationError` rather than guessed.

The async surface used below (``AsyncWeb3`` + ``AsyncHTTPProvider`` with
``w3.eth.*`` coroutines) is web3.py's documented async API. Because web3 is not
installed in the offline test sandbox, this adapter is exercised in unit tests
via the in-memory fake in ``tests/fixtures/blockchain.py`` and, optionally,
against a local fork in the integration tests.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from polymarket_pair_bot.blockchain.errors import (
    ChainConfigurationError,
    ChainRpcUnavailableError,
)


def _to_int(value: Any) -> int:
    """Coerce a JSON-RPC integer (int or 0x-hex string) to int."""
    if isinstance(value, bool):
        raise ValueError("expected integer, got bool")
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        return int(value, 16) if value.startswith("0x") else int(value)
    raise ValueError(f"cannot coerce {type(value).__name__} to int")


class Web3Rpc:
    """Concrete :class:`EthereumRpc` backed by an ``AsyncWeb3`` HTTP provider."""

    def __init__(
        self,
        rpc_url: str,
        *,
        label: str,
        request_timeout_seconds: float = 10.0,
    ) -> None:
        self._label = label
        try:
            from web3 import AsyncHTTPProvider, AsyncWeb3
        except ImportError as exc:  # pragma: no cover - env-dependent
            raise ChainConfigurationError(
                "web3.py is required for live Polygon RPC access but is not "
                "installed; install the 'web3' package (declared in "
                "pyproject.toml) to enable chain reads"
            ) from exc
        # request_kwargs carries the per-request timeout; the URL is never
        # logged by this adapter.
        self._provider = AsyncHTTPProvider(
            rpc_url,
            request_kwargs={"timeout": request_timeout_seconds},
        )
        self._w3 = AsyncWeb3(self._provider)

    @property
    def label(self) -> str:
        return self._label

    async def chain_id(self) -> int:
        try:
            return int(await self._w3.eth.chain_id)
        except Exception as exc:  # pragma: no cover - network path
            raise ChainRpcUnavailableError(
                f"chain_id read failed on endpoint {self._label!r}"
            ) from exc

    async def get_balance(self, address: str, *, block: str = "latest") -> int:
        try:
            return int(await self._w3.eth.get_balance(address, block_identifier=block))
        except Exception as exc:  # pragma: no cover - network path
            raise ChainRpcUnavailableError(
                f"get_balance failed on endpoint {self._label!r}"
            ) from exc

    async def call(self, *, to: str, data: str, block: str = "latest") -> str:
        try:
            result = await self._w3.eth.call(
                {"to": to, "data": data}, block_identifier=block
            )
            return result.hex() if hasattr(result, "hex") else str(result)
        except Exception as exc:  # pragma: no cover - network path
            raise ChainRpcUnavailableError(
                f"eth_call failed on endpoint {self._label!r}"
            ) from exc

    async def estimate_gas(
        self,
        *,
        to: str,
        data: str,
        value: int = 0,
        sender: str | None = None,
    ) -> int:
        tx: dict[str, Any] = {"to": to, "data": data, "value": value}
        if sender is not None:
            tx["from"] = sender
        try:
            return int(await self._w3.eth.estimate_gas(tx))
        except Exception as exc:  # pragma: no cover - network path
            raise ChainRpcUnavailableError(
                f"estimate_gas failed on endpoint {self._label!r}"
            ) from exc

    async def gas_price(self) -> int:
        try:
            return int(await self._w3.eth.gas_price)
        except Exception as exc:  # pragma: no cover - network path
            raise ChainRpcUnavailableError(
                f"gas_price failed on endpoint {self._label!r}"
            ) from exc

    async def get_transaction(self, tx_hash: str) -> Mapping[str, Any] | None:
        try:
            tx = await self._w3.eth.get_transaction(tx_hash)
        except Exception as exc:  # pragma: no cover - network path
            # web3 raises TransactionNotFound (subclass of Exception) when the
            # tx is unknown; treat that as "not found" rather than transport
            # failure by name to avoid importing web3 exception types here.
            if type(exc).__name__ == "TransactionNotFound":
                return None
            raise ChainRpcUnavailableError(
                f"get_transaction failed on endpoint {self._label!r}"
            ) from exc
        return dict(tx) if tx is not None else None

    async def get_transaction_receipt(
        self, tx_hash: str
    ) -> Mapping[str, Any] | None:
        try:
            receipt = await self._w3.eth.get_transaction_receipt(tx_hash)
        except Exception as exc:  # pragma: no cover - network path
            if type(exc).__name__ == "TransactionNotFound":
                return None
            raise ChainRpcUnavailableError(
                f"get_transaction_receipt failed on endpoint {self._label!r}"
            ) from exc
        return dict(receipt) if receipt is not None else None

    async def get_transaction_count(
        self, address: str, *, block: str = "latest"
    ) -> int:
        try:
            return int(
                await self._w3.eth.get_transaction_count(
                    address, block_identifier=block
                )
            )
        except Exception as exc:  # pragma: no cover - network path
            raise ChainRpcUnavailableError(
                f"get_transaction_count failed on endpoint {self._label!r}"
            ) from exc

    async def block_number(self) -> int:
        try:
            return int(await self._w3.eth.block_number)
        except Exception as exc:  # pragma: no cover - network path
            raise ChainRpcUnavailableError(
                f"block_number failed on endpoint {self._label!r}"
            ) from exc

    async def aclose(self) -> None:
        # AsyncHTTPProvider manages its own session lifecycle; expose a no-op
        # close hook so the port contract is uniform across adapters/fakes.
        disconnect = getattr(self._provider, "disconnect", None)
        if disconnect is not None:  # pragma: no cover - network path
            result = disconnect()
            if hasattr(result, "__await__"):
                await result


__all__ = ["Web3Rpc"]
