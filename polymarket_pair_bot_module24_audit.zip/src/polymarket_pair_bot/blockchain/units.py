"""Exact base-unit <-> Decimal conversions for on-chain quantities (Module 16).

Every monetary / quantity conversion here is exact: it uses ``int`` base units
and :class:`~decimal.Decimal`. Binary floating point is never used for money,
token quantities or gas-cost conversions (project safety rule).

* Native gas (POL/MATIC) has 18 decimals (``wei``).
* USDC collateral has 6 decimals on Polygon.
* Polymarket outcome tokens are ERC-1155 positions; their display precision is
  operator-configured (default 6) and passed in explicitly -- never guessed.
"""

from __future__ import annotations

from decimal import ROUND_FLOOR, Decimal

NATIVE_DECIMALS: int = 18
WEI_PER_NATIVE: int = 10**NATIVE_DECIMALS


def _require_non_negative_int(name: str, value: int) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise TypeError(f"{name} must be an int base-unit value")
    if value < 0:
        raise ValueError(f"{name} must be non-negative, got {value}")
    return value


def base_units_to_decimal(base_units: int, decimals: int) -> Decimal:
    """Convert an integer base-unit amount to an exact Decimal.

    ``decimals`` is the token's on-chain precision (e.g. 6 for USDC, 18 for
    native gas). The result is exact -- no rounding, no float.
    """
    _require_non_negative_int("base_units", base_units)
    if decimals < 0:
        raise ValueError("decimals must be non-negative")
    if decimals == 0:
        return Decimal(base_units)
    return Decimal(base_units) / (Decimal(10) ** decimals)


def decimal_to_base_units(amount: Decimal, decimals: int) -> int:
    """Convert a Decimal amount to integer base units, flooring any remainder.

    Flooring is deliberate and conservative: it never overstates a balance or
    an amount to spend.
    """
    if amount < 0:
        raise ValueError("amount must be non-negative")
    if decimals < 0:
        raise ValueError("decimals must be non-negative")
    scaled = amount * (Decimal(10) ** decimals)
    return int(scaled.to_integral_value(rounding=ROUND_FLOOR))


def wei_to_native(wei: int) -> Decimal:
    """Convert wei (native-gas base units) to an exact Decimal amount of POL."""
    return base_units_to_decimal(wei, NATIVE_DECIMALS)


__all__ = [
    "NATIVE_DECIMALS",
    "WEI_PER_NATIVE",
    "base_units_to_decimal",
    "decimal_to_base_units",
    "wei_to_native",
]
