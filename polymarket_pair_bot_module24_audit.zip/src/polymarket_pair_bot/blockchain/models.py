"""Validated result models for the Polygon wallet-state service (Module 16).

All monetary / quantity fields are exact :class:`~decimal.Decimal` values plus
the integer base units they were derived from. External RPC payloads are
validated at the boundary before any of these models are constructed, so the
rest of the service works with trusted, typed data.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum


class TransactionStatus(str, Enum):
    """Classification of a submitted transaction's observable state.

    * ``PENDING``   -- seen in the mempool, not yet mined.
    * ``SUCCESS``   -- mined, receipt status == 1.
    * ``REVERTED``  -- mined, receipt status == 0.
    * ``REPLACED``  -- our hash never mined but the sender nonce advanced past
      it (another transaction took the slot; e.g. a speed-up/cancel).
    * ``DROPPED``   -- not in the mempool and the nonce has not advanced; the
      transaction appears to have been evicted.
    * ``UNKNOWN``   -- insufficient information; the caller must reconcile.
    """

    PENDING = "pending"
    SUCCESS = "success"
    REVERTED = "reverted"
    REPLACED = "replaced"
    DROPPED = "dropped"
    UNKNOWN = "unknown"

    @property
    def is_terminal(self) -> bool:
        return self in {
            TransactionStatus.SUCCESS,
            TransactionStatus.REVERTED,
            TransactionStatus.REPLACED,
            TransactionStatus.DROPPED,
        }


@dataclass(frozen=True, slots=True)
class TokenAmount:
    """An on-chain amount: exact base units plus a Decimal display value."""

    base_units: int
    decimals: int
    amount: Decimal


@dataclass(frozen=True, slots=True)
class ChainIdentity:
    """Observed chain id per endpoint and the agreed value."""

    chain_id: int
    primary: int
    secondary: int | None = None


@dataclass(frozen=True, slots=True)
class TransactionOutcome:
    """The classified outcome of waiting on / inspecting a transaction."""

    tx_hash: str
    status: TransactionStatus
    block_number: int | None = None
    gas_used: int | None = None
    confirmations: int = 0
    detail: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.status is TransactionStatus.SUCCESS


@dataclass(frozen=True, slots=True)
class SimulationResult:
    """Result of an ``eth_call`` dry-run of a transaction."""

    success: bool
    return_data: str | None = None
    revert_reason: str | None = None


@dataclass(frozen=True, slots=True)
class GasEstimate:
    """A gas estimate plus a conservative buffered limit and cost.

    ``gas_price_wei`` and ``max_cost_native`` are exact; the cost applies the
    configured Decimal buffer and is intended as an upper bound for reserve
    checks, never a profitability claim.
    """

    gas_limit: int
    buffered_gas_limit: int
    gas_price_wei: int | None = None
    max_cost_wei: int | None = None
    max_cost_native: Decimal | None = None


@dataclass(frozen=True, slots=True)
class WalletStateSnapshot:
    """Aggregate read-only view of the trading wallet at a point in time.

    ``degraded`` is True when only one RPC endpoint could be consulted for at
    least one field (comparison could not be performed); the caller decides
    whether that is acceptable.
    """

    wallet_address: str
    chain_id: int
    native_gas: TokenAmount
    collateral: TokenAmount | None = None
    token_balances: dict[str, TokenAmount] = field(default_factory=dict)
    allowances: dict[str, TokenAmount] = field(default_factory=dict)
    nonce_latest: int | None = None
    nonce_pending: int | None = None
    degraded: bool = False
    notes: tuple[str, ...] = ()


__all__ = [
    "ChainIdentity",
    "GasEstimate",
    "SimulationResult",
    "TokenAmount",
    "TransactionOutcome",
    "TransactionStatus",
    "WalletStateSnapshot",
]
