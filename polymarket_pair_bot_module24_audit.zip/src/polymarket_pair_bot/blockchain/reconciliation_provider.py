"""Adapt the wallet-state service to reconciliation's ChainStateProvider port.

Module 15 (reconciliation) depends on a ``ChainStateProvider`` Protocol
(``async load(tokens) -> ChainState``) and until now shipped only a
``BlockedChainStateProvider`` because the on-chain reader (this module) did not
exist. This adapter is the real provider: it reads collateral and per-token
balances via :class:`WalletStateService` and maps them into reconciliation's
:class:`ChainState`.

Interface note: this is purely additive. It implements the existing
``ChainStateProvider`` Protocol structurally; no reconciliation interface is
changed. Wiring it into the reconciliation CLI/service in place of
``BlockedChainStateProvider`` is left to the operator/next module -- this file
only provides the capability.

Fail-closed behaviour: any chain error (RPC unavailable, disagreement,
misconfiguration) is converted into ``ChainState(available=False, note=...)``
rather than a fabricated balance, exactly matching how reconciliation already
treats an unavailable on-chain source (it escalates to manual review when
``require_chain_verification`` is set).
"""

from __future__ import annotations

from collections.abc import Sequence

from polymarket_pair_bot.blockchain.errors import ChainError
from polymarket_pair_bot.blockchain.service import WalletStateService
from polymarket_pair_bot.domain.value_objects import TokenId
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.reconciliation.models import ChainState

_LOGGER = get_logger("blockchain.reconciliation_provider")


class WalletServiceChainStateProvider:
    """A reconciliation ``ChainStateProvider`` backed by the wallet service."""

    def __init__(
        self,
        service: WalletStateService,
        *,
        include_collateral: bool = True,
    ) -> None:
        self._service = service
        self._include_collateral = include_collateral

    async def load(self, tokens: Sequence[TokenId]) -> ChainState:
        token_ids = tuple(str(token) for token in tokens)
        try:
            snapshot = await self._service.get_wallet_snapshot(
                token_ids=token_ids,
                include_collateral=self._include_collateral,
            )
        except ChainError as exc:
            _LOGGER.warning(
                "on-chain wallet read failed; reporting unavailable",
                extra={"error": type(exc).__name__},
            )
            return ChainState(
                available=False,
                note=f"on-chain read failed ({type(exc).__name__})",
            )
        token_balances = {
            token_id: amount.amount
            for token_id, amount in snapshot.token_balances.items()
        }
        collateral = (
            snapshot.collateral.amount if snapshot.collateral is not None else None
        )
        note = "; ".join(snapshot.notes) if snapshot.notes else None
        if snapshot.degraded:
            note = "; ".join(
                filter(None, [note, "degraded: single-RPC read"])
            )
        return ChainState(
            token_balances=token_balances,
            collateral_balance=collateral,
            pending_txs=(),
            available=True,
            note=note,
        )


__all__ = ["WalletServiceChainStateProvider"]
