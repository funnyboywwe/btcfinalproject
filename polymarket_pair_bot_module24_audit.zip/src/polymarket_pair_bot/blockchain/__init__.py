"""Polygon RPC and read-only wallet-state service (Module 16).

This package reads the dedicated trading wallet's on-chain state from Polygon
over a resilient dual-RPC layer (bounded retries + circuit breakers), verifies
the chain id, cross-checks primary/secondary endpoints under an explicit
tolerance policy, classifies transaction status (including replaced/dropped/
reverted), simulates calls and estimates gas.

It is strictly READ-ONLY. Conditional-token split/merge/redeem (the write path)
is intentionally NOT implemented here -- that is Module 21. The private key is
never read or displayed; only the public wallet address is used.

The web3.py dependency is imported lazily inside :mod:`.web3_rpc`, so the
typed ports, models, resilience primitives and service orchestration import and
unit-test cleanly without a blockchain client installed.
"""

from __future__ import annotations

from polymarket_pair_bot.blockchain.errors import (
    ChainConfigurationError,
    ChainError,
    ChainRpcUnavailableError,
    CircuitOpenError,
    InvalidRpcResponseError,
    ReceiptTimeoutError,
    RpcDisagreementError,
    TransactionRevertedError,
    UnsupportedChainOperationError,
)
from polymarket_pair_bot.blockchain.factory import build_wallet_state_service
from polymarket_pair_bot.blockchain.models import (
    ChainIdentity,
    GasEstimate,
    SimulationResult,
    TokenAmount,
    TransactionOutcome,
    TransactionStatus,
    WalletStateSnapshot,
)
from polymarket_pair_bot.blockchain.ports import EthereumRpc
from polymarket_pair_bot.blockchain.reconciliation_provider import (
    WalletServiceChainStateProvider,
)
from polymarket_pair_bot.blockchain.service import (
    ChainReadParams,
    WalletStateService,
)

__all__ = [
    "ChainConfigurationError",
    "ChainError",
    "ChainIdentity",
    "ChainReadParams",
    "ChainRpcUnavailableError",
    "CircuitOpenError",
    "EthereumRpc",
    "GasEstimate",
    "InvalidRpcResponseError",
    "ReceiptTimeoutError",
    "RpcDisagreementError",
    "SimulationResult",
    "TokenAmount",
    "TransactionOutcome",
    "TransactionRevertedError",
    "TransactionStatus",
    "UnsupportedChainOperationError",
    "WalletServiceChainStateProvider",
    "WalletStateService",
    "WalletStateSnapshot",
    "build_wallet_state_service",
]
