"""Composition root for the Polygon wallet-state service (Module 16).

Builds the service from :class:`AppConfig`:

* Resolves the *public* trading wallet address from the account identity
  (Module 15 auth). The private key is never read here (requirement 15).
* Constructs a :class:`Web3Rpc` for the primary and (optional) secondary RPC
  URLs. web3.py is imported lazily inside the adapter, so importing this
  factory never requires web3 to be installed.
* Wraps each endpoint in a circuit breaker + bounded retry policy and combines
  them in a :class:`DualRpcReader` with the configured tolerance.

RPC URLs are :class:`SecretStr`; their plaintext is only read at the moment the
adapter is created and is never logged or placed in an exception.
"""

from __future__ import annotations

import time
from decimal import Decimal

from polymarket_pair_bot.auth.factory import resolve_account_identity
from polymarket_pair_bot.blockchain.dual_rpc import DualRpcReader, Endpoint
from polymarket_pair_bot.blockchain.errors import ChainConfigurationError
from polymarket_pair_bot.blockchain.ports import Clock
from polymarket_pair_bot.blockchain.resilience import CircuitBreaker, RetryPolicy
from polymarket_pair_bot.blockchain.service import ChainReadParams, WalletStateService
from polymarket_pair_bot.blockchain.web3_rpc import Web3Rpc
from polymarket_pair_bot.config import AppConfig


def _endpoint(
    url: str,
    *,
    label: str,
    timeout: float,
    policy: RetryPolicy,
    fail_threshold: int,
    reset_seconds: float,
    clock: Clock,
) -> Endpoint:
    rpc = Web3Rpc(url, label=label, request_timeout_seconds=timeout)
    breaker = CircuitBreaker(
        name=label,
        fail_threshold=fail_threshold,
        reset_seconds=reset_seconds,
        clock=clock,
    )
    return Endpoint(rpc, breaker=breaker, policy=policy)


def build_wallet_state_service(
    config: AppConfig,
    *,
    clock: Clock = time.monotonic,
) -> WalletStateService:
    """Build a live :class:`WalletStateService` from configuration.

    Raises :class:`ChainConfigurationError` if no primary RPC URL is set.
    """
    chain = config.chain
    polygon = config.polygon
    if polygon.polygon_rpc_primary is None:
        raise ChainConfigurationError(
            "POLYGON_RPC_PRIMARY is not configured; a primary Polygon RPC "
            "endpoint is required for chain reads"
        )
    identity = resolve_account_identity(config)
    wallet_address = identity.funder_address

    policy = RetryPolicy(
        max_retries=chain.polygon_rpc_max_retries,
        backoff_base_seconds=chain.polygon_rpc_backoff_base_seconds,
        backoff_max_seconds=chain.polygon_rpc_backoff_max_seconds,
    )
    primary = _endpoint(
        polygon.polygon_rpc_primary.get_secret_value(),
        label="primary",
        timeout=chain.polygon_rpc_timeout_seconds,
        policy=policy,
        fail_threshold=chain.polygon_rpc_circuit_fail_threshold,
        reset_seconds=chain.polygon_rpc_circuit_reset_seconds,
        clock=clock,
    )
    secondary: Endpoint | None = None
    if polygon.polygon_rpc_secondary is not None:
        secondary = _endpoint(
            polygon.polygon_rpc_secondary.get_secret_value(),
            label="secondary",
            timeout=chain.polygon_rpc_timeout_seconds,
            policy=policy,
            fail_threshold=chain.polygon_rpc_circuit_fail_threshold,
            reset_seconds=chain.polygon_rpc_circuit_reset_seconds,
            clock=clock,
        )
    reader = DualRpcReader(
        primary,
        secondary,
        tolerance_base_units=chain.polygon_balance_tolerance_base_units,
        require_secondary=chain.polygon_require_secondary_rpc,
    )
    params = ChainReadParams(
        chain_id=polygon.polygon_chain_id,
        wallet_address=wallet_address,
        usdc_address=chain.polygon_usdc_address,
        usdc_decimals=chain.polygon_usdc_decimals,
        conditional_tokens_address=chain.polygon_conditional_tokens_address,
        outcome_token_decimals=chain.polygon_outcome_token_decimals,
        receipt_timeout_seconds=chain.polygon_receipt_timeout_seconds,
        receipt_poll_interval_seconds=chain.polygon_receipt_poll_interval_seconds,
        required_confirmations=chain.polygon_required_confirmations,
        gas_estimate_buffer=Decimal(chain.polygon_gas_estimate_buffer),
    )
    return WalletStateService(reader, params, clock=clock)


__all__ = ["build_wallet_state_service"]
