"""Error hierarchy for the Polygon RPC / wallet-state service (Module 16).

These let callers distinguish transport problems (retryable) from semantic /
safety problems (fail closed). No error message ever contains a private key,
an RPC URL (which may embed a provider API key), or any secret material.
"""

from __future__ import annotations


class ChainError(RuntimeError):
    """Base class for all wallet-state / chain-read failures."""


class ChainConfigurationError(ChainError):
    """Required chain configuration is missing or inconsistent.

    Raised, for example, when a contract address needed for a read is not
    configured (the service refuses to guess Polymarket's contract addresses),
    or when the connected chain id does not match the configured one.
    """


class ChainRpcUnavailableError(ChainError):
    """An RPC endpoint could not be reached after bounded retries.

    Treated as 'unknown' -> the caller must fail closed rather than assume a
    balance, nonce or transaction outcome.
    """


class CircuitOpenError(ChainRpcUnavailableError):
    """The circuit breaker for an endpoint is open; the call was not attempted."""


class RpcDisagreementError(ChainError):
    """Primary and secondary RPC endpoints disagreed beyond tolerance.

    Balances/nonces that disagree beyond the configured tolerance are a
    fail-closed condition: the bot must not trade on an ambiguous view of the
    wallet.
    """


class InvalidRpcResponseError(ChainError):
    """An RPC response failed runtime validation (shape/type/range)."""


class ReceiptTimeoutError(ChainError):
    """A transaction receipt did not appear within the allotted timeout.

    The transaction's true status is unknown; the caller must reconcile.
    """


class TransactionRevertedError(ChainError):
    """A mined transaction reverted (receipt status == 0)."""


class UnsupportedChainOperationError(ChainError):
    """A chain operation is intentionally not implemented in this module.

    Used for the split/merge/redeem write path (Module 21) and for any adapter
    method whose package behaviour cannot be verified here. The message names
    the blocked operation and points at the owning module.
    """

    def __init__(self, operation: str, detail: str = "") -> None:
        self.operation = operation
        message = f"chain operation {operation!r} is not supported here"
        if detail:
            message = f"{message}: {detail}"
        super().__init__(message)


__all__ = [
    "ChainConfigurationError",
    "ChainError",
    "ChainRpcUnavailableError",
    "CircuitOpenError",
    "InvalidRpcResponseError",
    "ReceiptTimeoutError",
    "RpcDisagreementError",
    "TransactionRevertedError",
    "UnsupportedChainOperationError",
]
