"""Bounded retries and a circuit breaker for read-only RPC calls (Module 16).

These primitives are deliberately transport-agnostic and injectable (clock,
sleep, rng) so tests exercise every branch deterministically without real
delays or real network access. They wrap *idempotent, read-only* operations
only; there is no retry logic for state-changing calls in this module.

Design choices that follow the project safety rules:

* Retries are bounded and only cover explicitly transient exceptions. A
  non-transient error fails fast (fail closed).
* The circuit breaker fails closed: once open it rejects calls with
  :class:`CircuitOpenError` until a cooldown elapses, then allows a single
  half-open trial before closing again.
* Everything is cancellation-safe: the only await points are the injected
  ``sleep`` calls, which propagate ``asyncio.CancelledError``.
"""

from __future__ import annotations

import asyncio
import random
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import Enum
from typing import TypeVar

from polymarket_pair_bot.blockchain.errors import (
    ChainRpcUnavailableError,
    CircuitOpenError,
)
from polymarket_pair_bot.blockchain.ports import Clock, Sleep
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("blockchain.resilience")

T = TypeVar("T")


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass(slots=True)
class RetryPolicy:
    """Bounded exponential-backoff-with-jitter retry configuration."""

    max_retries: int = 3
    backoff_base_seconds: float = 0.5
    backoff_max_seconds: float = 8.0

    def __post_init__(self) -> None:
        if self.max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if self.backoff_base_seconds <= 0 or self.backoff_max_seconds <= 0:
            raise ValueError("backoff seconds must be positive")
        if self.backoff_max_seconds < self.backoff_base_seconds:
            raise ValueError("backoff_max must be >= backoff_base")

    def delay_for(self, attempt: int, rng: Callable[[], float]) -> float:
        ceiling = min(self.backoff_max_seconds, self.backoff_base_seconds * (2**attempt))
        return rng() * ceiling


class CircuitBreaker:
    """A simple per-endpoint circuit breaker with a half-open trial state."""

    def __init__(
        self,
        *,
        name: str,
        fail_threshold: int = 5,
        reset_seconds: float = 30.0,
        clock: Clock,
    ) -> None:
        if fail_threshold <= 0:
            raise ValueError("fail_threshold must be positive")
        if reset_seconds <= 0:
            raise ValueError("reset_seconds must be positive")
        self._name = name
        self._fail_threshold = fail_threshold
        self._reset_seconds = reset_seconds
        self._clock = clock
        self._state = CircuitState.CLOSED
        self._failures = 0
        self._opened_at: float | None = None

    @property
    def state(self) -> CircuitState:
        return self._state

    def _maybe_half_open(self) -> None:
        if self._state is CircuitState.OPEN and self._opened_at is not None:
            if self._clock() - self._opened_at >= self._reset_seconds:
                self._state = CircuitState.HALF_OPEN

    def before_call(self) -> None:
        """Raise :class:`CircuitOpenError` if calls are currently disallowed."""
        self._maybe_half_open()
        if self._state is CircuitState.OPEN:
            raise CircuitOpenError(
                f"circuit for endpoint {self._name!r} is open"
            )

    def record_success(self) -> None:
        self._failures = 0
        self._opened_at = None
        self._state = CircuitState.CLOSED

    def record_failure(self) -> None:
        self._failures += 1
        if (
            self._state is CircuitState.HALF_OPEN
            or self._failures >= self._fail_threshold
        ):
            self._state = CircuitState.OPEN
            self._opened_at = self._clock()
            _LOGGER.warning(
                "circuit opened",
                extra={"endpoint": self._name, "failures": self._failures},
            )


async def guarded_read(
    operation: str,
    func: Callable[[], Awaitable[T]],
    *,
    breaker: CircuitBreaker,
    policy: RetryPolicy,
    transient: tuple[type[BaseException], ...],
    sleep: Sleep = asyncio.sleep,
    rng: Callable[[], float] = random.random,
) -> T:
    """Run ``func`` with circuit-breaker protection and bounded retries.

    Only exceptions in ``transient`` are retried; anything else propagates
    immediately (fail fast). ``CircuitOpenError`` from the breaker is raised
    before any attempt when the circuit is open.
    """
    breaker.before_call()
    last_error: BaseException | None = None
    for attempt in range(policy.max_retries + 1):
        try:
            result = await func()
        except transient as exc:  # type: ignore[misc]
            last_error = exc
            breaker.record_failure()
            if attempt >= policy.max_retries:
                break
            delay = policy.delay_for(attempt, rng)
            _LOGGER.warning(
                "rpc read transient failure; retrying",
                extra={
                    "operation": operation,
                    "endpoint": breaker._name,
                    "attempt": attempt,
                    "delay": delay,
                },
            )
            await sleep(delay)
            breaker.before_call()
            continue
        else:
            breaker.record_success()
            return result
    raise ChainRpcUnavailableError(
        f"operation {operation!r} failed after {policy.max_retries + 1} attempt(s): "
        f"{type(last_error).__name__ if last_error else 'unknown'}"
    )


__all__ = [
    "CircuitBreaker",
    "CircuitState",
    "RetryPolicy",
    "guarded_read",
]
