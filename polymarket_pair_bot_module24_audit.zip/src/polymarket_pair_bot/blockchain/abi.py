"""Minimal, dependency-free ABI encoding for read-only contract calls (Module 16).

We intentionally hand-encode calldata for a tiny, well-known set of *read-only*
ERC-20 / ERC-1155 view functions instead of pulling in a full ABI/contract
layer. The 4-byte selectors below are the standard, publicly documented
selectors for these canonical functions; they are stable across every
compliant token. Encoding is pure and fully unit-testable offline.

This module NEVER encodes a state-changing call (transfer/approve/merge/etc.):
those belong to the CTF write path (Module 21) and are deliberately absent.
"""

from __future__ import annotations

# Standard function selectors (first 4 bytes of keccak256 of the signature).
# balanceOf(address)             -> 0x70a08231
# allowance(address,address)     -> 0xdd62ed3e
# balanceOf(address,uint256)     -> 0x00fdd58e   (ERC-1155)
SELECTOR_ERC20_BALANCE_OF = "70a08231"
SELECTOR_ERC20_ALLOWANCE = "dd62ed3e"
SELECTOR_ERC1155_BALANCE_OF = "00fdd58e"

_ADDRESS_HEX_LEN = 40


def _clean_address(address: str) -> str:
    candidate = address.strip().lower()
    if candidate.startswith("0x"):
        candidate = candidate[2:]
    if len(candidate) != _ADDRESS_HEX_LEN or any(
        c not in "0123456789abcdef" for c in candidate
    ):
        raise ValueError("address must be 0x + 40 hex characters")
    return candidate


def _encode_address(address: str) -> str:
    return _clean_address(address).rjust(64, "0")


def _encode_uint256(value: int) -> str:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("uint256 value must be an int")
    if value < 0:
        raise ValueError("uint256 value must be non-negative")
    if value >= 2**256:
        raise ValueError("uint256 value out of range")
    return format(value, "064x")


def encode_erc20_balance_of(owner: str) -> str:
    """Calldata for ERC-20 ``balanceOf(owner)``."""
    return "0x" + SELECTOR_ERC20_BALANCE_OF + _encode_address(owner)


def encode_erc20_allowance(owner: str, spender: str) -> str:
    """Calldata for ERC-20 ``allowance(owner, spender)``."""
    return (
        "0x"
        + SELECTOR_ERC20_ALLOWANCE
        + _encode_address(owner)
        + _encode_address(spender)
    )


def encode_erc1155_balance_of(owner: str, token_id: int) -> str:
    """Calldata for ERC-1155 ``balanceOf(owner, id)``."""
    return (
        "0x"
        + SELECTOR_ERC1155_BALANCE_OF
        + _encode_address(owner)
        + _encode_uint256(token_id)
    )


def decode_uint256(return_data: str) -> int:
    """Decode a 32-byte (or shorter) hex return value into a non-negative int."""
    if return_data is None:
        raise ValueError("empty return data")
    raw = return_data.strip()
    if raw.startswith("0x"):
        raw = raw[2:]
    if raw == "":
        raise ValueError("empty return data")
    if any(c not in "0123456789abcdefABCDEF" for c in raw):
        raise ValueError("return data is not valid hex")
    if len(raw) > 64:
        raw = raw[-64:]
    return int(raw, 16)


__all__ = [
    "SELECTOR_ERC1155_BALANCE_OF",
    "SELECTOR_ERC20_ALLOWANCE",
    "SELECTOR_ERC20_BALANCE_OF",
    "decode_uint256",
    "encode_erc1155_balance_of",
    "encode_erc20_allowance",
    "encode_erc20_balance_of",
]
