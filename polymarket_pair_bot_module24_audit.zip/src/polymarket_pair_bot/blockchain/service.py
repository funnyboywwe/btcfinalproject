"""High-level read-only Polygon wallet-state service (Module 16).

This is the module's public surface. It composes a :class:`DualRpcReader`
(primary + optional secondary endpoints, each with bounded retries and a
circuit breaker) and exposes typed, validated reads of the dedicated trading
wallet:

* Polygon chain-id verification (requirement 1).
* Native gas balance, USDC collateral balance, Up/Down outcome-token balances,
  ERC-20 allowances, transaction status and nonce (requirement 3).
* Transaction simulation via ``eth_call`` (requirement 8).
* Gas estimation with a conservative Decimal buffer (requirement 9).
* Receipt waiting with timeout (requirement 10) and replaced/dropped/reverted
  detection (requirement 11).

Safety:

* It is strictly read-only. There is NO split/merge/redeem here (requirement
  12); the blocked :meth:`submit_ctf_operation` documents the boundary.
* It only ever needs the *public* wallet address, never the private key
  (requirement 15).
* Money/quantities use Decimal + integer base units throughout; no floats.
* Missing contract configuration fails closed with a typed error rather than
  guessing an address.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from decimal import ROUND_CEILING, Decimal
from typing import NoReturn

from polymarket_pair_bot.blockchain import abi
from polymarket_pair_bot.blockchain.dual_rpc import Conservative, DualRpcReader
from polymarket_pair_bot.blockchain.errors import (
    ChainConfigurationError,
    ReceiptTimeoutError,
    UnsupportedChainOperationError,
)
from polymarket_pair_bot.blockchain.models import (
    ChainIdentity,
    GasEstimate,
    SimulationResult,
    TokenAmount,
    TransactionOutcome,
    TransactionStatus,
    WalletStateSnapshot,
)
from polymarket_pair_bot.blockchain.ports import Clock, EthereumRpc, Sleep
from polymarket_pair_bot.blockchain.tx_status import classify_transaction
from polymarket_pair_bot.blockchain.units import (
    base_units_to_decimal,
    wei_to_native,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("blockchain.service")

# Selector for Solidity's Error(string) revert payload: keccak('Error(string)')
# first 4 bytes. Standard and stable; used only to decode a revert reason.
_ERROR_STRING_SELECTOR = "08c379a0"


@dataclass(frozen=True, slots=True)
class ChainReadParams:
    """Immutable parameters for the service (derived from ChainReadSettings)."""

    chain_id: int
    wallet_address: str
    usdc_address: str | None = None
    usdc_decimals: int = 6
    conditional_tokens_address: str | None = None
    outcome_token_decimals: int = 6
    receipt_timeout_seconds: float = 120.0
    receipt_poll_interval_seconds: float = 2.0
    required_confirmations: int = 1
    gas_estimate_buffer: Decimal = field(default_factory=lambda: Decimal("1.25"))


class WalletStateService:
    """Read-only wallet-state service over a dual-RPC reader."""

    def __init__(
        self,
        reader: DualRpcReader,
        params: ChainReadParams,
        *,
        clock: Clock,
        sleep: Sleep = asyncio.sleep,
    ) -> None:
        self._reader = reader
        self._p = params
        self._clock = clock
        self._sleep = sleep

    # -- chain identity ---------------------------------------------------

    async def verify_chain_id(self) -> ChainIdentity:
        """Read and cross-check the chain id; fail closed on mismatch."""
        outcome = await self._reader.read_exact(
            "chain_id", lambda rpc: rpc.chain_id()
        )
        if outcome.value != self._p.chain_id:
            raise ChainConfigurationError(
                f"connected chain id {outcome.value} does not match configured "
                f"chain id {self._p.chain_id}"
            )
        return ChainIdentity(
            chain_id=outcome.value,
            primary=outcome.primary,
            secondary=outcome.secondary,
        )

    # -- balances ---------------------------------------------------------

    async def get_native_gas_balance(self) -> TokenAmount:
        outcome = await self._reader.read_int(
            "native_balance",
            lambda rpc: rpc.get_balance(self._p.wallet_address),
            conservative=Conservative.MIN,
        )
        return TokenAmount(
            base_units=outcome.value,
            decimals=18,
            amount=wei_to_native(outcome.value),
        )

    async def get_collateral_balance(self) -> TokenAmount:
        address = self._require_contract(
            self._p.usdc_address, "USDC collateral", "POLYGON_USDC_ADDRESS"
        )
        data = abi.encode_erc20_balance_of(self._p.wallet_address)
        outcome = await self._reader.read_int(
            "collateral_balance",
            lambda rpc: self._call_uint(rpc, to=address, data=data),
            conservative=Conservative.MIN,
        )
        return TokenAmount(
            base_units=outcome.value,
            decimals=self._p.usdc_decimals,
            amount=base_units_to_decimal(outcome.value, self._p.usdc_decimals),
        )

    async def get_token_balance(self, token_id: str) -> TokenAmount:
        """Read an ERC-1155 outcome-token balance (Up or Down) by token id."""
        address = self._require_contract(
            self._p.conditional_tokens_address,
            "conditional tokens",
            "POLYGON_CONDITIONAL_TOKENS_ADDRESS",
        )
        token_int = _parse_token_id(token_id)
        data = abi.encode_erc1155_balance_of(self._p.wallet_address, token_int)
        outcome = await self._reader.read_int(
            "token_balance",
            lambda rpc: self._call_uint(rpc, to=address, data=data),
            conservative=Conservative.MIN,
        )
        return TokenAmount(
            base_units=outcome.value,
            decimals=self._p.outcome_token_decimals,
            amount=base_units_to_decimal(
                outcome.value, self._p.outcome_token_decimals
            ),
        )

    async def get_allowance(
        self, *, spender: str, token_address: str | None = None
    ) -> TokenAmount:
        """Read an ERC-20 allowance (defaults to the USDC collateral token)."""
        address = token_address or self._require_contract(
            self._p.usdc_address, "USDC collateral", "POLYGON_USDC_ADDRESS"
        )
        data = abi.encode_erc20_allowance(self._p.wallet_address, spender)
        outcome = await self._reader.read_int(
            "allowance",
            lambda rpc: self._call_uint(rpc, to=address, data=data),
            conservative=Conservative.MIN,
        )
        return TokenAmount(
            base_units=outcome.value,
            decimals=self._p.usdc_decimals,
            amount=base_units_to_decimal(outcome.value, self._p.usdc_decimals),
        )

    async def get_nonce(self, *, pending: bool = False) -> int:
        block = "pending" if pending else "latest"
        outcome = await self._reader.read_int(
            f"nonce_{block}",
            lambda rpc: rpc.get_transaction_count(
                self._p.wallet_address, block=block
            ),
            conservative=Conservative.MAX,
        )
        return outcome.value

    # -- transactions -----------------------------------------------------

    async def get_transaction_status(
        self, tx_hash: str, *, expected_nonce: int | None = None
    ) -> TransactionOutcome:
        """Classify a transaction (pending/success/reverted/replaced/dropped)."""
        receipt = await self._reader.read_primary(
            "tx_receipt", lambda rpc: rpc.get_transaction_receipt(tx_hash)
        )
        tx = await self._reader.read_primary(
            "tx_lookup", lambda rpc: rpc.get_transaction(tx_hash)
        )
        latest_nonce: int | None = None
        latest_block: int | None = None
        if receipt is None and tx is None:
            latest_nonce = await self.get_nonce()
        if receipt is not None:
            latest_block = await self._reader.read_primary(
                "block_number", lambda rpc: rpc.block_number()
            )
        return classify_transaction(
            tx_hash=tx_hash,
            receipt=dict(receipt) if receipt is not None else None,
            tx_present=tx is not None,
            latest_nonce=latest_nonce,
            expected_nonce=expected_nonce,
            latest_block=latest_block,
            required_confirmations=self._p.required_confirmations,
        )

    async def wait_for_receipt(
        self,
        tx_hash: str,
        *,
        expected_nonce: int | None = None,
        timeout_seconds: float | None = None,
        poll_interval_seconds: float | None = None,
    ) -> TransactionOutcome:
        """Poll until the transaction reaches a terminal status or times out.

        Cancellation-safe: the only await points are the injected ``sleep`` and
        the read calls. On timeout raises :class:`ReceiptTimeoutError` -- the
        true status is unknown and the caller must reconcile.
        """
        timeout = (
            timeout_seconds
            if timeout_seconds is not None
            else self._p.receipt_timeout_seconds
        )
        interval = (
            poll_interval_seconds
            if poll_interval_seconds is not None
            else self._p.receipt_poll_interval_seconds
        )
        deadline = self._clock() + timeout
        while True:
            outcome = await self.get_transaction_status(
                tx_hash, expected_nonce=expected_nonce
            )
            if outcome.status.is_terminal:
                if (
                    outcome.status is TransactionStatus.SUCCESS
                    and outcome.confirmations < self._p.required_confirmations
                ):
                    # Mined but not yet deep enough; keep waiting.
                    pass
                else:
                    return outcome
            if self._clock() >= deadline:
                raise ReceiptTimeoutError(
                    f"transaction {tx_hash} did not confirm within "
                    f"{timeout:g}s (last status: {outcome.status.value})"
                )
            await self._sleep(interval)

    async def simulate(
        self, *, to: str, data: str, block: str = "latest"
    ) -> SimulationResult:
        """Dry-run a call via ``eth_call`` (read-only). Never broadcasts."""
        try:
            raw = await self._reader.read_primary(
                "simulate", lambda rpc: rpc.call(to=to, data=data, block=block)
            )
        except Exception as exc:  # noqa: BLE001 - surfaced as a failed sim
            return SimulationResult(
                success=False, revert_reason=_short_reason(str(exc))
            )
        return SimulationResult(success=True, return_data=raw)

    async def estimate_gas(
        self, *, to: str, data: str, value: int = 0, sender: str | None = None
    ) -> GasEstimate:
        """Estimate gas and compute a conservative buffered upper-bound cost."""
        gas = await self._reader.read_primary(
            "estimate_gas",
            lambda rpc: rpc.estimate_gas(
                to=to, data=data, value=value, sender=sender or self._p.wallet_address
            ),
        )
        buffered = int(
            (Decimal(gas) * self._p.gas_estimate_buffer).to_integral_value(
                rounding=ROUND_CEILING
            )
        )
        price = await self._reader.read_primary(
            "gas_price", lambda rpc: rpc.gas_price()
        )
        max_cost_wei = buffered * price
        return GasEstimate(
            gas_limit=gas,
            buffered_gas_limit=buffered,
            gas_price_wei=price,
            max_cost_wei=max_cost_wei,
            max_cost_native=wei_to_native(max_cost_wei),
        )

    # -- aggregate snapshot ----------------------------------------------

    async def get_wallet_snapshot(
        self,
        *,
        token_ids: tuple[str, ...] = (),
        allowance_spenders: tuple[str, ...] = (),
        include_collateral: bool = True,
    ) -> WalletStateSnapshot:
        """Aggregate read of the wallet for diagnostics/reconciliation."""
        identity = await self.verify_chain_id()
        native = await self.get_native_gas_balance()
        notes: list[str] = []
        # A single configured RPC endpoint means reads cannot be
        # cross-checked; surface that as a degraded snapshot so callers
        # (e.g. reconciliation) can decide whether it is acceptable.
        degraded = not self._reader.has_secondary
        if degraded:
            notes.append("single RPC endpoint: reads not cross-checked")

        collateral: TokenAmount | None = None
        if include_collateral and self._p.usdc_address is not None:
            collateral = await self.get_collateral_balance()
        elif include_collateral:
            notes.append("collateral skipped: USDC address not configured")

        token_balances: dict[str, TokenAmount] = {}
        for token_id in token_ids:
            token_balances[token_id] = await self.get_token_balance(token_id)

        allowances: dict[str, TokenAmount] = {}
        for spender in allowance_spenders:
            allowances[spender] = await self.get_allowance(spender=spender)

        nonce_latest = await self.get_nonce()
        nonce_pending = await self.get_nonce(pending=True)

        return WalletStateSnapshot(
            wallet_address=self._p.wallet_address,
            chain_id=identity.chain_id,
            native_gas=native,
            collateral=collateral,
            token_balances=token_balances,
            allowances=allowances,
            nonce_latest=nonce_latest,
            nonce_pending=nonce_pending,
            degraded=degraded,
            notes=tuple(notes),
        )

    # -- blocked write path (Module 21) ----------------------------------

    async def submit_ctf_operation(self, *args: object, **kwargs: object) -> NoReturn:
        """Blocked: CTF split/merge/redeem is intentionally not in this module.

        Requirement 12 defers the conditional-token write path to Module 21.
        This method exists so the boundary is explicit and callers get a clear,
        typed refusal instead of a silent gap.
        """
        raise UnsupportedChainOperationError(
            "submit_ctf_operation",
            "split/merge/redeem is implemented in Module 21, not the read-only "
            "wallet-state service",
        )

    async def aclose(self) -> None:
        await self._reader.aclose()

    # -- helpers ----------------------------------------------------------

    async def _call_uint(
        self, rpc: EthereumRpc, *, to: str, data: str
    ) -> int:
        raw = await rpc.call(to=to, data=data)
        return abi.decode_uint256(raw)

    def _require_contract(
        self, address: str | None, label: str, env_name: str
    ) -> str:
        if address is None:
            raise ChainConfigurationError(
                f"{label} contract address is not configured; set {env_name}. "
                "The service refuses to guess on-chain contract addresses."
            )
        return address


def _parse_token_id(token_id: str) -> int:
    candidate = token_id.strip()
    if not candidate or any(c not in "0123456789" for c in candidate):
        raise ValueError("token id must be a base-10 unsigned integer string")
    return int(candidate)


def _short_reason(message: str) -> str:
    text = message.strip().splitlines()[0] if message.strip() else "reverted"
    return text[:200]


__all__ = ["ChainReadParams", "WalletStateService"]
