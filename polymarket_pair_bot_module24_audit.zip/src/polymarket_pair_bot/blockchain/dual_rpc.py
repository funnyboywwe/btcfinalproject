"""Dual-RPC reader: cross-check primary and secondary endpoints (Module 16).

Requirements 4 and 5: read the same value from two independent Polygon RPC
endpoints and reconcile them under an explicit tolerance policy.

Policy (fail closed):

* ``chain_id`` must match *exactly* across endpoints -- any mismatch is a hard
  :class:`RpcDisagreementError` (you are not talking to the same network).
* Integer readings (balances, allowances, nonces) agree when they differ by no
  more than ``tolerance_base_units``. When they agree we return the
  *conservative* value:
    - balances/allowances -> the minimum (never overstate funds),
    - nonces              -> the maximum (never reuse a nonce).
* Disagreement beyond tolerance raises :class:`RpcDisagreementError`.
* When only one endpoint is configured, or the secondary is unavailable
  (circuit open / exhausted retries), the read is returned as ``degraded`` so
  the caller can decide whether a single-source read is acceptable. If
  ``require_secondary`` is set, a missing/failed secondary is instead a hard
  failure.

Each per-endpoint read is wrapped in :func:`guarded_read` (bounded retries +
circuit breaker).
"""

from __future__ import annotations

import asyncio
import random
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import Enum
from typing import Generic, TypeVar

from polymarket_pair_bot.blockchain.errors import (
    ChainRpcUnavailableError,
    RpcDisagreementError,
)
from polymarket_pair_bot.blockchain.ports import EthereumRpc, Sleep
from polymarket_pair_bot.blockchain.resilience import (
    CircuitBreaker,
    RetryPolicy,
    guarded_read,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("blockchain.dual_rpc")

T = TypeVar("T")

# Exceptions treated as transient at the transport layer. OSError covers most
# connection/timeout failures raised by HTTP libraries; TimeoutError covers
# asyncio timeouts. Semantic/validation errors are NOT transient.
_TRANSIENT: tuple[type[BaseException], ...] = (OSError, asyncio.TimeoutError)


class Conservative(str, Enum):
    """Which side to prefer when two readings agree within tolerance."""

    MIN = "min"
    MAX = "max"


@dataclass(frozen=True, slots=True)
class ReadOutcome(Generic[T]):
    """The reconciled value plus provenance for auditing/diagnostics."""

    value: T
    primary: T
    secondary: T | None
    degraded: bool
    note: str | None = None


class Endpoint:
    """One RPC client wrapped with its own circuit breaker + retry policy."""

    def __init__(
        self,
        rpc: EthereumRpc,
        *,
        breaker: CircuitBreaker,
        policy: RetryPolicy,
        sleep: Sleep = asyncio.sleep,
        rng: Callable[[], float] = random.random,
    ) -> None:
        self._rpc = rpc
        self._breaker = breaker
        self._policy = policy
        self._sleep = sleep
        self._rng = rng

    @property
    def label(self) -> str:
        return self._rpc.label

    @property
    def rpc(self) -> EthereumRpc:
        return self._rpc

    async def read(
        self, operation: str, func: Callable[[EthereumRpc], Awaitable[T]]
    ) -> T:
        return await guarded_read(
            operation,
            lambda: func(self._rpc),
            breaker=self._breaker,
            policy=self._policy,
            transient=_TRANSIENT,
            sleep=self._sleep,
            rng=self._rng,
        )

    async def aclose(self) -> None:
        await self._rpc.aclose()


class DualRpcReader:
    """Read a value from both endpoints and reconcile under the tolerance policy."""

    def __init__(
        self,
        primary: Endpoint,
        secondary: Endpoint | None = None,
        *,
        tolerance_base_units: int = 0,
        require_secondary: bool = False,
    ) -> None:
        if tolerance_base_units < 0:
            raise ValueError("tolerance_base_units must be non-negative")
        self._primary = primary
        self._secondary = secondary
        self._tolerance = tolerance_base_units
        self._require_secondary = require_secondary

    @property
    def has_secondary(self) -> bool:
        return self._secondary is not None

    async def read_exact(
        self, operation: str, func: Callable[[EthereumRpc], Awaitable[T]]
    ) -> ReadOutcome[T]:
        """Read a value that must match *exactly* across endpoints (e.g. chain id)."""
        primary = await self._primary.read(operation, func)
        if self._secondary is None:
            self._require_both_or_raise(operation)
            return ReadOutcome(primary, primary, None, degraded=True,
                               note="single endpoint")
        try:
            secondary = await self._secondary.read(operation, func)
        except ChainRpcUnavailableError as exc:
            return self._degraded_or_raise(operation, primary, exc)
        if primary != secondary:
            raise RpcDisagreementError(
                f"{operation}: endpoints disagree ({primary!r} vs {secondary!r})"
            )
        return ReadOutcome(primary, primary, secondary, degraded=False)

    async def read_int(
        self,
        operation: str,
        func: Callable[[EthereumRpc], Awaitable[int]],
        *,
        conservative: Conservative,
    ) -> ReadOutcome[int]:
        """Read an integer base-unit value and reconcile within tolerance."""
        primary = await self._primary.read(operation, func)
        if self._secondary is None:
            self._require_both_or_raise(operation)
            return ReadOutcome(primary, primary, None, degraded=True,
                               note="single endpoint")
        try:
            secondary = await self._secondary.read(operation, func)
        except ChainRpcUnavailableError as exc:
            return self._degraded_or_raise(operation, primary, exc)
        if abs(primary - secondary) > self._tolerance:
            raise RpcDisagreementError(
                f"{operation}: endpoints disagree beyond tolerance "
                f"({primary} vs {secondary}, tolerance={self._tolerance})"
            )
        value = (
            min(primary, secondary)
            if conservative is Conservative.MIN
            else max(primary, secondary)
        )
        return ReadOutcome(value, primary, secondary, degraded=False)

    async def read_primary(
        self, operation: str, func: Callable[[EthereumRpc], Awaitable[T]]
    ) -> T:
        """Read a value from the primary endpoint only (no cross-check).

        Used for inherently node-local reads where cross-checking is not
        meaningful (e.g. gas price, a single eth_call simulation, mempool
        transaction lookups). Still protected by retries + circuit breaker.
        """
        return await self._primary.read(operation, func)

    def _degraded_or_raise(
        self, operation: str, primary: T, exc: ChainRpcUnavailableError
    ) -> ReadOutcome[T]:
        if self._require_secondary:
            raise RpcDisagreementError(
                f"{operation}: secondary endpoint unavailable and "
                "require_secondary is set"
            ) from exc
        _LOGGER.warning(
            "secondary endpoint unavailable; returning degraded primary read",
            extra={"operation": operation, "endpoint": self._secondary.label
                   if self._secondary else "n/a"},
        )
        return ReadOutcome(
            primary, primary, None, degraded=True,
            note="secondary unavailable",
        )

    def _require_both_or_raise(self, operation: str) -> None:
        if self._require_secondary:
            raise RpcDisagreementError(
                f"{operation}: require_secondary is set but no secondary "
                "endpoint is configured"
            )

    async def aclose(self) -> None:
        await self._primary.aclose()
        if self._secondary is not None:
            await self._secondary.aclose()


__all__ = [
    "Conservative",
    "DualRpcReader",
    "Endpoint",
    "ReadOutcome",
]
