"""Typed ports for the Polygon wallet-state service (Module 16).

Dependency inversion: the service depends only on the :class:`EthereumRpc`
Protocol, never on web3.py or any concrete client. The web3-backed adapter
(:mod:`.web3_rpc`) and the in-memory test fakes both satisfy this Protocol.

Every method is a *read-only* JSON-RPC operation. There is deliberately no
method that signs or broadcasts a transaction: the write path (split/merge/
redeem) belongs to Module 21. ``eth_call``/``estimate_gas`` are read-only
simulations and are allowed.

All amounts are integer base units (wei / micro-USDC / raw uint256). Returned
mappings mirror the raw JSON-RPC result and MUST be validated by the caller
before use.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from typing import Any, Protocol, runtime_checkable

Sleep = Callable[[float], Awaitable[None]]
Clock = Callable[[], float]


@runtime_checkable
class EthereumRpc(Protocol):
    """Minimal read-only Polygon JSON-RPC surface used by the service."""

    @property
    def label(self) -> str:
        """Human-readable endpoint label (e.g. 'primary'); never the URL."""
        ...

    async def chain_id(self) -> int: ...

    async def get_balance(self, address: str, *, block: str = "latest") -> int: ...

    async def call(self, *, to: str, data: str, block: str = "latest") -> str: ...

    async def estimate_gas(
        self,
        *,
        to: str,
        data: str,
        value: int = 0,
        sender: str | None = None,
    ) -> int: ...

    async def gas_price(self) -> int: ...

    async def get_transaction(self, tx_hash: str) -> Mapping[str, Any] | None: ...

    async def get_transaction_receipt(
        self, tx_hash: str
    ) -> Mapping[str, Any] | None: ...

    async def get_transaction_count(
        self, address: str, *, block: str = "latest"
    ) -> int: ...

    async def block_number(self) -> int: ...

    async def aclose(self) -> None: ...


__all__ = ["Clock", "EthereumRpc", "Sleep"]
