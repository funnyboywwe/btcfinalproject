"""Read-only wallet-diagnostics CLI (Module 16, requirement 14).

Usage::

    uv run polymarket-pair-bot wallet-diagnostics \\
        [--up-token TOKEN_ID] [--down-token TOKEN_ID] \\
        [--allowance-spender ADDRESS ...] [--json]

It performs ONLY read-only Polygon RPC calls: it verifies the chain id, reads
the native gas balance, USDC collateral, any requested Up/Down token balances,
allowances and the wallet nonce. It never submits a transaction, never signs
anything and never requests or displays the private key (requirement 15). The
RPC URLs (which may embed provider API keys) are never printed either.

Exit code is ``0`` on a clean read and ``1`` when a chain error, RPC
disagreement or misconfiguration prevents a trustworthy read (fail closed), so
operator scripts can gate on it.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Sequence

from polymarket_pair_bot.blockchain.errors import ChainError
from polymarket_pair_bot.blockchain.factory import build_wallet_state_service
from polymarket_pair_bot.blockchain.models import WalletStateSnapshot
from polymarket_pair_bot.config import AppConfig, load_config


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--up-token",
        dest="up_token",
        default=None,
        help="Up outcome-token id (base-10 uint string) to read the balance of.",
    )
    parser.add_argument(
        "--down-token",
        dest="down_token",
        default=None,
        help="Down outcome-token id (base-10 uint string) to read the balance of.",
    )
    parser.add_argument(
        "--allowance-spender",
        action="append",
        default=None,
        dest="allowance_spenders",
        help="Spender address to read the USDC allowance for (repeatable).",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="Emit the diagnostics as JSON.",
    )


def _print_snapshot(snapshot: WalletStateSnapshot, *, as_json: bool) -> None:
    if as_json:
        payload = {
            "wallet_address": snapshot.wallet_address,
            "chain_id": snapshot.chain_id,
            "native_gas": str(snapshot.native_gas.amount),
            "native_gas_wei": snapshot.native_gas.base_units,
            "collateral": (
                str(snapshot.collateral.amount)
                if snapshot.collateral is not None
                else None
            ),
            "token_balances": {
                token_id: str(amount.amount)
                for token_id, amount in snapshot.token_balances.items()
            },
            "allowances": {
                spender: str(amount.amount)
                for spender, amount in snapshot.allowances.items()
            },
            "nonce_latest": snapshot.nonce_latest,
            "nonce_pending": snapshot.nonce_pending,
            "degraded": snapshot.degraded,
            "notes": list(snapshot.notes),
        }
        print(json.dumps(payload, indent=2))
        return
    print(f"wallet diagnostics for {snapshot.wallet_address}")
    print(f"  chain id       : {snapshot.chain_id}")
    print(
        f"  native gas     : {snapshot.native_gas.amount} POL "
        f"({snapshot.native_gas.base_units} wei)"
    )
    if snapshot.collateral is not None:
        print(f"  collateral     : {snapshot.collateral.amount} USDC")
    else:
        print("  collateral     : (USDC address not configured)")
    for token_id, amount in snapshot.token_balances.items():
        print(f"  token {token_id}: {amount.amount}")
    for spender, amount in snapshot.allowances.items():
        print(f"  allowance[{spender}]: {amount.amount} USDC")
    print(f"  nonce (latest) : {snapshot.nonce_latest}")
    print(f"  nonce (pending): {snapshot.nonce_pending}")
    if snapshot.degraded:
        print("  WARNING: degraded read (single RPC endpoint)")
    for note in snapshot.notes:
        print(f"  note: {note}")


async def _run(config: AppConfig, args: argparse.Namespace) -> int:
    token_ids: list[str] = []
    if args.up_token:
        token_ids.append(str(args.up_token))
    if args.down_token:
        token_ids.append(str(args.down_token))
    spenders = tuple(args.allowance_spenders or ())
    service = build_wallet_state_service(config)
    try:
        snapshot = await service.get_wallet_snapshot(
            token_ids=tuple(token_ids),
            allowance_spenders=spenders,
        )
    except ChainError as exc:
        print(f"wallet diagnostics failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    finally:
        await service.aclose()
    _print_snapshot(snapshot, as_json=args.as_json)
    return 0


def run(args: argparse.Namespace) -> int:
    config = load_config()
    return asyncio.run(_run(config, args))


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-wallet-diagnostics",
        description="Read-only Polygon wallet diagnostics.",
    )
    add_arguments(parser)
    return run(parser.parse_args(argv))


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
