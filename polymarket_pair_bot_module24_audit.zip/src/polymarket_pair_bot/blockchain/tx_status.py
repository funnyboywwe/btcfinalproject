"""Pure transaction-status classification (Module 16, requirement 11).

Given the raw (already-validated) transaction + receipt views and the sender's
current on-chain nonce, decide whether a submitted transaction is pending,
mined-success, reverted, replaced or dropped. This logic is intentionally pure
and side-effect free so every branch is unit-tested without a node.

Detection rules (fail closed toward UNKNOWN when ambiguous):

* Receipt present -> SUCCESS if ``status == 1`` else REVERTED.
* No receipt, tx present in mempool -> PENDING.
* No receipt, tx absent:
    - If we know the transaction's own nonce and the sender's latest on-chain
      nonce has advanced past it, the slot was consumed by a *different*
      transaction -> REPLACED (our hash never mined; e.g. a speed-up/cancel).
    - If the nonce has NOT advanced past it, the transaction is gone from the
      mempool without being mined -> DROPPED.
    - If the expected nonce is unknown, we cannot distinguish -> UNKNOWN.
"""

from __future__ import annotations

from polymarket_pair_bot.blockchain.models import (
    TransactionOutcome,
    TransactionStatus,
)


def _receipt_status(raw_status: object) -> int | None:
    """Coerce a receipt ``status`` field (int or 0x-hex) to 0/1, else None."""
    if isinstance(raw_status, bool):
        return int(raw_status)
    if isinstance(raw_status, int):
        return raw_status
    if isinstance(raw_status, str):
        try:
            return int(raw_status, 16) if raw_status.startswith("0x") else int(
                raw_status
            )
        except ValueError:
            return None
    return None


def classify_transaction(
    *,
    tx_hash: str,
    receipt: dict[str, object] | None,
    tx_present: bool,
    latest_nonce: int | None,
    expected_nonce: int | None,
    latest_block: int | None = None,
    required_confirmations: int = 0,
) -> TransactionOutcome:
    """Classify a transaction from its receipt/mempool presence and nonce."""
    if receipt is not None:
        status_val = _receipt_status(receipt.get("status"))
        block_raw = receipt.get("blockNumber")
        block_number = block_raw if isinstance(block_raw, int) else None
        gas_raw = receipt.get("gasUsed")
        gas_used = gas_raw if isinstance(gas_raw, int) else None
        confirmations = 0
        if latest_block is not None and block_number is not None:
            confirmations = max(0, latest_block - block_number + 1)
        if status_val == 1:
            detail = None
            if confirmations < required_confirmations:
                detail = (
                    f"mined but only {confirmations}/{required_confirmations} "
                    "confirmations"
                )
            return TransactionOutcome(
                tx_hash=tx_hash,
                status=TransactionStatus.SUCCESS,
                block_number=block_number,
                gas_used=gas_used,
                confirmations=confirmations,
                detail=detail,
            )
        return TransactionOutcome(
            tx_hash=tx_hash,
            status=TransactionStatus.REVERTED,
            block_number=block_number,
            gas_used=gas_used,
            confirmations=confirmations,
            detail="receipt status == 0",
        )

    if tx_present:
        return TransactionOutcome(
            tx_hash=tx_hash,
            status=TransactionStatus.PENDING,
            detail="in mempool, not yet mined",
        )

    if expected_nonce is not None and latest_nonce is not None:
        if latest_nonce > expected_nonce:
            return TransactionOutcome(
                tx_hash=tx_hash,
                status=TransactionStatus.REPLACED,
                detail=(
                    f"sender nonce advanced to {latest_nonce} past tx nonce "
                    f"{expected_nonce}; hash not mined"
                ),
            )
        return TransactionOutcome(
            tx_hash=tx_hash,
            status=TransactionStatus.DROPPED,
            detail="absent from mempool; nonce not advanced",
        )

    return TransactionOutcome(
        tx_hash=tx_hash,
        status=TransactionStatus.UNKNOWN,
        detail="insufficient information to classify; reconcile",
    )


__all__ = ["classify_transaction"]
