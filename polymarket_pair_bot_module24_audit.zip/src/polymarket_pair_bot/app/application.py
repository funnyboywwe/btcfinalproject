"""Compose configuration, logging, health and services into a runnable app.

Module 0 registers no long-lived trading services yet; the wiring point exists
so later modules can add them without touching the entry point. The application
starts and stops cleanly with zero services and without any secrets.

Module 1 replaces the flat ``Settings`` with the composed ``AppConfig`` and logs
a fully-redacted configuration summary on startup.
"""

from __future__ import annotations

from polymarket_pair_bot.app.lifecycle import LifecycleManager
from polymarket_pair_bot.app.services import Service
from polymarket_pair_bot.config.settings import AppConfig, load_config
from polymarket_pair_bot.observability.logging import configure_logging, get_logger
from polymarket_pair_bot.shared.health import HealthTracker

_log = get_logger(__name__)


def build_lifecycle(config: AppConfig, health: HealthTracker) -> LifecycleManager:
    """Assemble the lifecycle manager and its service set.

    Module 21 (dashboard) additively registers the private read-only operator
    dashboard when ``dashboard_enabled`` is true. It is OFF by default, so the
    default service set stays empty and existing lifecycle tests are unaffected.
    The dashboard is bound to a private interface and never exposes trade
    controls; wiring failures are logged and swallowed (fail-open for a
    diagnostics UI) so they can never block trading startup.
    """
    services: list[Service] = []
    # Later modules register long-lived services here, e.g. market-data feeds,
    # the execution engine, and the reconciliation service.
    if config.dashboard.dashboard_enabled:
        # Imported lazily so the default (dashboard OFF) path never needs the
        # web stack. Uses the placeholder provider until a live aggregator is
        # injected by a later module.
        from polymarket_pair_bot.dashboard.factory import build_dashboard_service

        try:
            services.append(build_dashboard_service(config))
        except Exception:  # noqa: BLE001 - dashboard must never block startup
            _log.exception("dashboard_wiring_failed")
    return LifecycleManager(
        services,
        health=health,
        shutdown_timeout=config.application.shutdown_timeout_seconds,
    )


async def run_app(config: AppConfig | None = None) -> None:
    """Configure logging and run the application lifecycle to completion."""
    config = config or load_config()
    configure_logging(
        level=config.logging.log_level, json_output=config.logging.log_json
    )
    _log.info(
        "application_configuring",
        extra={
            "run_mode": config.run_mode.value,
            # Fully redacted; safe to log.
            "config": config.redacted_summary(),
        },
    )
    health = HealthTracker()
    lifecycle = build_lifecycle(config, health)
    await lifecycle.run()
