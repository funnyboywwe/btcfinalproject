"""Service abstractions for the application lifecycle (dependency inversion).

Concrete services (market data, execution, reconciliation, ...) will be added by
later modules. Each must implement this structural ``Service`` protocol so the
lifecycle manager can start and stop them uniformly without importing concrete
infrastructure classes.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class Service(Protocol):
    """A long-lived component with an async start/stop lifecycle.

    Implementations must be idempotent: calling ``stop`` after a failed or
    partial ``start`` must be safe, and ``stop`` must not raise for a component
    that never fully started.
    """

    @property
    def name(self) -> str: ...

    async def start(self) -> None: ...

    async def stop(self) -> None: ...
