"""Asynchronous application lifecycle management.

Responsibilities:

* Start services in declaration order and stop them in reverse order.
* Install SIGTERM/SIGINT handlers that request a single graceful shutdown.
* Bound every service stop with a configurable timeout (fail closed).
* Own all background tasks via :class:`TaskSupervisor` (no untracked tasks).

This module contains no trading logic and performs no network I/O itself.
"""

from __future__ import annotations

import asyncio
import signal
from collections.abc import Coroutine, Sequence
from typing import Any

from polymarket_pair_bot.app.services import Service
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.shared.health import HealthState, HealthTracker

_log = get_logger(__name__)

_HANDLED_SIGNALS: tuple[signal.Signals, ...] = (signal.SIGTERM, signal.SIGINT)


class TaskSupervisor:
    """Owns every background task so none is left untracked."""

    def __init__(self) -> None:
        self._tasks: set[asyncio.Task[Any]] = set()

    def create_task(
        self, coro: Coroutine[Any, Any, Any], *, name: str | None = None
    ) -> asyncio.Task[Any]:
        """Schedule and track a background task."""
        task = asyncio.create_task(coro, name=name)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return task

    @property
    def active_count(self) -> int:
        return len(self._tasks)

    async def cancel_all(self, timeout: float) -> None:
        """Cancel and await all tracked tasks within ``timeout`` seconds."""
        if not self._tasks:
            return
        for task in list(self._tasks):
            task.cancel()
        await asyncio.wait(set(self._tasks), timeout=timeout)


class LifecycleManager:
    """Coordinates ordered startup, signal-driven and graceful shutdown."""

    def __init__(
        self,
        services: Sequence[Service],
        *,
        health: HealthTracker,
        shutdown_timeout: float,
    ) -> None:
        self._services = list(services)
        self._health = health
        self._shutdown_timeout = shutdown_timeout
        self._shutdown_event = asyncio.Event()
        self._started: list[Service] = []
        self._signals_installed = False

    def request_shutdown(self, reason: str = "manual") -> None:
        """Request a single graceful shutdown (idempotent)."""
        if not self._shutdown_event.is_set():
            _log.info("shutdown_requested", extra={"reason": reason})
            self._shutdown_event.set()

    async def run(self) -> None:
        """Run the full lifecycle until a shutdown is requested."""
        self._install_signal_handlers()
        await self._health.set(HealthState.STARTING, "starting services")
        try:
            await self._start_services()
        except Exception:
            _log.exception("startup_failed")
            await self._health.set(HealthState.DEGRADED, "startup failed")
            await self._shutdown(reason="startup-failure")
            raise
        await self._health.set(HealthState.READY, "all services started")
        _log.info("application_ready", extra={"service_count": len(self._started)})
        await self._shutdown_event.wait()
        await self._shutdown(reason="signal")

    async def _start_services(self) -> None:
        for service in self._services:
            _log.info("service_starting", extra={"service": service.name})
            await service.start()
            self._started.append(service)
            _log.info("service_started", extra={"service": service.name})

    async def _stop_services(self) -> None:
        for service in reversed(self._started):
            _log.info("service_stopping", extra={"service": service.name})
            try:
                await asyncio.wait_for(service.stop(), timeout=self._shutdown_timeout)
            except TimeoutError:
                _log.error("service_stop_timeout", extra={"service": service.name})
            except Exception:  # noqa: BLE001 - keep stopping remaining services
                _log.exception("service_stop_failed", extra={"service": service.name})
            else:
                _log.info("service_stopped", extra={"service": service.name})

    async def _shutdown(self, *, reason: str) -> None:
        await self._health.set(HealthState.STOPPING, f"stopping ({reason})")
        _log.info("application_stopping", extra={"reason": reason})
        await self._stop_services()
        self._remove_signal_handlers()
        _log.info("application_stopped")

    def _install_signal_handlers(self) -> None:
        loop = asyncio.get_running_loop()
        for sig in _HANDLED_SIGNALS:
            try:
                loop.add_signal_handler(sig, self.request_shutdown, sig.name)
            except NotImplementedError:  # pragma: no cover - platform dependent
                _log.warning("signal_handler_unavailable", extra={"signal": sig.name})
        self._signals_installed = True

    def _remove_signal_handlers(self) -> None:
        if not self._signals_installed:
            return
        loop = asyncio.get_running_loop()
        for sig in _HANDLED_SIGNALS:
            try:
                loop.remove_signal_handler(sig)
            except (NotImplementedError, RuntimeError):  # pragma: no cover
                pass
        self._signals_installed = False
