"""httpx adapter for Polymarket's public Gamma market-metadata API.

This is the only Module 5 file that talks to the network. It is an *adapter*
behind the :class:`~polymarket_pair_bot.market_discovery.ports.
MarketMetadataSource` protocol, so domain/strategy code never imports httpx.

Safety characteristics:

* Only safe, idempotent ``GET`` requests are issued -- never an order.
* Bounded retries with exponential backoff and jitter for transient failures
  (connection/timeout errors and 5xx responses).
* Explicit rate-limit handling for HTTP 429, honoring ``Retry-After`` when the
  server provides it, otherwise falling back to capped backoff.
* Non-retryable 4xx client errors fail fast (fail closed) rather than looping.
* Responses are shape-checked (must be a JSON array); field-level validation is
  performed by the caller with Pydantic.

The exact BTC 5-minute slug format is *not* encoded here; slug construction is
the caller's responsibility (operator-configured and verified). This adapter
only fetches whatever slug it is given.
"""

from __future__ import annotations

import asyncio
import random
from collections.abc import Awaitable, Callable, Sequence
from typing import Any

import httpx

from polymarket_pair_bot.market_discovery.errors import (
    InvalidMarketMetadataError,
    MarketMetadataUnavailableError,
    RateLimitedError,
)
from polymarket_pair_bot.market_discovery.ports import RawMarket
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("market_discovery.gamma_client")

_RETRYABLE_STATUS = frozenset({500, 502, 503, 504})


class GammaMarketSource:
    """Concrete :class:`MarketMetadataSource` backed by httpx.

    Parameters mirror the retry/backoff configuration; ``sleep`` and ``rng`` are
    injectable so tests exercise the retry logic deterministically without real
    delays or real network access.
    """

    def __init__(
        self,
        base_url: str,
        *,
        client: httpx.AsyncClient | None = None,
        timeout_seconds: float = 10.0,
        max_retries: int = 4,
        backoff_base_seconds: float = 0.5,
        backoff_max_seconds: float = 8.0,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
        rng: Callable[[], float] = random.random,
    ) -> None:
        if max_retries < 0:
            raise ValueError("max_retries must be non-negative")
        if backoff_base_seconds <= 0 or backoff_max_seconds <= 0:
            raise ValueError("backoff seconds must be positive")
        if backoff_max_seconds < backoff_base_seconds:
            raise ValueError("backoff_max must be >= backoff_base")
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout_seconds
        self._max_retries = max_retries
        self._backoff_base = backoff_base_seconds
        self._backoff_max = backoff_max_seconds
        self._sleep = sleep
        self._rng = rng
        self._external_client = client
        self._client = client

    async def __aenter__(self) -> GammaMarketSource:
        self._ensure_client()
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()

    def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self._timeout)
        return self._client

    async def aclose(self) -> None:
        """Close the underlying client if this instance created it."""
        if self._external_client is None and self._client is not None:
            await self._client.aclose()
            self._client = None

    async def fetch_markets_by_slug(self, slug: str) -> Sequence[RawMarket]:
        """Return raw market objects matching ``slug`` (possibly empty)."""
        if not slug or not slug.strip():
            raise ValueError("slug must be a non-empty string")
        payload = await self._get_json("/markets", {"slug": slug})
        if not isinstance(payload, list):
            raise InvalidMarketMetadataError(
                "expected a JSON array of markets from the metadata API"
            )
        markets: list[RawMarket] = []
        for item in payload:
            if not isinstance(item, dict):
                raise InvalidMarketMetadataError(
                    "each market entry must be a JSON object"
                )
            markets.append(item)
        return markets

    def _backoff_delay(self, attempt: int) -> float:
        """Full-jitter exponential backoff, capped at ``backoff_max``."""
        ceiling = min(self._backoff_max, self._backoff_base * (2**attempt))
        return self._rng() * ceiling

    @staticmethod
    def _parse_retry_after(response: httpx.Response) -> float | None:
        raw = response.headers.get("Retry-After")
        if raw is None:
            return None
        try:
            seconds = float(raw)
        except ValueError:
            return None
        return seconds if seconds >= 0 else None

    async def _get_json(self, path: str, params: dict[str, str]) -> Any:
        url = f"{self._base_url}{path}"
        client = self._ensure_client()
        last_error: str = "unknown error"
        # attempt index 0 is the first try; up to max_retries additional tries.
        for attempt in range(self._max_retries + 1):
            try:
                response = await client.get(url, params=params)
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                if attempt >= self._max_retries:
                    break
                delay = self._backoff_delay(attempt)
                _LOGGER.warning(
                    "gamma GET transport error; retrying",
                    extra={"attempt": attempt, "delay": delay, "path": path},
                )
                await self._sleep(delay)
                continue

            status = response.status_code
            if status == 429:
                retry_after = self._parse_retry_after(response)
                if attempt >= self._max_retries:
                    raise RateLimitedError(
                        "rate limited by metadata API and retries exhausted"
                    )
                delay = retry_after if retry_after is not None else self._backoff_delay(
                    attempt
                )
                _LOGGER.warning(
                    "gamma GET rate limited; backing off",
                    extra={"attempt": attempt, "delay": delay, "path": path},
                )
                await self._sleep(delay)
                continue
            if status in _RETRYABLE_STATUS:
                last_error = f"HTTP {status}"
                if attempt >= self._max_retries:
                    break
                delay = self._backoff_delay(attempt)
                _LOGGER.warning(
                    "gamma GET server error; retrying",
                    extra={"attempt": attempt, "delay": delay, "status": status},
                )
                await self._sleep(delay)
                continue
            if status >= 400:
                # Non-retryable client error: fail fast, fail closed.
                raise MarketMetadataUnavailableError(
                    f"metadata API returned client error HTTP {status}"
                )

            try:
                return response.json()
            except ValueError as exc:
                raise InvalidMarketMetadataError(
                    "metadata API returned a non-JSON body"
                ) from exc

        raise MarketMetadataUnavailableError(
            f"metadata API unavailable after {self._max_retries + 1} attempt(s): "
            f"{last_error}"
        )


__all__ = ["GammaMarketSource"]
