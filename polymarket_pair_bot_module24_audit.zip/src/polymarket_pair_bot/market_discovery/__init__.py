"""Module 5: BTC five-minute Polymarket market discovery.

Public surface:

* Pure window math (:mod:`.windows`).
* Pydantic validation + the validated :class:`DiscoveredMarket` (:mod:`.schemas`).
* The :class:`MarketMetadataSource` port (:mod:`.ports`) and its httpx adapter
  (:mod:`.gamma_client`).
* Slug strategies (:mod:`.slugs`) -- the exact slug format is operator-verified,
  never guessed.
* The :class:`MarketDiscoveryService` (:mod:`.service`) and composition helpers
  (:mod:`.factory`).

Importing this package does not import httpx, SQLAlchemy or redis; those live in
adapter/wiring modules that are imported on demand.
"""

from __future__ import annotations

from polymarket_pair_bot.market_discovery.errors import (
    InvalidMarketMetadataError,
    MarketDiscoveryConfigurationError,
    MarketDiscoveryError,
    MarketMetadataUnavailableError,
    MarketNotFoundError,
    RateLimitedError,
)
from polymarket_pair_bot.market_discovery.schemas import (
    DiscoveredMarket,
    GammaMarket,
    build_discovered_market,
    discovered_from_raw,
    parse_gamma_market,
)
from polymarket_pair_bot.market_discovery.service import (
    DiscoveryResult,
    MarketDiscoveryService,
)
from polymarket_pair_bot.market_discovery.windows import (
    WINDOW_SECONDS,
    FiveMinuteWindow,
    WindowSet,
    current_window,
    next_window,
    previous_window,
    window_set,
)

__all__ = [
    "WINDOW_SECONDS",
    "DiscoveredMarket",
    "DiscoveryResult",
    "FiveMinuteWindow",
    "GammaMarket",
    "InvalidMarketMetadataError",
    "MarketDiscoveryConfigurationError",
    "MarketDiscoveryError",
    "MarketDiscoveryService",
    "MarketMetadataUnavailableError",
    "MarketNotFoundError",
    "RateLimitedError",
    "WindowSet",
    "build_discovered_market",
    "current_window",
    "discovered_from_raw",
    "next_window",
    "parse_gamma_market",
    "previous_window",
    "window_set",
]
