"""Ports (typed protocols) for market discovery.

The discovery service depends only on these interfaces, never on httpx or any
concrete client (dependency inversion). Module 5 provides one concrete
implementation (:class:`~polymarket_pair_bot.market_discovery.gamma_client.
GammaMarketSource`); tests provide in-memory fakes.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Protocol, runtime_checkable

from polymarket_pair_bot.market_discovery.windows import FiveMinuteWindow

# Raw, still-untrusted JSON objects as decoded from the HTTP response. The
# service validates these with Pydantic before any field is used.
RawMarket = Mapping[str, Any]


@runtime_checkable
class MarketMetadataSource(Protocol):
    """Read-only source of raw Polymarket market metadata.

    Implementations must perform only safe, idempotent GETs, apply bounded
    retries with backoff, and never submit orders. Returned values are raw and
    unvalidated; the caller validates them.
    """

    async def fetch_markets_by_slug(self, slug: str) -> Sequence[RawMarket]:
        """Return raw market objects matching ``slug`` (possibly empty)."""
        ...


@runtime_checkable
class SlugStrategy(Protocol):
    """Maps a five-minute window to the market slug that should identify it.

    The exact BTC 5-minute slug format is operator-configured and must be
    verified against live Polymarket data; it is never guessed here.
    """

    def build(self, window: FiveMinuteWindow) -> str: ...


__all__ = ["MarketMetadataSource", "RawMarket", "SlugStrategy"]
