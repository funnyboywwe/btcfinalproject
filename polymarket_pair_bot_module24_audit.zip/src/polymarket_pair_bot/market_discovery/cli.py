"""``discover-market`` command: discover, validate, print (persist/cache).

Invoked as ``uv run polymarket-pair-bot discover-market`` (wired in
:mod:`polymarket_pair_bot.__main__`) or standalone via
``python -m polymarket_pair_bot.market_discovery.cli``.

Safety: this command performs only safe GETs against the public metadata API
and never submits an order. It prints a concise, secret-free summary. By
default it also persists validated markets to PostgreSQL and caches them in
Redis; ``--dry-run`` skips all infrastructure and only validates + prints.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Sequence
from dataclasses import asdict
from datetime import UTC, datetime

from polymarket_pair_bot.config import AppConfig, load_config
from polymarket_pair_bot.market_discovery.errors import MarketDiscoveryError
from polymarket_pair_bot.market_discovery.factory import (
    build_market_discovery_service,
)
from polymarket_pair_bot.market_discovery.schemas import DiscoveredMarket
from polymarket_pair_bot.market_discovery.service import DiscoveryResult


def add_arguments(parser: argparse.ArgumentParser) -> None:
    """Register ``discover-market`` options on an existing parser."""
    parser.add_argument(
        "--slug",
        default=None,
        help=(
            "Explicit market slug to target (disables window matching). "
            "Overrides the configured slug template."
        ),
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate and print only; do not persist to Postgres or cache in Redis.",
    )
    parser.add_argument(
        "--no-preload-next",
        action="store_true",
        help="Do not attempt to preload the next window.",
    )
    parser.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="Emit machine-readable JSON instead of human-readable text.",
    )


def _iso(epoch: int) -> str:
    return datetime.fromtimestamp(epoch, tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _market_to_public_dict(market: DiscoveredMarket) -> dict[str, object]:
    data = asdict(market)
    # Decimals -> strings for stable, precise, JSON-safe output.
    data["tick_size"] = str(market.tick_size)
    data["min_order_size"] = str(market.min_order_size)
    data["open_iso"] = _iso(market.open_time)
    data["close_iso"] = _iso(market.close_time)
    return data


def _print_text(result: DiscoveryResult, *, persisted: bool, cached: bool) -> None:
    windows = result.windows
    print("Five-minute UTC windows:")
    print(
        f"  previous: [{_iso(windows.previous.open_epoch)}, "
        f"{_iso(windows.previous.close_epoch)})"
    )
    print(
        f"  current:  [{_iso(windows.current.open_epoch)}, "
        f"{_iso(windows.current.close_epoch)})"
    )
    print(
        f"  next:     [{_iso(windows.next.open_epoch)}, "
        f"{_iso(windows.next.close_epoch)})"
    )
    _print_market_text("current window market", result.current)
    if result.next is not None:
        _print_market_text("next window market (preloaded)", result.next)
    else:
        print("\nnext window market: not yet discoverable")
    print(f"\npersisted={persisted} cached={cached}")


def _print_market_text(label: str, market: DiscoveredMarket) -> None:
    print(f"\n{label}:")
    print(f"  slug:              {market.slug}")
    print(f"  market_id:         {market.market_id}")
    print(f"  condition_id:      {market.condition_id}")
    print(f"  up_token_id:       {market.up_token_id}")
    print(f"  down_token_id:     {market.down_token_id}")
    print(f"  open_time:         {market.open_time} ({_iso(market.open_time)})")
    print(f"  close_time:        {market.close_time} ({_iso(market.close_time)})")
    print(f"  active:            {market.active}")
    print(f"  closed:            {market.closed}")
    print(f"  order_book_enabled:{market.order_book_enabled}")
    print(f"  tick_size:         {market.tick_size}")
    print(f"  min_order_size:    {market.min_order_size}")
    print(f"  neg_risk:          {market.neg_risk}")
    print(f"  resolution_source: {market.resolution_source or '(none provided)'}")
    print(f"  open_for_trading:  {market.is_open_for_trading}")


async def _run(config: AppConfig, args: argparse.Namespace) -> int:
    uow_factory = None
    cache = None
    engine = None
    coordination = None

    if not args.dry_run:
        # Import concrete adapters lazily so --dry-run never needs the drivers.
        from polymarket_pair_bot.coordination.factory import build_redis_coordination
        from polymarket_pair_bot.persistence import (
            create_engine_from_dsn,
            create_session_factory,
            create_unit_of_work_factory,
        )

        engine = create_engine_from_dsn(
            config.postgres.dsn,
            echo=False,
            pool_size=config.postgres.db_pool_size,
        )
        uow_factory = create_unit_of_work_factory(create_session_factory(engine))
        coordination = build_redis_coordination(config)
        cache = coordination.market_metadata

    service = build_market_discovery_service(
        config,
        slug_override=args.slug,
        require_window_match=False if args.slug else None,
        uow_factory=uow_factory,
        metadata_cache=cache,
    )

    try:
        result = await service.run_once(preload_next=not args.no_preload_next)
    finally:
        source = getattr(service, "_source", None)
        aclose = getattr(source, "aclose", None)
        if aclose is not None:
            await aclose()
        if coordination is not None:
            await coordination.aclose()
        if engine is not None:
            await engine.dispose()

    persisted = result.persisted
    cached = result.cached
    if args.as_json:
        payload = {
            "windows": {
                "previous": {
                    "open": result.windows.previous.open_epoch,
                    "close": result.windows.previous.close_epoch,
                },
                "current": {
                    "open": result.windows.current.open_epoch,
                    "close": result.windows.current.close_epoch,
                },
                "next": {
                    "open": result.windows.next.open_epoch,
                    "close": result.windows.next.close_epoch,
                },
            },
            "current": _market_to_public_dict(result.current),
            "next": (
                _market_to_public_dict(result.next)
                if result.next is not None
                else None
            ),
            "persisted": persisted,
            "cached": cached,
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        _print_text(result, persisted=persisted, cached=cached)
    return 0


def run(args: argparse.Namespace) -> int:
    """Execute the ``discover-market`` command; return a process exit code."""
    config = load_config()
    try:
        return asyncio.run(_run(config, args))
    except MarketDiscoveryError as exc:
        print(f"discover-market failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-discover-market",
        description="Discover and validate the current BTC 5-minute market.",
    )
    add_arguments(parser)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    return run(_build_parser().parse_args(argv))


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
