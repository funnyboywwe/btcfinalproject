"""Pure five-minute UTC window arithmetic.

BTC 5-minute markets are aligned to fixed 300-second UTC boundaries. This
module is deliberately dependency-free (standard library only) and performs no
I/O, so it is trivially testable and safe to import from anywhere.

All instants are integer UNIX seconds (UTC). No binary floats are used.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Final

WINDOW_SECONDS: Final = 300


@dataclass(frozen=True, slots=True)
class FiveMinuteWindow:
    """A single aligned five-minute window ``[open_epoch, close_epoch)``.

    ``open_epoch`` is a multiple of :data:`WINDOW_SECONDS`; ``close_epoch`` is
    exactly ``open_epoch + WINDOW_SECONDS``. Both are integer UNIX seconds UTC.
    """

    open_epoch: int
    close_epoch: int

    def __post_init__(self) -> None:
        if isinstance(self.open_epoch, bool) or isinstance(self.close_epoch, bool):
            raise TypeError("window bounds must be integers, not booleans")
        if not isinstance(self.open_epoch, int) or not isinstance(
            self.close_epoch, int
        ):
            raise TypeError("window bounds must be integer seconds")
        if self.open_epoch < 0:
            raise ValueError("open_epoch must be non-negative")
        if self.open_epoch % WINDOW_SECONDS != 0:
            raise ValueError("open_epoch must be aligned to a 5-minute boundary")
        if self.close_epoch != self.open_epoch + WINDOW_SECONDS:
            raise ValueError("close_epoch must be open_epoch + WINDOW_SECONDS")

    @property
    def open_datetime(self) -> datetime:
        """Window open as a timezone-aware UTC datetime."""
        return datetime.fromtimestamp(self.open_epoch, tz=UTC)

    @property
    def close_datetime(self) -> datetime:
        """Window close as a timezone-aware UTC datetime."""
        return datetime.fromtimestamp(self.close_epoch, tz=UTC)

    def contains(self, epoch: int) -> bool:
        """True if ``epoch`` falls within ``[open_epoch, close_epoch)``."""
        return self.open_epoch <= epoch < self.close_epoch


@dataclass(frozen=True, slots=True)
class WindowSet:
    """The previous, current and next windows relative to a reference instant."""

    previous: FiveMinuteWindow
    current: FiveMinuteWindow
    next: FiveMinuteWindow


def floor_to_window(epoch: int) -> int:
    """Return the aligned open boundary of the window containing ``epoch``."""
    if isinstance(epoch, bool) or not isinstance(epoch, int):
        raise TypeError("epoch must be an integer number of seconds")
    if epoch < 0:
        raise ValueError("epoch must be non-negative")
    return (epoch // WINDOW_SECONDS) * WINDOW_SECONDS


def window_containing(epoch: int) -> FiveMinuteWindow:
    """Return the five-minute window containing ``epoch``."""
    open_epoch = floor_to_window(epoch)
    return FiveMinuteWindow(open_epoch, open_epoch + WINDOW_SECONDS)


def current_window(now_epoch: int) -> FiveMinuteWindow:
    """Return the current window for reference instant ``now_epoch``."""
    return window_containing(now_epoch)


def previous_window(now_epoch: int) -> FiveMinuteWindow:
    """Return the window immediately before the current one."""
    open_epoch = floor_to_window(now_epoch) - WINDOW_SECONDS
    if open_epoch < 0:
        raise ValueError("no previous window before the Unix epoch")
    return FiveMinuteWindow(open_epoch, open_epoch + WINDOW_SECONDS)


def next_window(now_epoch: int) -> FiveMinuteWindow:
    """Return the window immediately after the current one."""
    open_epoch = floor_to_window(now_epoch) + WINDOW_SECONDS
    return FiveMinuteWindow(open_epoch, open_epoch + WINDOW_SECONDS)


def window_set(now_epoch: int) -> WindowSet:
    """Return previous/current/next windows for reference instant ``now_epoch``."""
    return WindowSet(
        previous=previous_window(now_epoch),
        current=current_window(now_epoch),
        next=next_window(now_epoch),
    )


__all__ = [
    "WINDOW_SECONDS",
    "FiveMinuteWindow",
    "WindowSet",
    "current_window",
    "floor_to_window",
    "next_window",
    "previous_window",
    "window_containing",
    "window_set",
]
