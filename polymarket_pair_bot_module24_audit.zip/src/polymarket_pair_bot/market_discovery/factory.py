"""Composition helpers that assemble the market-discovery service.

This is the wiring boundary: it may import concrete adapters (the httpx client,
the SQLAlchemy unit of work, the Redis cache). The service itself only ever
sees domain/port types.

Persistence and cache wiring are optional and only built on request, so the
``discover-market`` command can run in a dry-run mode (validate + print) without
any live infrastructure.
"""

from __future__ import annotations

from polymarket_pair_bot.config import AppConfig
from polymarket_pair_bot.domain.coordination import MarketMetadataCache
from polymarket_pair_bot.market_discovery.gamma_client import GammaMarketSource
from polymarket_pair_bot.market_discovery.ports import (
    MarketMetadataSource,
    SlugStrategy,
)
from polymarket_pair_bot.market_discovery.service import (
    Clock,
    MarketDiscoveryService,
    UnitOfWorkFactory,
)
from polymarket_pair_bot.market_discovery.slugs import (
    BlockedSlugStrategy,
    FixedSlugStrategy,
    SlugTemplateStrategy,
)


def build_slug_strategy(
    config: AppConfig, *, slug_override: str | None = None
) -> SlugStrategy:
    """Choose a slug strategy from configuration / explicit override.

    Precedence: explicit ``slug_override`` > configured template > blocked.
    The blocked strategy raises a clear error instead of guessing a slug.
    """
    if slug_override:
        return FixedSlugStrategy(slug_override)
    template = config.market_discovery.btc_5m_slug_template
    if template:
        return SlugTemplateStrategy(template)
    return BlockedSlugStrategy()


def build_gamma_source(config: AppConfig) -> GammaMarketSource:
    """Build the httpx-backed Gamma metadata source from configuration."""
    md = config.market_discovery
    return GammaMarketSource(
        config.polymarket_public.polymarket_gamma_url,
        timeout_seconds=md.discovery_request_timeout_seconds,
        max_retries=md.discovery_max_retries,
        backoff_base_seconds=md.discovery_backoff_base_seconds,
        backoff_max_seconds=md.discovery_backoff_max_seconds,
    )


def build_market_discovery_service(
    config: AppConfig,
    *,
    source: MarketMetadataSource | None = None,
    slug_override: str | None = None,
    require_window_match: bool | None = None,
    uow_factory: UnitOfWorkFactory | None = None,
    metadata_cache: MarketMetadataCache | None = None,
    clock: Clock | None = None,
) -> MarketDiscoveryService:
    """Assemble a :class:`MarketDiscoveryService` from configuration."""
    md = config.market_discovery
    resolved_source = source if source is not None else build_gamma_source(config)
    strategy = build_slug_strategy(config, slug_override=slug_override)
    match = (
        md.discovery_require_window_match
        if require_window_match is None
        else require_window_match
    )
    cache_ttl = md.discovery_cache_ttl_seconds or config.coordination.market_metadata_ttl_seconds
    return MarketDiscoveryService(
        resolved_source,
        strategy,
        expected_up=md.discovery_expected_up_outcome,
        expected_down=md.discovery_expected_down_outcome,
        window_match_tolerance_seconds=md.discovery_window_match_tolerance_seconds,
        require_window_match=match,
        clock=clock,
        uow_factory=uow_factory,
        metadata_cache=metadata_cache,
        cache_ttl_seconds=cache_ttl,
    )


__all__ = [
    "build_gamma_source",
    "build_market_discovery_service",
    "build_slug_strategy",
]
