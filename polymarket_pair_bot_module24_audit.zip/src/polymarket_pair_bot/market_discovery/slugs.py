"""Slug strategies mapping a five-minute window to a Polymarket market slug.

The precise slug format for BTC 5-minute Up/Down markets is **not** hard-coded
or guessed here. Doing so would violate the project's rule against inventing
undocumented external behavior. Instead:

* :class:`SlugTemplateStrategy` builds a slug from an operator-supplied format
  string that must be verified against live Polymarket data.
* :class:`FixedSlugStrategy` targets a single explicit slug (operator override).
* :class:`BlockedSlugStrategy` is the safe default: it raises a clear error
  explaining that a verified slug template must be configured. This is the
  "blocked adapter method with a clear explanation instead of guessing".

Even when a template is configured, the discovery service independently checks
that the market it receives actually matches the requested window, so a wrong
template fails closed rather than accepting the wrong market.
"""

from __future__ import annotations

from polymarket_pair_bot.market_discovery.errors import (
    MarketDiscoveryConfigurationError,
)
from polymarket_pair_bot.market_discovery.windows import FiveMinuteWindow


def _placeholders(window: FiveMinuteWindow) -> dict[str, object]:
    open_dt = window.open_datetime
    close_dt = window.close_datetime
    return {
        "open_epoch": window.open_epoch,
        "close_epoch": window.close_epoch,
        "open_iso": open_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "close_iso": close_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "date": open_dt.strftime("%Y-%m-%d"),
        "year": open_dt.strftime("%Y"),
        "month": open_dt.strftime("%m"),
        "day": open_dt.strftime("%d"),
        "hour": open_dt.strftime("%H"),
        "minute": open_dt.strftime("%M"),
        "hhmm": open_dt.strftime("%H%M"),
    }


class SlugTemplateStrategy:
    """Build a slug from a ``str.format``-style template.

    Supported placeholders: ``open_epoch``, ``close_epoch``, ``open_iso``,
    ``close_iso``, ``date``, ``year``, ``month``, ``day``, ``hour``, ``minute``,
    ``hhmm``.
    """

    def __init__(self, template: str) -> None:
        if not template or not template.strip():
            raise MarketDiscoveryConfigurationError("slug template must be non-empty")
        self._template = template

    def build(self, window: FiveMinuteWindow) -> str:
        try:
            return self._template.format_map(_placeholders(window))
        except (KeyError, IndexError, ValueError) as exc:
            raise MarketDiscoveryConfigurationError(
                f"slug template refers to an unknown placeholder: {exc}"
            ) from exc


class FixedSlugStrategy:
    """Always return one explicit slug (operator override; ignores the window)."""

    def __init__(self, slug: str) -> None:
        if not slug or not slug.strip():
            raise MarketDiscoveryConfigurationError("fixed slug must be non-empty")
        self._slug = slug.strip()

    def build(self, window: FiveMinuteWindow) -> str:
        return self._slug


class BlockedSlugStrategy:
    """Safe default that refuses to guess a slug."""

    def build(self, window: FiveMinuteWindow) -> str:
        raise MarketDiscoveryConfigurationError(
            "No BTC 5-minute slug template is configured. Set "
            "MARKET_DISCOVERY_BTC_5M_SLUG_TEMPLATE (after verifying the exact "
            "slug format against live Polymarket data) or pass an explicit "
            "--slug override. The slug format is intentionally not guessed."
        )


__all__ = [
    "BlockedSlugStrategy",
    "FixedSlugStrategy",
    "SlugTemplateStrategy",
]
