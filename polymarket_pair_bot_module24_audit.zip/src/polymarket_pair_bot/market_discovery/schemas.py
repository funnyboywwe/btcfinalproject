"""Pydantic validation of Polymarket public market metadata.

The Polymarket Gamma API (``/markets``) returns market objects whose numeric
fields may arrive as JSON numbers or strings and whose ``clobTokenIds`` /
``outcomes`` arrive as JSON-encoded string arrays. Every externally sourced
value is validated here before any other module trusts it.

Only documented fields are consumed. Unknown fields are ignored (never
invented). Monetary/price values are parsed straight into ``Decimal`` via their
string form so no binary-float artifact is ever introduced.

The validated, cross-checked descriptor is :class:`DiscoveredMarket`. Building
one enforces the invariants required by the strategy: exactly one Up and one
Down outcome, index-aligned token ids, a coherent open/close window, and no
contradictory active/closed flags. The outcome-to-token mapping is resolved by
**outcome name**, never by positional assumption.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from polymarket_pair_bot.domain.coordination import MarketMetadata
from polymarket_pair_bot.domain.entities import BinaryMarket, MarketWindow, OutcomeToken
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    ConditionId,
    MarketId,
    TickSize,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.market_discovery.errors import InvalidMarketMetadataError


def _to_decimal(value: Any) -> Decimal:
    """Convert an API scalar to ``Decimal`` without going through a float."""
    if isinstance(value, bool):
        raise ValueError("boolean is not a valid numeric value")
    if isinstance(value, Decimal):
        return value
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, float):
        # str() gives the shortest round-trip repr, avoiding binary artifacts.
        return Decimal(str(value))
    if isinstance(value, str):
        text = value.strip()
        if not text:
            raise ValueError("empty numeric string")
        try:
            return Decimal(text)
        except InvalidOperation as exc:
            raise ValueError(f"invalid numeric string: {value!r}") from exc
    raise ValueError(f"unsupported numeric type: {type(value).__name__}")


def _to_epoch_seconds(value: datetime) -> int:
    """Return integer UNIX seconds (UTC) for a datetime, assuming UTC if naive."""
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return int(value.astimezone(UTC).timestamp())


class GammaMarket(BaseModel):
    """Runtime-validated view of a single Gamma ``/markets`` object.

    Field aliases mirror the documented camelCase API names. Fields that the
    API does not always populate default to conservative values; the semantic
    completeness checks live in :func:`build_discovered_market`.
    """

    model_config = ConfigDict(populate_by_name=True, extra="ignore", frozen=True)

    market_id: str = Field(alias="id")
    slug: str
    condition_id: str = Field(alias="conditionId")
    clob_token_ids: list[str] = Field(alias="clobTokenIds")
    outcomes: list[str]
    active: bool = False
    closed: bool = False
    enable_order_book: bool = Field(default=False, alias="enableOrderBook")
    neg_risk: bool = Field(default=False, alias="negRisk")
    start_date: datetime | None = Field(default=None, alias="startDate")
    end_date: datetime | None = Field(default=None, alias="endDate")
    order_price_min_tick_size: Decimal | None = Field(
        default=None, alias="orderPriceMinTickSize"
    )
    order_min_size: Decimal | None = Field(default=None, alias="orderMinSize")
    resolution_source: str | None = Field(default=None, alias="resolutionSource")

    @field_validator("market_id", "slug", "condition_id", mode="before")
    @classmethod
    def _require_nonempty_str(cls, value: Any) -> str:
        if value is None:
            raise ValueError("value is required")
        text = str(value).strip()
        if not text:
            raise ValueError("value must be a non-empty string")
        return text

    @field_validator("clob_token_ids", "outcomes", mode="before")
    @classmethod
    def _decode_json_array(cls, value: Any) -> list[str]:
        if value is None:
            raise ValueError("value is required")
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except json.JSONDecodeError as exc:
                raise ValueError("expected a JSON-encoded array") from exc
        if not isinstance(value, list):
            raise ValueError("expected a list")
        return [str(item) for item in value]

    @field_validator("order_price_min_tick_size", "order_min_size", mode="before")
    @classmethod
    def _coerce_optional_decimal(cls, value: Any) -> Decimal | None:
        if value is None or value == "":
            return None
        return _to_decimal(value)

    @field_validator("resolution_source", mode="before")
    @classmethod
    def _normalize_resolution_source(cls, value: Any) -> str | None:
        if value is None:
            return None
        text = str(value).strip()
        return text or None


@dataclass(frozen=True, slots=True)
class DiscoveredMarket:
    """A fully validated, cross-checked BTC 5-minute market descriptor.

    All the fields Module 5 is required to extract, with the Up/Down mapping
    resolved by outcome name. Timestamps are integer UNIX seconds (UTC); tick
    size and minimum order size are ``Decimal``. This is the only market shape
    the rest of the system should treat as trustworthy.
    """

    slug: str
    market_id: str
    condition_id: str
    up_token_id: str
    down_token_id: str
    open_time: int
    close_time: int
    active: bool
    closed: bool
    order_book_enabled: bool
    tick_size: Decimal
    min_order_size: Decimal
    neg_risk: bool
    resolution_source: str | None
    fetched_at: int

    @property
    def is_open_for_trading(self) -> bool:
        """True only when the market is active, not closed and order-book on."""
        return self.active and not self.closed and self.order_book_enabled

    def ensure_open_for_trading(self) -> None:
        """Raise if the market cannot currently accept order-book trading."""
        if not self.is_open_for_trading:
            raise InvalidMarketMetadataError(
                f"market {self.market_id} is not open for trading "
                f"(active={self.active}, closed={self.closed}, "
                f"order_book_enabled={self.order_book_enabled})"
            )

    def to_market_window(self) -> MarketWindow:
        return MarketWindow(
            market_id=MarketId(self.market_id),
            condition_id=ConditionId(self.condition_id),
            open_time=UnixTimestamp(self.open_time),
            close_time=UnixTimestamp(self.close_time),
        )

    def to_binary_market(self) -> BinaryMarket:
        market_id = MarketId(self.market_id)
        condition_id = ConditionId(self.condition_id)
        tick = TickSize(self.tick_size)
        return BinaryMarket(
            market_id=market_id,
            condition_id=condition_id,
            window=self.to_market_window(),
            up_token=OutcomeToken(
                token_id=TokenId(self.up_token_id),
                side=OutcomeSide.UP,
                market_id=market_id,
                tick_size=tick,
            ),
            down_token=OutcomeToken(
                token_id=TokenId(self.down_token_id),
                side=OutcomeSide.DOWN,
                market_id=market_id,
                tick_size=tick,
            ),
        )

    def to_market_metadata(self) -> MarketMetadata:
        return MarketMetadata(
            market_id=self.market_id,
            condition_id=self.condition_id,
            up_token_id=self.up_token_id,
            down_token_id=self.down_token_id,
            up_tick_size=self.tick_size,
            down_tick_size=self.tick_size,
            close_time=self.close_time,
            fetched_at=self.fetched_at,
        )


def parse_gamma_market(raw: Any) -> GammaMarket:
    """Validate a single raw market object, or raise InvalidMarketMetadataError."""
    try:
        return GammaMarket.model_validate(raw)
    except ValidationError as exc:
        raise InvalidMarketMetadataError(
            f"market metadata failed schema validation: {exc.error_count()} error(s)"
        ) from exc


def _resolve_side_mapping(
    market: GammaMarket, *, expected_up: str, expected_down: str
) -> tuple[str, str]:
    """Return ``(up_token_id, down_token_id)`` resolved by outcome name.

    Never assumes the first token is Up. Requires exactly one outcome matching
    the configured Up name and exactly one matching the Down name.
    """
    outcomes = market.outcomes
    tokens = market.clob_token_ids
    if len(outcomes) != 2 or len(tokens) != 2:
        raise InvalidMarketMetadataError(
            "market must have exactly two outcomes and two token ids "
            f"(got {len(outcomes)} outcomes, {len(tokens)} tokens)"
        )

    up_norm = expected_up.strip().casefold()
    down_norm = expected_down.strip().casefold()
    up_indices = [i for i, name in enumerate(outcomes) if name.strip().casefold() == up_norm]
    down_indices = [
        i for i, name in enumerate(outcomes) if name.strip().casefold() == down_norm
    ]
    if len(up_indices) != 1 or len(down_indices) != 1:
        raise InvalidMarketMetadataError(
            "outcomes must map to exactly one Up and one Down by name "
            f"(outcomes={outcomes!r}, expected up={expected_up!r}, "
            f"down={expected_down!r})"
        )
    if up_indices[0] == down_indices[0]:
        raise InvalidMarketMetadataError("Up and Down resolved to the same outcome")

    up_token = tokens[up_indices[0]]
    down_token = tokens[down_indices[0]]
    if not up_token or not down_token:
        raise InvalidMarketMetadataError("missing token id for an outcome")
    if up_token == down_token:
        raise InvalidMarketMetadataError("Up and Down share the same token id")
    return up_token, down_token


def build_discovered_market(
    market: GammaMarket,
    *,
    expected_up: str,
    expected_down: str,
    fetched_at: int,
) -> DiscoveredMarket:
    """Cross-check a validated ``GammaMarket`` and build a DiscoveredMarket.

    Rejects contradictory or incomplete metadata:

    * missing tick size / minimum order size / open / close timestamps;
    * non-increasing (or non-positive) window timestamps;
    * a market flagged both active and closed;
    * outcomes that do not map to exactly one Up and one Down.
    """
    if market.active and market.closed:
        raise InvalidMarketMetadataError(
            f"market {market.market_id} is both active and closed"
        )
    if market.start_date is None or market.end_date is None:
        raise InvalidMarketMetadataError("market is missing open/close timestamps")
    if market.order_price_min_tick_size is None:
        raise InvalidMarketMetadataError("market is missing a tick size")
    if market.order_min_size is None:
        raise InvalidMarketMetadataError("market is missing a minimum order size")

    open_time = _to_epoch_seconds(market.start_date)
    close_time = _to_epoch_seconds(market.end_date)
    if close_time <= open_time:
        raise InvalidMarketMetadataError(
            f"close_time ({close_time}) must be after open_time ({open_time})"
        )
    if open_time <= 0:
        raise InvalidMarketMetadataError("open_time must be a positive UNIX timestamp")

    tick_size = market.order_price_min_tick_size
    if not (Decimal(0) < tick_size <= Decimal(1)):
        raise InvalidMarketMetadataError(f"tick size out of range: {tick_size}")
    min_order_size = market.order_min_size
    if min_order_size <= Decimal(0):
        raise InvalidMarketMetadataError(
            f"minimum order size must be positive: {min_order_size}"
        )

    up_token, down_token = _resolve_side_mapping(
        market, expected_up=expected_up, expected_down=expected_down
    )

    # ConditionId enforces the bytes32 hex shape; surface as a metadata error.
    try:
        ConditionId(market.condition_id)
    except ValueError as exc:
        raise InvalidMarketMetadataError(f"invalid condition id: {exc}") from exc

    return DiscoveredMarket(
        slug=market.slug,
        market_id=market.market_id,
        condition_id=market.condition_id,
        up_token_id=up_token,
        down_token_id=down_token,
        open_time=open_time,
        close_time=close_time,
        active=market.active,
        closed=market.closed,
        order_book_enabled=market.enable_order_book,
        tick_size=tick_size,
        min_order_size=min_order_size,
        neg_risk=market.neg_risk,
        resolution_source=market.resolution_source,
        fetched_at=fetched_at,
    )


def discovered_from_raw(
    raw: Any,
    *,
    expected_up: str,
    expected_down: str,
    fetched_at: int,
) -> DiscoveredMarket:
    """Validate + cross-check a raw market object into a DiscoveredMarket."""
    market = parse_gamma_market(raw)
    return build_discovered_market(
        market,
        expected_up=expected_up,
        expected_down=expected_down,
        fetched_at=fetched_at,
    )


__all__ = [
    "DiscoveredMarket",
    "GammaMarket",
    "build_discovered_market",
    "discovered_from_raw",
    "parse_gamma_market",
]
