"""Market-discovery error hierarchy.

These errors let callers distinguish *transport* problems (retryable, external
infrastructure unavailable) from *semantic* problems (the returned metadata is
contradictory, incomplete or does not match the requested window). The system
fails closed: any of these prevents a market from being persisted, cached or
treated as tradable.
"""

from __future__ import annotations


class MarketDiscoveryError(RuntimeError):
    """Base class for all market-discovery failures."""


class MarketDiscoveryConfigurationError(MarketDiscoveryError):
    """Discovery cannot proceed because required configuration is missing.

    Raised, for example, when no BTC 5-minute slug template has been configured
    and no explicit slug override was supplied. This is intentionally a hard
    stop rather than a guess at an undocumented slug format.
    """


class MarketMetadataUnavailableError(MarketDiscoveryError):
    """The upstream metadata API could not be reached or returned an error.

    Raised after bounded retries are exhausted, or for non-retryable HTTP
    client errors. Treated as "unknown" -> the caller must not assume a market
    exists or is tradable.
    """


class RateLimitedError(MarketMetadataUnavailableError):
    """The upstream API rate-limited us and retries were exhausted."""


class MarketNotFoundError(MarketDiscoveryError):
    """No market matched the requested slug / window."""


class InvalidMarketMetadataError(MarketDiscoveryError):
    """Returned metadata was contradictory, incomplete or failed validation.

    Examples: missing condition id, wrong number of outcomes/tokens, outcome
    names that do not map to exactly one Up and one Down, non-increasing
    timestamps, or a market simultaneously flagged active and closed.
    """


__all__ = [
    "InvalidMarketMetadataError",
    "MarketDiscoveryConfigurationError",
    "MarketDiscoveryError",
    "MarketMetadataUnavailableError",
    "MarketNotFoundError",
    "RateLimitedError",
]
