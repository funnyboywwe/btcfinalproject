"""Cancellation-safe reconnecting authenticated user stream.

The stream logic is transport-agnostic: it drives a
:class:`~polymarket_pair_bot.auth.ports.UserStreamConnectionFactory` and applies
the project's safety requirements around it:

* freshness checks -- each ``receive`` is bounded by ``freshness_seconds``; a
  timeout raises :class:`StaleUserStreamError` and forces a reconnect;
* a reconnect requires a fresh authoritative synchronization -- the optional
  ``resync`` callback runs immediately after every (re)connect;
* bounded retries -- after ``max_reconnects`` failures the stream fails closed;
* de-duplication -- messages are keyed and deduped (fills are not unique);
* cancellation-safe / graceful shutdown -- the connection is always closed in a
  ``finally`` block and :meth:`stop` requests a cooperative shutdown.

The concrete Polymarket user-stream connection is a blocked adapter (its exact
framing/auth is not verified locally); this class is exercised in tests with a
fake connection factory.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Mapping
from typing import Any

from polymarket_pair_bot.auth.dedup import BoundedDedupCache
from polymarket_pair_bot.auth.errors import StaleUserStreamError
from polymarket_pair_bot.auth.ports import (
    UserStreamConnection,
    UserStreamConnectionFactory,
)
from polymarket_pair_bot.auth.readiness import (
    AuthReadinessState,
    AuthReadinessTracker,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("auth.user_stream")

MessageHandler = Callable[[Mapping[str, Any]], Awaitable[None]]
ResyncCallback = Callable[[], Awaitable[None]]
KeyFn = Callable[[Mapping[str, Any]], str]


class ReconnectingUserStream:
    """Drives an authenticated user stream with reconnect + dedup + freshness."""

    def __init__(
        self,
        *,
        factory: UserStreamConnectionFactory,
        handler: MessageHandler,
        readiness: AuthReadinessTracker | None = None,
        dedup: BoundedDedupCache | None = None,
        resync: ResyncCallback | None = None,
        freshness_seconds: float = 30.0,
        max_reconnects: int = 5,
        message_id_key: str = "id",
        key_fn: KeyFn | None = None,
        backoff_base_seconds: float = 0.5,
        backoff_max_seconds: float = 8.0,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        if freshness_seconds <= 0:
            raise ValueError("freshness_seconds must be positive")
        if max_reconnects < 0:
            raise ValueError("max_reconnects must be non-negative")
        if backoff_base_seconds <= 0 or backoff_max_seconds <= 0:
            raise ValueError("backoff seconds must be positive")
        if backoff_max_seconds < backoff_base_seconds:
            raise ValueError("backoff_max must be >= backoff_base")
        self._factory = factory
        self._handler = handler
        self._readiness = readiness or AuthReadinessTracker()
        self._dedup = dedup or BoundedDedupCache(4096)
        self._resync = resync
        self._freshness_seconds = freshness_seconds
        self._max_reconnects = max_reconnects
        self._message_id_key = message_id_key
        self._key_fn = key_fn or self._default_key
        self._backoff_base = backoff_base_seconds
        self._backoff_max = backoff_max_seconds
        self._sleep = sleep
        self._stopped = asyncio.Event()

    @property
    def readiness(self) -> AuthReadinessTracker:
        return self._readiness

    def stop(self) -> None:
        """Request a cooperative shutdown (effective at the next loop turn)."""
        self._stopped.set()

    def _default_key(self, message: Mapping[str, Any]) -> str:
        raw = message.get(self._message_id_key)
        if raw is not None:
            return f"{self._message_id_key}:{raw}"
        # Keys are unique, so sorting items never compares (unorderable) values.
        return "repr:" + repr(sorted(message.items()))

    def _backoff(self, attempt: int) -> float:
        delay = self._backoff_base * (2 ** max(0, attempt - 1))
        return min(delay, self._backoff_max)

    async def _safe_close(self, conn: UserStreamConnection) -> None:
        try:
            await conn.aclose()
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # closing must never mask the primary error
            _LOGGER.debug(
                "user_stream_close_error", extra={"reason": type(exc).__name__}
            )

    async def _consume(self, conn: UserStreamConnection) -> None:
        while not self._stopped.is_set():
            try:
                message = await asyncio.wait_for(
                    conn.receive(), timeout=self._freshness_seconds
                )
            except asyncio.TimeoutError as exc:
                raise StaleUserStreamError(
                    f"no user-stream message within {self._freshness_seconds}s"
                ) from exc
            key = self._key_fn(message)
            if not self._dedup.add(key):
                _LOGGER.debug("user_stream_duplicate", extra={"key": key})
                continue
            await self._readiness.mark_stream_message()
            await self._handler(message)

    async def run(self) -> None:
        """Run the reconnect loop until stopped, cancelled, or budget exhausted."""
        reconnects = 0
        while not self._stopped.is_set():
            conn: UserStreamConnection | None = None
            try:
                conn = await self._factory.connect()
                if self._resync is not None:
                    # A reconnect requires a fresh authoritative synchronization.
                    await self._resync()
                await self._readiness.set(
                    AuthReadinessState.STREAM_LIVE, "user stream connected"
                )
                await self._consume(conn)
                return  # clean, requested stop
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                reconnects += 1
                _LOGGER.warning(
                    "user_stream_drop",
                    extra={
                        "reconnects": reconnects,
                        "reason": type(exc).__name__,
                    },
                )
                await self._readiness.set(
                    AuthReadinessState.DEGRADED, f"reconnect {reconnects}"
                )
                if reconnects > self._max_reconnects:
                    _LOGGER.error(
                        "user_stream_exhausted",
                        extra={"max_reconnects": self._max_reconnects},
                    )
                    raise StaleUserStreamError(
                        "user-stream reconnect budget exhausted; failing closed"
                    ) from exc
                await self._sleep(self._backoff(reconnects))
            finally:
                if conn is not None:
                    await self._safe_close(conn)
        await self._readiness.set(AuthReadinessState.CLOSED, "user stream stopped")


__all__ = [
    "KeyFn",
    "MessageHandler",
    "ReconnectingUserStream",
    "ResyncCallback",
]
