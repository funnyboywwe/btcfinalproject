"""Blocked live CLOB adapter for authenticated read-only access (Module 15).

The official Polymarket CLOB Python package is NOT verifiable locally in this
environment, so -- per the project safety rules -- we do not guess its method
names or response shapes. This module:

* implements the :class:`AuthenticatedAccountReader` interface so higher layers
  can already depend on it, but every read raises
  :class:`UnsupportedAuthOperationError` naming the exact operation to wire once
  the installed package API has been inspected;
* lazily imports the package so importing this module never requires it;
* keeps credentials private and never logs secret material.

When implementing for real: import the official client, construct it with the
validated signer/funder/signature-type + API credentials, call the package's
documented read methods, then map each response into the local Pydantic models
in :mod:`auth.models`. Do not add fields that the documented API does not
return.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polymarket_pair_bot.auth.credentials import ApiCredentials
from polymarket_pair_bot.auth.errors import UnsupportedAuthOperationError
from polymarket_pair_bot.auth.models import (
    AccountIdentity,
    AllowanceView,
    BalanceView,
    OpenOrderView,
    OrderStatusView,
    TradeFillView,
)
from polymarket_pair_bot.auth.ports import UserStreamConnection
from polymarket_pair_bot.observability.logging import get_logger

if TYPE_CHECKING:
    from polymarket_pair_bot.config.models import PolymarketPublicSettings

_LOGGER = get_logger("auth.clob_adapter")


def load_clob_package() -> object:
    """Lazily import the official CLOB package or block with guidance."""
    try:
        import py_clob_client  # type: ignore[import-not-found,import-untyped]
    except ImportError as exc:
        raise UnsupportedAuthOperationError(
            "import_clob_package",
            "install and verify the official Polymarket CLOB package, then "
            "inspect its public API before implementing the adapter",
        ) from exc
    return py_clob_client


class ClobAuthenticatedReader:
    """Live read-only reader (blocked until the CLOB API is verified)."""

    def __init__(
        self,
        *,
        identity: AccountIdentity,
        credentials: ApiCredentials,
        public_settings: PolymarketPublicSettings,
    ) -> None:
        self._identity = identity
        self._credentials = credentials  # secret; never logged
        self._public_settings = public_settings
        _LOGGER.info(
            "clob_reader_constructed",
            extra={
                "chain_id": identity.chain_id,
                "signature_type": int(identity.signature_type),
            },
        )

    @property
    def identity(self) -> AccountIdentity:
        return self._identity

    async def get_open_orders(
        self, *, market_id: str | None = None
    ) -> tuple[OpenOrderView, ...]:
        raise UnsupportedAuthOperationError(
            "get_open_orders",
            "map the official CLOB open-orders response into OpenOrderView",
        )

    async def get_order_status(self, order_id: str) -> OrderStatusView | None:
        raise UnsupportedAuthOperationError(
            "get_order_status",
            "map the official CLOB order lookup into OrderStatusView",
        )

    async def get_trades(
        self, *, market_id: str | None = None
    ) -> tuple[TradeFillView, ...]:
        raise UnsupportedAuthOperationError(
            "get_trades",
            "map the official CLOB trades/fills response into TradeFillView",
        )

    async def get_balances(self) -> tuple[BalanceView, ...]:
        raise UnsupportedAuthOperationError(
            "get_balances",
            "map the official CLOB balance response into BalanceView",
        )

    async def get_allowances(self) -> tuple[AllowanceView, ...]:
        raise UnsupportedAuthOperationError(
            "get_allowances",
            "allowances require a verified balance/allowance API (Module 20)",
        )

    async def aclose(self) -> None:
        # Nothing was opened; safe no-op.
        return None


class ClobUserStreamConnectionFactory:
    """Blocked authenticated user-stream connection factory (Module 16)."""

    def __init__(
        self,
        *,
        identity: AccountIdentity,
        credentials: ApiCredentials,
        public_settings: PolymarketPublicSettings,
    ) -> None:
        self._identity = identity
        self._credentials = credentials  # secret; never logged
        self._public_settings = public_settings

    async def connect(self) -> UserStreamConnection:
        raise UnsupportedAuthOperationError(
            "user_stream_connect",
            "authenticate and subscribe to the user WebSocket using the "
            "verified package framing before enabling this path",
        )


def initialize_authenticated_client(
    *,
    identity: AccountIdentity,
    credentials: ApiCredentials,
    public_settings: PolymarketPublicSettings,
) -> object:
    """Blocked: construct the official CLOB client after verifying its API."""
    raise UnsupportedAuthOperationError(
        "initialize_authenticated_client",
        "construct the official CLOB client once its constructor and auth API "
        "are verified locally",
    )


__all__ = [
    "ClobAuthenticatedReader",
    "ClobUserStreamConnectionFactory",
    "initialize_authenticated_client",
    "load_clob_package",
]
