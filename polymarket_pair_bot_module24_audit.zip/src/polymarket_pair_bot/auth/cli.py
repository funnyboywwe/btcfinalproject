"""Read-only authenticated account diagnostics CLI (Module 15).

``python -m polymarket_pair_bot.auth.cli diagnose`` prints a non-secret summary
of the authenticated account (open orders, fills, balances, allowances). It is
strictly READ-ONLY: it never submits or cancels anything and never enables live
trading. Secrets, addresses' private keys and signed payloads are never printed.

Exit codes:
* 0  -- diagnostics succeeded;
* 2  -- configuration error (prints the missing, non-secret field names);
* 3  -- a required operation is blocked (CLOB API not verified locally).
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from collections.abc import Sequence

from polymarket_pair_bot.auth.errors import (
    AuthConfigurationError,
    UnsupportedAuthOperationError,
)
from polymarket_pair_bot.auth.factory import build_account_reader
from polymarket_pair_bot.auth.models import AccountSnapshot
from polymarket_pair_bot.auth.service import AuthenticationService
from polymarket_pair_bot.config.settings import load_config


def _print_snapshot(snapshot: AccountSnapshot) -> None:
    identity = snapshot.identity
    lines = [
        "Polymarket authenticated account diagnostics (READ-ONLY)",
        f"  signer address    : {identity.signer_address}",
        f"  funder address    : {identity.funder_address}",
        f"  signature type    : {identity.signature_type.name} "
        f"({int(identity.signature_type)})",
        f"  chain id          : {identity.chain_id}",
        f"  generated at      : {snapshot.generated_at.isoformat()}",
        f"  open orders       : {snapshot.open_order_count}",
        f"  fills / trades    : {snapshot.fill_count}",
        f"  balances          : {snapshot.balance_count}",
        f"  allowances        : {snapshot.allowance_count} "
        f"(supported={snapshot.allowances_supported})",
    ]
    for note in snapshot.notes:
        lines.append(f"  note              : {note}")
    print("\n".join(lines))


async def _diagnose() -> int:
    config = load_config()
    reader = build_account_reader(config)
    service = AuthenticationService(reader=reader)
    try:
        snapshot = await service.diagnose()
    finally:
        await reader.aclose()
    _print_snapshot(snapshot)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="polymarket_pair_bot.auth.cli",
        description=(
            "Read-only authenticated account diagnostics. "
            "Never submits or cancels orders."
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser(
        "diagnose", help="Print a read-only authenticated account snapshot."
    )
    args = parser.parse_args(argv)

    if args.command == "diagnose":
        try:
            return asyncio.run(_diagnose())
        except AuthConfigurationError as exc:
            print(f"configuration error: {exc}", file=sys.stderr)
            return 2
        except UnsupportedAuthOperationError as exc:
            print(f"unsupported (blocked) operation: {exc}", file=sys.stderr)
            return 3
    parser.error(f"unknown command: {args.command!r}")
    return 1  # pragma: no cover - argparse exits before reaching here


if __name__ == "__main__":
    raise SystemExit(main())
