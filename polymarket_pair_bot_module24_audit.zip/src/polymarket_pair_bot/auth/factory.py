"""Composition helpers wiring config -> identity/credentials -> reader.

Mode selection is fail-closed:

* paper/dev (LIVE_TRADING disabled): a :class:`StubAccountReader` with an empty
  account is returned -- safe, no network, no secrets required beyond the
  operator-provided addresses;
* live (LIVE_TRADING enabled): a :class:`ClobAuthenticatedReader` is built with
  loaded credentials. Its reads are currently blocked (the CLOB API is not
  verified locally), so it raises a typed unsupported-operation error rather
  than guessing.

This module does not enable live trading; it only reflects the configured mode.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polymarket_pair_bot.auth.addresses import (
    build_account_identity,
    derive_signer_address,
)
from polymarket_pair_bot.auth.clob_adapter import ClobAuthenticatedReader
from polymarket_pair_bot.auth.credentials import ConfigCredentialProvider
from polymarket_pair_bot.auth.errors import AuthConfigurationError
from polymarket_pair_bot.auth.models import AccountIdentity
from polymarket_pair_bot.auth.ports import AuthenticatedAccountReader
from polymarket_pair_bot.auth.stub_reader import StubAccountReader

if TYPE_CHECKING:
    from polymarket_pair_bot.config.settings import AppConfig


def resolve_account_identity(config: AppConfig) -> AccountIdentity:
    """Validate and build the account identity from configuration."""
    wallet = config.wallet
    signer = wallet.polymarket_signer_address
    if signer is None:
        if wallet.polymarket_private_key is None:
            raise AuthConfigurationError(
                "POLYMARKET_SIGNER_ADDRESS is not set and no private key is "
                "configured to derive it"
            )
        signer = derive_signer_address(
            wallet.polymarket_private_key.get_secret_value()
        )
    funder = wallet.polymarket_funder_address
    if funder is None:
        raise AuthConfigurationError("POLYMARKET_FUNDER_ADDRESS is required")
    return build_account_identity(
        signer_address=signer,
        funder_address=funder,
        signature_type=wallet.polymarket_signature_type,
        chain_id=config.polygon.polygon_chain_id,
    )


def build_account_reader(config: AppConfig) -> AuthenticatedAccountReader:
    """Build the appropriate read-only account reader for the run mode."""
    identity = resolve_account_identity(config)
    if config.application.live_trading:
        credentials = ConfigCredentialProvider(config.polymarket_auth).load()
        return ClobAuthenticatedReader(
            identity=identity,
            credentials=credentials,
            public_settings=config.polymarket_public,
        )
    # Paper/dev: safe, empty, read-only account view.
    return StubAccountReader(identity=identity)


__all__ = ["build_account_reader", "resolve_account_identity"]
