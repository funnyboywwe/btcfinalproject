"""Loading of authenticated Polymarket API credentials (never logged).

Credentials are wrapped in pydantic ``SecretStr`` so they are masked in reprs,
logs and tracebacks. :class:`ConfigCredentialProvider` loads them from validated
settings. Deriving credentials from a private key is a *blocked* operation here:
it requires the official CLOB package whose API is not verified locally, so
:class:`DerivedCredentialProvider` raises a typed unsupported-operation error.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, SecretStr

from polymarket_pair_bot.auth.errors import (
    CredentialError,
    UnsupportedAuthOperationError,
)
from polymarket_pair_bot.config.models import PolymarketAuthSettings


class ApiCredentials(BaseModel):
    """Authenticated CLOB API credentials (L2 headers). Secret by construction."""

    model_config = ConfigDict(frozen=True)

    api_key: SecretStr
    api_secret: SecretStr
    api_passphrase: SecretStr

    def as_header_material(self) -> dict[str, str]:
        """Return raw values for signing/headers. NEVER log the result."""
        return {
            "api_key": self.api_key.get_secret_value(),
            "api_secret": self.api_secret.get_secret_value(),
            "api_passphrase": self.api_passphrase.get_secret_value(),
        }

    def __str__(self) -> str:  # defensive: never expose secret material
        return "ApiCredentials(***REDACTED***)"

    __repr__ = __str__


@runtime_checkable
class CredentialProvider(Protocol):
    """Supplies authenticated API credentials from some safe source."""

    def load(self) -> ApiCredentials: ...


class ConfigCredentialProvider:
    """Loads credentials from validated :class:`PolymarketAuthSettings`."""

    def __init__(self, auth_settings: PolymarketAuthSettings) -> None:
        self._auth = auth_settings

    def load(self) -> ApiCredentials:
        if not self._auth.has_full_auth:
            missing = ", ".join(self._auth.missing_fields())
            raise CredentialError(
                f"Authenticated API credentials are incomplete; missing: {missing}"
            )
        # ``has_full_auth`` guarantees these SecretStr values are present.
        assert self._auth.polymarket_api_key is not None
        assert self._auth.polymarket_api_secret is not None
        assert self._auth.polymarket_api_passphrase is not None
        return ApiCredentials(
            api_key=self._auth.polymarket_api_key,
            api_secret=self._auth.polymarket_api_secret,
            api_passphrase=self._auth.polymarket_api_passphrase,
        )


class DerivedCredentialProvider:
    """Blocked: deriving API credentials needs the unverified CLOB package."""

    def load(self) -> ApiCredentials:
        raise UnsupportedAuthOperationError(
            "derive_api_credentials",
            "key-based credential derivation needs the official CLOB package "
            "API, which is not verified locally; configure "
            "POLYMARKET_API_KEY/SECRET/PASSPHRASE instead",
        )


__all__ = [
    "ApiCredentials",
    "ConfigCredentialProvider",
    "CredentialProvider",
    "DerivedCredentialProvider",
]
