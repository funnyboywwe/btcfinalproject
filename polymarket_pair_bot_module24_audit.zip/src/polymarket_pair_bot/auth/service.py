"""Authentication service: read-only account diagnostics + readiness.

The service depends only on the :class:`AuthenticatedAccountReader` abstraction
(dependency inversion). :meth:`AuthenticationService.diagnose` performs a
read-only sweep of the account and returns a validated
:class:`~polymarket_pair_bot.auth.models.AccountSnapshot`. It NEVER submits or
cancels an order, and it never enables live trading -- diagnostics are read-only
regardless of the run mode.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime

from polymarket_pair_bot.auth.errors import (
    AuthConnectionError,
    UnsupportedAuthOperationError,
)
from polymarket_pair_bot.auth.models import AccountSnapshot, AllowanceView
from polymarket_pair_bot.auth.ports import AuthenticatedAccountReader
from polymarket_pair_bot.auth.readiness import (
    AuthReadinessState,
    AuthReadinessTracker,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("auth.service")


def _utcnow() -> datetime:
    return datetime.now(UTC)


class AuthenticationService:
    """Coordinates read-only authenticated access and readiness state."""

    def __init__(
        self,
        *,
        reader: AuthenticatedAccountReader,
        readiness: AuthReadinessTracker | None = None,
        clock: Callable[[], datetime] = _utcnow,
    ) -> None:
        self._reader = reader
        self._readiness = readiness or AuthReadinessTracker()
        self._clock = clock

    @property
    def readiness(self) -> AuthReadinessTracker:
        return self._readiness

    async def diagnose(self) -> AccountSnapshot:
        """Return a read-only account snapshot. Never submits or cancels."""
        await self._readiness.set(
            AuthReadinessState.CREDENTIALS_LOADED,
            "starting read-only diagnostics",
        )
        notes: list[str] = []
        try:
            open_orders = await self._reader.get_open_orders()
            trades = await self._reader.get_trades()
            balances = await self._reader.get_balances()
            allowances: tuple[AllowanceView, ...] = ()
            allowances_supported = True
            try:
                allowances = await self._reader.get_allowances()
            except UnsupportedAuthOperationError as exc:
                allowances_supported = False
                notes.append(f"allowances unavailable: {exc.operation}")
        except UnsupportedAuthOperationError:
            await self._readiness.set(
                AuthReadinessState.DEGRADED,
                "authenticated reads not implemented (blocked adapter)",
            )
            raise
        except Exception as exc:
            await self._readiness.set(
                AuthReadinessState.DEGRADED, "authenticated read failed"
            )
            raise AuthConnectionError("authenticated read failed") from exc

        snapshot = AccountSnapshot(
            identity=self._reader.identity,
            generated_at=self._clock(),
            open_orders=open_orders,
            fills=trades,
            balances=balances,
            allowances=allowances,
            allowances_supported=allowances_supported,
            notes=tuple(notes),
        )
        await self._readiness.set(
            AuthReadinessState.CLIENT_READY, "read-only diagnostics complete"
        )
        _LOGGER.info("auth_diagnostics", extra=dict(snapshot.summary()))
        return snapshot


__all__ = ["AuthenticationService"]
