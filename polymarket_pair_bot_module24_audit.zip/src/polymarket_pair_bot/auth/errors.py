"""Typed errors for Polymarket authentication and read-only account access.

Every message here is safe to log: no secret, key, passphrase, signature or
signed payload is ever interpolated into an exception. When external package
behaviour cannot be verified locally we raise :class:`UnsupportedAuthOperationError`
rather than guessing an implementation (fail closed).
"""

from __future__ import annotations


class AuthError(Exception):
    """Base class for every authentication-module error."""


class AuthConfigurationError(AuthError):
    """Authenticated configuration is missing or inconsistent."""


class CredentialError(AuthConfigurationError):
    """API credentials could not be loaded (never echoes secret material)."""


class AddressValidationError(AuthConfigurationError):
    """A signer or funder address is malformed."""


class AuthConnectionError(AuthError):
    """An authenticated connection or read failed at runtime."""


class StaleUserStreamError(AuthConnectionError):
    """The authenticated user stream breached its freshness bound."""


class UnsupportedAuthOperationError(AuthError):
    """A blocked adapter method whose behaviour is not verified locally.

    Per the project's safety rules, when the official CLOB package's public API
    cannot be inspected/verified locally we DO NOT guess method names or
    response shapes. The concrete live adapter raises this typed error instead,
    naming the operation that must be implemented after inspecting the real
    installed package API.
    """

    def __init__(self, operation: str, detail: str = "") -> None:
        self.operation = operation
        message = (
            f"Authenticated operation {operation!r} is not implemented because "
            "the official Polymarket CLOB package API could not be verified "
            "locally. Inspect the installed package and implement the mapping "
            "before enabling this path."
        )
        if detail:
            message = f"{message} ({detail})"
        super().__init__(message)


__all__ = [
    "AddressValidationError",
    "AuthConfigurationError",
    "AuthConnectionError",
    "AuthError",
    "CredentialError",
    "StaleUserStreamError",
    "UnsupportedAuthOperationError",
]
