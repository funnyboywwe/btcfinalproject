"""Typed protocols for authenticated account access (dependency inversion).

Domain/strategy/service code depends only on these abstractions -- never on the
official CLOB package, httpx, websockets or any concrete client. Paper and live
adapters implement the SAME :class:`AuthenticatedAccountReader` protocol (a
safety requirement), so a stub can be swapped for the live adapter without any
upstream change.

The reader is strictly READ-ONLY: it exposes no submit or cancel method.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Protocol, runtime_checkable

from polymarket_pair_bot.auth.models import (
    AccountIdentity,
    AllowanceView,
    BalanceView,
    OpenOrderView,
    OrderStatusView,
    TradeFillView,
)


@runtime_checkable
class AuthenticatedAccountReader(Protocol):
    """Read-only authenticated account access. Never submits or cancels."""

    @property
    def identity(self) -> AccountIdentity: ...

    async def get_open_orders(
        self, *, market_id: str | None = None
    ) -> tuple[OpenOrderView, ...]: ...

    async def get_order_status(self, order_id: str) -> OrderStatusView | None: ...

    async def get_trades(
        self, *, market_id: str | None = None
    ) -> tuple[TradeFillView, ...]: ...

    async def get_balances(self) -> tuple[BalanceView, ...]: ...

    async def get_allowances(self) -> tuple[AllowanceView, ...]: ...

    async def aclose(self) -> None: ...


@runtime_checkable
class UserStreamConnection(Protocol):
    """A single authenticated user-stream connection yielding raw messages.

    ``receive`` returns one decoded message mapping and must raise on close or
    transport error so the reconnect loop can recover with a fresh sync.
    """

    async def receive(self) -> Mapping[str, Any]: ...

    async def aclose(self) -> None: ...


@runtime_checkable
class UserStreamConnectionFactory(Protocol):
    """Opens a fresh authenticated user-stream connection on each call.

    Every successful connect represents a new authoritative synchronization
    point (a reconnect requires a fresh authoritative sync).
    """

    async def connect(self) -> UserStreamConnection: ...


__all__ = [
    "AuthenticatedAccountReader",
    "UserStreamConnection",
    "UserStreamConnectionFactory",
]
