"""Bounded FIFO/LRU de-duplication cache for user-stream messages.

Fill and order messages are NOT assumed unique, so the user stream de-duplicates
by a stable message key. The cache is bounded (no unbounded memory growth); the
oldest key is evicted once capacity is exceeded. Authoritative de-duplication
still lives in PostgreSQL (unique ids); this is an in-memory guard only.
"""

from __future__ import annotations

from collections import OrderedDict


class BoundedDedupCache:
    """Remembers up to ``capacity`` recently-seen keys."""

    def __init__(self, capacity: int) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be a positive integer")
        self._capacity = capacity
        self._seen: OrderedDict[str, None] = OrderedDict()

    @property
    def capacity(self) -> int:
        return self._capacity

    def add(self, key: str) -> bool:
        """Record ``key``; return ``True`` if new, ``False`` if a duplicate."""
        if key in self._seen:
            self._seen.move_to_end(key)
            return False
        self._seen[key] = None
        if len(self._seen) > self._capacity:
            self._seen.popitem(last=False)
        return True

    def __contains__(self, key: object) -> bool:
        return key in self._seen

    def __len__(self) -> int:
        return len(self._seen)


__all__ = ["BoundedDedupCache"]
