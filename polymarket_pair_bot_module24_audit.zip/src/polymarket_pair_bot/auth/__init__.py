"""Module 15: Polymarket authentication and read-only account access.

Only package-independent, import-safe symbols are re-exported here (stdlib +
pydantic). The live CLOB adapter, the composition factory and the CLI are NOT
imported at package import time so that importing :mod:`polymarket_pair_bot.auth`
never requires the official CLOB package, eth-account, websockets or httpx.

This module does not claim or assume the strategy is profitable, and it
implements no live execution -- account access here is strictly read-only.
"""

from __future__ import annotations

from polymarket_pair_bot.auth.credentials import (
    ApiCredentials,
    ConfigCredentialProvider,
    CredentialProvider,
    DerivedCredentialProvider,
)
from polymarket_pair_bot.auth.dedup import BoundedDedupCache
from polymarket_pair_bot.auth.errors import (
    AddressValidationError,
    AuthConfigurationError,
    AuthConnectionError,
    AuthError,
    CredentialError,
    StaleUserStreamError,
    UnsupportedAuthOperationError,
)
from polymarket_pair_bot.auth.models import (
    AccountIdentity,
    AccountSnapshot,
    AllowanceView,
    BalanceView,
    OpenOrderView,
    OrderStatusView,
    TradeFillView,
)
from polymarket_pair_bot.auth.ports import (
    AuthenticatedAccountReader,
    UserStreamConnection,
    UserStreamConnectionFactory,
)
from polymarket_pair_bot.auth.readiness import (
    AuthReadinessSnapshot,
    AuthReadinessState,
    AuthReadinessTracker,
)
from polymarket_pair_bot.auth.service import AuthenticationService
from polymarket_pair_bot.auth.stub_reader import StubAccountReader
from polymarket_pair_bot.auth.user_stream import ReconnectingUserStream

__all__ = [
    "AccountIdentity",
    "AccountSnapshot",
    "AddressValidationError",
    "AllowanceView",
    "ApiCredentials",
    "AuthConfigurationError",
    "AuthConnectionError",
    "AuthError",
    "AuthReadinessSnapshot",
    "AuthReadinessState",
    "AuthReadinessTracker",
    "AuthenticatedAccountReader",
    "AuthenticationService",
    "BalanceView",
    "BoundedDedupCache",
    "ConfigCredentialProvider",
    "CredentialError",
    "CredentialProvider",
    "DerivedCredentialProvider",
    "OpenOrderView",
    "OrderStatusView",
    "ReconnectingUserStream",
    "StaleUserStreamError",
    "StubAccountReader",
    "TradeFillView",
    "UnsupportedAuthOperationError",
    "UserStreamConnection",
    "UserStreamConnectionFactory",
]
