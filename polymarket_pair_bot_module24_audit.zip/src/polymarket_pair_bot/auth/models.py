"""Local Pydantic v2 adapters validating authenticated read-only account data.

These models are the bot's *own* normalized representation of account data
(open orders, order status, fills/trades, balances, allowances). An adapter is
responsible for mapping an external payload into these shapes; validation then
happens here. We deliberately only model the fields the bot uses -- we never
invent undocumented API fields.

Monetary values, prices and quantities are ``Decimal`` (never binary floats):
a strict before-validator refuses ``float`` inputs outright via
``domain.precision.coerce_decimal``.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Annotated, Any

from pydantic import (
    BaseModel,
    BeforeValidator,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

from polymarket_pair_bot.config.enums import SignatureType
from polymarket_pair_bot.config.validators import ensure_valid_evm_address
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus, OutcomeSide
from polymarket_pair_bot.domain.precision import coerce_decimal

_BASE = ConfigDict(frozen=True, extra="forbid")


def _to_decimal(value: Any) -> Decimal:
    """Coerce to ``Decimal``; refuses binary floats (see domain.precision).

    ``coerce_decimal`` raises ``TypeError`` for floats and ``InvalidOperation``
    for malformed strings. Pydantic only wraps ``ValueError``/``AssertionError``
    into a ``ValidationError``, so we re-raise as ``ValueError`` to guarantee a
    clean validation error when adapting external data. The message never
    contains secret material.
    """
    try:
        return coerce_decimal(value)
    except (TypeError, InvalidOperation, ValueError) as exc:
        raise ValueError(str(exc)) from exc


def _to_optional_decimal(value: Any) -> Decimal | None:
    return None if value is None else _to_decimal(value)


# A Decimal that never accepts a binary float.
Money = Annotated[Decimal, BeforeValidator(_to_decimal)]
OptionalMoney = Annotated[Decimal | None, BeforeValidator(_to_optional_decimal)]


def _non_negative(value: Decimal) -> Decimal:
    if value < 0:
        raise ValueError("value must be non-negative")
    return value


def _price_range(value: Decimal) -> Decimal:
    if value < 0 or value > 1:
        raise ValueError("price must be within [0, 1]")
    return value


class AccountIdentity(BaseModel):
    """Validated, non-secret identity of the trading account."""

    model_config = _BASE

    signer_address: str
    funder_address: str
    signature_type: SignatureType
    chain_id: int = Field(gt=0)

    @field_validator("signer_address", "funder_address")
    @classmethod
    def _check_addr(cls, value: str) -> str:
        return ensure_valid_evm_address(value).lower()


class OpenOrderView(BaseModel):
    """A single non-terminal (open) order as the bot understands it.

    ``size_matched`` is the confirmed matched/filled portion. An open order is
    NEVER treated as a matched pair; only ``status is FILLED`` is complete.
    """

    model_config = _BASE

    order_id: str = Field(min_length=1)
    token_id: str = Field(min_length=1)
    market_id: str | None = None
    outcome: OutcomeSide | None = None
    side: OrderSide
    status: OrderStatus
    price: Money
    original_size: Money
    size_matched: Money = Decimal(0)

    @field_validator("price")
    @classmethod
    def _vprice(cls, value: Decimal) -> Decimal:
        return _price_range(value)

    @field_validator("original_size", "size_matched")
    @classmethod
    def _vsize(cls, value: Decimal) -> Decimal:
        return _non_negative(value)

    @model_validator(mode="after")
    def _matched_le_original(self) -> OpenOrderView:
        if self.size_matched > self.original_size:
            raise ValueError("size_matched cannot exceed original_size")
        return self

    @property
    def is_confirmed_complete(self) -> bool:
        """True only when the whole order quantity is confirmed filled."""
        return self.status is OrderStatus.FILLED


class OrderStatusView(BaseModel):
    """The status of a single order looked up by id."""

    model_config = _BASE

    order_id: str = Field(min_length=1)
    status: OrderStatus
    size_matched: Money = Decimal(0)
    original_size: OptionalMoney = None

    @field_validator("size_matched")
    @classmethod
    def _vsize(cls, value: Decimal) -> Decimal:
        return _non_negative(value)

    @property
    def is_confirmed_complete(self) -> bool:
        return self.status is OrderStatus.FILLED


class TradeFillView(BaseModel):
    """A confirmed fill/trade. Fills are NOT assumed unique; dedup upstream."""

    model_config = _BASE

    fill_id: str = Field(min_length=1)
    order_id: str = Field(min_length=1)
    token_id: str = Field(min_length=1)
    market_id: str | None = None
    side: OrderSide
    price: Money
    size: Money
    fee_paid: Money = Decimal(0)
    matched_at: datetime | None = None

    @field_validator("price")
    @classmethod
    def _vprice(cls, value: Decimal) -> Decimal:
        return _price_range(value)

    @field_validator("size", "fee_paid")
    @classmethod
    def _vsize(cls, value: Decimal) -> Decimal:
        return _non_negative(value)


class BalanceView(BaseModel):
    """A balance for one asset (e.g. ``USDC`` collateral or a token id)."""

    model_config = _BASE

    asset: str = Field(min_length=1)
    total: Money
    available: Money

    @field_validator("total", "available")
    @classmethod
    def _vamount(cls, value: Decimal) -> Decimal:
        return _non_negative(value)

    @model_validator(mode="after")
    def _available_le_total(self) -> BalanceView:
        if self.available > self.total:
            raise ValueError("available cannot exceed total")
        return self


class AllowanceView(BaseModel):
    """An ERC-20/1155 allowance granted to a spender (where reportable)."""

    model_config = _BASE

    token: str = Field(min_length=1)
    spender: str = Field(min_length=1)
    amount: Money

    @field_validator("amount")
    @classmethod
    def _vamount(cls, value: Decimal) -> Decimal:
        return _non_negative(value)


class AccountSnapshot(BaseModel):
    """A read-only, validated snapshot of authenticated account state.

    ``allowances_supported`` is ``False`` when the underlying adapter cannot
    report allowances (a blocked/unsupported operation) rather than guessing.
    """

    model_config = _BASE

    identity: AccountIdentity
    generated_at: datetime
    open_orders: tuple[OpenOrderView, ...] = ()
    fills: tuple[TradeFillView, ...] = ()
    balances: tuple[BalanceView, ...] = ()
    allowances: tuple[AllowanceView, ...] = ()
    allowances_supported: bool = True
    notes: tuple[str, ...] = ()

    @property
    def open_order_count(self) -> int:
        return len(self.open_orders)

    @property
    def fill_count(self) -> int:
        return len(self.fills)

    @property
    def balance_count(self) -> int:
        return len(self.balances)

    @property
    def allowance_count(self) -> int:
        return len(self.allowances)

    def summary(self) -> dict[str, int | bool]:
        """Return a non-secret count summary safe for logs and the CLI."""
        return {
            "open_orders": self.open_order_count,
            "fills": self.fill_count,
            "balances": self.balance_count,
            "allowances": self.allowance_count,
            "allowances_supported": self.allowances_supported,
        }


__all__ = [
    "AccountIdentity",
    "AccountSnapshot",
    "AllowanceView",
    "BalanceView",
    "Money",
    "OpenOrderView",
    "OptionalMoney",
    "OrderStatusView",
    "TradeFillView",
]
