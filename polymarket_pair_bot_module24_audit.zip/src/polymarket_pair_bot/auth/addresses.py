"""Signer/funder address validation and (blocked) signer derivation.

Address *format* validation (0x + 40 hex) is pure and lives here. Full EIP-55
checksum validation and deriving the signer address from a private key both
require an Ethereum library; that path lazily imports ``eth_account`` and, when
unavailable, raises a typed unsupported-operation error rather than guessing.
Key material is never echoed in any error message.
"""

from __future__ import annotations

from pydantic import ValidationError

from polymarket_pair_bot.auth.errors import (
    AddressValidationError,
    UnsupportedAuthOperationError,
)
from polymarket_pair_bot.auth.models import AccountIdentity
from polymarket_pair_bot.config.enums import SignatureType


def build_account_identity(
    *,
    signer_address: str,
    funder_address: str,
    signature_type: SignatureType,
    chain_id: int,
) -> AccountIdentity:
    """Validate and build an :class:`AccountIdentity` (fails closed)."""
    try:
        return AccountIdentity(
            signer_address=signer_address,
            funder_address=funder_address,
            signature_type=signature_type,
            chain_id=chain_id,
        )
    except (ValidationError, ValueError) as exc:
        raise AddressValidationError(
            "Invalid account identity; expected 0x-prefixed 20-byte hex signer "
            "and funder addresses and a positive chain id"
        ) from exc


def derive_signer_address(private_key: str) -> str:
    """Derive the signer (EOA) address from a private key.

    Lazily imports ``eth_account``; if it is not importable the operation is
    blocked with guidance to configure the signer address explicitly. The key
    is never included in any exception message.
    """
    try:
        from eth_account import Account
    except ImportError as exc:
        raise UnsupportedAuthOperationError(
            "derive_signer_address",
            "eth-account is not importable here; set POLYMARKET_SIGNER_ADDRESS "
            "explicitly instead",
        ) from exc
    try:
        account = Account.from_key(private_key)
    except (ValueError, TypeError) as exc:
        raise AddressValidationError(
            "could not derive signer address from the configured private key"
        ) from exc
    return str(account.address).lower()


__all__ = ["build_account_identity", "derive_signer_address"]
