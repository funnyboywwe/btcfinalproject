"""Authenticated readiness state (async-safe), including stream freshness.

Mirrors the style of :mod:`shared.health` but is specific to the authenticated
session lifecycle. Nothing here performs I/O.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum


class AuthReadinessState(str, Enum):
    """Lifecycle of the authenticated session."""

    UNINITIALIZED = "uninitialized"
    CREDENTIALS_LOADED = "credentials_loaded"
    CLIENT_READY = "client_ready"
    STREAM_LIVE = "stream_live"
    DEGRADED = "degraded"
    CLOSED = "closed"


_READY_STATES = frozenset(
    {AuthReadinessState.CLIENT_READY, AuthReadinessState.STREAM_LIVE}
)


def _utcnow() -> datetime:
    return datetime.now(UTC)


@dataclass(frozen=True, slots=True)
class AuthReadinessSnapshot:
    """Immutable point-in-time view of authenticated readiness."""

    state: AuthReadinessState
    detail: str
    updated_at: datetime
    stream_last_message_at: datetime | None

    @property
    def is_ready(self) -> bool:
        return self.state in _READY_STATES

    def stream_is_fresh(self, *, now: datetime, max_age_seconds: float) -> bool:
        """True when a stream message arrived within ``max_age_seconds``.

        Absent any message the stream is considered NOT fresh (fail closed).
        """
        if self.stream_last_message_at is None:
            return False
        age = (now - self.stream_last_message_at).total_seconds()
        return 0 <= age <= max_age_seconds


class AuthReadinessTracker:
    """Async-safe holder for the current authenticated readiness state."""

    def __init__(
        self, initial: AuthReadinessState = AuthReadinessState.UNINITIALIZED
    ) -> None:
        self._state = initial
        self._detail = ""
        self._updated_at = _utcnow()
        self._stream_at: datetime | None = None
        self._lock = asyncio.Lock()

    @property
    def state(self) -> AuthReadinessState:
        return self._state

    @property
    def is_ready(self) -> bool:
        return self._state in _READY_STATES

    def snapshot(self) -> AuthReadinessSnapshot:
        return AuthReadinessSnapshot(
            state=self._state,
            detail=self._detail,
            updated_at=self._updated_at,
            stream_last_message_at=self._stream_at,
        )

    async def set(
        self, state: AuthReadinessState, detail: str = ""
    ) -> AuthReadinessSnapshot:
        async with self._lock:
            self._state = state
            self._detail = detail
            self._updated_at = _utcnow()
            return self.snapshot()

    async def mark_stream_message(self, at: datetime | None = None) -> None:
        """Record a fresh stream message and mark the stream live."""
        async with self._lock:
            self._stream_at = at or _utcnow()
            if self._state is not AuthReadinessState.CLOSED:
                self._state = AuthReadinessState.STREAM_LIVE
                self._updated_at = _utcnow()


__all__ = [
    "AuthReadinessSnapshot",
    "AuthReadinessState",
    "AuthReadinessTracker",
]
