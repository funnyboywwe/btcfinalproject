"""In-memory read-only account reader for paper/dev mode and tests.

:class:`StubAccountReader` implements the SAME
:class:`~polymarket_pair_bot.auth.ports.AuthenticatedAccountReader` interface as
the live adapter (paper/live parity). It performs no network I/O and can NEVER
submit or cancel an order. By default it reports an empty account; tests inject
explicit fixtures.
"""

from __future__ import annotations

from collections.abc import Sequence

from polymarket_pair_bot.auth.errors import UnsupportedAuthOperationError
from polymarket_pair_bot.auth.models import (
    AccountIdentity,
    AllowanceView,
    BalanceView,
    OpenOrderView,
    OrderStatusView,
    TradeFillView,
)


class StubAccountReader:
    """Deterministic, side-effect-free authenticated account reader."""

    def __init__(
        self,
        identity: AccountIdentity,
        *,
        open_orders: Sequence[OpenOrderView] = (),
        order_statuses: Sequence[OrderStatusView] = (),
        trades: Sequence[TradeFillView] = (),
        balances: Sequence[BalanceView] = (),
        allowances: Sequence[AllowanceView] = (),
        allowances_supported: bool = True,
    ) -> None:
        self._identity = identity
        self._open_orders = tuple(open_orders)
        self._trades = tuple(trades)
        self._balances = tuple(balances)
        self._allowances = tuple(allowances)
        self._allowances_supported = allowances_supported
        statuses: dict[str, OrderStatusView] = {
            order.order_id: OrderStatusView(
                order_id=order.order_id,
                status=order.status,
                size_matched=order.size_matched,
                original_size=order.original_size,
            )
            for order in self._open_orders
        }
        statuses.update({status.order_id: status for status in order_statuses})
        self._statuses = statuses

    @property
    def identity(self) -> AccountIdentity:
        return self._identity

    async def get_open_orders(
        self, *, market_id: str | None = None
    ) -> tuple[OpenOrderView, ...]:
        if market_id is None:
            return self._open_orders
        return tuple(o for o in self._open_orders if o.market_id == market_id)

    async def get_order_status(self, order_id: str) -> OrderStatusView | None:
        return self._statuses.get(order_id)

    async def get_trades(
        self, *, market_id: str | None = None
    ) -> tuple[TradeFillView, ...]:
        if market_id is None:
            return self._trades
        return tuple(t for t in self._trades if t.market_id == market_id)

    async def get_balances(self) -> tuple[BalanceView, ...]:
        return self._balances

    async def get_allowances(self) -> tuple[AllowanceView, ...]:
        if not self._allowances_supported:
            raise UnsupportedAuthOperationError(
                "get_allowances",
                "this reader is configured to report allowances as unsupported",
            )
        return self._allowances

    async def aclose(self) -> None:
        return None


__all__ = ["StubAccountReader"]
