"""Console entry point for ``uv run polymarket-pair-bot``.

Without a subcommand the bot runs its normal application lifecycle (unchanged
from Module 0). Module 5 adds a ``discover-market`` subcommand:

    uv run polymarket-pair-bot discover-market [--slug ...] [--dry-run] [--json]

Module 6 adds a ``market-data-monitor`` subcommand:

    uv run polymarket-pair-bot market-data-monitor [--slug ...] [--duration-seconds N]

The subcommands only read public data (safe GETs / a read-only market-data
WebSocket) and never submit an order.
"""

from __future__ import annotations

import argparse
import asyncio
from collections.abc import Sequence

from polymarket_pair_bot.app.application import run_app
from polymarket_pair_bot.backtest import cli as backtest_cli
from polymarket_pair_bot.blockchain import cli as wallet_cli
from polymarket_pair_bot.ctf import cli as ctf_cli
from polymarket_pair_bot.dashboard import cli as dashboard_cli
from polymarket_pair_bot.market_data import cli as market_data_cli
from polymarket_pair_bot.market_discovery import cli as discover_cli
from polymarket_pair_bot.reconciliation import cli as reconcile_cli
from polymarket_pair_bot.recorder import cli as recorder_cli
from polymarket_pair_bot.release import cli as release_cli


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot",
        description="Polymarket BTC 5-minute pair-accumulation bot.",
    )
    sub = parser.add_subparsers(dest="command")
    discover = sub.add_parser(
        "discover-market",
        help="Discover and validate the current BTC 5-minute market.",
    )
    discover_cli.add_arguments(discover)
    monitor = sub.add_parser(
        "market-data-monitor",
        help="Stream and display the live Up/Down order books (read-only).",
    )
    market_data_cli.add_arguments(monitor)
    record = sub.add_parser(
        "record-market-data",
        help="Record research-grade Up/Down book snapshots (read-only).",
    )
    recorder_cli.add_start_arguments(record)
    export = sub.add_parser(
        "market-data-export",
        help="Export recorded market data for a UTC date range.",
    )
    recorder_cli.add_export_arguments(export)
    validate = sub.add_parser(
        "market-data-validate",
        help="Validate recorded Parquet files.",
    )
    recorder_cli.add_validate_arguments(validate)
    replay = sub.add_parser(
        "market-data-replay",
        help="Deterministically replay a recorded window (read-only).",
    )
    recorder_cli.add_replay_arguments(replay)
    reconcile = sub.add_parser(
        "reconcile",
        help="Run one authoritative reconciliation pass (read + persist).",
    )
    reconcile_cli.add_arguments(reconcile)
    wallet = sub.add_parser(
        "wallet-diagnostics",
        help="Read-only Polygon wallet diagnostics (balances/nonce/allowances).",
    )
    wallet_cli.add_arguments(wallet)
    ctf_mergeable = sub.add_parser(
        "ctf-mergeable",
        help="Read-only CTF mergeable-quantity report (no writes).",
    )
    ctf_cli.add_arguments(ctf_mergeable)
    render_dashboard = sub.add_parser(
        "render-dashboard",
        help="Render the read-only operator dashboard HTML (no server/network).",
    )
    dashboard_cli.add_arguments(render_dashboard)
    run_backtest = sub.add_parser(
        "run-backtest",
        help="Deterministically replay recorded windows and export reports "
        "(paper only; no network/orders).",
    )
    backtest_cli.add_arguments(run_backtest)
    release_gate = sub.add_parser(
        "release-gate",
        help="Run all release gates and print a go-live readiness report "
        "(read-only; never enables live trading).",
    )
    release_cli.add_arguments(release_gate)
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    """Synchronous entry point invoked by the installed console script.

    Interface note (Module 5): ``main`` now accepts an optional ``argv`` and
    dispatches subcommands. Calling it with no arguments preserves the previous
    behaviour of running the application lifecycle.
    """
    args = _build_parser().parse_args(argv)
    if args.command == "discover-market":
        raise SystemExit(discover_cli.run(args))
    if args.command == "market-data-monitor":
        raise SystemExit(market_data_cli.run(args))
    if args.command == "record-market-data":
        raise SystemExit(recorder_cli.run_start(args))
    if args.command == "market-data-export":
        raise SystemExit(recorder_cli.run_export(args))
    if args.command == "market-data-validate":
        raise SystemExit(recorder_cli.run_validate(args))
    if args.command == "market-data-replay":
        raise SystemExit(recorder_cli.run_replay(args))
    if args.command == "reconcile":
        raise SystemExit(reconcile_cli.run(args))
    if args.command == "wallet-diagnostics":
        raise SystemExit(wallet_cli.run(args))
    if args.command == "ctf-mergeable":
        raise SystemExit(ctf_cli.run(args))
    if args.command == "render-dashboard":
        raise SystemExit(dashboard_cli.run(args))
    if args.command == "run-backtest":
        raise SystemExit(backtest_cli.run(args))
    if args.command == "release-gate":
        raise SystemExit(release_cli.run(args))

    try:
        asyncio.run(run_app())
    except KeyboardInterrupt:  # pragma: no cover - defensive; signals preferred
        pass


if __name__ == "__main__":
    main()
