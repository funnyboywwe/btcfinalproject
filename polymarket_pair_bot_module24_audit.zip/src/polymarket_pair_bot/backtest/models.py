"""Pydantic models validating external backtest inputs (Module 22).

External data validated here (requirement 6):

* :class:`MarketSpec` / :class:`MarketSpecFile` -- the per-window market
  definition (condition id, token ids, tick size, window open/close) supplied
  alongside recorded book data. The recorder persists only book snapshots keyed
  by an opaque ``window_id``; the authoritative market metadata is provided out
  of band and validated here before being turned into a domain
  :class:`BinaryMarket`.
* :class:`BacktestRunConfig` -- per-run knobs (seed, optional window filter,
  per-window snapshot cap).

Every monetary value is a ``Decimal`` (never a binary float); a float tick size
is rejected outright so JSON must supply it as a string. Token ids are validated
as base-10 uint strings by the domain value objects. Nothing here asserts the
strategy is profitable.
"""

from __future__ import annotations

from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    MarketWindow,
    OutcomeToken,
)
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    ConditionId,
    MarketId,
    TickSize,
    TokenId,
    UnixTimestamp,
)


class MarketSpec(BaseModel):
    """Authoritative market metadata for one recorded window."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    window_id: str = Field(min_length=1)
    market_id: str = Field(min_length=1)
    condition_id: str = Field(min_length=1)
    up_token_id: str = Field(min_length=1)
    down_token_id: str = Field(min_length=1)
    tick_size: Decimal = Field(gt=0, le=1)
    open_epoch: int = Field(ge=0)
    close_epoch: int = Field(gt=0)

    @field_validator("tick_size", mode="before")
    @classmethod
    def _reject_float_tick(cls, value: object) -> object:
        if isinstance(value, float):
            raise ValueError("tick_size must be a string or integer, not a float")
        return value

    @model_validator(mode="after")
    def _check(self) -> "MarketSpec":
        if self.close_epoch <= self.open_epoch:
            raise ValueError("close_epoch must be after open_epoch")
        if self.up_token_id == self.down_token_id:
            raise ValueError("up_token_id and down_token_id must differ")
        return self

    def to_market(self) -> BinaryMarket:
        """Project to the validated domain :class:`BinaryMarket`."""
        market_id = MarketId(self.market_id)
        condition_id = ConditionId(self.condition_id)
        window = MarketWindow(
            market_id=market_id,
            condition_id=condition_id,
            open_time=UnixTimestamp(self.open_epoch),
            close_time=UnixTimestamp(self.close_epoch),
        )
        tick = TickSize(self.tick_size)
        up = OutcomeToken(
            token_id=TokenId(self.up_token_id),
            side=OutcomeSide.UP,
            market_id=market_id,
            tick_size=tick,
        )
        down = OutcomeToken(
            token_id=TokenId(self.down_token_id),
            side=OutcomeSide.DOWN,
            market_id=market_id,
            tick_size=tick,
        )
        return BinaryMarket(
            market_id=market_id,
            condition_id=condition_id,
            window=window,
            up_token=up,
            down_token=down,
        )


class MarketSpecFile(BaseModel):
    """A collection of market specs, as loaded from a JSON spec file."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    specs: tuple[MarketSpec, ...] = ()

    def by_window(self) -> dict[str, MarketSpec]:
        """Index the specs by ``window_id`` (last spec wins on duplicates)."""
        return {spec.window_id: spec for spec in self.specs}


class BacktestRunConfig(BaseModel):
    """Per-run knobs for one backtest invocation.

    ``seed`` makes every stochastic draw in the paper execution simulator
    reproducible (requirement 4). ``window_ids`` optionally restricts the run to
    a subset; ``max_snapshots_per_window`` optionally caps replay length.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    seed: int = 0
    label: str = "backtest"
    window_ids: tuple[str, ...] = ()
    max_snapshots_per_window: int = Field(default=0, ge=0)

    def includes(self, window_id: str) -> bool:
        """True when ``window_id`` should be replayed by this run."""
        return not self.window_ids or window_id in self.window_ids


__all__ = [
    "BacktestRunConfig",
    "MarketSpec",
    "MarketSpecFile",
]
