"""Pure conversion of recorded snapshots into replay inputs (Module 22).

This module is side-effect free and deterministic. It translates a recorder
:class:`RecordedBookSide` into the domain :class:`OrderBookSnapshot` the detector
and paper adapter understand, and synthesizes conservative trade prints from the
change between two consecutive snapshots.

Look-ahead safety (requirement 6): every function here derives its output from
the current snapshot and, for trade synthesis, the immediately preceding
snapshot only. Both timestamps are less than or equal to the event instant, so
no future information can influence a decision made at the event instant.

Synthetic trades are a documented, conservative model: the recorder captures L2
book snapshots but not the exchange trade tape, so we infer executed volume from
the reduction in size at an unchanged best bid/ask. A bid whose size shrank is
modeled as a SELL-aggressor print at that bid; an ask whose size shrank is
modeled as a BUY-aggressor print at that ask. Volume is capped at the observed
reduction (never invented). Real recorded trade prints would be preferable; this
is explicitly a proxy and asserts nothing about profitability.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.entities import OrderBookSnapshot, PriceLevel
from polymarket_pair_bot.domain.enums import OrderSide
from polymarket_pair_bot.domain.recording import RecordedBookSide, RecordedLevel
from polymarket_pair_bot.domain.value_objects import (
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.types import TradeTick

_ZERO = Decimal(0)


def side_is_fresh(side: RecordedBookSide) -> bool:
    """True when a side's recorded book is usable and fresh (fail closed)."""
    flags = side.flags
    return (
        flags.has_snapshot
        and flags.is_live
        and not flags.is_stale
        and not flags.is_unavailable
    )


def _safe_level(level: RecordedLevel) -> PriceLevel | None:
    """Build a validated price level, skipping out-of-domain or empty rows."""
    if level.size is None or level.size <= _ZERO:
        return None
    try:
        return PriceLevel(ProbabilityPrice(level.price), Shares(level.size))
    except (ValueError, TypeError):
        return None


def to_book_snapshot(
    side: RecordedBookSide, token_id: TokenId, as_of: UnixTimestamp
) -> OrderBookSnapshot | None:
    """Convert a recorded side into a domain book snapshot, or ``None``.

    Returns ``None`` when the side carried no usable snapshot. Levels are sorted
    defensively (bids descending, asks ascending) and invalid levels dropped.
    """
    if not side.flags.has_snapshot:
        return None
    bids = [lvl for lvl in (_safe_level(row) for row in side.bids) if lvl is not None]
    asks = [lvl for lvl in (_safe_level(row) for row in side.asks) if lvl is not None]
    bids.sort(key=lambda lvl: lvl.price.value, reverse=True)
    asks.sort(key=lambda lvl: lvl.price.value)
    return OrderBookSnapshot(
        token_id=token_id,
        bids=tuple(bids),
        asks=tuple(asks),
        as_of=as_of,
        sequence=None,
    )


def _best(levels: tuple[RecordedLevel, ...], *, highest: bool) -> RecordedLevel | None:
    usable = [row for row in levels if row.size is not None and row.size > _ZERO]
    if not usable:
        return None
    return max(usable, key=lambda r: r.price) if highest else min(usable, key=lambda r: r.price)


def _maybe_trade(
    *,
    prev: RecordedLevel | None,
    curr: RecordedLevel | None,
    token_id: TokenId,
    aggressor: OrderSide,
    trade_id: str,
) -> TradeTick | None:
    if prev is None or curr is None:
        return None
    if prev.price != curr.price:
        return None
    delta = prev.size - curr.size
    if delta <= _ZERO:
        return None
    try:
        return TradeTick(
            trade_id=trade_id,
            token_id=token_id,
            price=ProbabilityPrice(curr.price),
            size=Shares(delta),
            aggressor=aggressor,
        )
    except (ValueError, TypeError):
        return None


def synthesize_trades(
    prev: RecordedBookSide | None,
    curr: RecordedBookSide,
    token_id: TokenId,
    *,
    trade_id_prefix: str,
) -> tuple[TradeTick, ...]:
    """Infer conservative trade prints from two consecutive recorded sides.

    Uses only ``prev`` and ``curr`` (both at or before the event instant), so it
    cannot leak future information. Returns an empty tuple on the first snapshot
    or when no reduction is observed at an unchanged best level.
    """
    if prev is None or not side_is_fresh(curr) or not side_is_fresh(prev):
        return ()
    trades: list[TradeTick] = []
    sell = _maybe_trade(
        prev=_best(prev.bids, highest=True),
        curr=_best(curr.bids, highest=True),
        token_id=token_id,
        aggressor=OrderSide.SELL,
        trade_id=f"{trade_id_prefix}:bid",
    )
    if sell is not None:
        trades.append(sell)
    buy = _maybe_trade(
        prev=_best(prev.asks, highest=False),
        curr=_best(curr.asks, highest=False),
        token_id=token_id,
        aggressor=OrderSide.BUY,
        trade_id=f"{trade_id_prefix}:ask",
    )
    if buy is not None:
        trades.append(buy)
    return tuple(trades)


__all__ = [
    "side_is_fresh",
    "synthesize_trades",
    "to_book_snapshot",
]
