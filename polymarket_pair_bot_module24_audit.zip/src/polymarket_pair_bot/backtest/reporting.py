"""Backtest report exporters: JSON, CSV and HTML (Module 22, requirement 8).

All exporters are pure, stdlib-only and side-effect free apart from the file
write helpers. Every monetary figure is rendered from an exact ``Decimal`` via
``format(value, "f")`` (never a binary float). The HTML exporter escapes every
dynamic value with :func:`html.escape` (``quote=True``) to avoid injection from
recorded slugs / reasons. No secret, key or signed payload is ever emitted, and
the report carries an explicit non-profitability disclaimer.
"""

from __future__ import annotations

import csv
import html
import io
import json
from decimal import Decimal
from pathlib import Path

from polymarket_pair_bot.backtest.metrics import (
    BacktestReport,
    BucketMetrics,
    WindowResult,
)

_DISCLAIMER = (
    "Backtest figures are modeled estimates from recorded data. They do not "
    "assert, imply or guarantee that the strategy is profitable."
)

_EM_DASH = "\u2014"


def _fmt(value: Decimal | int | None) -> str:
    if value is None:
        return _EM_DASH
    if isinstance(value, Decimal):
        return format(value, "f")
    return str(value)


def _esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def render_json(report: BacktestReport) -> str:
    """Render the report as a pretty, deterministic JSON document."""
    return json.dumps(report.to_json_dict(), indent=2, sort_keys=False)


def render_csv(report: BacktestReport) -> str:
    """Render one row per window plus a TOTAL row as CSV text."""
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(
        [
            "window_id",
            "duration_seconds",
            "snapshots",
            "total_opportunities",
            "attempted_trades",
            "complete_pairs",
            "unmatched_events",
            "gross_edge",
            "fees",
            "slippage",
            "emergency_hedge_pnl",
            "realized_net_pnl",
            "residual_pnl",
            "merged_pairs",
            "final_state",
        ]
    )
    for window in report.windows:
        writer.writerow(_csv_window_row(window))
    writer.writerow(
        [
            "TOTAL",
            "",
            "",
            report.total_opportunities,
            report.attempted_trades,
            _fmt(report.complete_pairs),
            report.unmatched_events,
            _fmt(report.gross_edge),
            _fmt(report.fees),
            _fmt(report.slippage),
            _fmt(report.emergency_hedge_pnl),
            _fmt(report.realized_net_pnl),
            _fmt(report.residual_pnl),
            _fmt(report.merged_pairs),
            f"max_drawdown={_fmt(report.max_drawdown)}",
        ]
    )
    return buffer.getvalue()


def _csv_window_row(window: WindowResult) -> list[object]:
    return [
        window.window_id,
        window.duration_seconds,
        window.snapshots,
        window.total_opportunities,
        window.attempted_trades,
        _fmt(window.complete_pairs),
        window.unmatched_events,
        _fmt(window.gross_edge),
        _fmt(window.fees),
        _fmt(window.slippage),
        _fmt(window.emergency_hedge_pnl),
        _fmt(window.realized_net_pnl),
        _fmt(window.residual_pnl),
        _fmt(window.merged_pairs),
        window.final_state,
    ]


def _totals_table(report: BacktestReport) -> str:
    rows = [
        ("Windows", str(report.window_count)),
        ("Total opportunities", str(report.total_opportunities)),
        ("Attempted trades", str(report.attempted_trades)),
        ("Complete pairs", _fmt(report.complete_pairs)),
        ("Unmatched events", str(report.unmatched_events)),
        ("Gross edge", _fmt(report.gross_edge)),
        ("Fees", _fmt(report.fees)),
        ("Slippage (modeled)", _fmt(report.slippage)),
        ("Emergency hedge P&L", _fmt(report.emergency_hedge_pnl)),
        ("Realized net P&L", _fmt(report.realized_net_pnl)),
        ("Residual P&L", _fmt(report.residual_pnl)),
        ("Merged pairs", _fmt(report.merged_pairs)),
        ("Max drawdown", _fmt(report.max_drawdown)),
    ]
    body = "".join(
        f"<tr><th>{_esc(label)}</th><td>{_esc(value)}</td></tr>" for label, value in rows
    )
    return f"<table class='kv'>{body}</table>"


def _bucket_table(title: str, buckets: tuple[BucketMetrics, ...]) -> str:
    if not buckets:
        return f"<h3>{_esc(title)}</h3><p>{_EM_DASH}</p>"
    header = (
        "<tr><th>Bucket</th><th>Opportunities</th>"
        "<th>Approved</th><th>Expected edge</th></tr>"
    )
    rows = "".join(
        "<tr>"
        f"<td>{_esc(bucket.label)}</td>"
        f"<td>{bucket.opportunities}</td>"
        f"<td>{bucket.approved_opportunities}</td>"
        f"<td>{_esc(_fmt(bucket.expected_edge))}</td>"
        "</tr>"
        for bucket in buckets
    )
    return f"<h3>{_esc(title)}</h3><table>{header}{rows}</table>"


def _failure_table(failures: dict[str, int]) -> str:
    if not failures:
        return "<h3>Failure reasons</h3><p>None recorded.</p>"
    rows = "".join(
        f"<tr><td>{_esc(reason)}</td><td>{count}</td></tr>"
        for reason, count in sorted(failures.items(), key=lambda item: (-item[1], item[0]))
    )
    return (
        "<h3>Failure reasons</h3>"
        "<table><tr><th>Reason</th><th>Count</th></tr>"
        f"{rows}</table>"
    )


def _windows_table(windows: tuple[WindowResult, ...]) -> str:
    if not windows:
        return "<h3>Windows</h3><p>No windows replayed.</p>"
    header = (
        "<tr><th>Window</th><th>Snapshots</th><th>Opps</th><th>Attempts</th>"
        "<th>Pairs</th><th>Unmatched</th><th>Gross edge</th><th>Fees</th>"
        "<th>Slippage</th><th>Hedge P&amp;L</th><th>Net P&amp;L</th>"
        "<th>Final state</th></tr>"
    )
    rows = "".join(
        "<tr>"
        f"<td>{_esc(window.window_id)}</td>"
        f"<td>{window.snapshots}</td>"
        f"<td>{window.total_opportunities}</td>"
        f"<td>{window.attempted_trades}</td>"
        f"<td>{_esc(_fmt(window.complete_pairs))}</td>"
        f"<td>{window.unmatched_events}</td>"
        f"<td>{_esc(_fmt(window.gross_edge))}</td>"
        f"<td>{_esc(_fmt(window.fees))}</td>"
        f"<td>{_esc(_fmt(window.slippage))}</td>"
        f"<td>{_esc(_fmt(window.emergency_hedge_pnl))}</td>"
        f"<td>{_esc(_fmt(window.realized_net_pnl))}</td>"
        f"<td>{_esc(window.final_state)}</td>"
        "</tr>"
        for window in windows
    )
    return f"<h3>Windows</h3><table>{header}{rows}</table>"


def render_html(report: BacktestReport) -> str:
    """Render a self-contained, escaped HTML report (no external assets)."""
    style = (
        "body{font-family:system-ui,Arial,sans-serif;margin:2rem;color:#1a1a1a}"
        "h1{font-size:1.4rem}h3{margin-top:1.6rem}"
        "table{border-collapse:collapse;margin:0.5rem 0;font-size:0.9rem}"
        "th,td{border:1px solid #ccc;padding:4px 8px;text-align:right}"
        "th{background:#f4f4f4}table.kv th{text-align:left}"
        ".disclaimer{background:#fff8e1;border:1px solid #f0c36d;padding:8px 12px;"
        "border-radius:6px;margin:1rem 0;font-size:0.9rem}"
    )
    parts = [
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>",
        f"<title>Backtest report {_esc(report.label)}</title>",
        f"<style>{style}</style></head><body>",
        f"<h1>Backtest report: {_esc(report.label)}</h1>",
        f"<p>Seed: <code>{_esc(report.seed)}</code></p>",
        f"<div class='disclaimer'>{_esc(_DISCLAIMER)}</div>",
        "<h3>Totals</h3>",
        _totals_table(report),
        _bucket_table("Results by time-to-close", report.time_to_close_buckets),
        _bucket_table("Results by target size", report.size_buckets),
        _failure_table(report.failure_reasons),
        _windows_table(report.windows),
        "</body></html>",
    ]
    return "".join(parts)


def write_json_report(report: BacktestReport, path: Path | str) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(render_json(report), encoding="utf-8")
    return destination


def write_csv_report(report: BacktestReport, path: Path | str) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(render_csv(report), encoding="utf-8")
    return destination


def write_html_report(report: BacktestReport, path: Path | str) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(render_html(report), encoding="utf-8")
    return destination


def write_reports(report: BacktestReport, directory: Path | str, *, stem: str) -> dict[str, Path]:
    """Write JSON, CSV and HTML reports into ``directory`` and return the paths."""
    base = Path(directory)
    return {
        "json": write_json_report(report, base / f"{stem}.json"),
        "csv": write_csv_report(report, base / f"{stem}.csv"),
        "html": write_html_report(report, base / f"{stem}.html"),
    }


__all__ = [
    "render_csv",
    "render_html",
    "render_json",
    "write_csv_report",
    "write_html_report",
    "write_json_report",
    "write_reports",
]
