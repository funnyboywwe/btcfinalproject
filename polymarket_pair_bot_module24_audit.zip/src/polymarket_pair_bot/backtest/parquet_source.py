"""Parquet-backed recording source for the backtest engine (Module 22).

This adapter is the ONLY place in the backtest package that touches the
recorder's on-disk parquet format, isolating the (optional, lazily imported)
``pyarrow`` dependency behind the :class:`RecordingSource` protocol. It maps
each declared :class:`MarketSpec` to a validated :class:`BinaryMarket` and
streams that window's recorded snapshots via ``recorder.parquet_io.replay_window``
in deterministic (capture_epoch, sequence) order.

The recorded book sides are positional (up/down); the authoritative token ids
come from the market spec, not from the recording, so the harness always books
trades against the spec's Up/Down token ids.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from polymarket_pair_bot.backtest.models import MarketSpecFile
from polymarket_pair_bot.backtest.ports import WindowRecording


class ParquetRecordingSource:
    """Yields :class:`WindowRecording` objects from recorded parquet files.

    ``root`` is the recorder output directory (``recorder_output_dir``).
    ``spec_file`` declares the market metadata for each window id, since the
    recorded snapshots intentionally do not carry the CTF condition id / token
    ids the strategy needs.
    """

    def __init__(self, *, root: str | Path, spec_file: MarketSpecFile) -> None:
        self._root = Path(root)
        self._spec_file = spec_file

    def windows(self) -> Iterator[WindowRecording]:
        # Lazy import keeps pyarrow optional and out of the import graph for
        # in-memory backtests / unit tests (requirement: isolate optional deps).
        from polymarket_pair_bot.recorder.parquet_io import replay_window

        by_window = self._spec_file.by_window()
        for window_id, spec in by_window.items():
            snapshots = tuple(replay_window(self._root, window_id))
            yield WindowRecording(market=spec.to_market(), snapshots=snapshots)


__all__ = ["ParquetRecordingSource"]
