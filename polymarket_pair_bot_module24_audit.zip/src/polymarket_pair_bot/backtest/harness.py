"""Deterministic replay / backtest engine (Module 22).

The engine replays recorded market windows chronologically and drives the
*production* components -- the pair opportunity detector, the centralized risk
engine, the pair-accumulation state machine, the inventory accounting, and the
paper execution interface -- exactly as the live orchestrator would, but fed
from recorded snapshots instead of a live WebSocket. Nothing here re-implements
strategy logic; it only wires the real components to recorded inputs and to the
deterministic in-memory ports.

Look-ahead safety (requirement 6): each snapshot is processed strictly in
capture order; the detector, risk engine and state machine only ever receive
the current snapshot (and state derived from strictly earlier snapshots).
Synthesized trades are derived from the transition between the *previous* and
*current* snapshot only. Order fills always lag their submission by at least the
modeled acknowledgement latency, so a fill can never be observed in the same
step that could have used a future book. The paper simulator's randomness is
seeded once per run (requirement 4).

This module makes no claim that the strategy is profitable; it only measures.
"""

from __future__ import annotations

from polymarket_pair_bot.backtest.events import (
    side_is_fresh,
    synthesize_trades,
    to_book_snapshot,
)
from polymarket_pair_bot.backtest.memory import (
    BacktestKillSwitchPort,
    BacktestMergePort,
    BacktestReconciliationPort,
    InMemoryExecutionPersistence,
    InMemorySessionStore,
)
from polymarket_pair_bot.backtest.metrics import (
    BacktestReport,
    WindowResult,
    build_window_result,
)
from polymarket_pair_bot.backtest.models import BacktestRunConfig
from polymarket_pair_bot.backtest.ports import RecordingSource, WindowRecording
from polymarket_pair_bot.backtest.recording import RecordingDetector
from polymarket_pair_bot.backtest.risk_adapter import BacktestRiskApprovalAdapter
from polymarket_pair_bot.config.settings import AppConfig
from polymarket_pair_bot.domain.entities import BinaryMarket
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    ProbabilityPrice,
    UnixTimestamp,
)
from polymarket_pair_bot.execution import (
    LatencyDistribution,
    MarketEvent,
    PaperExecutionAdapter,
    PaperExecutionConfig,
)
from polymarket_pair_bot.inventory.accounting import build_inventory
from polymarket_pair_bot.risk.engine import RiskEngine
from polymarket_pair_bot.risk.limits import RiskLimits
from polymarket_pair_bot.strategy.session_events import (
    BooksUpdatedEvent,
    FillConfirmedEvent,
    LimitCheckEvent,
    MarketValidatedEvent,
    MergeEvaluateEvent,
    WindowClosingEvent,
)
from polymarket_pair_bot.strategy.session_factory import (
    build_pair_detector,
    build_state_machine,
)
from polymarket_pair_bot.strategy.session_states import SessionState

_MAX_MERGE_DRAIN_STEPS = 8


class BacktestEngine:
    """Replays recordings through the production strategy components."""

    def __init__(self, config: AppConfig, run_config: BacktestRunConfig) -> None:
        self._config = config
        self._run = run_config
        backtest = config.backtest
        self._ttc_edges = backtest.time_to_close_edges
        self._size_edges = backtest.size_edges

    def _paper_config(self) -> PaperExecutionConfig:
        backtest = self._config.backtest
        if backtest.latency_jitter_ms > 0:
            ack_latency = LatencyDistribution.uniform(
                backtest.ack_latency_ms,
                backtest.ack_latency_ms + backtest.latency_jitter_ms,
            )
        else:
            ack_latency = LatencyDistribution.constant(backtest.ack_latency_ms)
        return PaperExecutionConfig(
            seed=self._run.seed,
            taker_fee_bps=BasisPoints(backtest.taker_fee_bps),
            maker_fee_bps=BasisPoints(backtest.maker_fee_bps),
            expected_slippage_bps=BasisPoints(backtest.expected_slippage_bps),
            ack_latency=ack_latency,
            cancel_latency=LatencyDistribution.constant(backtest.cancel_latency_ms),
            stale_after_ms=backtest.stale_after_ms,
            gtd_ttl_ms=backtest.gtd_ttl_ms,
            unknown_submission_probability=backtest.unknown_submission_probability,
            maker_fill_probability=backtest.maker_fill_probability,
        )

    async def run(self, source: RecordingSource) -> BacktestReport:
        """Replay every window the source yields that the run config includes."""
        windows: list[WindowResult] = []
        for recording in source.windows():
            if not self._run.includes(recording.window_id):
                continue
            windows.append(await self.run_window(recording))
        return BacktestReport.from_windows(
            windows, label=self._run.label, seed=self._run.seed
        )

    async def run_window(self, recording: WindowRecording) -> WindowResult:
        """Replay a single recorded window and compute its metrics."""
        market = recording.market
        snapshots = list(recording.snapshots)
        if self._run.max_snapshots_per_window > 0:
            snapshots = snapshots[: self._run.max_snapshots_per_window]

        open_epoch = market.window.open_time.value
        close_epoch = market.window.close_time.value
        start_ms = (snapshots[0].capture_epoch if snapshots else open_epoch) * 1000

        persistence = InMemoryExecutionPersistence()
        adapter = PaperExecutionAdapter(
            config=self._paper_config(),
            persistence=persistence,
            start_ms=start_ms,
        )
        adapter.register_market(market)

        detector = RecordingDetector(
            build_pair_detector(
                strategy=self._config.pair_strategy,
                tick_size=market.up_token.tick_size,
                min_seconds_to_close=self._config.state_machine.first_leg_cutoff_seconds,
            )
        )
        risk = BacktestRiskApprovalAdapter(
            RiskEngine(RiskLimits.from_settings(self._config.risk))
        )
        store = InMemorySessionStore()
        merge = BacktestMergePort()
        reconciliation = BacktestReconciliationPort()
        kill_switch = BacktestKillSwitchPort()
        machine = build_state_machine(
            state_machine_settings=self._config.state_machine,
            strategy=self._config.pair_strategy,
            tick_size=market.up_token.tick_size,
            store=store,
            execution=adapter,
            risk=risk,
            merge=merge,
            reconciliation=reconciliation,
            kill_switch=kill_switch,
            detector=detector,
        )

        self._event_counter = 0
        market_id = market.market_id
        up_token = market.up_token.token_id
        down_token = market.down_token.token_id

        await machine.process(
            MarketValidatedEvent(
                event_id=self._next_id("validated"),
                market_id=market_id,
                occurred_at=UnixTimestamp(open_epoch),
                market=market,
            )
        )

        prev_up = None
        prev_down = None
        clock_ms = start_ms
        fill_cursor = 0
        last_up_bid: ProbabilityPrice | None = None
        last_down_bid: ProbabilityPrice | None = None

        for index, snap in enumerate(snapshots):
            epoch = snap.capture_epoch
            seconds_to_close = max(0, close_epoch - epoch)
            clock_ms = max(clock_ms + 1, epoch * 1000)
            as_of = UnixTimestamp(epoch)

            up_fresh = side_is_fresh(snap.up)
            down_fresh = side_is_fresh(snap.down)
            up_book = to_book_snapshot(snap.up, up_token, as_of)
            down_book = to_book_snapshot(snap.down, down_token, as_of)
            up_trades = synthesize_trades(
                prev_up, snap.up, up_token, trade_id_prefix=f"{market_id.value}:{index}:up"
            )
            down_trades = synthesize_trades(
                prev_down,
                snap.down,
                down_token,
                trade_id_prefix=f"{market_id.value}:{index}:down",
            )

            # Advance the market: this settles any due order transitions (e.g. a
            # taker submitted a step earlier now acknowledges) and matches
            # resting maker orders against real trade volume only.
            await adapter.apply_market_event(
                MarketEvent(
                    event_id=self._next_id("mev-up"),
                    token_id=up_token,
                    timestamp_ms=clock_ms,
                    snapshot=up_book if up_fresh else None,
                    trades=up_trades,
                    feed_live=up_fresh,
                )
            )
            clock_ms += 1
            await adapter.apply_market_event(
                MarketEvent(
                    event_id=self._next_id("mev-down"),
                    token_id=down_token,
                    timestamp_ms=clock_ms,
                    snapshot=down_book if down_fresh else None,
                    trades=down_trades,
                    feed_live=down_fresh,
                )
            )

            # Apply any confirmed fills BEFORE the machine looks at the books, so
            # inventory reflects the past, never the future.
            fill_cursor = await self._drain_fills(
                machine, market, persistence, fill_cursor
            )

            await machine.process(
                BooksUpdatedEvent(
                    event_id=self._next_id("books"),
                    market_id=market_id,
                    occurred_at=as_of,
                    market=market,
                    up_book=up_book,
                    down_book=down_book,
                    up_is_fresh=up_fresh,
                    down_is_fresh=down_fresh,
                    feed_live=up_fresh or down_fresh,
                    seconds_to_close=seconds_to_close,
                )
            )
            fill_cursor = await self._drain_fills(
                machine, market, persistence, fill_cursor
            )

            snapshot = store.snapshots.get(market_id.value)
            if snapshot is not None and snapshot.has_unmatched:
                await machine.process(
                    LimitCheckEvent(
                        event_id=self._next_id("limit"),
                        market_id=market_id,
                        occurred_at=as_of,
                        market=market,
                    )
                )
            snapshot = store.snapshots.get(market_id.value)
            if snapshot is not None and snapshot.matched_pairs.value > 0:
                merge.set_mergeable(snapshot.matched_pairs)
                await machine.process(
                    MergeEvaluateEvent(
                        event_id=self._next_id("merge"),
                        market_id=market_id,
                        occurred_at=as_of,
                        market=market,
                    )
                )

            prev_up = snap.up
            prev_down = snap.down
            if up_book is not None and up_book.best_bid is not None:
                last_up_bid = up_book.best_bid
            if down_book is not None and down_book.best_bid is not None:
                last_down_bid = down_book.best_bid

        # Close cutoff: advance past close, settle, then run the closing event.
        close_ms = max(
            clock_ms + 1,
            close_epoch * 1000 + self._config.backtest.settle_buffer_ms,
        )
        await adapter.advance_to(close_ms)
        fill_cursor = await self._drain_fills(machine, market, persistence, fill_cursor)

        await machine.process(
            WindowClosingEvent(
                event_id=self._next_id("closing"),
                market_id=market_id,
                occurred_at=UnixTimestamp(close_epoch),
                market=market,
                seconds_to_close=0,
            )
        )
        fill_cursor = await self._drain_fills(machine, market, persistence, fill_cursor)

        # Bounded merge drain: MATCHED_PAIR -> MERGE_PENDING -> MERGING -> CLOSED.
        for _ in range(_MAX_MERGE_DRAIN_STEPS):
            snapshot = store.snapshots.get(market_id.value)
            if snapshot is None or snapshot.matched_pairs.value <= 0:
                break
            merge.set_mergeable(snapshot.matched_pairs)
            await machine.process(
                MergeEvaluateEvent(
                    event_id=self._next_id("merge-close"),
                    market_id=market_id,
                    occurred_at=UnixTimestamp(close_epoch),
                    market=market,
                )
            )

        fills = tuple(persistence.fills.ordered)
        inventory = build_inventory(market, fills)
        final_snapshot = store.snapshots.get(market_id.value)
        final_state = (
            final_snapshot.state.value
            if final_snapshot is not None
            else SessionState.DISCOVERED.value
        )

        return build_window_result(
            window_id=recording.window_id,
            duration_seconds=close_epoch - open_epoch,
            snapshots=len(snapshots),
            decisions=detector.records,
            transitions=tuple(store.transitions),
            attempted_trades=len(persistence.intents.items),
            fills=fills,
            inventory=inventory,
            last_up_bid=last_up_bid,
            last_down_bid=last_down_bid,
            overhead=detector.config.engine_parameters.overhead,
            slippage_bps=BasisPoints(self._config.backtest.expected_slippage_bps),
            merged_pairs=merge.merged_pairs,
            final_state=final_state,
            ttc_edges=self._ttc_edges,
            size_edges=self._size_edges,
        )

    async def _drain_fills(
        self,
        machine: object,
        market: BinaryMarket,
        persistence: InMemoryExecutionPersistence,
        cursor: int,
    ) -> int:
        ordered = persistence.fills.ordered
        while cursor < len(ordered):
            fill = ordered[cursor]
            cursor += 1
            await machine.process(  # type: ignore[attr-defined]
                FillConfirmedEvent(
                    event_id=f"fill-{fill.fill_id.value}",
                    market_id=market.market_id,
                    occurred_at=fill.filled_at,
                    market=market,
                    fill=fill,
                )
            )
        return cursor

    def _next_id(self, prefix: str) -> str:
        self._event_counter += 1
        return f"{prefix}-{self._event_counter}"


__all__ = ["BacktestEngine"]
