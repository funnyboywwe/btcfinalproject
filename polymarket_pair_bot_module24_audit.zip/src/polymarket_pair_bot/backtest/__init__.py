"""Deterministic replay and backtesting (architecture item: Module 22).

This package replays recorded BTC 5-minute market windows chronologically and
drives the SAME production components as live/paper trading -- the pair
opportunity detector, the centralized risk engine, the pair-accumulation state
machine, inventory accounting and the paper execution interface (requirement 2)
-- entirely offline and reproducibly (requirement 4).

It models latency, queue position, partial fills, cancellation delay, taker
slippage, fees, missed second legs, data outages and the close cutoff
(requirement 3), prevents look-ahead bias (requirement 6), produces a rich set
of metrics (requirement 5) and exports JSON / CSV / HTML reports (requirement 8).

Nothing in this package asserts the strategy is profitable; every figure is a
modeled accounting quantity.
"""

from __future__ import annotations

from polymarket_pair_bot.backtest.harness import BacktestEngine
from polymarket_pair_bot.backtest.metrics import (
    BacktestReport,
    BucketMetrics,
    WindowResult,
)
from polymarket_pair_bot.backtest.models import (
    BacktestRunConfig,
    MarketSpec,
    MarketSpecFile,
)
from polymarket_pair_bot.backtest.ports import RecordingSource, WindowRecording
from polymarket_pair_bot.backtest.reporting import (
    write_csv_report,
    write_html_report,
    write_json_report,
    write_reports,
)

__all__ = [
    "BacktestEngine",
    "BacktestReport",
    "BacktestRunConfig",
    "BucketMetrics",
    "MarketSpec",
    "MarketSpecFile",
    "RecordingSource",
    "WindowRecording",
    "WindowResult",
    "write_csv_report",
    "write_html_report",
    "write_json_report",
    "write_reports",
]
