"""In-memory backtest infrastructure adapters (Module 22).

Deterministic, in-process implementations of the ports the reused production
components depend on. They contain no networking, no database, no blockchain
access and no secrets, so the backtest can drive the SAME paper execution
adapter, state machine, risk engine and inventory accounting as production
(requirement 2) entirely offline.

The repositories mirror the semantics of the SQLAlchemy-backed production
repositories (idempotent inserts, upserts, open-order listing) so the paper
adapter and state machine behave identically. The CTF merge / reconciliation /
kill-switch ports use explicit, documented modeling assumptions for offline
replay (see each class).
"""

from __future__ import annotations

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    ExchangeOrder,
    Fill,
    OrderIntent,
    ReconciliationResult,
    RiskDecision,
)
from polymarket_pair_bot.domain.enums import CtfOperationStatus, ReconciliationStatus
from polymarket_pair_bot.domain.value_objects import (
    FillId,
    MarketId,
    OrderId,
    Shares,
    UnixTimestamp,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.strategy.session_models import (
    PairSessionSnapshot,
    SessionTransition,
)
from polymarket_pair_bot.strategy.session_ports import MergeOutcome


class InMemoryIntentRepository:
    """Idempotent order-intent store (dedupes by ``intent_id``)."""

    def __init__(self) -> None:
        self.items: dict[str, OrderIntent] = {}

    async def add(self, intent: OrderIntent) -> bool:
        if intent.intent_id in self.items:
            return False
        self.items[intent.intent_id] = intent
        return True

    async def get(self, intent_id: str) -> OrderIntent | None:
        return self.items.get(intent_id)


class InMemoryOrderRepository:
    """Upsert-by-``order_id`` exchange-order store."""

    def __init__(self) -> None:
        self.items: dict[str, ExchangeOrder] = {}

    async def upsert(self, order: ExchangeOrder) -> None:
        self.items[order.order_id.value] = order

    async def get(self, order_id: OrderId) -> ExchangeOrder | None:
        return self.items.get(order_id.value)

    async def list_open(self, market_id: MarketId) -> list[ExchangeOrder]:
        return [
            order
            for order in self.items.values()
            if order.market_id.value == market_id.value and not order.status.is_terminal
        ]


class InMemoryFillRepository:
    """Idempotent fill journal (dedupes by ``fill_id``; preserves order)."""

    def __init__(self) -> None:
        self.items: dict[str, Fill] = {}
        self.ordered: list[Fill] = []

    async def insert_idempotent(self, fill: Fill) -> bool:
        if fill.fill_id.value in self.items:
            return False
        self.items[fill.fill_id.value] = fill
        self.ordered.append(fill)
        return True

    async def get(self, fill_id: FillId) -> Fill | None:
        return self.items.get(fill_id.value)

    async def list_for_order(self, order_id: OrderId) -> list[Fill]:
        return [fill for fill in self.ordered if fill.order_id.value == order_id.value]


class InMemoryExecutionPersistence:
    """Bundle of the three in-memory repositories the paper adapter needs."""

    def __init__(self) -> None:
        self.intents = InMemoryIntentRepository()
        self.orders = InMemoryOrderRepository()
        self.fills = InMemoryFillRepository()


class InMemorySessionStore:
    """In-memory :class:`SessionStore` that also keeps a transition audit log."""

    def __init__(self) -> None:
        self.snapshots: dict[str, PairSessionSnapshot] = {}
        self.transitions: list[SessionTransition] = []

    async def load(self, market_id: MarketId) -> PairSessionSnapshot | None:
        return self.snapshots.get(market_id.value)

    async def save(
        self, snapshot: PairSessionSnapshot, transition: SessionTransition
    ) -> None:
        self.snapshots[snapshot.market_id.value] = snapshot
        self.transitions.append(transition)


class BacktestMergePort:
    """Deterministic CTF merge model for offline replay.

    Modeling assumption (documented): a scheduled merge of confirmed pairs
    always succeeds in the backtest and recovers $1 of collateral per pair. On
    chain merge failures / gas spikes are out of scope for the strategy
    backtest; the risk engine still gates the merge through the BLOCKCHAIN
    operation kind. ``mergeable`` reports the quantity the harness last declared
    confirmed on chain (set from the session's matched pairs before each merge
    evaluation), so the machine never merges more than it holds.
    """

    def __init__(self) -> None:
        self._mergeable = Shares(0)
        self.merged_pairs = Shares(0)
        self.merge_calls = 0

    def set_mergeable(self, quantity: Shares) -> None:
        self._mergeable = quantity

    async def mergeable(self, market: BinaryMarket) -> Shares:
        return self._mergeable

    async def merge(
        self,
        *,
        market: BinaryMarket,
        quantity: Shares,
        risk_decision: RiskDecision,
    ) -> MergeOutcome:
        self.merge_calls += 1
        self.merged_pairs = Shares(self.merged_pairs.value + quantity.value)
        return MergeOutcome(
            operation_id=f"backtest-merge-{self.merge_calls}",
            status=CtfOperationStatus.CONFIRMED,
            quantity=quantity,
            mergeable=self._mergeable,
            detail="backtest_deterministic_merge",
        )


class BacktestReconciliationPort:
    """Reconciliation model for offline replay.

    Modeling assumption (documented): because the paper adapter is the single
    authoritative source of fills in a backtest, a reconciliation always returns
    a CONSISTENT result. The port still records every trigger so tests can
    assert the machine reconciles when required.
    """

    def __init__(self) -> None:
        self.triggers: list[ReconciliationTrigger] = []

    async def reconcile(self, trigger: ReconciliationTrigger) -> ReconciliationResult:
        self.triggers.append(trigger)
        return ReconciliationResult(
            status=ReconciliationStatus.CONSISTENT,
            as_of=UnixTimestamp(0),
        )


class BacktestKillSwitchPort:
    """Kill switch view for offline replay (inactive by default).

    A backtest never touches real capital, so the kill switch defaults to
    inactive; it can be constructed active to exercise the machine's fail-closed
    path in tests.
    """

    def __init__(self, *, active: bool = False) -> None:
        self._active = active

    async def is_active(self) -> bool:
        return self._active


__all__ = [
    "BacktestKillSwitchPort",
    "BacktestMergePort",
    "BacktestReconciliationPort",
    "InMemoryExecutionPersistence",
    "InMemoryFillRepository",
    "InMemoryIntentRepository",
    "InMemoryOrderRepository",
    "InMemorySessionStore",
]
