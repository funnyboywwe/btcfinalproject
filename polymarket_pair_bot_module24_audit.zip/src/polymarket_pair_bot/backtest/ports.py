"""Typed inputs for the backtest harness (Module 22).

The harness consumes an abstract :class:`RecordingSource` yielding one
:class:`WindowRecording` per market window: a validated domain
:class:`BinaryMarket` paired with its chronologically-ordered recorded book
snapshots. Concrete sources (Parquet on disk, or in-memory fixtures) live behind
this port so the harness never imports ``pyarrow`` directly (dependency
inversion).
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import BinaryMarket
from polymarket_pair_bot.domain.recording import RecordedPairSnapshot


@dataclass(frozen=True, slots=True)
class WindowRecording:
    """One market window's authoritative definition plus its recorded books.

    ``snapshots`` must be ordered chronologically by ``(capture_epoch,
    sequence)``; the harness relies on that ordering to replay without
    look-ahead.
    """

    market: BinaryMarket
    snapshots: tuple[RecordedPairSnapshot, ...]

    @property
    def window_id(self) -> str:
        return self.market.market_id.value


@runtime_checkable
class RecordingSource(Protocol):
    """Yields recorded windows to replay, in whatever order the source stores."""

    def windows(self) -> Iterator[WindowRecording]: ...


__all__ = ["RecordingSource", "WindowRecording"]
