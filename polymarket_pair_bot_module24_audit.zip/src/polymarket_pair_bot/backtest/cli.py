"""Read-only operator CLI for deterministic replay / backtesting (Module 22).

``run-backtest`` replays recorded market windows through the production strategy
components and writes JSON, CSV and HTML reports. It performs no live network
I/O, places no orders (paper execution only), and never emits a secret. It
follows the project's ``add_arguments(parser)`` / ``run(args)`` convention so
``__main__`` can register it as a subcommand.

Market metadata (CTF condition id and Up/Down token ids) is supplied via a
JSON/YAML market-spec file, since recorded snapshots intentionally omit those
strategy-critical identifiers.
"""

from __future__ import annotations

import argparse
import asyncio
import json
from decimal import Decimal
from pathlib import Path

from polymarket_pair_bot.backtest.harness import BacktestEngine
from polymarket_pair_bot.backtest.models import BacktestRunConfig, MarketSpecFile
from polymarket_pair_bot.backtest.parquet_source import ParquetRecordingSource
from polymarket_pair_bot.backtest.reporting import write_reports
from polymarket_pair_bot.config.settings import load_config


def add_arguments(parser: argparse.ArgumentParser) -> None:
    """Register CLI arguments for ``run-backtest``."""
    parser.add_argument(
        "--specs",
        type=Path,
        required=True,
        help="Path to a JSON/YAML market-spec file describing each window.",
    )
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=None,
        help="Recorder output directory (defaults to configured recorder dir).",
    )
    parser.add_argument(
        "--output-dir",
        "-o",
        type=Path,
        default=Path("data/backtests"),
        help="Directory to write JSON/CSV/HTML reports into.",
    )
    parser.add_argument(
        "--label",
        default="backtest",
        help="Human-readable label / report file stem.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Deterministic RNG seed (defaults to configured backtest seed).",
    )
    parser.add_argument(
        "--window",
        action="append",
        default=None,
        dest="windows",
        help="Restrict to this window id (repeatable). Omit to replay all.",
    )
    parser.add_argument(
        "--max-snapshots",
        type=int,
        default=0,
        help="Cap snapshots per window (0 = no cap). Useful for smoke runs.",
    )


def _load_spec_file(path: Path) -> MarketSpecFile:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in (".yaml", ".yml"):
        import yaml  # lazy: PyYAML is already a project dependency

        payload = yaml.safe_load(text)
    else:
        payload = json.loads(text)
    return MarketSpecFile.model_validate(payload)


def run(args: argparse.Namespace) -> int:
    """Execute a deterministic backtest run. Returns a process exit code."""
    config = load_config()
    spec_file = _load_spec_file(args.specs)
    root = args.data_dir or Path(config.recorder.recorder_output_dir)
    seed = args.seed if args.seed is not None else config.backtest.seed
    window_ids = tuple(args.windows) if args.windows else ()
    run_config = BacktestRunConfig(
        seed=seed,
        label=args.label,
        window_ids=window_ids,
        max_snapshots_per_window=max(0, args.max_snapshots),
    )
    engine = BacktestEngine(config, run_config)
    source = ParquetRecordingSource(root=root, spec_file=spec_file)
    report = asyncio.run(engine.run(source))
    paths = write_reports(report, args.output_dir, stem=args.label)

    print(
        "Backtest complete (modeled results only; not a profitability claim)."
    )
    print(f"  windows replayed : {report.window_count}")
    print(f"  opportunities    : {report.total_opportunities}")
    print(f"  attempted trades : {report.attempted_trades}")
    print(f"  complete pairs   : {_fmt(report.complete_pairs)}")
    print(f"  realized net P&L : {_fmt(report.realized_net_pnl)}")
    print(f"  max drawdown     : {_fmt(report.max_drawdown)}")
    for kind, destination in paths.items():
        print(f"  {kind:<4} report    : {destination}")
    return 0


def _fmt(value: Decimal) -> str:
    return format(value, "f")


__all__ = ["add_arguments", "run"]
