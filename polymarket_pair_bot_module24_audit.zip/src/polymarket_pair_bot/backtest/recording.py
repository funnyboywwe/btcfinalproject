"""Recording wrapper around the pure pair detector (Module 22).

The state machine consults a :class:`PairDetector` internally on every books
update. To measure exactly the decisions the machine acted on -- without
re-running the detector separately and risking divergence -- the backtest passes
a :class:`RecordingDetector`: a thin subclass that delegates to the real
detector and appends a :class:`DecisionRecord` (the classified action, modeled
edge, candidate/approval flags, plus the time-to-close and target size at the
decision instant) to an in-memory log.

This wrapper is pure and look-ahead-free: it adds nothing to the detector's
inputs or logic; it only observes the result the detector already produced for
the current event and derives ``seconds_to_close`` from the market window the
detector was already given. It makes no profitability claim.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from polymarket_pair_bot.domain.entities import BinaryMarket, OrderBookSnapshot
from polymarket_pair_bot.domain.value_objects import Shares, UnixTimestamp
from polymarket_pair_bot.strategy.detector import (
    DetectionResult,
    DetectorAction,
    PairDetector,
    RiskInput,
)
from polymarket_pair_bot.strategy.engine import InventorySummary

_ACTIONABLE: frozenset[DetectorAction] = frozenset(
    {
        DetectorAction.PASSIVE_FIRST_LEG,
        DetectorAction.PASSIVE_SECOND_LEG,
        DetectorAction.IMMEDIATE_TWO_LEG,
    }
)


@dataclass(frozen=True, slots=True)
class DecisionRecord:
    """An observed detector decision with time-to-close / size context."""

    action: DetectorAction
    expected_net_edge: Decimal
    has_candidates: bool
    approved: bool
    seconds_to_close: int
    target_size: Decimal

    @property
    def is_opportunity(self) -> bool:
        """An actionable pair opportunity was classified (not a rejection)."""
        return self.action in _ACTIONABLE


class RecordingDetector(PairDetector):
    """A :class:`PairDetector` that records every evaluation result."""

    def __init__(self, inner: PairDetector) -> None:
        super().__init__(config=inner.config)
        self.records: list[DecisionRecord] = []

    def evaluate(
        self,
        *,
        market: BinaryMarket,
        up_book: OrderBookSnapshot | None,
        down_book: OrderBookSnapshot | None,
        inventory: InventorySummary,
        target_quantity: Shares,
        now: UnixTimestamp,
        up_is_fresh: bool,
        down_is_fresh: bool,
        risk_input: RiskInput | None,
    ) -> DetectionResult:
        result = super().evaluate(
            market=market,
            up_book=up_book,
            down_book=down_book,
            inventory=inventory,
            target_quantity=target_quantity,
            now=now,
            up_is_fresh=up_is_fresh,
            down_is_fresh=down_is_fresh,
            risk_input=risk_input,
        )
        seconds_to_close = max(0, market.window.close_time.value - now.value)
        self.records.append(
            DecisionRecord(
                action=result.action,
                expected_net_edge=result.expected_net_edge.value,
                has_candidates=result.has_candidates,
                approved=bool(result.approved_candidates),
                seconds_to_close=seconds_to_close,
                target_size=target_quantity.value,
            )
        )
        return result


__all__ = ["DecisionRecord", "RecordingDetector"]
