"""Backtest metrics accumulation and report structures (Module 22, requirement 5).

All figures are ``Decimal`` accounting quantities derived from authoritative,
replayed records: the confirmed fill journal (rebuilt via the SAME inventory
accounting as production), the state-machine transition audit log, and the
observed detector decisions. Nothing here asserts the strategy is profitable;
every P&L / edge figure is a modeled quantity, computed conservatively (profits
rounded down, fees rounded up).

Metric definitions (documented so the numbers are unambiguous):

* total_opportunities  -- detector decisions classified as an actionable pair
  opportunity (passive first/second leg or immediate two-leg).
* attempted_trades     -- distinct order intents submitted to the adapter.
* complete_pairs       -- confirmed matched pairs = min(Up, Down) confirmed
  fills (an ack / open / partial fill is never counted).
* unmatched_events     -- transitions into UNMATCHED_INVENTORY or UNWIND_REQUIRED
  (directional exposure opened / stranded).
* gross_edge           -- matched pairs * ($1 - avg_up - avg_down), before fees
  and overhead.
* fees                 -- total confirmed taker/maker fees paid.
* slippage             -- modeled taker slippage = configured slippage rate
  applied to executed taker notional (the paper fills already embed it).
* emergency_hedge_pnl  -- for hedge (emergency second-leg) fills: collateral the
  completed pair recovers minus the hedge leg's own cost; excludes the first-leg
  cost, which is in acquisition costs.
* realized_net_pnl     -- matched (locked value - all-in matched cost - overhead)
  plus residual marked conservatively to the last executable bid (0 recovery if
  no bid).
* drawdown             -- max peak-to-trough of cumulative realized net P&L
  across windows in replay order.
* failure_reasons      -- tally of transition reasons / negative actions.
* buckets              -- opportunity funnel by time-to-close and by target size.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass, field
from decimal import Decimal

from polymarket_pair_bot.backtest.recording import DecisionRecord
from polymarket_pair_bot.domain.arithmetic import mark_to_executable_bid_pnl
from polymarket_pair_bot.domain.entities import Fill
from polymarket_pair_bot.domain.precision import (
    DOLLAR,
    round_profit_down,
    round_usd,
)
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    ProbabilityPrice,
    Shares,
)
from polymarket_pair_bot.inventory.accounting import MarketInventory
from polymarket_pair_bot.strategy.session_models import SessionTransition
from polymarket_pair_bot.strategy.session_states import SessionState

_ZERO = Decimal(0)

_UNMATCHED_STATES: frozenset[SessionState] = frozenset(
    {SessionState.UNMATCHED_INVENTORY, SessionState.UNWIND_REQUIRED}
)
_FAILURE_STATES: frozenset[SessionState] = frozenset(
    {
        SessionState.HALTED,
        SessionState.UNWIND_REQUIRED,
        SessionState.RECONCILIATION_REQUIRED,
    }
)
_FAILURE_KEYWORDS: tuple[str, ...] = (
    "reject",
    "illegal",
    "no_safe",
    "not_economical",
    "incomplete",
    "unmatched_at_close",
    "failed",
    "halt",
)


@dataclass(frozen=True, slots=True)
class BucketMetrics:
    """Opportunity funnel for one time-to-close or size bucket."""

    label: str
    opportunities: int
    approved_opportunities: int
    expected_edge: Decimal

    def to_json_dict(self) -> dict[str, object]:
        return {
            "label": self.label,
            "opportunities": self.opportunities,
            "approved_opportunities": self.approved_opportunities,
            "expected_edge": str(self.expected_edge),
        }


@dataclass(frozen=True, slots=True)
class WindowResult:
    """All metrics for a single replayed market window."""

    window_id: str
    duration_seconds: int
    snapshots: int
    total_opportunities: int
    attempted_trades: int
    complete_pairs: Decimal
    unmatched_events: int
    gross_edge: Decimal
    fees: Decimal
    slippage: Decimal
    emergency_hedge_pnl: Decimal
    realized_net_pnl: Decimal
    residual_pnl: Decimal
    merged_pairs: Decimal
    final_state: str
    failure_reasons: dict[str, int] = field(default_factory=dict)
    time_to_close_buckets: tuple[BucketMetrics, ...] = ()
    size_buckets: tuple[BucketMetrics, ...] = ()

    def to_json_dict(self) -> dict[str, object]:
        return {
            "window_id": self.window_id,
            "duration_seconds": self.duration_seconds,
            "snapshots": self.snapshots,
            "total_opportunities": self.total_opportunities,
            "attempted_trades": self.attempted_trades,
            "complete_pairs": str(self.complete_pairs),
            "unmatched_events": self.unmatched_events,
            "gross_edge": str(self.gross_edge),
            "fees": str(self.fees),
            "slippage": str(self.slippage),
            "emergency_hedge_pnl": str(self.emergency_hedge_pnl),
            "realized_net_pnl": str(self.realized_net_pnl),
            "residual_pnl": str(self.residual_pnl),
            "merged_pairs": str(self.merged_pairs),
            "final_state": self.final_state,
            "failure_reasons": dict(self.failure_reasons),
            "time_to_close_buckets": [
                bucket.to_json_dict() for bucket in self.time_to_close_buckets
            ],
            "size_buckets": [bucket.to_json_dict() for bucket in self.size_buckets],
        }


@dataclass(frozen=True, slots=True)
class BacktestReport:
    """Aggregate report across every replayed window."""

    label: str
    seed: int
    windows: tuple[WindowResult, ...]
    total_opportunities: int
    attempted_trades: int
    complete_pairs: Decimal
    unmatched_events: int
    gross_edge: Decimal
    fees: Decimal
    slippage: Decimal
    emergency_hedge_pnl: Decimal
    realized_net_pnl: Decimal
    residual_pnl: Decimal
    merged_pairs: Decimal
    max_drawdown: Decimal
    failure_reasons: dict[str, int]
    time_to_close_buckets: tuple[BucketMetrics, ...]
    size_buckets: tuple[BucketMetrics, ...]

    @property
    def window_count(self) -> int:
        return len(self.windows)

    def to_json_dict(self) -> dict[str, object]:
        return {
            "label": self.label,
            "seed": self.seed,
            "disclaimer": (
                "All figures are modeled backtest accounting quantities. "
                "They do not assert or imply the strategy is profitable."
            ),
            "window_count": self.window_count,
            "totals": {
                "total_opportunities": self.total_opportunities,
                "attempted_trades": self.attempted_trades,
                "complete_pairs": str(self.complete_pairs),
                "unmatched_events": self.unmatched_events,
                "gross_edge": str(self.gross_edge),
                "fees": str(self.fees),
                "slippage": str(self.slippage),
                "emergency_hedge_pnl": str(self.emergency_hedge_pnl),
                "realized_net_pnl": str(self.realized_net_pnl),
                "residual_pnl": str(self.residual_pnl),
                "merged_pairs": str(self.merged_pairs),
                "max_drawdown": str(self.max_drawdown),
            },
            "failure_reasons": dict(self.failure_reasons),
            "time_to_close_buckets": [
                bucket.to_json_dict() for bucket in self.time_to_close_buckets
            ],
            "size_buckets": [bucket.to_json_dict() for bucket in self.size_buckets],
            "windows": [window.to_json_dict() for window in self.windows],
        }

    @classmethod
    def from_windows(
        cls, windows: Sequence[WindowResult], *, label: str, seed: int
    ) -> "BacktestReport":
        cum = _ZERO
        peak = _ZERO
        max_dd = _ZERO
        for window in windows:
            cum += window.realized_net_pnl
            peak = max(peak, cum)
            max_dd = max(max_dd, peak - cum)
        failure: Counter[str] = Counter()
        for window in windows:
            failure.update(window.failure_reasons)
        return cls(
            label=label,
            seed=seed,
            windows=tuple(windows),
            total_opportunities=sum(w.total_opportunities for w in windows),
            attempted_trades=sum(w.attempted_trades for w in windows),
            complete_pairs=sum((w.complete_pairs for w in windows), _ZERO),
            unmatched_events=sum(w.unmatched_events for w in windows),
            gross_edge=sum((w.gross_edge for w in windows), _ZERO),
            fees=sum((w.fees for w in windows), _ZERO),
            slippage=sum((w.slippage for w in windows), _ZERO),
            emergency_hedge_pnl=sum((w.emergency_hedge_pnl for w in windows), _ZERO),
            realized_net_pnl=sum((w.realized_net_pnl for w in windows), _ZERO),
            residual_pnl=sum((w.residual_pnl for w in windows), _ZERO),
            merged_pairs=sum((w.merged_pairs for w in windows), _ZERO),
            max_drawdown=max_dd,
            failure_reasons=dict(failure),
            time_to_close_buckets=_merge_buckets(
                w.time_to_close_buckets for w in windows
            ),
            size_buckets=_merge_buckets(w.size_buckets for w in windows),
        )


def _is_hedge_fill(fill: Fill) -> bool:
    return ":hedge:" in fill.order_id.value


def _is_taker_fill(fill: Fill) -> bool:
    order_id = fill.order_id.value
    return ":taker:" in order_id or ":hedge:" in order_id


def _emergency_hedge_pnl(fills: Sequence[Fill]) -> Decimal:
    total = _ZERO
    for fill in fills:
        if not _is_hedge_fill(fill):
            continue
        total += fill.size.value * (DOLLAR - fill.price.value) - fill.fee.value
    return round_profit_down(total)


def _modeled_slippage(fills: Sequence[Fill], slippage_bps: BasisPoints) -> Decimal:
    notional = _ZERO
    for fill in fills:
        if _is_taker_fill(fill):
            notional += fill.price.value * fill.size.value
    return round_usd(notional * slippage_bps.as_fraction())


def _residual_side_pnl(
    quantity: Shares,
    average_cost: ProbabilityPrice | None,
    best_bid: ProbabilityPrice | None,
) -> Decimal:
    if not quantity.is_positive or average_cost is None:
        return _ZERO
    if best_bid is None:
        return round_profit_down(-(quantity.value * average_cost.value))
    return mark_to_executable_bid_pnl(quantity, average_cost, best_bid).value


def _failure_reasons(transitions: Sequence[SessionTransition]) -> dict[str, int]:
    counter: Counter[str] = Counter()
    for transition in transitions:
        if transition.to_state in _FAILURE_STATES:
            counter[transition.reason] += 1
        for action in transition.actions:
            lowered = action.lower()
            if any(keyword in lowered for keyword in _FAILURE_KEYWORDS):
                counter[action] += 1
    return dict(counter)


def _ttc_labels(edges: Sequence[int]) -> list[str]:
    ordered = sorted(edges)
    labels = [f"<{ordered[0]}"]
    for low, high in zip(ordered, ordered[1:], strict=False):
        labels.append(f"{low}-{high}")
    labels.append(f">={ordered[-1]}")
    return labels


def _ttc_label(seconds_to_close: int, edges: Sequence[int]) -> str:
    ordered = sorted(edges)
    if seconds_to_close < ordered[0]:
        return f"<{ordered[0]}"
    for low, high in zip(ordered, ordered[1:], strict=False):
        if low <= seconds_to_close < high:
            return f"{low}-{high}"
    return f">={ordered[-1]}"


def _size_labels(edges: Sequence[Decimal]) -> list[str]:
    ordered = sorted(edges)
    labels = [f"<{ordered[0]}"]
    for low, high in zip(ordered, ordered[1:], strict=False):
        labels.append(f"{low}-{high}")
    labels.append(f">={ordered[-1]}")
    return labels


def _size_label(size: Decimal, edges: Sequence[Decimal]) -> str:
    ordered = sorted(edges)
    if size < ordered[0]:
        return f"<{ordered[0]}"
    for low, high in zip(ordered, ordered[1:], strict=False):
        if low <= size < high:
            return f"{low}-{high}"
    return f">={ordered[-1]}"


def _bucket(
    records: Sequence[DecisionRecord],
    labels: Sequence[str],
    label_of: object,
) -> tuple[BucketMetrics, ...]:
    opportunities: Counter[str] = Counter()
    approved: Counter[str] = Counter()
    edge: dict[str, Decimal] = {label: _ZERO for label in labels}
    for record in records:
        if not record.is_opportunity:
            continue
        key = label_of(record)  # type: ignore[operator]
        opportunities[key] += 1
        if record.approved:
            approved[key] += 1
        edge[key] = edge.get(key, _ZERO) + record.expected_net_edge
    return tuple(
        BucketMetrics(
            label=label,
            opportunities=opportunities.get(label, 0),
            approved_opportunities=approved.get(label, 0),
            expected_edge=edge.get(label, _ZERO),
        )
        for label in labels
    )


def _merge_buckets(
    grouped: object,
) -> tuple[BucketMetrics, ...]:
    opportunities: Counter[str] = Counter()
    approved: Counter[str] = Counter()
    edge: dict[str, Decimal] = {}
    order: list[str] = []
    for buckets in grouped:  # type: ignore[attr-defined]
        for bucket in buckets:
            if bucket.label not in edge:
                edge[bucket.label] = _ZERO
                order.append(bucket.label)
            opportunities[bucket.label] += bucket.opportunities
            approved[bucket.label] += bucket.approved_opportunities
            edge[bucket.label] += bucket.expected_edge
    return tuple(
        BucketMetrics(
            label=label,
            opportunities=opportunities[label],
            approved_opportunities=approved[label],
            expected_edge=edge[label],
        )
        for label in order
    )


def build_window_result(
    *,
    window_id: str,
    duration_seconds: int,
    snapshots: int,
    decisions: Sequence[DecisionRecord],
    transitions: Sequence[SessionTransition],
    attempted_trades: int,
    fills: Sequence[Fill],
    inventory: MarketInventory,
    last_up_bid: ProbabilityPrice | None,
    last_down_bid: ProbabilityPrice | None,
    overhead: CollateralAmount,
    slippage_bps: BasisPoints,
    merged_pairs: Shares,
    final_state: str,
    ttc_edges: Sequence[int],
    size_edges: Sequence[Decimal],
) -> WindowResult:
    """Compute every window-level metric from authoritative replay records."""
    pairs = inventory.matched_quantity.value
    up_avg = inventory.up.average_cost
    down_avg = inventory.down.average_cost
    if pairs > _ZERO and up_avg is not None and down_avg is not None:
        gross_edge = round_profit_down(
            pairs * (DOLLAR - up_avg.value - down_avg.value)
        )
    else:
        gross_edge = _ZERO
    matched_net = (
        inventory.locked_pair_value.value
        - inventory.matched_cost_basis.value
        - overhead.value * pairs
    )
    residual_pnl = round_profit_down(
        _residual_side_pnl(inventory.residual_up, up_avg, last_up_bid)
        + _residual_side_pnl(inventory.residual_down, down_avg, last_down_bid)
    )
    realized_net = round_profit_down(matched_net + residual_pnl)
    total_opportunities = sum(1 for record in decisions if record.is_opportunity)
    unmatched_events = sum(
        1 for transition in transitions if transition.to_state in _UNMATCHED_STATES
    )
    return WindowResult(
        window_id=window_id,
        duration_seconds=duration_seconds,
        snapshots=snapshots,
        total_opportunities=total_opportunities,
        attempted_trades=attempted_trades,
        complete_pairs=pairs,
        unmatched_events=unmatched_events,
        gross_edge=gross_edge,
        fees=inventory.total_fees.value,
        slippage=_modeled_slippage(fills, slippage_bps),
        emergency_hedge_pnl=_emergency_hedge_pnl(fills),
        realized_net_pnl=realized_net,
        residual_pnl=residual_pnl,
        merged_pairs=merged_pairs.value,
        final_state=final_state,
        failure_reasons=_failure_reasons(transitions),
        time_to_close_buckets=_bucket(
            decisions,
            _ttc_labels(ttc_edges),
            lambda record: _ttc_label(record.seconds_to_close, ttc_edges),
        ),
        size_buckets=_bucket(
            decisions,
            _size_labels(size_edges),
            lambda record: _size_label(record.target_size, size_edges),
        ),
    )


__all__ = [
    "BacktestReport",
    "BucketMetrics",
    "WindowResult",
    "build_window_result",
]
