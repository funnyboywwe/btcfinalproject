"""Backtest risk-approval adapter over the real risk engine (Module 22).

The state machine talks to a :class:`RiskApprovalPort`. In production a
composition-layer adapter enriches each request with live capital / feed / gas
state and calls the centralized :class:`RiskEngine`. The backtest uses the SAME
pure ``RiskEngine`` (requirement 2), enriching each request with a
deterministic, within-limits capital context so the meaningful, data-driven
rules -- order and pair size ceilings, unmatched exposure, the mandatory-cancel
and latest-entry close windows, execution leadership and the kill switch -- are
genuinely evaluated against the real configured limits.

Fields a pure historical book replay cannot observe (wallet balance, gas
balance, open-order count, realized losses, and -- when the machine does not
supply one -- the expected pair edge) are provided as safe, within-limit
constants so they never spuriously block a decision. This is the only synthetic
part of the context and is documented here. Nothing here asserts profitability.
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ProfitAmount,
    Shares,
)
from polymarket_pair_bot.risk.context import OperationKind, RiskContext
from polymarket_pair_bot.risk.engine import RiskEngine
from polymarket_pair_bot.strategy.session_ports import (
    ApprovalKind,
    RiskApprovalRequest,
    RiskApprovalResult,
)

_KIND_MAP: dict[ApprovalKind, OperationKind] = {
    ApprovalKind.FIRST_LEG: OperationKind.ORDER_INTENT,
    ApprovalKind.SECOND_LEG: OperationKind.ORDER_INTENT,
    ApprovalKind.HEDGE: OperationKind.HEDGE,
    ApprovalKind.MERGE: OperationKind.BLOCKCHAIN,
}

_HEADROOM = Decimal(1000)


class BacktestRiskApprovalAdapter:
    """Implements :class:`RiskApprovalPort` over the real :class:`RiskEngine`."""

    def __init__(self, engine: RiskEngine) -> None:
        self._engine = engine
        limits = engine.limits
        self._wallet = CollateralAmount(limits.min_wallet_collateral.value + _HEADROOM)
        self._gas = limits.min_polygon_gas_native + _HEADROOM
        self._edge = ProfitAmount(limits.min_expected_pair_edge.value)

    async def evaluate(self, request: RiskApprovalRequest) -> RiskApprovalResult:
        kind = _KIND_MAP[request.kind]
        context = self._build_context(request, kind)
        evaluation = self._engine.evaluate(context)
        if kind is OperationKind.BLOCKCHAIN:
            # Blockchain (merge) approvals carry no sizing; honor the verdict and
            # authorize the requested pair quantity.
            approved = evaluation.approved
            approved_size = request.desired_size if approved else Shares(0)
        else:
            approved = evaluation.approved and evaluation.approved_size.is_positive
            approved_size = evaluation.approved_size if approved else Shares(0)
        return RiskApprovalResult(
            approved=approved,
            approved_size=approved_size,
            reason=evaluation.reason_summary(),
            decision=evaluation.to_decision(),
        )

    def _build_context(
        self, request: RiskApprovalRequest, kind: OperationKind
    ) -> RiskContext:
        size = request.desired_size
        # Each share settles at most at $1, so size in USD is a conservative
        # upper bound on the collateral committed.
        collateral = CollateralAmount(size.value)
        unmatched = (
            request.unmatched_shares
            if request.unmatched_shares is not None
            else Shares(0)
        )
        oldest = (
            request.oldest_unmatched_age_seconds
            if request.oldest_unmatched_age_seconds is not None
            else 0
        )
        edge = (
            request.expected_pair_edge
            if request.expected_pair_edge is not None
            else self._edge
        )
        return RiskContext(
            operation_id=request.request_id,
            kind=kind,
            now=request.occurred_at,
            is_execution_leader=True,
            order_quantity=size,
            order_collateral=collateral,
            market_position_notional=CollateralAmount(0),
            unmatched_shares=unmatched,
            unmatched_collateral=CollateralAmount(0),
            oldest_unmatched_age_seconds=oldest,
            deployed_capital=CollateralAmount(0),
            reserved_collateral=CollateralAmount(0),
            open_orders=0,
            window_loss=CollateralAmount(0),
            daily_loss=CollateralAmount(0),
            expected_pair_edge=edge,
            hedge_depth=size,
            book_age_seconds=0,
            feed_live=True,
            seconds_to_close=request.seconds_to_close,
            opening_first_leg=request.opening_first_leg,
            api_failures=0,
            ws_reconnects=0,
            wallet_collateral=self._wallet,
            gas_balance_native=self._gas,
        )


__all__ = ["BacktestRiskApprovalAdapter"]
