"""Gate specifications and the command-runner protocol (Module 24).

The release gate executes a fixed set of read-only technical checks. Commands
are run through an injected :class:`CommandRunner`, so tests can drive the whole
flow with a fake and never spawn subprocesses, touch the network, or place
orders. Every command below is read-only: linters, type-checkers, the test
suite, a report-only reconciliation, and a dependency-consistency check.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class CommandResult:
    """Result of running a single command."""

    returncode: int
    stdout: str = ""
    stderr: str = ""

    @property
    def ok(self) -> bool:
        return self.returncode == 0


class CommandRunner(Protocol):
    """Runs a command and returns its result. Implementations must not raise
    for a non-zero exit; they encode failure in :class:`CommandResult`.
    """

    def run(self, command: Sequence[str]) -> CommandResult: ...


@dataclass(frozen=True, slots=True)
class GateSpec:
    """A command-backed release gate."""

    name: str
    command: tuple[str, ...]
    description: str = ""
    mandatory: bool = True


# The mandatory, command-backed technical gates. Names match the release-gate
# report sections required by the module spec. ``secret-scan`` is run in-process
# (see :mod:`.secret_scan`) and ``paper statistics`` / ``unresolved risks`` are
# computed, so they are not listed here.
COMMAND_GATES: tuple[GateSpec, ...] = (
    GateSpec(
        "formatting",
        ("ruff", "format", "--check", "."),
        description="Ruff formatting check.",
    ),
    GateSpec(
        "lint",
        ("ruff", "check", "."),
        description="Ruff lint.",
    ),
    GateSpec(
        "type-check",
        ("mypy", "src"),
        description="mypy strict type check.",
    ),
    GateSpec(
        "unit-test",
        ("pytest", "-q", "-m", "not integration", "tests/unit"),
        description="Unit tests.",
    ),
    GateSpec(
        "integration-test",
        ("pytest", "-q", "-m", "integration"),
        description="Integration tests (mocks/local containers).",
    ),
    GateSpec(
        "replay-test",
        ("pytest", "-q", "tests/replay"),
        description="Deterministic recorded-window replay tests.",
    ),
    GateSpec(
        "e2e-test",
        ("pytest", "-q", "tests/e2e"),
        description="End-to-end crash and recovery scenarios.",
    ),
    GateSpec(
        "reconciliation",
        ("polymarket-pair-bot", "reconcile", "--report-only", "--json"),
        description="Authoritative report-only reconciliation pass.",
    ),
    GateSpec(
        "dependency-audit",
        ("uv", "pip", "check"),
        description="Installed dependency consistency audit.",
    ),
)
