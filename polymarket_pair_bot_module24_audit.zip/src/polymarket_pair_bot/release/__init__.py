"""Release-gate assembly for the manually gated go-live decision (Module 24).

This package aggregates the project's automated quality gates plus a
secret-scan and a human go-live checklist into a single, typed
:class:`ReleaseReport`. It is deliberately conservative:

* It NEVER enables live trading. It only *reports* readiness.
* ``live_ready`` is true only when every mandatory technical gate passes AND
  every human checklist item is explicitly confirmed. The checklist defaults to
  unconfirmed, so readiness can never be reached by accident.
* Any missing tool, crashed command, or scan finding fails closed (the gate is
  not ``PASSED``), which blocks readiness.

The runner takes an injected :class:`CommandRunner`, so tests drive it with a
fake and never execute real subprocesses or touch the network.
"""

from __future__ import annotations

from .checklist import CHECKLIST_ITEMS, build_checklist
from .gates import (
    COMMAND_GATES,
    CommandResult,
    CommandRunner,
    GateSpec,
)
from .models import (
    ChecklistItem,
    GateResult,
    GateStatus,
    PaperStatistics,
    ReleaseReport,
)
from .runner import (
    PaperStatisticsProvider,
    ReleaseGateRunner,
    StaticPaperStatistics,
)
from .secret_scan import SecretFinding, SecretScanner

__all__ = [
    "CHECKLIST_ITEMS",
    "COMMAND_GATES",
    "ChecklistItem",
    "CommandResult",
    "CommandRunner",
    "GateResult",
    "GateSpec",
    "GateStatus",
    "PaperStatistics",
    "PaperStatisticsProvider",
    "ReleaseGateRunner",
    "ReleaseReport",
    "SecretFinding",
    "SecretScanner",
    "StaticPaperStatistics",
    "build_checklist",
]
