"""Operator CLI for the release gate (Module 24).

Usage::

    uv run polymarket-pair-bot release-gate [--json] [--confirm KEY ...] \
        [--paper-sessions N] [--required-sessions N] [--root PATH]

The release gate runs the project's read-only technical gates (formatting, lint,
type-check, unit/integration/replay/e2e tests, a report-only reconciliation and
a dependency audit), an in-process secret scan, then prints paper statistics,
unresolved risks and a human go-live checklist.

It NEVER enables live trading and never places an order. ``live_ready`` is only
reported when every mandatory gate passes AND every human checklist item is
confirmed via ``--confirm``.

Exit code is ``0`` when every mandatory gate passes and ``1`` otherwise, so CI
and operator scripts can gate on technical health. A ``0`` exit still does NOT
mean the bot may go live -- the human checklist must also be completed.
"""

from __future__ import annotations

import argparse
import json
import subprocess  # noqa: S404 - runs fixed read-only dev commands, no shell
import sys
from collections.abc import Sequence
from decimal import Decimal
from pathlib import Path

from .checklist import CHECKLIST_KEYS
from .gates import CommandResult
from .models import PaperStatistics, ReleaseReport
from .runner import ReleaseGateRunner, StaticPaperStatistics

_DEFAULT_TIMEOUT_SECONDS = 1800


class SubprocessCommandRunner:
    """Runs commands with :func:`subprocess.run` (no shell, bounded timeout).

    Never raises for a non-zero exit; a missing executable or timeout is encoded
    as a non-zero :class:`CommandResult` so the gate fails closed.
    """

    def __init__(
        self,
        *,
        cwd: str | Path,
        timeout_seconds: int = _DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self._cwd = str(cwd)
        self._timeout = timeout_seconds

    def run(self, command: Sequence[str]) -> CommandResult:
        try:
            completed = subprocess.run(  # noqa: S603 - fixed argv, shell=False
                list(command),
                cwd=self._cwd,
                capture_output=True,
                text=True,
                timeout=self._timeout,
                check=False,
            )
        except FileNotFoundError as exc:
            return CommandResult(returncode=127, stderr=f"executable not found: {exc}")
        except subprocess.TimeoutExpired as exc:
            return CommandResult(returncode=124, stderr=f"timeout after {exc.timeout}s")
        return CommandResult(
            returncode=completed.returncode,
            stdout=completed.stdout or "",
            stderr=completed.stderr or "",
        )


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit the full report as JSON instead of human-readable text.",
    )
    parser.add_argument(
        "--confirm",
        action="append",
        default=None,
        dest="confirmations",
        metavar="KEY",
        help="Mark a human checklist item confirmed (repeatable). "
        f"Valid keys: {', '.join(sorted(CHECKLIST_KEYS))}.",
    )
    parser.add_argument(
        "--confirm-all",
        action="store_true",
        help="Confirm every human checklist item (operator attestation only).",
    )
    parser.add_argument(
        "--paper-sessions",
        type=int,
        default=0,
        help="Number of paper-trading sessions observed (descriptive).",
    )
    parser.add_argument(
        "--confirmed-pairs",
        type=int,
        default=0,
        help="Number of confirmed matched pairs observed in paper trading.",
    )
    parser.add_argument(
        "--unmatched-incidents",
        type=int,
        default=0,
        help="Number of unmatched-inventory incidents observed in paper trading.",
    )
    parser.add_argument(
        "--required-sessions",
        type=int,
        default=200,
        help="Minimum paper sessions considered a sufficient sample.",
    )
    parser.add_argument(
        "--root",
        default=".",
        help="Project root to scan and run commands in (default: current dir).",
    )


def run(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    confirmations: set[str] = set(args.confirmations or ())
    if getattr(args, "confirm_all", False):
        confirmations |= set(CHECKLIST_KEYS)

    statistics = PaperStatistics(
        paper_sessions=max(0, args.paper_sessions),
        confirmed_pairs=max(0, args.confirmed_pairs),
        unmatched_incidents=max(0, args.unmatched_incidents),
        gross_pair_cost=Decimal(0),
        required_sessions=max(0, args.required_sessions),
    )

    runner = ReleaseGateRunner(
        command_runner=SubprocessCommandRunner(cwd=root),
        project_root=root,
        paper_statistics=StaticPaperStatistics(statistics),
        confirmed_checklist=confirmations,
    )
    report = runner.run()

    if args.json:
        print(json.dumps(_report_to_dict(report), indent=2, sort_keys=True))
    else:
        _print_report(report)

    return 0 if report.all_mandatory_passed else 1


def _report_to_dict(report: ReleaseReport) -> dict[str, object]:
    return {
        "gates": [
            {
                "name": g.name,
                "status": g.status.value,
                "mandatory": g.mandatory,
                "summary": g.summary,
                "duration_ms": g.duration_ms,
            }
            for g in report.gates
        ],
        "checklist": [
            {"key": c.key, "confirmed": c.confirmed, "description": c.description}
            for c in report.checklist
        ],
        "paper_statistics": {
            "paper_sessions": report.paper_statistics.paper_sessions,
            "confirmed_pairs": report.paper_statistics.confirmed_pairs,
            "unmatched_incidents": report.paper_statistics.unmatched_incidents,
            "gross_pair_cost": str(report.paper_statistics.gross_pair_cost),
            "required_sessions": report.paper_statistics.required_sessions,
            "sufficient_sample": report.paper_statistics.sufficient_sample,
            "note": "Descriptive paper statistics only; not a profitability claim.",
        },
        "unresolved_risks": list(report.unresolved_risks),
        "all_mandatory_passed": report.all_mandatory_passed,
        "checklist_complete": report.checklist_complete,
        "live_ready": report.live_ready,
        "live_trading_enabled": report.live_trading_enabled,
    }


def _print_report(report: ReleaseReport) -> None:
    out = sys.stdout
    out.write("Release gate report\n")
    out.write("===================\n\n")
    out.write("Gates:\n")
    for gate in report.gates:
        marker = "PASS" if gate.passed else gate.status.value.upper()
        flag = "" if gate.mandatory else " (optional)"
        out.write(f"  [{marker:>7}] {gate.name}{flag}: {gate.summary}\n")
    out.write("\nPaper statistics (descriptive only; NOT a profitability claim):\n")
    stats = report.paper_statistics
    out.write(f"  sessions: {stats.paper_sessions} ")
    out.write(f"(required {stats.required_sessions}, ")
    out.write(f"sufficient={stats.sufficient_sample})\n")
    out.write(f"  confirmed pairs: {stats.confirmed_pairs}\n")
    out.write(f"  unmatched incidents: {stats.unmatched_incidents}\n")
    out.write("\nUnresolved risks:\n")
    if report.unresolved_risks:
        for risk in report.unresolved_risks:
            out.write(f"  - {risk}\n")
    else:
        out.write("  (none)\n")
    out.write("\nHuman go-live checklist:\n")
    for item in report.checklist:
        box = "[x]" if item.confirmed else "[ ]"
        out.write(f"  {box} {item.key}: {item.description}\n")
    out.write("\nSummary:\n")
    out.write(f"  all mandatory gates passed: {report.all_mandatory_passed}\n")
    out.write(f"  human checklist complete:   {report.checklist_complete}\n")
    out.write(f"  LIVE READY:                 {report.live_ready}\n")
    if not report.live_ready:
        out.write(
            "\nLive trading is NOT enabled and this build is NOT cleared to go "
            "live.\n"
        )
