"""Lightweight static secret scanner for the release gate (Module 24).

Pattern-based, offline and dependency-free. It flags material that must never
be committed (private keys, API secrets, passphrases, bearer tokens). It never
prints the matched secret value -- only the file, line number and rule name,
with the value redacted.

This is a defence-in-depth check, not a replacement for a dedicated secret
scanner in CI; it is intentionally conservative to avoid false positives on the
project's own source while still catching planted secrets.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True, slots=True)
class SecretFinding:
    """A single potential secret match (value is never stored or printed)."""

    path: str
    line: int
    rule: str

    def render(self) -> str:
        return f"{self.path}:{self.line}: {self.rule} [REDACTED]"


# (rule name, compiled pattern). Patterns match secret *material*, not mere
# mentions of the word "secret".
_RULES: tuple[tuple[str, re.Pattern[str]], ...] = (
    (
        "pem_private_key",
        re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"),
    ),
    (
        "hex_private_key",
        re.compile(
            r"(?i)(?:private[_-]?key|priv[_-]?key)\s*[:=]\s*['\"]?0x[0-9a-f]{64}\b"
        ),
    ),
    ("aws_access_key_id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    (
        "quoted_secret_assignment",
        re.compile(
            r"(?i)\b(?:api[_-]?secret|secret[_-]?key|passphrase|hmac[_-]?secret)"
            r"\b\s*[:=]\s*['\"][^'\"\s]{12,}['\"]"
        ),
    ),
    (
        "bearer_token",
        re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._\-]{20,}\b"),
    ),
)

_DEFAULT_EXCLUDE_DIRS: frozenset[str] = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "__pycache__",
        "node_modules",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
        "dist",
        "build",
        ".eggs",
    }
)

_DEFAULT_EXCLUDE_SUFFIXES: frozenset[str] = frozenset(
    {
        ".pyc",
        ".lock",
        ".parquet",
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".ico",
        ".pdf",
        ".woff",
        ".woff2",
        ".zip",
    }
)

# Files that legitimately contain secret *detection patterns* (not real
# secrets). Matched by POSIX path suffix.
_DEFAULT_ALLOWLIST: tuple[str, ...] = (
    "release/secret_scan.py",
    "tests/unit/test_release_gate.py",
    "tests/unit/test_deployment_packaging.py",
)

_MAX_BYTES = 2_000_000  # skip very large files defensively


@dataclass(frozen=True, slots=True)
class SecretScanner:
    """Scans a directory tree or text for secret-shaped material."""

    exclude_dirs: frozenset[str] = _DEFAULT_EXCLUDE_DIRS
    exclude_suffixes: frozenset[str] = _DEFAULT_EXCLUDE_SUFFIXES
    allowlist_suffixes: tuple[str, ...] = _DEFAULT_ALLOWLIST

    def scan_text(self, text: str, *, path: str = "<text>") -> list[SecretFinding]:
        findings: list[SecretFinding] = []
        for lineno, line in enumerate(text.splitlines(), start=1):
            for rule, pattern in _RULES:
                if pattern.search(line):
                    findings.append(SecretFinding(path=path, line=lineno, rule=rule))
        return findings

    def _is_allowlisted(self, *paths: str) -> bool:
        return any(
            p.endswith(suffix)
            for p in paths
            for suffix in self.allowlist_suffixes
        )

    def _iter_files(self, root: Path) -> Iterable[Path]:
        for entry in sorted(root.rglob("*")):
            if not entry.is_file():
                continue
            if any(part in self.exclude_dirs for part in entry.parts):
                continue
            if entry.suffix in self.exclude_suffixes:
                continue
            yield entry

    def scan_path(self, root: str | Path) -> list[SecretFinding]:
        root_path = Path(root)
        findings: list[SecretFinding] = []
        if root_path.is_file():
            files = [root_path]
            base = root_path.parent
        else:
            files = list(self._iter_files(root_path))
            base = root_path
        for file in files:
            try:
                rel = file.relative_to(base).as_posix()
            except ValueError:
                rel = file.as_posix()
            # Match the allowlist against both the relative path and the full
            # posix path so it works regardless of which subtree is scanned.
            if self._is_allowlisted(rel, file.as_posix()):
                continue
            try:
                if file.stat().st_size > _MAX_BYTES:
                    continue
                text = file.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            findings.extend(self.scan_text(text, path=rel))
        return findings
