"""Typed result models for the release gate (Module 24).

All monetary aggregates use :class:`~decimal.Decimal`; binary floats are never
used for money. The paper statistics are descriptive only and DO NOT constitute
a profitability claim.
"""

from __future__ import annotations

from decimal import Decimal
from enum import Enum

from pydantic import BaseModel, ConfigDict, NonNegativeInt


class GateStatus(str, Enum):
    """Outcome of a single release gate."""

    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"  # the gate could not be executed (missing tool, crash)
    SKIPPED = "skipped"
    INFO = "info"  # informational only; never gates readiness


class GateResult(BaseModel):
    """Result of one gate execution."""

    model_config = ConfigDict(frozen=True)

    name: str
    status: GateStatus
    mandatory: bool
    summary: str
    detail: str = ""
    duration_ms: NonNegativeInt = 0

    @property
    def passed(self) -> bool:
        return self.status is GateStatus.PASSED

    @property
    def blocks_release(self) -> bool:
        """A mandatory gate that is not PASSED blocks live readiness."""
        return self.mandatory and self.status is not GateStatus.PASSED


class ChecklistItem(BaseModel):
    """A single human go-live checklist item. Never auto-confirmed."""

    model_config = ConfigDict(frozen=True)

    key: str
    description: str
    confirmed: bool = False


class PaperStatistics(BaseModel):
    """Descriptive statistics for the paper-trading sample.

    These counts and Decimal aggregates summarise observed *simulated* activity
    to help a human judge whether the sample is large enough to review. They are
    explicitly NOT a claim or estimate of profitability.
    """

    model_config = ConfigDict(frozen=True)

    paper_sessions: NonNegativeInt = 0
    confirmed_pairs: NonNegativeInt = 0
    unmatched_incidents: NonNegativeInt = 0
    # Collateral base-unit aggregate (Decimal), descriptive only.
    gross_pair_cost: Decimal = Decimal(0)
    required_sessions: NonNegativeInt = 200

    @property
    def sufficient_sample(self) -> bool:
        return self.paper_sessions >= self.required_sessions


class ReleaseReport(BaseModel):
    """The complete release-gate report.

    ``live_ready`` is intentionally conservative: it requires every mandatory
    gate to pass AND every human checklist item to be confirmed. Because the
    checklist defaults to unconfirmed, readiness can never be reached by an
    automated run alone.
    """

    model_config = ConfigDict(frozen=True)

    gates: tuple[GateResult, ...]
    checklist: tuple[ChecklistItem, ...]
    paper_statistics: PaperStatistics
    unresolved_risks: tuple[str, ...] = ()
    # This build never enables live trading; recorded for auditability.
    live_trading_enabled: bool = False

    @property
    def mandatory_gates(self) -> tuple[GateResult, ...]:
        return tuple(g for g in self.gates if g.mandatory)

    @property
    def all_mandatory_passed(self) -> bool:
        gates = self.mandatory_gates
        return bool(gates) and all(g.passed for g in gates)

    @property
    def checklist_complete(self) -> bool:
        return bool(self.checklist) and all(c.confirmed for c in self.checklist)

    @property
    def live_ready(self) -> bool:
        # Fail closed: technical gates AND the human checklist must both pass,
        # and live trading must not already be (incorrectly) enabled.
        return (
            self.all_mandatory_passed
            and self.checklist_complete
            and not self.live_trading_enabled
        )
