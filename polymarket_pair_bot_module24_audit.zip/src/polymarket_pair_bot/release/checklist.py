"""The human go-live checklist for the release gate (Module 24).

Every item requires explicit human confirmation. The release gate never marks
these as confirmed on its own; an operator supplies confirmations (e.g. via the
``--confirm`` CLI flag) only after actually completing each step.
"""

from __future__ import annotations

from collections.abc import Iterable

from .models import ChecklistItem

# (key, human-readable description). Order is stable and meaningful.
CHECKLIST_ITEMS: tuple[tuple[str, str], ...] = (
    (
        "legal_eligibility",
        "Legal and account eligibility confirmed for this jurisdiction and venue.",
    ),
    (
        "dedicated_wallet",
        "A dedicated, isolated trading wallet is in use (not a personal wallet).",
    ),
    (
        "limited_capital",
        "Only limited, loss-tolerant capital is funded on the wallet.",
    ),
    (
        "working_backups",
        "Database and configuration backups are taken and a restore was tested.",
    ),
    (
        "working_alerts",
        "Alerting is wired end-to-end and a test alert was received.",
    ),
    (
        "reviewed_risk_limits",
        "Risk-engine limits (order size, notional, unmatched size/duration) reviewed.",
    ),
    (
        "tested_kill_switch",
        "The global kill switch was engaged and verified to stop new trading "
        "while still allowing cancellation.",
    ),
    (
        "successful_reconciliation",
        "A full authoritative reconciliation pass completed consistently.",
    ),
    (
        "sufficient_paper_sample",
        "A sufficient paper-trading sample was collected and reviewed.",
    ),
    (
        "reviewed_tx_config",
        "On-chain transaction configuration (gas, allowances, RPC endpoints) reviewed.",
    ),
    (
        "reviewed_market_api",
        "Market and API behavior (5-minute windows, fills, rate limits) reviewed.",
    ),
)

CHECKLIST_KEYS: frozenset[str] = frozenset(key for key, _ in CHECKLIST_ITEMS)


def build_checklist(confirmed: Iterable[str] | None = None) -> tuple[ChecklistItem, ...]:
    """Build the checklist, marking the given keys as confirmed.

    Unknown keys are ignored (they cannot silently satisfy a real item).
    """
    confirmed_set = frozenset(confirmed or ())
    return tuple(
        ChecklistItem(key=key, description=desc, confirmed=key in confirmed_set)
        for key, desc in CHECKLIST_ITEMS
    )


def unknown_confirmations(confirmed: Iterable[str]) -> tuple[str, ...]:
    """Return any supplied confirmation keys that are not real checklist items."""
    return tuple(sorted(set(confirmed) - CHECKLIST_KEYS))
