"""Release-gate runner: execute gates and assemble the report (Module 24).

The runner is pure orchestration: it takes an injected :class:`CommandRunner`
and (optionally) a paper-statistics provider and a secret scanner. It never
spawns subprocesses itself, so it is fully unit-testable offline. Everything
fails closed: a command that errors, crashes, or is missing yields a gate that
is not ``PASSED`` and therefore blocks live readiness.
"""

from __future__ import annotations

import time
from collections.abc import Iterable
from pathlib import Path
from typing import Protocol

from .checklist import build_checklist, unknown_confirmations
from .gates import COMMAND_GATES, CommandRunner, GateSpec
from .models import GateResult, GateStatus, PaperStatistics, ReleaseReport
from .secret_scan import SecretScanner


class PaperStatisticsProvider(Protocol):
    """Supplies descriptive paper-run statistics (never a profit claim)."""

    def collect(self) -> PaperStatistics: ...


class StaticPaperStatistics:
    """A provider that returns a fixed :class:`PaperStatistics` value."""

    def __init__(self, statistics: PaperStatistics) -> None:
        self._statistics = statistics

    def collect(self) -> PaperStatistics:
        return self._statistics


class ReleaseGateRunner:
    """Runs every gate and assembles a :class:`ReleaseReport`."""

    def __init__(
        self,
        *,
        command_runner: CommandRunner,
        project_root: str | Path,
        secret_scanner: SecretScanner | None = None,
        paper_statistics: PaperStatisticsProvider | None = None,
        confirmed_checklist: Iterable[str] | None = None,
        command_gates: tuple[GateSpec, ...] = COMMAND_GATES,
        secret_scan_targets: tuple[str, ...] = ("src", "tests", "docker", "deploy"),
    ) -> None:
        self._runner = command_runner
        self._root = Path(project_root)
        self._scanner = secret_scanner or SecretScanner()
        self._paper_statistics = paper_statistics
        self._confirmed = frozenset(confirmed_checklist or ())
        self._command_gates = command_gates
        self._secret_scan_targets = secret_scan_targets

    def run(self) -> ReleaseReport:
        gates: list[GateResult] = [
            self._run_command_gate(spec) for spec in self._command_gates
        ]
        gates.append(self._run_secret_scan())

        statistics = (
            self._paper_statistics.collect()
            if self._paper_statistics is not None
            else PaperStatistics()
        )
        risks = self._collect_unresolved_risks(gates, statistics)
        return ReleaseReport(
            gates=tuple(gates),
            checklist=build_checklist(self._confirmed),
            paper_statistics=statistics,
            unresolved_risks=tuple(risks),
            live_trading_enabled=False,
        )

    # ------------------------------------------------------------------ #
    # Gate execution
    # ------------------------------------------------------------------ #
    def _run_command_gate(self, spec: GateSpec) -> GateResult:
        start = time.monotonic()
        try:
            result = self._runner.run(spec.command)
        except Exception as exc:  # noqa: BLE001 - fail closed on any runner error
            elapsed = int((time.monotonic() - start) * 1000)
            return GateResult(
                name=spec.name,
                status=GateStatus.ERROR,
                mandatory=spec.mandatory,
                summary=f"{spec.description or spec.name} could not be executed",
                detail=f"{type(exc).__name__}: {exc}",
                duration_ms=elapsed,
            )
        elapsed = int((time.monotonic() - start) * 1000)
        status = GateStatus.PASSED if result.ok else GateStatus.FAILED
        summary = (
            f"{spec.description or spec.name} passed"
            if result.ok
            else f"{spec.description or spec.name} failed (exit {result.returncode})"
        )
        return GateResult(
            name=spec.name,
            status=status,
            mandatory=spec.mandatory,
            summary=summary,
            detail=_tail(result.stderr or result.stdout),
            duration_ms=elapsed,
        )

    def _run_secret_scan(self) -> GateResult:
        start = time.monotonic()
        findings = []
        for target in self._secret_scan_targets:
            path = self._root / target
            if path.exists():
                findings.extend(self._scanner.scan_path(path))
        elapsed = int((time.monotonic() - start) * 1000)
        if findings:
            preview = "; ".join(f.render() for f in findings[:10])
            return GateResult(
                name="secret-scan",
                status=GateStatus.FAILED,
                mandatory=True,
                summary=f"{len(findings)} potential secret(s) found",
                detail=preview,
                duration_ms=elapsed,
            )
        return GateResult(
            name="secret-scan",
            status=GateStatus.PASSED,
            mandatory=True,
            summary="No secrets detected",
            duration_ms=elapsed,
        )

    # ------------------------------------------------------------------ #
    # Unresolved risks
    # ------------------------------------------------------------------ #
    def _collect_unresolved_risks(
        self, gates: Iterable[GateResult], statistics: PaperStatistics
    ) -> list[str]:
        risks: list[str] = []
        for gate in gates:
            if gate.blocks_release:
                risks.append(f"Mandatory gate '{gate.name}' is {gate.status.value}.")
        if not statistics.sufficient_sample:
            risks.append(
                "Paper sample is below the required threshold "
                f"({statistics.paper_sessions}/{statistics.required_sessions} "
                "sessions)."
            )
        unknown = unknown_confirmations(self._confirmed)
        if unknown:
            risks.append(
                "Unknown checklist confirmation key(s) ignored: "
                + ", ".join(unknown)
                + "."
            )
        missing = [
            item.key
            for item in build_checklist(self._confirmed)
            if not item.confirmed
        ]
        if missing:
            risks.append(
                f"{len(missing)} human checklist item(s) not yet confirmed."
            )
        return risks


def _tail(text: str, *, max_lines: int = 12, max_chars: int = 1200) -> str:
    """Return a bounded tail of command output for the report detail."""
    if not text:
        return ""
    lines = text.strip().splitlines()[-max_lines:]
    joined = "\n".join(lines)
    return joined[-max_chars:]
