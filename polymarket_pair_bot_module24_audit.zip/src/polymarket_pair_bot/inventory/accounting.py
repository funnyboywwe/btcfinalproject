"""Inventory and matched-pair accounting (architecture item 12).

Pure, deterministic, side-effect-free accounting for one binary market's
Up/Down inventory. This module is the authoritative in-memory model of what the
bot *owns*, derived exclusively from **confirmed fills**.

Dependency inversion
--------------------
This module imports only domain value objects, entities and arithmetic. It
never imports SQLAlchemy, HTTP / WebSocket / blockchain clients, environment
variables or concrete execution classes. Persistence and rebuild orchestration
live in :mod:`polymarket_pair_bot.inventory.service`, strictly behind the
domain repository protocols.

Lot-allocation method
---------------------
We use **weighted-average cost (WAC)** per outcome side (see
:class:`LotAllocationMethod`). Rationale:

* the accumulation strategy only ever *buys* to acquire, so acquisition order
  never changes the reported average -- rebuilding from the fill journal is
  therefore order-independent, deterministic and idempotent;
* it matches the single ``average_price`` field already carried by the
  persisted :class:`~polymarket_pair_bot.domain.entities.Position`, so no new
  per-lot storage is required;
* it keeps matched and unmatched cost bases consistent (both priced at the same
  average), which is what the CTF-merge economics assume.

Conservative rounding follows the domain policy: fees round UP, profit rounds
DOWN. Nothing here asserts the strategy is profitable; every figure is a
modeled accounting quantity.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, replace
from decimal import Decimal, localcontext
from enum import Enum

from polymarket_pair_bot.domain.arithmetic import (
    locked_net_profit as _locked_net_profit,
)
from polymarket_pair_bot.domain.arithmetic import (
    locked_pair_value as _locked_pair_value,
)
from polymarket_pair_bot.domain.arithmetic import (
    matched_quantity as _matched_quantity,
)
from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    Fill,
    InventorySnapshot,
    MatchedPair,
    Position,
)
from polymarket_pair_bot.domain.enums import OrderSide, OutcomeSide
from polymarket_pair_bot.domain.precision import (
    computation_context,
    round_fee_up,
    round_price,
    round_profit_down,
    round_usd,
)
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ConditionId,
    FeeAmount,
    MarketId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TokenId,
    UnixTimestamp,
)


class LotAllocationMethod(str, Enum):
    """Documented cost-basis method for outcome-token inventory.

    Only ``WEIGHTED_AVERAGE_COST`` is implemented; see the module docstring for
    why it is the correct default for a buy-only accumulation strategy.
    """

    WEIGHTED_AVERAGE_COST = "weighted_average_cost"


class NegativeInventoryError(ValueError):
    """Raised when an operation would drive a side's inventory below zero.

    The accounting layer fails closed: it refuses to represent a negative
    holding rather than silently clamping it.
    """


def outcome_side_for(market: BinaryMarket, token_id: TokenId) -> OutcomeSide:
    """Resolve which outcome side ``token_id`` belongs to within ``market``.

    Raises ``ValueError`` if the token is neither the Up nor Down token; the
    accounting layer never guesses a side.
    """
    if token_id == market.up_token.token_id:
        return OutcomeSide.UP
    if token_id == market.down_token.token_id:
        return OutcomeSide.DOWN
    raise ValueError("fill token does not belong to this market")


@dataclass(frozen=True, slots=True)
class SideAccount:
    """Weighted-average-cost accounting for one outcome side.

    Fields:
        side: which outcome (Up/Down).
        token_id: the outcome token id.
        quantity: confirmed net shares held (Shares, >= 0).
        acquisition_cost: cumulative notional paid for the held shares
            (CollateralAmount, USD; sum of price*size, excludes fees).
        fees: cumulative taker fees attributed to this side (FeeAmount).
    """

    side: OutcomeSide
    token_id: TokenId
    quantity: Shares
    acquisition_cost: CollateralAmount
    fees: FeeAmount

    @property
    def average_cost(self) -> ProbabilityPrice | None:
        """Weighted-average acquisition price, or ``None`` when flat."""
        if not self.quantity.is_positive:
            return None
        with localcontext(computation_context()):
            avg = round_price(self.acquisition_cost.value / self.quantity.value)
        return ProbabilityPrice(avg)

    @property
    def cost_basis(self) -> CollateralAmount:
        """Acquisition cost plus fees (full USD outlay for this side)."""
        with localcontext(computation_context()):
            total = self.acquisition_cost.value + self.fees.value
        return CollateralAmount(round_usd(total))

    def with_buy(
        self, price: ProbabilityPrice, size: Shares, fee: FeeAmount
    ) -> SideAccount:
        """Return a new account after adding a confirmed BUY fill."""
        with localcontext(computation_context()):
            new_qty = self.quantity.value + size.value
            new_cost = round_usd(self.acquisition_cost.value + price.value * size.value)
            new_fees = round_fee_up(self.fees.value + fee.value)
        return replace(
            self,
            quantity=Shares(new_qty),
            acquisition_cost=CollateralAmount(new_cost),
            fees=FeeAmount(new_fees),
        )

    def with_sell(
        self, price: ProbabilityPrice, size: Shares, fee: FeeAmount
    ) -> tuple[SideAccount, ProfitAmount]:
        """Return a new account and realized P&L after a confirmed SELL fill.

        The accumulation strategy does not normally sell (it merges pairs), but
        this path is supported defensively for residual liquidation. A sell
        larger than the held quantity raises :class:`NegativeInventoryError`
        (fail closed -- never negative inventory). Cost basis is reduced at the
        weighted-average price; realized P&L is ``size*(price-avg) - fee``.
        """
        if size.value > self.quantity.value:
            raise NegativeInventoryError("sell would drive inventory negative")
        average = self.average_cost
        average_value = Decimal(0) if average is None else average.value
        with localcontext(computation_context()):
            cost_removed = average_value * size.value
            new_qty = self.quantity.value - size.value
            new_cost = self.acquisition_cost.value - cost_removed
            if new_cost < 0:
                new_cost = Decimal(0)
            new_fees = round_fee_up(self.fees.value + fee.value)
            realized = round_profit_down(
                (price.value - average_value) * size.value - fee.value
            )
        updated = replace(
            self,
            quantity=Shares(new_qty),
            acquisition_cost=CollateralAmount(round_usd(new_cost)),
            fees=FeeAmount(new_fees),
        )
        return updated, ProfitAmount(realized)


@dataclass(frozen=True, slots=True)
class MarketInventory:
    """Immutable per-market inventory derived only from confirmed fills.

    ``applied_fill_ids`` records which fill ids have already been folded in, so
    :meth:`apply_fill` is idempotent even before persistence-level dedup.

    Matched and unmatched accounting are kept strictly separate: ``matched_*``
    concerns complete Up/Down pairs (mergeable for $1 each), while ``residual_*``
    concerns directional exposure not yet paired.
    """

    market_id: MarketId
    condition_id: ConditionId
    up: SideAccount
    down: SideAccount
    realized_pnl: ProfitAmount
    rebates: CollateralAmount
    as_of: UnixTimestamp
    applied_fill_ids: frozenset[str]
    lot_method: LotAllocationMethod = LotAllocationMethod.WEIGHTED_AVERAGE_COST

    # -- matched / unmatched decomposition ---------------------------------
    @property
    def matched_quantity(self) -> Shares:
        """Confirmed complete pairs = min(up, down)."""
        return _matched_quantity(self.up.quantity, self.down.quantity)

    @property
    def residual_up(self) -> Shares:
        """Unmatched Up exposure (up - matched)."""
        return Shares(self.up.quantity.value - self.matched_quantity.value)

    @property
    def residual_down(self) -> Shares:
        """Unmatched Down exposure (down - matched)."""
        return Shares(self.down.quantity.value - self.matched_quantity.value)

    @property
    def total_fees(self) -> FeeAmount:
        with localcontext(computation_context()):
            total = self.up.fees.value + self.down.fees.value
        return FeeAmount(round_fee_up(total))

    @property
    def locked_pair_value(self) -> CollateralAmount:
        """Collateral recoverable by merging complete pairs (pairs * $1)."""
        return _locked_pair_value(self.matched_quantity)

    def _fee_allocation(self, side: SideAccount) -> Decimal:
        """Fees attributable to the matched portion of ``side`` (pro-rata)."""
        matched = self.matched_quantity
        if not matched.is_positive or not side.quantity.is_positive:
            return Decimal(0)
        with localcontext(computation_context()):
            return side.fees.value * (matched.value / side.quantity.value)

    @property
    def matched_cost_basis(self) -> CollateralAmount:
        """All-in cost of the matched portion (avg cost + allocated fees)."""
        matched = self.matched_quantity
        if not matched.is_positive:
            return CollateralAmount(0)
        up_avg = self.up.average_cost
        down_avg = self.down.average_cost
        assert up_avg is not None and down_avg is not None  # matched > 0 => qty > 0
        with localcontext(computation_context()):
            total = matched.value * (up_avg.value + down_avg.value)
            total += self._fee_allocation(self.up) + self._fee_allocation(self.down)
        return CollateralAmount(round_usd(total))

    @property
    def locked_net_profit(self) -> ProfitAmount:
        """Locked net profit of the matched portion (may be negative)."""
        return _locked_net_profit(self.locked_pair_value, self.matched_cost_basis)

    @property
    def residual_cost_basis(self) -> CollateralAmount:
        """Cost basis of the unmatched residual (total minus matched)."""
        with localcontext(computation_context()):
            total = (
                self.up.cost_basis.value
                + self.down.cost_basis.value
                - self.matched_cost_basis.value
            )
            if total < 0:
                total = Decimal(0)
        return CollateralAmount(round_usd(total))

    # -- projections -------------------------------------------------------
    def to_matched_pair(self) -> MatchedPair | None:
        """Project the matched portion into a :class:`MatchedPair`, if any."""
        matched = self.matched_quantity
        if not matched.is_positive:
            return None
        up_avg = self.up.average_cost
        down_avg = self.down.average_cost
        assert up_avg is not None and down_avg is not None
        with localcontext(computation_context()):
            up_cost = round_usd(matched.value * up_avg.value + self._fee_allocation(self.up))
            down_cost = round_usd(
                matched.value * down_avg.value + self._fee_allocation(self.down)
            )
            fees_total = round_fee_up(
                self._fee_allocation(self.up) + self._fee_allocation(self.down)
            )
        return MatchedPair(
            market_id=self.market_id,
            condition_id=self.condition_id,
            quantity=matched,
            up_cost=CollateralAmount(up_cost),
            down_cost=CollateralAmount(down_cost),
            fees=FeeAmount(fees_total),
            locked_value=self.locked_pair_value,
            net_profit=self.locked_net_profit,
            created_at=self.as_of,
        )

    def to_snapshot(self) -> InventorySnapshot:
        """Project to the persisted :class:`InventorySnapshot` shape."""
        return InventorySnapshot(
            market_id=self.market_id,
            up_position=self._position(self.up),
            down_position=self._position(self.down),
            matched_pairs=self.matched_quantity,
            as_of=self.as_of,
        )

    @staticmethod
    def _position(side: SideAccount) -> Position:
        average = side.average_cost or ProbabilityPrice(0)
        return Position(
            token_id=side.token_id,
            side=side.side,
            quantity=side.quantity,
            average_price=average,
            fees_paid=side.fees,
        )

    # -- mutation (returns a new immutable value) --------------------------
    def apply_fill(self, fill: Fill, side: OutcomeSide) -> MarketInventory:
        """Fold one confirmed fill into inventory (idempotent by fill id).

        Only confirmed fills reach this method; callers must never pass an
        order that is merely submitted/acknowledged/open/partially-filled.
        Duplicate fill ids are ignored so a repeated fill message never
        double-counts. Raises if the fill's token does not match ``side``.
        """
        if fill.fill_id.value in self.applied_fill_ids:
            return self
        account = self.up if side is OutcomeSide.UP else self.down
        if fill.token_id != account.token_id:
            raise ValueError("fill token does not match the resolved side")
        realized_delta = Decimal(0)
        if fill.side is OrderSide.BUY:
            account = account.with_buy(fill.price, fill.size, fill.fee)
        elif fill.side is OrderSide.SELL:
            account, realized = account.with_sell(fill.price, fill.size, fill.fee)
            realized_delta = realized.value
        else:  # pragma: no cover - enum is exhaustive
            raise ValueError(f"unsupported order side: {fill.side!r}")
        new_up = account if side is OutcomeSide.UP else self.up
        new_down = account if side is OutcomeSide.DOWN else self.down
        with localcontext(computation_context()):
            realized_total = self.realized_pnl.value + realized_delta
        as_of = fill.filled_at if fill.filled_at.value >= self.as_of.value else self.as_of
        return replace(
            self,
            up=new_up,
            down=new_down,
            realized_pnl=ProfitAmount(realized_total),
            as_of=as_of,
            applied_fill_ids=self.applied_fill_ids | {fill.fill_id.value},
        )


def empty_inventory(
    market: BinaryMarket,
    *,
    as_of: UnixTimestamp | None = None,
    rebates: CollateralAmount | None = None,
) -> MarketInventory:
    """Build a flat inventory for ``market`` (no holdings)."""
    return MarketInventory(
        market_id=market.market_id,
        condition_id=market.condition_id,
        up=SideAccount(
            OutcomeSide.UP,
            market.up_token.token_id,
            Shares(0),
            CollateralAmount(0),
            FeeAmount(0),
        ),
        down=SideAccount(
            OutcomeSide.DOWN,
            market.down_token.token_id,
            Shares(0),
            CollateralAmount(0),
            FeeAmount(0),
        ),
        realized_pnl=ProfitAmount(0),
        rebates=rebates or CollateralAmount(0),
        as_of=as_of or market.window.open_time,
        applied_fill_ids=frozenset(),
    )


def build_inventory(
    market: BinaryMarket,
    fills: Sequence[Fill],
    *,
    rebates: CollateralAmount | None = None,
    as_of: UnixTimestamp | None = None,
) -> MarketInventory:
    """Rebuild inventory entirely from the fill journal (requirement 9).

    Fills are processed in deterministic ``(filled_at, fill_id)`` order so the
    rebuild is reproducible regardless of the journal's storage order.
    Duplicate fill ids are ignored. Authoritative ``rebates`` (recovered
    elsewhere) may be supplied; they are never inferred.
    """
    inventory = empty_inventory(market, as_of=as_of, rebates=rebates)
    ordered = sorted(fills, key=lambda fill: (fill.filled_at.value, fill.fill_id.value))
    for fill in ordered:
        inventory = inventory.apply_fill(fill, outcome_side_for(market, fill.token_id))
    return inventory


# Explicit, self-documenting alias for requirement 9 ("rebuild from journal").
rebuild_from_fills = build_inventory


def inventory_from_snapshot(
    snapshot: InventorySnapshot,
    condition_id: ConditionId,
    *,
    rebates: CollateralAmount | None = None,
    realized_pnl: ProfitAmount | None = None,
) -> MarketInventory:
    """Seed a live accountant from the latest persisted snapshot.

    Used on the incremental write path so a single new fill can be applied
    without replaying the whole journal; database-level idempotency still
    guarantees a duplicate fill never mutates inventory twice.
    """
    return MarketInventory(
        market_id=snapshot.market_id,
        condition_id=condition_id,
        up=_side_from_position(snapshot.up_position),
        down=_side_from_position(snapshot.down_position),
        realized_pnl=realized_pnl or ProfitAmount(0),
        rebates=rebates or CollateralAmount(0),
        as_of=snapshot.as_of,
        applied_fill_ids=frozenset(),
    )


def _side_from_position(position: Position) -> SideAccount:
    with localcontext(computation_context()):
        acquisition = round_usd(position.quantity.value * position.average_price.value)
    return SideAccount(
        side=position.side,
        token_id=position.token_id,
        quantity=position.quantity,
        acquisition_cost=CollateralAmount(acquisition),
        fees=position.fees_paid,
    )


__all__ = [
    "LotAllocationMethod",
    "MarketInventory",
    "NegativeInventoryError",
    "SideAccount",
    "build_inventory",
    "empty_inventory",
    "inventory_from_snapshot",
    "outcome_side_for",
    "rebuild_from_fills",
]
