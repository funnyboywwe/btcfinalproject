"""Inventory and matched-pair accounting (architecture item 12).

This package is the authoritative model of what the bot owns, derived only from
confirmed fills. It keeps matched (complete Up/Down pair) accounting strictly
separate from unmatched (residual directional) accounting, marks residual
exposure conservatively at executable bid prices, and can rebuild the entire
inventory from the fill journal for verification against stored snapshots.

Public surface:

* :mod:`~polymarket_pair_bot.inventory.accounting` -- pure WAC accounting model.
* :mod:`~polymarket_pair_bot.inventory.marking` -- executable-bid residual marks.
* :mod:`~polymarket_pair_bot.inventory.audit` -- pending reserves, rebuild
  comparison, and a secret-free audit report.
* :mod:`~polymarket_pair_bot.inventory.ports` -- dependency-inversion protocols.
* :mod:`~polymarket_pair_bot.inventory.service` -- async persist + rebuild.
"""

from __future__ import annotations

from polymarket_pair_bot.inventory.accounting import (
    LotAllocationMethod,
    MarketInventory,
    NegativeInventoryError,
    SideAccount,
    build_inventory,
    empty_inventory,
    inventory_from_snapshot,
    outcome_side_for,
    rebuild_from_fills,
)
from polymarket_pair_bot.inventory.audit import (
    InventoryAudit,
    InventoryComparison,
    PendingOrdersSummary,
    build_audit,
    compare_inventories,
    summarize_pending,
)
from polymarket_pair_bot.inventory.marking import (
    ResidualMark,
    SideResidualMark,
    mark_residual,
)
from polymarket_pair_bot.inventory.ports import MarketFillJournal, ResidualBookSource
from polymarket_pair_bot.inventory.service import InventoryService, RebuildResult

__all__ = [
    "InventoryAudit",
    "InventoryComparison",
    "InventoryService",
    "LotAllocationMethod",
    "MarketFillJournal",
    "MarketInventory",
    "NegativeInventoryError",
    "PendingOrdersSummary",
    "RebuildResult",
    "ResidualBookSource",
    "ResidualMark",
    "SideAccount",
    "SideResidualMark",
    "build_audit",
    "build_inventory",
    "compare_inventories",
    "empty_inventory",
    "inventory_from_snapshot",
    "mark_residual",
    "outcome_side_for",
    "rebuild_from_fills",
    "summarize_pending",
]
