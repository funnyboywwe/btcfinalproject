"""Mark unmatched (residual) positions at executable bid prices.

Residual directional exposure is valued *conservatively* using the price at
which it could actually be sold -- the **executable bid VWAP** obtained by
walking the bid side of the book. This module never uses midpoint, last-trade
or best-ask prices for liquidation value (requirement 6): those overstate what
could be recovered in an emergency exit.

Pure and dependency-inverted: it takes already-loaded
:class:`~polymarket_pair_bot.domain.entities.OrderBookSnapshot` values and does
no I/O. Unmarketable residual (beyond available bid depth) is marked at zero
and reported as a shortfall, so the emergency-liquidation value is a floor,
never an optimistic estimate.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, localcontext

from polymarket_pair_bot.domain.arithmetic import (
    executable_vwap,
    mark_to_executable_bid_pnl,
)
from polymarket_pair_bot.domain.entities import OrderBookSnapshot
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.precision import computation_context, round_usd
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
)
from polymarket_pair_bot.inventory.accounting import MarketInventory


@dataclass(frozen=True, slots=True)
class SideResidualMark:
    """Executable-bid marking for one side's residual exposure.

    Fields:
        side: which outcome side.
        residual: unmatched quantity being marked (Shares).
        marketable: quantity the bids can actually absorb (Shares).
        shortfall: residual the book cannot absorb (Shares); marked at zero.
        executable_bid: VWAP bid over the marketable quantity, or ``None`` when
            no bid liquidity exists.
        marked_value: marketable * executable_bid (CollateralAmount, USD).
        marked_pnl: mark-to-executable-bid P&L vs average cost, or ``None``.
    """

    side: OutcomeSide
    residual: Shares
    marketable: Shares
    shortfall: Shares
    executable_bid: ProbabilityPrice | None
    marked_value: CollateralAmount
    marked_pnl: ProfitAmount | None


@dataclass(frozen=True, slots=True)
class ResidualMark:
    """Both sides' residual marks plus the conservative liquidation floor."""

    up: SideResidualMark
    down: SideResidualMark
    total_marked_value: CollateralAmount

    @property
    def has_shortfall(self) -> bool:
        """True when bid depth cannot absorb the full residual on some side."""
        return self.up.shortfall.is_positive or self.down.shortfall.is_positive

    @property
    def emergency_liquidation_value(self) -> CollateralAmount:
        """Bids-only conservative liquidation floor.

        This deliberately equals the summed executable-bid value. Midpoint,
        last-trade and best-ask prices are never used here.
        """
        return self.total_marked_value


def _mark_side(
    side: OutcomeSide,
    residual: Shares,
    book: OrderBookSnapshot | None,
    average_cost: ProbabilityPrice | None,
) -> SideResidualMark:
    if not residual.is_positive:
        return SideResidualMark(
            side, residual, Shares(0), Shares(0), None, CollateralAmount(0), None
        )
    bids = book.bids if book is not None else ()
    if not bids:
        # No bid liquidity: nothing is marketable; entire residual is shortfall.
        return SideResidualMark(
            side, residual, Shares(0), residual, None, CollateralAmount(0), None
        )
    vwap = executable_vwap(bids, residual)
    marketable = vwap.filled
    executable_bid = vwap.average_price
    with localcontext(computation_context()):
        shortfall = residual.value - marketable.value
        if executable_bid is None:
            value = Decimal(0)
        else:
            value = marketable.value * executable_bid.value
    marked_value = CollateralAmount(round_usd(value))
    marked_pnl: ProfitAmount | None = None
    if executable_bid is not None and marketable.is_positive and average_cost is not None:
        marked_pnl = mark_to_executable_bid_pnl(marketable, average_cost, executable_bid)
    return SideResidualMark(
        side=side,
        residual=residual,
        marketable=marketable,
        shortfall=Shares(shortfall),
        executable_bid=executable_bid,
        marked_value=marked_value,
        marked_pnl=marked_pnl,
    )


def mark_residual(
    inventory: MarketInventory,
    *,
    up_book: OrderBookSnapshot | None = None,
    down_book: OrderBookSnapshot | None = None,
) -> ResidualMark:
    """Mark both residual legs at executable bid prices (conservative).

    Only one side can have a positive residual at a time (residual is
    ``|up - down|`` on a single side), but both are marked for completeness.
    A missing book marks that side's residual entirely as shortfall.
    """
    if up_book is not None and up_book.token_id != inventory.up.token_id:
        raise ValueError("up_book token does not match inventory up token")
    if down_book is not None and down_book.token_id != inventory.down.token_id:
        raise ValueError("down_book token does not match inventory down token")
    up_mark = _mark_side(
        OutcomeSide.UP, inventory.residual_up, up_book, inventory.up.average_cost
    )
    down_mark = _mark_side(
        OutcomeSide.DOWN, inventory.residual_down, down_book, inventory.down.average_cost
    )
    with localcontext(computation_context()):
        total = up_mark.marked_value.value + down_mark.marked_value.value
    return ResidualMark(up_mark, down_mark, CollateralAmount(round_usd(total)))


__all__ = [
    "ResidualMark",
    "SideResidualMark",
    "mark_residual",
]
