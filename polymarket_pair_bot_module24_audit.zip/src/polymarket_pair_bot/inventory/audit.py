"""Complete inventory audit: pending-order reserves, rebuilt-vs-stored
comparison, and a secret-free report.

Pure and dependency-inverted: everything here operates on already-loaded domain
values (:class:`MarketInventory`, :class:`InventorySnapshot`,
:class:`ExchangeOrder`) plus an optional :class:`ResidualMark`. No I/O, no
secrets, no SQLAlchemy.

The audit intentionally reports matched and unmatched accounting separately and
never prints wallet keys, API secrets or signatures -- only accounting figures
rendered as decimal strings.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from decimal import Decimal, localcontext

from polymarket_pair_bot.domain.entities import ExchangeOrder, InventorySnapshot
from polymarket_pair_bot.domain.enums import OrderSide
from polymarket_pair_bot.domain.precision import (
    computation_context,
    round_fee_up,
)
from polymarket_pair_bot.domain.value_objects import CollateralAmount, Shares
from polymarket_pair_bot.inventory.accounting import MarketInventory
from polymarket_pair_bot.inventory.marking import ResidualMark


@dataclass(frozen=True, slots=True)
class PendingOrdersSummary:
    """Reserved exposure implied by not-yet-terminal orders.

    Fields:
        pending_count: number of non-terminal orders.
        reserved_collateral: USD reserved by open BUY orders
            (sum of remaining_size * limit_price), rounded UP (conservative).
        reserved_sell_shares: shares reserved by open SELL orders.
    """

    pending_count: int
    reserved_collateral: CollateralAmount
    reserved_sell_shares: Shares


def summarize_pending(orders: Sequence[ExchangeOrder]) -> PendingOrdersSummary:
    """Summarize collateral/shares reserved by non-terminal orders.

    Terminal orders (filled, canceled, rejected, expired) reserve nothing.
    ``UNKNOWN`` is treated as still pending -- it reserves conservatively until
    reconciliation resolves it. BUY reserves collateral; SELL reserves shares.
    """
    count = 0
    with localcontext(computation_context()):
        reserved = Decimal(0)
        sell_shares = Decimal(0)
        for order in orders:
            if order.status.is_terminal:
                continue
            count += 1
            remaining = order.remaining_size.value
            if order.side is OrderSide.BUY:
                reserved += remaining * order.limit_price.value
            else:
                sell_shares += remaining
    return PendingOrdersSummary(
        pending_count=count,
        reserved_collateral=CollateralAmount(round_fee_up(reserved)),
        reserved_sell_shares=Shares(sell_shares),
    )


@dataclass(frozen=True, slots=True)
class InventoryComparison:
    """Result of comparing rebuilt inventory against a stored snapshot."""

    consistent: bool
    discrepancies: tuple[str, ...]


def compare_inventories(
    rebuilt: MarketInventory,
    stored: InventorySnapshot | None,
) -> InventoryComparison:
    """Compare a journal-rebuilt inventory with the stored snapshot.

    A missing snapshot is reported as inconsistent (nothing to verify against).
    Average prices are compared using the same ``None -> 0`` convention that
    :meth:`MarketInventory.to_snapshot` uses when persisting.
    """
    if stored is None:
        return InventoryComparison(False, ("no stored snapshot to compare against",))
    issues: list[str] = []

    def check(name: str, left: Decimal, right: Decimal) -> None:
        if left != right:
            issues.append(f"{name}: rebuilt={left} stored={right}")

    up_avg = rebuilt.up.average_cost.value if rebuilt.up.average_cost else Decimal(0)
    down_avg = rebuilt.down.average_cost.value if rebuilt.down.average_cost else Decimal(0)
    check("up_quantity", rebuilt.up.quantity.value, stored.up_position.quantity.value)
    check("down_quantity", rebuilt.down.quantity.value, stored.down_position.quantity.value)
    check("up_average_price", up_avg, stored.up_position.average_price.value)
    check("down_average_price", down_avg, stored.down_position.average_price.value)
    check("up_fees", rebuilt.up.fees.value, stored.up_position.fees_paid.value)
    check("down_fees", rebuilt.down.fees.value, stored.down_position.fees_paid.value)
    check("matched_pairs", rebuilt.matched_quantity.value, stored.matched_pairs.value)
    return InventoryComparison(not issues, tuple(issues))


@dataclass(frozen=True, slots=True)
class InventoryAudit:
    """A complete, renderable inventory audit for one market."""

    inventory: MarketInventory
    residual_mark: ResidualMark | None = None
    pending: PendingOrdersSummary | None = None
    comparison: InventoryComparison | None = None

    def as_dict(self) -> dict[str, object]:
        """Structured audit with every tracked figure as a decimal string."""
        inv = self.inventory
        up_avg = inv.up.average_cost
        down_avg = inv.down.average_cost
        data: dict[str, object] = {
            "market_id": inv.market_id.value,
            "condition_id": inv.condition_id.value,
            "lot_method": inv.lot_method.value,
            "as_of": inv.as_of.value,
            "up_quantity": str(inv.up.quantity.value),
            "down_quantity": str(inv.down.quantity.value),
            "up_acquisition_cost": str(inv.up.acquisition_cost.value),
            "down_acquisition_cost": str(inv.down.acquisition_cost.value),
            "up_average_cost": str(up_avg.value) if up_avg else None,
            "down_average_cost": str(down_avg.value) if down_avg else None,
            "matched_quantity": str(inv.matched_quantity.value),
            "residual_up": str(inv.residual_up.value),
            "residual_down": str(inv.residual_down.value),
            "locked_pair_value": str(inv.locked_pair_value.value),
            "locked_net_profit": str(inv.locked_net_profit.value),
            "realized_pnl": str(inv.realized_pnl.value),
            "fees": str(inv.total_fees.value),
            "rebates": str(inv.rebates.value),
        }
        if self.residual_mark is not None:
            mark = self.residual_mark
            data["marked_residual_value"] = str(mark.total_marked_value.value)
            data["emergency_liquidation_value"] = str(
                mark.emergency_liquidation_value.value
            )
            data["residual_marking_shortfall"] = (
                str(mark.up.shortfall.value)
                if mark.up.shortfall.is_positive
                else str(mark.down.shortfall.value)
            )
        else:
            data["marked_residual_value"] = None
        if self.pending is not None:
            data["pending_orders"] = self.pending.pending_count
            data["reserved_collateral"] = str(self.pending.reserved_collateral.value)
            data["reserved_sell_shares"] = str(self.pending.reserved_sell_shares.value)
        if self.comparison is not None:
            data["rebuild_consistent"] = self.comparison.consistent
            data["rebuild_discrepancies"] = list(self.comparison.discrepancies)
        return data

    def render_text(self) -> str:
        """Human-readable, secret-free audit report."""
        data = self.as_dict()
        lines = [
            f"Inventory audit for market {data['market_id']}",
            f"  condition_id:        {data['condition_id']}",
            f"  lot_method:          {data['lot_method']}",
            f"  as_of:               {data['as_of']}",
            "  -- confirmed positions (from fills only) --",
            f"  up_quantity:         {data['up_quantity']}",
            f"  down_quantity:       {data['down_quantity']}",
            f"  up_acquisition_cost: {data['up_acquisition_cost']}",
            f"  down_acquisition_cost: {data['down_acquisition_cost']}",
            f"  up_average_cost:     {data['up_average_cost']}",
            f"  down_average_cost:   {data['down_average_cost']}",
            "  -- matched (complete pairs) --",
            f"  matched_quantity:    {data['matched_quantity']}",
            f"  locked_pair_value:   {data['locked_pair_value']}",
            f"  locked_net_profit:   {data['locked_net_profit']}",
            "  -- unmatched (residual) --",
            f"  residual_up:         {data['residual_up']}",
            f"  residual_down:       {data['residual_down']}",
            f"  marked_residual_value: {data['marked_residual_value']}",
        ]
        if "emergency_liquidation_value" in data:
            lines.append(
                f"  emergency_liquidation_value (bids only): "
                f"{data['emergency_liquidation_value']}"
            )
        if "residual_marking_shortfall" in data:
            lines.append(
                f"  residual_marking_shortfall: {data['residual_marking_shortfall']}"
            )
        lines += [
            "  -- realized / fees / rebates --",
            f"  realized_pnl:        {data['realized_pnl']}",
            f"  fees:                {data['fees']}",
            f"  rebates:             {data['rebates']}",
        ]
        if self.pending is not None:
            lines += [
                "  -- pending orders --",
                f"  pending_orders:      {data['pending_orders']}",
                f"  reserved_collateral: {data['reserved_collateral']}",
                f"  reserved_sell_shares: {data['reserved_sell_shares']}",
            ]
        if self.comparison is not None:
            lines.append("  -- rebuild vs stored snapshot --")
            lines.append(f"  rebuild_consistent:  {data['rebuild_consistent']}")
            discrepancies = self.comparison.discrepancies
            if discrepancies:
                for issue in discrepancies:
                    lines.append(f"    ! {issue}")
        return "\n".join(lines)


def build_audit(
    inventory: MarketInventory,
    *,
    residual_mark: ResidualMark | None = None,
    pending: PendingOrdersSummary | None = None,
    comparison: InventoryComparison | None = None,
) -> InventoryAudit:
    """Assemble a complete :class:`InventoryAudit`."""
    return InventoryAudit(
        inventory=inventory,
        residual_mark=residual_mark,
        pending=pending,
        comparison=comparison,
    )


__all__ = [
    "InventoryAudit",
    "InventoryComparison",
    "PendingOrdersSummary",
    "build_audit",
    "compare_inventories",
    "summarize_pending",
]
