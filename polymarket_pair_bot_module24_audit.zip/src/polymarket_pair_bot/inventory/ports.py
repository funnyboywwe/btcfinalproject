"""Typed ports (Protocols) the inventory layer depends on.

These are the dependency-inversion boundaries for inventory rebuild and audit.
Concrete implementations live in the persistence layer (which may import
SQLAlchemy); the inventory service and CLI depend only on these protocols.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import BinaryMarket, Fill, OrderBookSnapshot
from polymarket_pair_bot.domain.value_objects import TokenId


@runtime_checkable
class MarketFillJournal(Protocol):
    """Read-only access to the confirmed-fill journal for one market.

    Implementations must return every confirmed fill whose token is the
    market's Up or Down token, ordered deterministically by
    ``(filled_at, fill_id)`` so a rebuild is reproducible.
    """

    async def list_market_fills(self, market: BinaryMarket) -> Sequence[Fill]: ...


@runtime_checkable
class ResidualBookSource(Protocol):
    """Latest authoritative order book for a token (for residual marking).

    Returns ``None`` when no fresh book is available; the caller then treats
    the residual as unmarketable rather than guessing a price.
    """

    async def latest_book(self, token_id: TokenId) -> OrderBookSnapshot | None: ...


__all__ = [
    "MarketFillJournal",
    "ResidualBookSource",
]
