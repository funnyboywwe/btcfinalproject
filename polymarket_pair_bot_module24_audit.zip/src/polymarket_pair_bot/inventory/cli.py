"""Command-line inventory audit (requirement 12).

Usage::

    python -m polymarket_pair_bot.inventory.cli audit --market <market_id>
    python -m polymarket_pair_bot.inventory.cli audit --market <market_id> --json

The audit rebuilds inventory entirely from the confirmed-fill journal, compares
it against the stored snapshot, summarizes reserved collateral from pending
orders, and prints a complete, secret-free report. It performs no live trading
and never prints the DSN or any secret.

Residual marking at executable bid prices is available in the accounting API
(:func:`polymarket_pair_bot.inventory.mark_residual`); it is intentionally
omitted from this offline audit because a fresh authoritative order book is
supplied by the live market-data modules, not by this command.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Sequence

from polymarket_pair_bot.config import load_config
from polymarket_pair_bot.domain.value_objects import MarketId
from polymarket_pair_bot.inventory.audit import build_audit, summarize_pending
from polymarket_pair_bot.inventory.service import InventoryService
from polymarket_pair_bot.persistence import (
    create_engine_from_dsn,
    create_session_factory,
    create_unit_of_work_factory,
)
from polymarket_pair_bot.persistence.inventory_journal import MarketFillJournalImpl


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-inventory",
        description="Inventory accounting and audit commands.",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    audit = sub.add_parser("audit", help="Display a complete inventory audit")
    audit.add_argument("--market", required=True, help="Market id to audit")
    audit.add_argument(
        "--json", action="store_true", help="Emit the audit as JSON instead of text"
    )
    return parser


async def _run_audit(market_id_value: str, *, as_json: bool) -> int:
    config = load_config()
    engine = create_engine_from_dsn(
        config.postgres.dsn, echo=False, pool_size=config.postgres.db_pool_size
    )
    try:
        session_factory = create_session_factory(engine)
        uow_factory = create_unit_of_work_factory(session_factory)
        journal = MarketFillJournalImpl(session_factory)
        service = InventoryService(uow_factory, journal)

        market_id = MarketId(market_id_value)
        async with uow_factory() as uow:
            market = await uow.markets.get_market(market_id)
            open_orders = (
                list(await uow.orders.list_open(market_id)) if market is not None else []
            )
        if market is None:
            print(f"market not found: {market_id_value}")
            return 1

        result = await service.rebuild_and_verify(market)
        pending = summarize_pending(open_orders)
        audit = build_audit(
            result.rebuilt, pending=pending, comparison=result.comparison
        )
    finally:
        await engine.dispose()

    if as_json:
        print(json.dumps(audit.as_dict(), indent=2, sort_keys=True))
    else:
        print(audit.render_text())
    return 0 if result.comparison.consistent else 1


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    if args.command == "audit":
        return asyncio.run(_run_audit(args.market, as_json=args.json))
    return 2


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
