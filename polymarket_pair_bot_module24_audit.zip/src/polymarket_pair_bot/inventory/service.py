"""Asynchronous inventory service: persist transitions and rebuild/verify.

This is the orchestration layer for architecture item 12. It depends only on
domain repository protocols (:class:`UnitOfWork` / :class:`UnitOfWorkFactory`)
and the inventory ports (:class:`MarketFillJournal`) -- never on SQLAlchemy,
HTTP, WebSocket or blockchain clients. Concrete infrastructure is injected.

Guarantees:

* positions change only from confirmed fills (callers pass confirmed fills);
* every accepted fill persists a new inventory snapshot in the same
  transaction as the fill (requirement 8), atomically;
* duplicate fills are idempotent -- the unit of work reports whether the fill
  was newly recorded, and inventory is only advanced when it was;
* inventory can be rebuilt entirely from the fill journal and compared with the
  stored snapshot (requirements 9 and 10).
"""

from __future__ import annotations

from dataclasses import dataclass

from polymarket_pair_bot.domain.entities import BinaryMarket, Fill, InventorySnapshot
from polymarket_pair_bot.domain.repositories import UnitOfWorkFactory
from polymarket_pair_bot.domain.value_objects import CollateralAmount
from polymarket_pair_bot.inventory.accounting import (
    MarketInventory,
    empty_inventory,
    inventory_from_snapshot,
    outcome_side_for,
    rebuild_from_fills,
)
from polymarket_pair_bot.inventory.audit import (
    InventoryComparison,
    compare_inventories,
)
from polymarket_pair_bot.inventory.ports import MarketFillJournal
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("inventory.service")


@dataclass(frozen=True, slots=True)
class RebuildResult:
    """Outcome of rebuilding inventory from the journal and comparing it."""

    rebuilt: MarketInventory
    stored: InventorySnapshot | None
    comparison: InventoryComparison


class InventoryService:
    """Persist inventory transitions and rebuild/verify from the journal.

    Args:
        uow_factory: opens a fresh transactional unit of work.
        journal: read-only confirmed-fill journal for rebuilds.
        rebates: authoritative rebate credit to attribute (default zero); never
            inferred from fills.
    """

    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        journal: MarketFillJournal,
        *,
        rebates: CollateralAmount | None = None,
    ) -> None:
        self._uow_factory = uow_factory
        self._journal = journal
        self._rebates = rebates or CollateralAmount(0)

    async def record_fill(self, market: BinaryMarket, fill: Fill) -> bool:
        """Apply one confirmed fill and persist the resulting snapshot.

        Returns ``True`` when the fill was newly recorded (inventory advanced),
        ``False`` when it was a duplicate (inventory unchanged). The fill and
        the new inventory snapshot commit atomically in a single transaction.
        """
        side = outcome_side_for(market, fill.token_id)
        async with self._uow_factory() as uow:
            latest = await uow.inventory.get_latest(market.market_id.value)
            if latest is None:
                current = empty_inventory(
                    market, as_of=market.window.open_time, rebates=self._rebates
                )
            else:
                current = inventory_from_snapshot(
                    latest, market.condition_id, rebates=self._rebates
                )
            updated = current.apply_fill(fill, side)
            applied = await uow.record_fill_and_update_inventory(
                fill, updated.to_snapshot()
            )
            await uow.commit()
        _LOGGER.info(
            "inventory.record_fill",
            extra={
                "market_id": market.market_id.value,
                "fill_id": fill.fill_id.value,
                "applied": applied,
                "outcome_side": side.value,
            },
        )
        return applied

    async def rebuild_and_verify(self, market: BinaryMarket) -> RebuildResult:
        """Rebuild inventory from the fill journal and compare with storage.

        Read-only: it never mutates persisted state. Use it for restart-time
        verification and the audit command.
        """
        fills = await self._journal.list_market_fills(market)
        rebuilt = rebuild_from_fills(market, fills, rebates=self._rebates)
        async with self._uow_factory() as uow:
            stored = await uow.inventory.get_latest(market.market_id.value)
        comparison = compare_inventories(rebuilt, stored)
        if not comparison.consistent:
            _LOGGER.warning(
                "inventory.rebuild_mismatch",
                extra={
                    "market_id": market.market_id.value,
                    "discrepancies": list(comparison.discrepancies),
                },
            )
        return RebuildResult(rebuilt=rebuilt, stored=stored, comparison=comparison)


__all__ = [
    "InventoryService",
    "RebuildResult",
]
