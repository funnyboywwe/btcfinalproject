"""Order lifecycle manager: authoritative order/fill state transitions (Module 14).

This component owns how an order's local state evolves from an authoritative
record set. It NEVER infers a fill from an acknowledgement: an ack only ever
yields an ``ACKNOWLEDGED`` order; fills are applied solely from authoritative
fill records (queried after a taker match, or delivered by the authenticated
user stream in Module 16).

Safety properties:

* Fill messages are de-duplicated by ``fill_id`` (they are NOT assumed unique).
* An order's ``filled_size`` is always recomputed from the authoritative fills
  table and clamped to ``original_size`` (never overstated -- understating is
  the conservative failure mode for pair matching).
* A fill arriving before its order is known (fill-before-ack) is still recorded
  and produces a conservative ``UNKNOWN`` placeholder order that a later
  placement/reconciliation corrects.
* Terminal states are never downgraded.

The manager depends only on the abstract ``ExecutionPersistence`` repositories
(dependency inversion); it performs no networking and handles no secrets.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, replace
from decimal import Decimal

from polymarket_pair_bot.domain.entities import ExchangeOrder, Fill, OrderIntent
from polymarket_pair_bot.domain.enums import OrderStatus, TimeInForce
from polymarket_pair_bot.domain.value_objects import (
    FeeAmount,
    FillId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.live_models import FillRecord, OrderPlacement
from polymarket_pair_bot.execution.ports import ExecutionPersistence
from polymarket_pair_bot.observability.logging import get_logger

_LOG = get_logger(__name__)
_ZERO = Decimal(0)


@dataclass(frozen=True, slots=True)
class FillApplication:
    """Result of applying a single authoritative fill record."""

    fill: Fill
    is_new: bool
    order: ExchangeOrder | None


class OrderLifecycleManager:
    """Applies authoritative placement, fill and terminal transitions."""

    def __init__(
        self,
        *,
        persistence: ExecutionPersistence,
        now_s: Callable[[], int],
    ) -> None:
        self._repos = persistence
        self._now_s = now_s

    async def record_placement(
        self, intent: OrderIntent, placement: OrderPlacement
    ) -> ExchangeOrder:
        """Persist the exchange response as an order. An ack is never a fill.

        A non-rejected placement is stored as ``ACKNOWLEDGED`` (working) with a
        ``filled_size`` recomputed strictly from authoritative fills already on
        record -- never from the ack's self-reported matched size.
        """
        now = self._now_s()
        if placement.is_rejected or placement.order_id is None:
            order_id = OrderId(placement.order_id or f"rejected-{intent.intent_id}")
            order = ExchangeOrder(
                order_id=order_id,
                intent_id=intent.intent_id,
                token_id=intent.token_id,
                side=intent.side,
                limit_price=intent.limit_price,
                original_size=intent.size,
                filled_size=Shares(_ZERO),
                status=OrderStatus.REJECTED,
                created_at=UnixTimestamp(now),
                updated_at=UnixTimestamp(now),
            )
            await self._repos.orders.upsert(order)
            return order

        order_id = OrderId(placement.order_id)
        filled = await self._sum_fills(order_id, cap=intent.size.value)
        status = OrderStatus.ACKNOWLEDGED
        if filled >= intent.size.value:
            status = OrderStatus.FILLED
        elif filled > _ZERO:
            status = OrderStatus.PARTIALLY_FILLED
        order = ExchangeOrder(
            order_id=order_id,
            intent_id=intent.intent_id,
            token_id=intent.token_id,
            side=intent.side,
            limit_price=intent.limit_price,
            original_size=intent.size,
            filled_size=Shares(filled),
            status=status,
            created_at=UnixTimestamp(now),
            updated_at=UnixTimestamp(now),
        )
        await self._repos.orders.upsert(order)
        return order

    async def process_fill(self, record: FillRecord) -> FillApplication:
        """Apply one authoritative fill record idempotently.

        Duplicate ``fill_id`` deliveries are ignored (no double counting). A
        fill for an unknown order creates a conservative ``UNKNOWN`` placeholder
        so the fill is never lost.
        """
        now = self._now_s()
        filled_at = record.filled_at_s if record.filled_at_s is not None else now
        fill = Fill(
            fill_id=FillId(record.fill_id),
            order_id=OrderId(record.order_id),
            token_id=TokenId(record.token_id),
            side=record.side,
            price=ProbabilityPrice(record.price),
            size=Shares(record.size),
            fee=FeeAmount(record.fee),
            filled_at=UnixTimestamp(filled_at),
        )
        is_new = await self._repos.fills.insert_idempotent(fill)
        if not is_new:
            _LOG.info("order_lifecycle.duplicate_fill", extra={"fill_id": fill.fill_id.value})
            existing = await self._repos.orders.get(fill.order_id)
            return FillApplication(fill=fill, is_new=False, order=existing)

        order = await self._repos.orders.get(fill.order_id)
        if order is None:
            # Fill-before-acknowledgement: record a conservative placeholder.
            order = ExchangeOrder(
                order_id=fill.order_id,
                intent_id=f"unknown:{fill.order_id.value}",
                token_id=fill.token_id,
                side=fill.side,
                limit_price=fill.price,
                original_size=fill.size,
                filled_size=fill.size,
                status=OrderStatus.UNKNOWN,
                created_at=UnixTimestamp(now),
                updated_at=UnixTimestamp(now),
            )
            _LOG.warning(
                "order_lifecycle.fill_before_ack",
                extra={"order_id": fill.order_id.value, "fill_id": fill.fill_id.value},
            )
            await self._repos.orders.upsert(order)
            return FillApplication(fill=fill, is_new=True, order=order)

        total = await self._sum_fills(fill.order_id, cap=order.original_size.value)
        status = order.status
        if not status.is_terminal and status is not OrderStatus.UNKNOWN:
            if total >= order.original_size.value:
                status = OrderStatus.FILLED
            elif total > _ZERO:
                status = OrderStatus.PARTIALLY_FILLED
        updated = replace(
            order,
            filled_size=Shares(total),
            status=status,
            updated_at=UnixTimestamp(max(now, order.created_at.value)),
        )
        await self._repos.orders.upsert(updated)
        return FillApplication(fill=fill, is_new=True, order=updated)

    async def finalize_taker(
        self, order_id: OrderId, *, time_in_force: TimeInForce
    ) -> ExchangeOrder | None:
        """Set the terminal state of a taker (IOC/FOK) order after matching.

        A fully-filled order becomes ``FILLED``; any unfilled remainder is
        killed (``CANCELED``) -- FOK is all-or-none, FAK/IOC keeps the matched
        portion. Already-terminal orders are left unchanged.
        """
        order = await self._repos.orders.get(order_id)
        if order is None or order.status.is_terminal:
            return order
        if order.filled_size.value >= order.original_size.value:
            status = OrderStatus.FILLED
        else:
            status = OrderStatus.CANCELED
        _ = time_in_force  # role already encoded by taker matching
        updated = replace(
            order,
            status=status,
            updated_at=UnixTimestamp(max(self._now_s(), order.created_at.value)),
        )
        await self._repos.orders.upsert(updated)
        return updated

    async def mark_unknown(
        self, *, order_id: OrderId, intent: OrderIntent
    ) -> ExchangeOrder:
        """Persist an ``UNKNOWN`` order for an indeterminate submission.

        Used after a submission timeout: the order may or may not exist on the
        exchange, so it is recorded as ``UNKNOWN`` for the reconciliation
        service to resolve. Never treated as accepted or filled.
        """
        now = self._now_s()
        existing = await self._repos.orders.get(order_id)
        if existing is not None and existing.status.is_terminal:
            return existing
        filled = await self._sum_fills(order_id, cap=intent.size.value)
        order = ExchangeOrder(
            order_id=order_id,
            intent_id=intent.intent_id,
            token_id=intent.token_id,
            side=intent.side,
            limit_price=intent.limit_price,
            original_size=intent.size,
            filled_size=Shares(filled),
            status=OrderStatus.UNKNOWN,
            created_at=UnixTimestamp(now),
            updated_at=UnixTimestamp(now),
        )
        await self._repos.orders.upsert(order)
        return order

    async def _sum_fills(self, order_id: OrderId, *, cap: Decimal) -> Decimal:
        fills = await self._repos.fills.list_for_order(order_id)
        total = sum((fill.size.value for fill in fills), _ZERO)
        return total if total < cap else cap


__all__ = ["FillApplication", "OrderLifecycleManager"]
