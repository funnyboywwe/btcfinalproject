"""Execution adapter port + persistence bundle (Modules 11, 17-18).

Paper and live adapters implement the SAME :class:`ExecutionAdapter` protocol
(a safety requirement), so higher layers depend only on this abstraction and
can swap paper for live without change. The domain repository protocols are
aggregated by :class:`ExecutionPersistence` so an adapter depends only on
abstract ports -- never on SQLAlchemy, asyncpg or any concrete persistence
class (dependency inversion).

The adapter is a low-level execution primitive: it executes intents it is
given and never bypasses the centralized risk engine, which gates intents
upstream (Modules 13 / 22). No submitted, acknowledged, open, or partially
filled order is ever treated as a matched pair.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import ExchangeOrder, Fill, OrderIntent
from polymarket_pair_bot.domain.repositories import (
    ExchangeOrderRepository,
    FillRepository,
    OrderIntentRepository,
)
from polymarket_pair_bot.domain.value_objects import MarketId, OrderId
from polymarket_pair_bot.execution.types import (
    CancelAck,
    CancelBatchAck,
    SubmitAck,
)


@runtime_checkable
class ExecutionPersistence(Protocol):
    """The subset of repositories an execution adapter persists through.

    Backed by the SQLAlchemy unit of work in production, or by in-memory fakes
    in tests. Intents/orders/fills are persisted idempotently so the bot can
    rebuild its position from authoritative records after a restart.
    """

    intents: OrderIntentRepository
    orders: ExchangeOrderRepository
    fills: FillRepository


@runtime_checkable
class ExecutionAdapter(Protocol):
    """Common execution interface implemented by paper and live adapters.

    Every method is asynchronous and cancellation-safe. Implementations must
    never place a real order during tests or normal development, must validate
    inputs, and must treat only a confirmed full fill as complete.
    """

    async def submit_order(self, intent: OrderIntent) -> SubmitAck:
        """Submit an order intent. Idempotent by ``intent.intent_id``."""
        ...

    async def cancel_order(self, order_id: OrderId) -> CancelAck:
        """Request cancellation of a single order (subject to cancel latency)."""
        ...

    async def cancel_market_orders(self, market_id: MarketId) -> CancelBatchAck:
        """Request cancellation of all non-terminal orders for one market."""
        ...

    async def cancel_all_orders(self) -> CancelBatchAck:
        """Request cancellation of every non-terminal order."""
        ...

    async def get_order(self, order_id: OrderId) -> ExchangeOrder | None:
        """Return the current known state of an order, or ``None``."""
        ...

    async def get_open_orders(
        self, market_id: MarketId | None = None
    ) -> tuple[ExchangeOrder, ...]:
        """Return non-terminal orders, optionally filtered by market."""
        ...

    async def get_fills(
        self,
        *,
        order_id: OrderId | None = None,
        market_id: MarketId | None = None,
    ) -> tuple[Fill, ...]:
        """Return confirmed fills, optionally filtered by order or market."""
        ...


__all__ = [
    "ExecutionAdapter",
    "ExecutionPersistence",
]
