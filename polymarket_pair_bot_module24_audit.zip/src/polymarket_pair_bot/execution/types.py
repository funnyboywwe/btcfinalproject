"""Value types, acks and configuration for execution adapters (Module 11).

Pure, side-effect-free datatypes shared by every :class:`ExecutionAdapter`
implementation (paper now; live later). Monetary values are domain value
objects (``Decimal``-backed); *durations* are integer **milliseconds** (a
duration is explicitly not money, so ``int`` ms is fine). No secrets, no I/O,
no networking here.

Nothing in this module asserts the strategy is profitable.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import TYPE_CHECKING, Literal

from polymarket_pair_bot.domain.entities import ExchangeOrder, OrderBookSnapshot
from polymarket_pair_bot.domain.enums import OrderSide, TimeInForce
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    OrderId,
    ProbabilityPrice,
    Shares,
    TokenId,
)

if TYPE_CHECKING:
    from polymarket_pair_bot.config.models import PaperExecutionSettings


class SubmitOutcome(str, Enum):
    """Outcome of a submit attempt.

    ``UNKNOWN`` means the submission result could not be determined (e.g. a
    timed-out acknowledgement). It is NEVER treated as a fill and requires
    reconciliation before any further action.
    """

    ACCEPTED = "accepted"
    REJECTED = "rejected"
    UNKNOWN = "unknown"


class CancelOutcome(str, Enum):
    """Outcome of a cancel request.

    ``SCHEDULED`` reflects cancellation latency: the cancel was accepted but is
    not yet effective, so a fill may still land first (a fill-before-cancel
    race). ``ALREADY_FILLED`` means the order fully filled before the cancel
    took effect.
    """

    SCHEDULED = "scheduled"
    ACCEPTED = "accepted"
    ALREADY_FILLED = "already_filled"
    ALREADY_TERMINAL = "already_terminal"
    UNKNOWN_ORDER = "unknown_order"


def is_taker_tif(tif: TimeInForce) -> bool:
    """IOC/FOK are marketable (taker); GTC/GTD rest passively (post-only maker).

    This is the adapter's fixed mapping from time-in-force to execution role.
    IOC models fill-and-kill (FAK); FOK models all-or-none.
    """
    return tif in (TimeInForce.IOC, TimeInForce.FOK)


@dataclass(frozen=True, slots=True)
class TradeTick:
    """A single executed trade print observed on a token's book.

    A resting passive order is only ever filled by *trade volume* through its
    price (after its queue is consumed) -- never merely because a displayed
    quote touched it. ``aggressor`` is the taker side of the print.
    """

    trade_id: str
    token_id: TokenId
    price: ProbabilityPrice
    size: Shares
    aggressor: OrderSide

    def __post_init__(self) -> None:
        if not self.trade_id.strip():
            raise ValueError("trade_id must not be empty")
        self.size.require_positive()


@dataclass(frozen=True, slots=True)
class MarketEvent:
    """One deterministic market event fed to a paper adapter.

    Fields:
        event_id: unique id used to de-duplicate duplicate event delivery.
        token_id: the token this event pertains to.
        timestamp_ms: simulated wall-clock in integer milliseconds (monotonic).
        snapshot: the full L2 book after this event, or ``None`` during a feed
            outage (no authoritative book).
        trades: trade prints that occurred at/for this event (may be empty).
        feed_live: ``False`` models a WebSocket outage / non-live feed; the
            book is then treated as unavailable (fail closed).
    """

    event_id: str
    token_id: TokenId
    timestamp_ms: int
    snapshot: OrderBookSnapshot | None = None
    trades: tuple[TradeTick, ...] = ()
    feed_live: bool = True

    def __post_init__(self) -> None:
        if not self.event_id.strip():
            raise ValueError("event_id must not be empty")
        if isinstance(self.timestamp_ms, bool) or not isinstance(self.timestamp_ms, int):
            raise TypeError("timestamp_ms must be an int number of milliseconds")
        if self.timestamp_ms < 0:
            raise ValueError("timestamp_ms must be non-negative")
        object.__setattr__(self, "trades", tuple(self.trades))
        if self.snapshot is not None and self.snapshot.token_id != self.token_id:
            raise ValueError("snapshot token_id must match event token_id")
        for trade in self.trades:
            if trade.token_id != self.token_id:
                raise ValueError("trade token_id must match event token_id")


@dataclass(frozen=True, slots=True)
class LatencyDistribution:
    """A deterministic latency model in integer milliseconds.

    Draws are made from an injected seeded ``random.Random`` so runs are
    reproducible. ``constant`` always returns ``min_ms``; ``uniform`` draws an
    inclusive integer in ``[min_ms, max_ms]``.
    """

    kind: Literal["constant", "uniform"]
    min_ms: int
    max_ms: int

    def __post_init__(self) -> None:
        if self.kind not in ("constant", "uniform"):
            raise ValueError("latency kind must be 'constant' or 'uniform'")
        if self.min_ms < 0 or self.max_ms < 0:
            raise ValueError("latency bounds must be non-negative")
        if self.max_ms < self.min_ms:
            raise ValueError("max_ms must be >= min_ms")

    @classmethod
    def constant(cls, ms: int) -> LatencyDistribution:
        return cls(kind="constant", min_ms=ms, max_ms=ms)

    @classmethod
    def uniform(cls, min_ms: int, max_ms: int) -> LatencyDistribution:
        return cls(kind="uniform", min_ms=min_ms, max_ms=max_ms)

    def draw(self, rng: random.Random) -> int:
        if self.kind == "constant" or self.min_ms == self.max_ms:
            return self.min_ms
        return rng.randint(self.min_ms, self.max_ms)


@dataclass(frozen=True, slots=True)
class PaperExecutionConfig:
    """Knobs for the paper execution simulator.

    Monetary rates are ``Decimal``-backed value objects; probabilities are
    ``Decimal`` in ``[0, 1]`` (never binary floats); durations are integer ms.
    A single ``seed`` makes every random draw (latency, unknown-outcome and
    missed-fill gates) reproducible.
    """

    seed: int = 0
    taker_fee_bps: BasisPoints = field(default_factory=lambda: BasisPoints(Decimal(0)))
    maker_fee_bps: BasisPoints = field(default_factory=lambda: BasisPoints(Decimal(0)))
    expected_slippage_bps: BasisPoints = field(
        default_factory=lambda: BasisPoints(Decimal(0))
    )
    ack_latency: LatencyDistribution = field(
        default_factory=lambda: LatencyDistribution.constant(50)
    )
    cancel_latency: LatencyDistribution = field(
        default_factory=lambda: LatencyDistribution.constant(50)
    )
    min_order_size: Shares = field(default_factory=lambda: Shares(Decimal("1")))
    stale_after_ms: int = 5_000
    gtd_ttl_ms: int = 60_000
    unknown_submission_probability: Decimal = Decimal(0)
    maker_fill_probability: Decimal = Decimal(1)

    def __post_init__(self) -> None:
        if self.stale_after_ms <= 0:
            raise ValueError("stale_after_ms must be positive")
        if self.gtd_ttl_ms <= 0:
            raise ValueError("gtd_ttl_ms must be positive")
        if not (Decimal(0) <= self.unknown_submission_probability <= Decimal(1)):
            raise ValueError("unknown_submission_probability must be in [0, 1]")
        if not (Decimal(0) <= self.maker_fill_probability <= Decimal(1)):
            raise ValueError("maker_fill_probability must be in [0, 1]")
        self.min_order_size.require_positive()

    @classmethod
    def from_settings(
        cls, settings: PaperExecutionSettings, *, seed: int = 0
    ) -> PaperExecutionConfig:
        """Build from validated ``PaperExecutionSettings`` (pydantic-settings).

        Only durations/rates cross over; no secret ever appears here.
        """
        return cls(
            seed=seed,
            taker_fee_bps=BasisPoints(settings.paper_taker_fee_bps),
            expected_slippage_bps=BasisPoints(settings.paper_expected_slippage_bps),
            ack_latency=LatencyDistribution.constant(settings.paper_latency_ms),
            cancel_latency=LatencyDistribution.constant(settings.paper_latency_ms),
            maker_fill_probability=settings.paper_fill_probability,
        )


@dataclass(frozen=True, slots=True)
class SubmitAck:
    """Immutable result of :meth:`ExecutionAdapter.submit_order`."""

    intent_id: str
    outcome: SubmitOutcome
    order: ExchangeOrder
    reason: str | None = None

    @property
    def accepted(self) -> bool:
        return self.outcome is SubmitOutcome.ACCEPTED


@dataclass(frozen=True, slots=True)
class CancelAck:
    """Immutable result of a single cancel request."""

    order_id: OrderId
    outcome: CancelOutcome
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class CancelBatchAck:
    """Immutable result of a bulk cancel request."""

    acks: tuple[CancelAck, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "acks", tuple(self.acks))

    @property
    def scheduled_count(self) -> int:
        return sum(1 for ack in self.acks if ack.outcome is CancelOutcome.SCHEDULED)


__all__ = [
    "CancelAck",
    "CancelBatchAck",
    "CancelOutcome",
    "LatencyDistribution",
    "MarketEvent",
    "PaperExecutionConfig",
    "SubmitAck",
    "SubmitOutcome",
    "TradeTick",
    "is_taker_tif",
]
