"""Exchange error classification and typed live-execution errors (Module 14).

The official Polymarket CLOB Python package is isolated behind an adapter port
(:mod:`polymarket_pair_bot.execution.live_ports`). Because its exact exception
types and error payloads cannot be verified offline, this module never inspects
package-specific exception classes directly. Instead the (blocked) concrete
client maps whatever it receives into the secret-free structures defined here.

Nothing in this module performs I/O, imports infrastructure, or logs secrets.
Error messages are treated as UNTRUSTED external text and are never assumed to
be secret-free by callers; the redaction layer is still applied before logging.
"""

from __future__ import annotations

from enum import Enum


class ExchangeErrorClass(str, Enum):
    """Coarse, provider-independent classification of an exchange failure.

    The classification drives *only* conservative control-flow decisions:
    whether a submission may be retried (idempotently), whether the request was
    definitively rejected, or whether the outcome is uncertain and therefore
    requires reconciliation. When in doubt we classify as ``UNKNOWN`` and fail
    closed (reconcile, never blindly retry).
    """

    # Transient/infrastructure problem; a bounded idempotent retry is safe.
    RETRYABLE = "retryable"
    # Explicit throttling; a bounded idempotent retry (with backoff) is safe.
    RATE_LIMITED = "rate_limited"
    # Deterministic client-side problem (bad tick, size, args); never retry.
    INVALID_REQUEST = "invalid_request"
    # Not enough collateral/allowance; never retry without operator action.
    INSUFFICIENT_FUNDS = "insufficient_funds"
    # Authentication/authorization failure; never retry automatically.
    AUTH = "auth"
    # A post-only order would have crossed the book and was rejected; the
    # order did NOT rest and was NOT filled. Safe to treat as a clean reject.
    POST_ONLY_WOULD_CROSS = "post_only_would_cross"
    # Referenced order/market does not exist (e.g. cancel of an unknown id).
    NOT_FOUND = "not_found"
    # Outcome uncertain. Requires reconciliation; must never be blindly retried.
    UNKNOWN = "unknown"

    @property
    def is_retryable(self) -> bool:
        """True only for transient classes where an idempotent retry is safe."""
        return self in (ExchangeErrorClass.RETRYABLE, ExchangeErrorClass.RATE_LIMITED)

    @property
    def is_clean_reject(self) -> bool:
        """True when the order definitively did not rest and did not fill."""
        return self in (
            ExchangeErrorClass.INVALID_REQUEST,
            ExchangeErrorClass.INSUFFICIENT_FUNDS,
            ExchangeErrorClass.AUTH,
            ExchangeErrorClass.POST_ONLY_WOULD_CROSS,
            ExchangeErrorClass.NOT_FOUND,
        )


class LiveExecutionError(RuntimeError):
    """Base class for all live-execution errors raised by this module."""


class UnsupportedLiveOperationError(LiveExecutionError):
    """Raised when a live operation cannot be verified against the package.

    Mirrors the auth module's blocked-adapter pattern: rather than guessing an
    unverified API shape, the concrete client raises this with a clear,
    secret-free explanation. Callers should treat it as fail-closed.
    """

    def __init__(self, operation: str, detail: str = "") -> None:
        self.operation = operation
        self.detail = detail
        message = f"unsupported live execution operation: {operation}"
        if detail:
            message = f"{message} ({detail})"
        super().__init__(message)


class SubmissionTimeoutError(LiveExecutionError):
    """Raised internally when an order submission exceeds its deadline.

    A timeout means the outcome is UNKNOWN: the order may or may not have been
    accepted. It must trigger reconciliation and must never be blindly retried.
    """

    def __init__(self, intent_id: str, timeout_seconds: float) -> None:
        self.intent_id = intent_id
        self.timeout_seconds = timeout_seconds
        super().__init__(
            f"submission for intent {intent_id} exceeded "
            f"{timeout_seconds:g}s deadline; outcome unknown"
        )


class ExchangeRejectedError(LiveExecutionError):
    """A classified rejection returned by the exchange adapter.

    ``message`` is untrusted external text; it is never assumed secret-free and
    is redacted before logging by the observability layer.
    """

    def __init__(
        self,
        error_class: ExchangeErrorClass,
        *,
        code: str | None = None,
        message: str = "",
    ) -> None:
        self.error_class = error_class
        self.code = code
        self.message = message
        super().__init__(f"exchange rejected order [{error_class.value}] code={code}")


# --------------------------------------------------------------------------- #
# Classification
# --------------------------------------------------------------------------- #
_CODE_MAP: dict[str, ExchangeErrorClass] = {
    "rate_limited": ExchangeErrorClass.RATE_LIMITED,
    "too_many_requests": ExchangeErrorClass.RATE_LIMITED,
    "429": ExchangeErrorClass.RATE_LIMITED,
    "timeout": ExchangeErrorClass.RETRYABLE,
    "temporarily_unavailable": ExchangeErrorClass.RETRYABLE,
    "service_unavailable": ExchangeErrorClass.RETRYABLE,
    "503": ExchangeErrorClass.RETRYABLE,
    "502": ExchangeErrorClass.RETRYABLE,
    "500": ExchangeErrorClass.RETRYABLE,
    "invalid": ExchangeErrorClass.INVALID_REQUEST,
    "invalid_order": ExchangeErrorClass.INVALID_REQUEST,
    "invalid_tick": ExchangeErrorClass.INVALID_REQUEST,
    "bad_request": ExchangeErrorClass.INVALID_REQUEST,
    "400": ExchangeErrorClass.INVALID_REQUEST,
    "422": ExchangeErrorClass.INVALID_REQUEST,
    "insufficient_balance": ExchangeErrorClass.INSUFFICIENT_FUNDS,
    "insufficient_funds": ExchangeErrorClass.INSUFFICIENT_FUNDS,
    "insufficient_allowance": ExchangeErrorClass.INSUFFICIENT_FUNDS,
    "unauthorized": ExchangeErrorClass.AUTH,
    "forbidden": ExchangeErrorClass.AUTH,
    "401": ExchangeErrorClass.AUTH,
    "403": ExchangeErrorClass.AUTH,
    "post_only": ExchangeErrorClass.POST_ONLY_WOULD_CROSS,
    "would_cross": ExchangeErrorClass.POST_ONLY_WOULD_CROSS,
    "marketable_post_only": ExchangeErrorClass.POST_ONLY_WOULD_CROSS,
    "not_found": ExchangeErrorClass.NOT_FOUND,
    "order_not_found": ExchangeErrorClass.NOT_FOUND,
    "404": ExchangeErrorClass.NOT_FOUND,
}

_MESSAGE_KEYWORDS: tuple[tuple[str, ExchangeErrorClass], ...] = (
    ("rate limit", ExchangeErrorClass.RATE_LIMITED),
    ("too many requests", ExchangeErrorClass.RATE_LIMITED),
    ("timed out", ExchangeErrorClass.RETRYABLE),
    ("timeout", ExchangeErrorClass.RETRYABLE),
    ("temporarily unavailable", ExchangeErrorClass.RETRYABLE),
    ("service unavailable", ExchangeErrorClass.RETRYABLE),
    ("insufficient", ExchangeErrorClass.INSUFFICIENT_FUNDS),
    ("allowance", ExchangeErrorClass.INSUFFICIENT_FUNDS),
    ("unauthorized", ExchangeErrorClass.AUTH),
    ("forbidden", ExchangeErrorClass.AUTH),
    ("post only", ExchangeErrorClass.POST_ONLY_WOULD_CROSS),
    ("post-only", ExchangeErrorClass.POST_ONLY_WOULD_CROSS),
    ("would cross", ExchangeErrorClass.POST_ONLY_WOULD_CROSS),
    ("not found", ExchangeErrorClass.NOT_FOUND),
    ("invalid", ExchangeErrorClass.INVALID_REQUEST),
)


def classify_exchange_error(
    *, code: str | None = None, message: str = ""
) -> ExchangeErrorClass:
    """Classify an exchange failure from an optional code and message.

    Deterministic and conservative: an unrecognised failure is ``UNKNOWN`` so
    the caller reconciles rather than assuming success or blindly retrying.
    Matching is case-insensitive and never raises.
    """
    if code is not None:
        normalized = code.strip().lower()
        mapped = _CODE_MAP.get(normalized)
        if mapped is not None:
            return mapped
    text = message.strip().lower()
    if text:
        for keyword, error_class in _MESSAGE_KEYWORDS:
            if keyword in text:
                return error_class
    return ExchangeErrorClass.UNKNOWN


__all__ = [
    "ExchangeErrorClass",
    "ExchangeRejectedError",
    "LiveExecutionError",
    "SubmissionTimeoutError",
    "UnsupportedLiveOperationError",
    "classify_exchange_error",
]
