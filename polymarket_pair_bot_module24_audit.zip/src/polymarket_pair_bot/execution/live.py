"""Live-capable execution adapter (Module 14).

:class:`LiveExecutionAdapter` implements the SAME ``ExecutionAdapter`` protocol
as the paper adapter, so higher layers swap paper for live without change. It
is the guarded path to a real exchange and enforces, in order:

1. a risk decision is fetched for the intent (centralized risk engine);
2. the live submission gate authorizes (LIVE_TRADING on, PAPER_TRADING off,
   execution leadership, healthy feeds, recent consistent reconciliation, kill
   switch clear, risk approval);
3. tick-size, quantity, notional, collateral and allowance validation;
4. the ``OrderIntent`` is persisted BEFORE submission;
5. a unique idempotency key is claimed (first-writer-wins) -- an already-claimed
   key is never blindly resubmitted; it triggers reconciliation instead;
6. the order is signed and submitted THROUGH the injected client (the adapter
   never touches key material);
7. the response is persisted; an acknowledgement is never treated as a fill;
8. a submission timeout marks the order ``UNKNOWN`` and reconciles.

Cancellation is deliberately NOT gated by the submission gate: resting orders
must remain cancellable even while the kill switch is on. The adapter depends
only on abstract ports (dependency inversion) and never places a real order in
tests or development -- wrap the client with ``DryRunOrderClient`` to guarantee
no real write endpoint is reached.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, replace
from decimal import Decimal, localcontext

from polymarket_pair_bot.config.models import LiveExecutionSettings
from polymarket_pair_bot.domain.coordination import IdempotencyStore
from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    ExchangeOrder,
    Fill,
    OrderIntent,
)
from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus
from polymarket_pair_bot.domain.precision import computation_context
from polymarket_pair_bot.domain.value_objects import (
    MarketId,
    OrderId,
    Shares,
    TickSize,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.errors import (
    ExchangeErrorClass,
    ExchangeRejectedError,
    LiveExecutionError,
    SubmissionTimeoutError,
    UnsupportedLiveOperationError,
)
from polymarket_pair_bot.execution.lifecycle import FillApplication, OrderLifecycleManager
from polymarket_pair_bot.execution.live_models import (
    CancelResult,
    FillRecord,
    OrderPlacement,
    OrderStateView,
)
from polymarket_pair_bot.execution.live_ports import (
    CollateralAllowanceProvider,
    LiveOrderClient,
    LiveOrderRequest,
    RiskDecisionProvider,
)
from polymarket_pair_bot.execution.ports import ExecutionPersistence
from polymarket_pair_bot.execution.submission_gate import LiveSubmissionGate
from polymarket_pair_bot.execution.types import (
    CancelAck,
    CancelBatchAck,
    CancelOutcome,
    SubmitAck,
    SubmitOutcome,
    is_taker_tif,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOG = get_logger(__name__)
_ZERO = Decimal(0)


@dataclass(frozen=True, slots=True)
class _TokenReg:
    market_id: MarketId
    tick: TickSize


@dataclass(frozen=True, slots=True)
class ReplaceResult:
    """Result of a reserve-aware cancel-and-replace.

    ``replacement`` is ``None`` when the replacement was intentionally withheld
    (the old order's reserve could not be confirmed freed, or it filled during
    the cancel), so collateral is never double-reserved.
    """

    cancel: CancelAck
    replacement: SubmitAck | None
    reason: str | None = None

    @property
    def replaced(self) -> bool:
        return self.replacement is not None and self.replacement.accepted


class LiveExecutionAdapter:
    """Guarded live implementation of ``ExecutionAdapter``."""

    def __init__(
        self,
        *,
        client: LiveOrderClient,
        persistence: ExecutionPersistence,
        submission_gate: LiveSubmissionGate,
        lifecycle: OrderLifecycleManager,
        allowance_provider: CollateralAllowanceProvider,
        risk_provider: RiskDecisionProvider,
        settings: LiveExecutionSettings,
        idempotency_store: IdempotencyStore,
        idempotency_ttl_seconds: int,
        now_s: Callable[[], int],
    ) -> None:
        self._client = client
        self._repos = persistence
        self._gate = submission_gate
        self._lifecycle = lifecycle
        self._allowance = allowance_provider
        self._risk = risk_provider
        self._settings = settings
        self._idempotency = idempotency_store
        self._idempotency_ttl = idempotency_ttl_seconds
        self._now_s = now_s
        self._tokens: dict[str, _TokenReg] = {}
        self._markets: dict[str, MarketId] = {}
        self._known_orders: dict[str, str] = {}  # order_id -> token_id

    # ------------------------------------------------------------------ #
    # Setup
    # ------------------------------------------------------------------ #
    def register_market(self, market: BinaryMarket) -> None:
        """Register a market's Up/Down tokens for validation and querying."""
        self._markets[market.market_id.value] = market.market_id
        for token in (market.up_token, market.down_token):
            self._tokens[token.token_id.value] = _TokenReg(
                market_id=market.market_id, tick=token.tick_size
            )

    # ------------------------------------------------------------------ #
    # Submit
    # ------------------------------------------------------------------ #
    async def submit_order(self, intent: OrderIntent) -> SubmitAck:
        now = self._now_s()
        reg = self._tokens.get(intent.token_id.value)
        if reg is None:
            return self._synthetic_reject(intent, now, "unknown_token")

        # (1) risk decision + (2) submission gate.
        risk_decision = await self._risk.decision_for(intent)
        gate = await self._gate.authorize(now_s=now, risk_decision=risk_decision)
        if not gate.allowed:
            await self._repos.intents.add(intent)  # audit the blocked attempt
            return self._synthetic_reject(intent, now, gate.reason_summary())

        # (3) validation.
        invalid = await self._validate(intent, reg)
        if invalid is not None:
            await self._repos.intents.add(intent)
            return self._synthetic_reject(intent, now, invalid)

        # (4) persist intent BEFORE submission.
        await self._repos.intents.add(intent)

        # (5) unique idempotency key; never blindly resubmit a claimed key.
        key = f"submit:{intent.intent_id}"
        claimed = await self._idempotency.claim(key, ttl_seconds=self._idempotency_ttl)
        if not claimed:
            _LOG.warning("live_submit.idempotency_replay", extra={"key": key})
            order = await self._reconcile_timeout(intent, reg)
            return SubmitAck(
                intent.intent_id,
                SubmitOutcome.UNKNOWN,
                order,
                "idempotency key already claimed; reconciled instead of resubmitting",
            )

        # (6) sign + submit through the client; (7)/(8) persist + reconcile.
        request = LiveOrderRequest(
            intent=intent,
            idempotency_key=key,
            post_only=not is_taker_tif(intent.time_in_force),
        )
        return await self._submit_request(intent, reg, request)

    async def _submit_request(
        self, intent: OrderIntent, reg: _TokenReg, request: LiveOrderRequest
    ) -> SubmitAck:
        try:
            placement = await self._place_with_retries(intent, request)
        except SubmissionTimeoutError as exc:
            _LOG.error("live_submit.timeout", extra={"intent_id": intent.intent_id})
            order = await self._reconcile_timeout(intent, reg)
            return SubmitAck(intent.intent_id, SubmitOutcome.UNKNOWN, order, str(exc))
        except UnsupportedLiveOperationError as exc:
            # Blocked client: fail closed, nothing was placed.
            _LOG.error("live_submit.unsupported", extra={"operation": exc.operation})
            return self._synthetic_reject(intent, self._now_s(), str(exc))
        except ExchangeRejectedError as exc:
            return await self._handle_rejection(intent, exc)

        order = await self._lifecycle.record_placement(intent, placement)
        self._known_orders[order.order_id.value] = intent.token_id.value
        if placement.is_rejected:
            return SubmitAck(
                intent.intent_id, SubmitOutcome.REJECTED, order, placement.error_message
            )

        # Taker orders match immediately: pull authoritative fills, then finalize.
        if is_taker_tif(intent.time_in_force):
            await self._ingest_order_fills(order.order_id)
            finalized = await self._lifecycle.finalize_taker(
                order.order_id, time_in_force=intent.time_in_force
            )
            if finalized is not None:
                order = finalized
        return SubmitAck(intent.intent_id, SubmitOutcome.ACCEPTED, order)

    async def _place_with_retries(
        self, intent: OrderIntent, request: LiveOrderRequest
    ) -> OrderPlacement:
        """Submit with a submission-timeout and bounded, idempotent retries.

        A timeout is NEVER retried (outcome unknown -> reconcile). Only
        transient classified rejections are retried, reusing the same
        idempotency key so the exchange de-duplicates a possible prior receipt.
        """
        attempts = 0
        timeout = self._settings.live_submit_timeout_seconds
        while True:
            try:
                return await asyncio.wait_for(
                    self._client.place_order(request), timeout=timeout
                )
            except (asyncio.TimeoutError, TimeoutError) as exc:
                raise SubmissionTimeoutError(intent.intent_id, timeout) from exc
            except ExchangeRejectedError as exc:
                if (
                    exc.error_class.is_retryable
                    and attempts < self._settings.live_max_submit_retries
                ):
                    attempts += 1
                    _LOG.warning(
                        "live_submit.retry",
                        extra={"attempt": attempts, "error_class": exc.error_class.value},
                    )
                    await asyncio.sleep(self._settings.live_order_poll_interval_seconds)
                    continue
                raise

    async def _handle_rejection(
        self, intent: OrderIntent, exc: ExchangeRejectedError
    ) -> SubmitAck:
        if exc.error_class is ExchangeErrorClass.UNKNOWN:
            # Uncertain outcome: reconcile, never assume rejected or accepted.
            reg = self._tokens[intent.token_id.value]
            order = await self._reconcile_timeout(intent, reg)
            return SubmitAck(
                intent.intent_id,
                SubmitOutcome.UNKNOWN,
                order,
                f"exchange error [{exc.error_class.value}]; reconciled",
            )
        # Clean, definitive rejection: the order did not rest and did not fill.
        placement = OrderPlacement(
            order_id=None,
            status=OrderStatus.REJECTED,
            error_code=exc.code,
            error_message=f"[{exc.error_class.value}]",
        )
        order = await self._lifecycle.record_placement(intent, placement)
        return SubmitAck(
            intent.intent_id, SubmitOutcome.REJECTED, order, f"[{exc.error_class.value}]"
        )

    # ------------------------------------------------------------------ #
    # Cancel (never gated by the kill switch)
    # ------------------------------------------------------------------ #
    async def cancel_order(self, order_id: OrderId) -> CancelAck:
        try:
            result = await self._client.cancel_order(order_id.value)
        except ExchangeRejectedError as exc:
            if exc.error_class is ExchangeErrorClass.NOT_FOUND:
                return CancelAck(order_id, CancelOutcome.UNKNOWN_ORDER, "not_found")
            raise
        await self._apply_cancel_result(result)
        return CancelAck(OrderId(result.order_id), result.outcome, result.reason)

    async def cancel_market_orders(self, market_id: MarketId) -> CancelBatchAck:
        results = await self._client.cancel_market_orders(market_id.value)
        acks = [await self._ack_from_result(r) for r in results]
        return CancelBatchAck(tuple(acks))

    async def cancel_all_orders(self) -> CancelBatchAck:
        results = await self._client.cancel_all_orders()
        acks = [await self._ack_from_result(r) for r in results]
        return CancelBatchAck(tuple(acks))

    async def cancel_and_replace(
        self, existing_order_id: OrderId, new_intent: OrderIntent
    ) -> ReplaceResult:
        """Cancel an order and place a replacement only after the reserve frees.

        Reserve-aware: the replacement is submitted only once the existing order
        is confirmed terminal with no fills, so collateral is never reserved for
        both orders at once. If the existing order (partially) filled during the
        cancel, or its terminal state cannot be confirmed, the replacement is
        withheld and reconciliation is left to resolve the state.
        """
        cancel_ack = await self.cancel_order(existing_order_id)
        terminal = await self._await_terminal(existing_order_id)
        if terminal is None:
            return ReplaceResult(
                cancel_ack,
                None,
                "cancel outcome unconfirmed; replacement withheld (reserve not freed)",
            )
        if terminal.status is OrderStatus.FILLED or terminal.filled_size > _ZERO:
            return ReplaceResult(
                cancel_ack,
                None,
                "existing order (partially) filled during cancel; replacement withheld",
            )
        replacement = await self.submit_order(new_intent)
        return ReplaceResult(cancel_ack, replacement)

    # ------------------------------------------------------------------ #
    # Authoritative fill ingestion (user stream / reconciliation entrypoint)
    # ------------------------------------------------------------------ #
    async def process_fill_event(self, record: FillRecord) -> FillApplication:
        """Apply an authoritative fill from the user stream or a query."""
        self._known_orders.setdefault(record.order_id, record.token_id)
        return await self._lifecycle.process_fill(record)

    # ------------------------------------------------------------------ #
    # Queries (rebuilt from authoritative persisted records)
    # ------------------------------------------------------------------ #
    async def get_order(self, order_id: OrderId) -> ExchangeOrder | None:
        return await self._repos.orders.get(order_id)

    async def get_open_orders(
        self, market_id: MarketId | None = None
    ) -> tuple[ExchangeOrder, ...]:
        if market_id is not None:
            return tuple(await self._repos.orders.list_open(market_id))
        result: list[ExchangeOrder] = []
        for mid in self._markets.values():
            result.extend(await self._repos.orders.list_open(mid))
        return tuple(result)

    async def get_fills(
        self,
        *,
        order_id: OrderId | None = None,
        market_id: MarketId | None = None,
    ) -> tuple[Fill, ...]:
        if order_id is not None:
            return tuple(await self._repos.fills.list_for_order(order_id))
        result: list[Fill] = []
        for oid, token_id in self._known_orders.items():
            if market_id is not None:
                reg = self._tokens.get(token_id)
                if reg is None or reg.market_id.value != market_id.value:
                    continue
            result.extend(await self._repos.fills.list_for_order(OrderId(oid)))
        return tuple(result)

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    def _synthetic_reject(
        self, intent: OrderIntent, now: int, reason: str
    ) -> SubmitAck:
        """Build a non-persisted REJECTED ack (no order was placed)."""
        order = ExchangeOrder(
            order_id=OrderId(f"blocked-{intent.intent_id}"),
            intent_id=intent.intent_id,
            token_id=intent.token_id,
            side=intent.side,
            limit_price=intent.limit_price,
            original_size=intent.size,
            filled_size=Shares(_ZERO),
            status=OrderStatus.REJECTED,
            created_at=UnixTimestamp(now),
            updated_at=UnixTimestamp(now),
        )
        return SubmitAck(intent.intent_id, SubmitOutcome.REJECTED, order, reason)

    async def _validate(self, intent: OrderIntent, reg: _TokenReg) -> str | None:
        """Return a rejection reason, or ``None`` when the intent is valid."""
        tick = reg.tick.value
        with localcontext(computation_context()):
            steps = intent.limit_price.value / tick
            if steps != steps.to_integral_value():
                return "tick_size_misaligned"
        if intent.size.value <= _ZERO:
            return "non_positive_size"
        with localcontext(computation_context()):
            notional = intent.limit_price.value * intent.size.value
        if notional > self._settings.live_max_order_notional_usd:
            return "exceeds_max_order_notional"
        if intent.side is OrderSide.BUY:
            collateral = await self._allowance.available_collateral()
            allowance = await self._allowance.spender_allowance()
            if collateral is None or allowance is None:
                return "collateral_or_allowance_unverified"
            if notional > collateral.value:
                return "insufficient_collateral"
            if notional > allowance.value:
                return "insufficient_allowance"
        return None

    async def _ingest_order_fills(self, order_id: OrderId) -> None:
        try:
            fills = await self._client.get_fills(order_id=order_id.value)
        except LiveExecutionError:
            _LOG.error(
                "live_submit.fill_query_failed", extra={"order_id": order_id.value}
            )
            return
        for record in fills:
            await self._lifecycle.process_fill(record)

    async def _reconcile_timeout(
        self, intent: OrderIntent, reg: _TokenReg
    ) -> ExchangeOrder:
        """Query authoritative sources and record an UNKNOWN order (no resubmit).

        Full order-to-intent correlation is the reconciliation service's job
        (Module 19); here we conservatively ingest any fills for already-known
        orders and persist an ``UNKNOWN`` order so the state is never lost.
        """
        try:
            await self._client.get_open_orders(market_id=reg.market_id.value)
            fills = await self._client.get_fills(market_id=reg.market_id.value)
        except LiveExecutionError:
            fills = ()
        for record in fills:
            if record.order_id in self._known_orders:
                await self._lifecycle.process_fill(record)
        order = await self._lifecycle.mark_unknown(
            order_id=OrderId(f"unknown-{intent.intent_id}"), intent=intent
        )
        self._known_orders[order.order_id.value] = intent.token_id.value
        return order

    async def _await_terminal(self, order_id: OrderId) -> OrderStateView | None:
        """Poll the client until the order is authoritatively terminal.

        Returns the exchange-reported :class:`OrderStateView` once terminal, or
        ``None`` on timeout (outcome unconfirmed). The reserve-freed decision in
        ``cancel_and_replace`` is based on this authoritative view, not on local
        persistence, which may not track an order that was placed out-of-band.
        """
        deadline = self._settings.live_submit_timeout_seconds
        interval = self._settings.live_order_poll_interval_seconds
        waited = 0.0
        while waited <= deadline:
            try:
                state = await self._client.get_order(order_id.value)
            except LiveExecutionError:
                return None
            if state is not None and state.status.is_terminal:
                await self._mirror_terminal_state(order_id, state)
                return state
            if interval <= 0:
                break
            await asyncio.sleep(interval)
            waited += interval
        return None

    async def _mirror_terminal_state(
        self, order_id: OrderId, state: OrderStateView
    ) -> None:
        """Reflect an authoritative terminal state onto a local order, if any."""
        existing = await self._repos.orders.get(order_id)
        if existing is None or existing.status.is_terminal:
            return
        updated = replace(
            existing,
            status=state.status,
            filled_size=Shares(state.filled_size),
            updated_at=UnixTimestamp(max(self._now_s(), existing.created_at.value)),
        )
        await self._repos.orders.upsert(updated)

    async def _apply_cancel_result(self, result: CancelResult) -> None:
        if result.outcome is not CancelOutcome.ACCEPTED:
            return
        order = await self._repos.orders.get(OrderId(result.order_id))
        if order is None or order.status.is_terminal:
            return
        updated = replace(
            order,
            status=OrderStatus.CANCELED,
            updated_at=UnixTimestamp(max(self._now_s(), order.created_at.value)),
        )
        await self._repos.orders.upsert(updated)

    async def _ack_from_result(self, result: CancelResult) -> CancelAck:
        await self._apply_cancel_result(result)
        return CancelAck(OrderId(result.order_id), result.outcome, result.reason)


__all__ = ["LiveExecutionAdapter", "ReplaceResult"]
