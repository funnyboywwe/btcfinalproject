"""Deterministic paper execution simulator (Module 11).

Implements :class:`ExecutionAdapter` entirely in-process: no networking, no
real orders, no secrets. It is driven by a virtual millisecond clock and a
stream of :class:`MarketEvent` (recorded books + trade prints), so runs are
fully reproducible given a seed. It persists simulated intents, orders and
fills through the injected :class:`ExecutionPersistence` repositories.

Modeled effects: post-only crossing rejection, maker queue position, partial
fills, acknowledgement/cancellation latency, fill-before-cancel races,
multi-level taker execution, FOK all-or-none, FAK(IOC) partial execution,
tick-size and minimum-size rejection, fees, slippage, stale-book rejection,
feed outage, missed fills on fast moves, duplicate event delivery, and unknown
submission outcomes.

A resting passive order is NEVER filled just because a displayed quote touched
its price -- only real trade volume through the price (after its queue is
consumed) fills it. No submitted/acknowledged/open/partially-filled order is
ever treated as a matched pair. This module makes NO profitability claim.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from decimal import ROUND_FLOOR, Decimal, localcontext

from polymarket_pair_bot.domain.arithmetic import taker_fee
from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    ExchangeOrder,
    Fill,
    OrderBookSnapshot,
    OrderIntent,
)
from polymarket_pair_bot.domain.enums import (
    OrderSide,
    OrderStatus,
    OutcomeSide,
    TimeInForce,
)
from polymarket_pair_bot.domain.precision import (
    computation_context,
    round_down_to_tick,
    round_shares,
    round_up_to_tick,
)
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.ports import ExecutionPersistence
from polymarket_pair_bot.execution.types import (
    CancelAck,
    CancelBatchAck,
    CancelOutcome,
    MarketEvent,
    PaperExecutionConfig,
    SubmitAck,
    SubmitOutcome,
    is_taker_tif,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOG = get_logger(__name__)

_ZERO = Decimal(0)
_ONE = Decimal(1)
_PROB_SCALE = Decimal(1_000_000)


@dataclass(frozen=True, slots=True)
class _TokenReg:
    """Static per-token registration (market, side, tick size)."""

    market_id: MarketId
    side: OutcomeSide
    tick: TickSize


@dataclass(slots=True)
class _BookState:
    """Latest known book for one token plus its freshness bookkeeping."""

    snapshot: OrderBookSnapshot | None = None
    last_update_ms: int = -1
    live: bool = False


@dataclass(slots=True)
class _PaperOrder:
    """Mutable internal order bookkeeping (never exposed directly).

    The immutable :class:`ExchangeOrder` snapshot is produced by :meth:`entity`.
    ``queue_ahead`` is the resting size ahead of us at our price when we joined
    the book; only trade volume decrements it (never mere quote changes).
    """

    order_id: OrderId
    intent: OrderIntent
    market_id: MarketId
    token_id: TokenId
    side: OrderSide
    tif: TimeInForce
    limit_price: ProbabilityPrice
    original: Decimal
    created_ms: int
    active_ms: int
    is_taker: bool
    filled: Decimal = _ZERO
    fee_paid: Decimal = _ZERO
    status: OrderStatus = OrderStatus.PENDING_SUBMIT
    queue_ahead: Decimal = _ZERO
    cancel_effective_ms: int | None = None
    expiry_ms: int | None = None
    unknown: bool = False
    fill_seq: int = 0
    updated_ms: int = 0

    @property
    def remaining(self) -> Decimal:
        return self.original - self.filled

    def entity(self) -> ExchangeOrder:
        created_s = self.created_ms // 1000
        updated_s = self.updated_ms // 1000
        if updated_s < created_s:
            updated_s = created_s
        return ExchangeOrder(
            order_id=self.order_id,
            intent_id=self.intent.intent_id,
            token_id=self.token_id,
            side=self.side,
            limit_price=self.limit_price,
            original_size=Shares(self.original),
            filled_size=Shares(self.filled),
            status=self.status,
            created_at=UnixTimestamp(created_s),
            updated_at=UnixTimestamp(updated_s),
        )


class PaperExecutionAdapter:
    """An in-process, deterministic paper implementation of ``ExecutionAdapter``.

    Time is virtual: call :meth:`advance_to` or feed :meth:`apply_market_event`
    to progress the simulated millisecond clock. All order-state transitions
    (acknowledgement, resting, fills, cancels, expiry) are resolved on the
    injected clock, so behavior is fully reproducible for a given ``seed`` and
    event script.
    """

    def __init__(
        self,
        *,
        config: PaperExecutionConfig,
        persistence: ExecutionPersistence,
        start_ms: int = 0,
    ) -> None:
        if start_ms < 0:
            raise ValueError("start_ms must be non-negative")
        self._config = config
        self._repos = persistence
        self._rng = random.Random(config.seed)
        self._now_ms = start_ms
        self._tokens: dict[str, _TokenReg] = {}
        self._books: dict[str, _BookState] = {}
        self._orders: dict[str, _PaperOrder] = {}
        self._fills: list[Fill] = []
        self._seen_events: set[str] = set()
        self._seen_trades: set[str] = set()

    # ------------------------------------------------------------------ #
    # Setup / clock
    # ------------------------------------------------------------------ #
    @property
    def now_ms(self) -> int:
        """Current simulated time in integer milliseconds."""
        return self._now_ms

    def register_market(self, market: BinaryMarket) -> None:
        """Register a market's Up/Down tokens (tick sizes, sides, market id).

        Orders for unregistered tokens are rejected (fail closed).
        """
        for token in (market.up_token, market.down_token):
            self._tokens[token.token_id.value] = _TokenReg(
                market_id=market.market_id,
                side=token.side,
                tick=token.tick_size,
            )
            self._books.setdefault(token.token_id.value, _BookState())

    async def advance_to(self, timestamp_ms: int) -> None:
        """Advance the simulated clock to ``timestamp_ms`` and settle state.

        The clock is monotonic: a request to move backward is ignored, but any
        due transitions are still settled at the current time.
        """
        if timestamp_ms > self._now_ms:
            self._now_ms = timestamp_ms
        await self._settle()

    async def settle(self) -> None:
        """Settle any due transitions at the current simulated time."""
        await self._settle()

    async def apply_market_event(self, event: MarketEvent) -> None:
        """Apply one market event: advance time, update the book, match trades.

        Duplicate events (by ``event_id``) are ignored. During a feed outage
        (``feed_live=False`` or no snapshot) the book is marked not-live and no
        resting order is matched (missed fills), modeling a WebSocket outage.
        """
        if event.event_id in self._seen_events:
            return
        # Settle transitions up to the event instant using the pre-event book.
        await self.advance_to(event.timestamp_ms)
        self._seen_events.add(event.event_id)

        book = self._books.setdefault(event.token_id.value, _BookState())
        if event.feed_live and event.snapshot is not None:
            book.snapshot = event.snapshot
            book.last_update_ms = self._now_ms
            book.live = True
        else:
            # Outage / non-live feed: keep the last snapshot but fail closed.
            book.live = False
            _LOG.warning("paper_feed_not_live")

        if book.live and event.trades:
            await self._match_trades(event.token_id, event.trades)

    # ------------------------------------------------------------------ #
    # ExecutionAdapter: submit
    # ------------------------------------------------------------------ #
    async def submit_order(self, intent: OrderIntent) -> SubmitAck:
        order_id = OrderId(f"paper-{intent.intent_id}")
        existing = self._orders.get(order_id.value)
        if existing is not None:
            # Idempotent: a repeat submit returns the current known state.
            return SubmitAck(
                intent.intent_id, self._outcome_for(existing), existing.entity()
            )

        token_key = intent.token_id.value
        reg = self._tokens.get(token_key)
        if reg is None:
            return await self._reject(intent, order_id, "unknown_token")

        if not self._is_tick_aligned(intent.limit_price.value, reg.tick.value):
            return await self._reject(intent, order_id, "tick_size")
        if intent.size.value < self._config.min_order_size.value:
            return await self._reject(intent, order_id, "min_size")
        if self._is_stale(token_key):
            return await self._reject(intent, order_id, "stale_book")

        snapshot = self._books[token_key].snapshot
        assert snapshot is not None  # guaranteed by _is_stale check
        taker = is_taker_tif(intent.time_in_force)
        if not taker and self._would_cross(intent.side, intent.limit_price, snapshot):
            return await self._reject(intent, order_id, "post_only_would_cross")

        if self._draw_probability(self._config.unknown_submission_probability):
            order = self._make_order(intent, order_id, taker=taker, unknown=True)
            order.status = OrderStatus.UNKNOWN
            self._orders[order_id.value] = order
            await self._persist_intent(intent)
            await self._persist_order(order)
            _LOG.warning("paper_submit_unknown_outcome")
            return SubmitAck(
                intent.intent_id,
                SubmitOutcome.UNKNOWN,
                order.entity(),
                "unknown_submission_outcome",
            )

        order = self._make_order(intent, order_id, taker=taker, unknown=False)
        self._orders[order_id.value] = order
        await self._persist_intent(intent)
        await self._persist_order(order)
        return SubmitAck(intent.intent_id, SubmitOutcome.ACCEPTED, order.entity())

    # ------------------------------------------------------------------ #
    # ExecutionAdapter: cancel
    # ------------------------------------------------------------------ #
    async def cancel_order(self, order_id: OrderId) -> CancelAck:
        order = self._orders.get(order_id.value)
        if order is None:
            return CancelAck(order_id, CancelOutcome.UNKNOWN_ORDER, "unknown_order")
        if order.status is OrderStatus.FILLED:
            return CancelAck(order_id, CancelOutcome.ALREADY_FILLED, "already_filled")
        if order.unknown:
            # Unknown status must be reconciled, not blindly canceled.
            return CancelAck(
                order_id,
                CancelOutcome.ALREADY_TERMINAL,
                "unknown_requires_reconciliation",
            )
        if order.status.is_terminal:
            return CancelAck(
                order_id, CancelOutcome.ALREADY_TERMINAL, order.status.value
            )
        if order.cancel_effective_ms is None:
            order.cancel_effective_ms = self._now_ms + self._config.cancel_latency.draw(
                self._rng
            )
        return CancelAck(order_id, CancelOutcome.SCHEDULED)

    async def cancel_market_orders(self, market_id: MarketId) -> CancelBatchAck:
        acks = [
            await self.cancel_order(order.order_id)
            for order in self._ordered_orders()
            if order.market_id.value == market_id.value
            and not order.status.is_terminal
            and not order.unknown
        ]
        return CancelBatchAck(tuple(acks))

    async def cancel_all_orders(self) -> CancelBatchAck:
        acks = [
            await self.cancel_order(order.order_id)
            for order in self._ordered_orders()
            if not order.status.is_terminal and not order.unknown
        ]
        return CancelBatchAck(tuple(acks))

    # ------------------------------------------------------------------ #
    # ExecutionAdapter: queries
    # ------------------------------------------------------------------ #
    async def get_order(self, order_id: OrderId) -> ExchangeOrder | None:
        order = self._orders.get(order_id.value)
        return order.entity() if order is not None else None

    async def get_open_orders(
        self, market_id: MarketId | None = None
    ) -> tuple[ExchangeOrder, ...]:
        open_states = {
            OrderStatus.PENDING_SUBMIT,
            OrderStatus.ACKNOWLEDGED,
            OrderStatus.OPEN,
            OrderStatus.PARTIALLY_FILLED,
        }
        return tuple(
            order.entity()
            for order in self._ordered_orders()
            if order.status in open_states
            and not order.unknown
            and (market_id is None or order.market_id.value == market_id.value)
        )

    async def get_fills(
        self,
        *,
        order_id: OrderId | None = None,
        market_id: MarketId | None = None,
    ) -> tuple[Fill, ...]:
        result: list[Fill] = []
        for fill in self._fills:
            if order_id is not None and fill.order_id.value != order_id.value:
                continue
            if market_id is not None:
                owner = self._orders.get(fill.order_id.value)
                if owner is None or owner.market_id.value != market_id.value:
                    continue
            result.append(fill)
        return tuple(result)

    # ------------------------------------------------------------------ #
    # Internal: settlement
    # ------------------------------------------------------------------ #
    async def _settle(self) -> None:
        for order in self._ordered_orders():
            if order.status.is_terminal or order.unknown:
                continue
            if order.status is OrderStatus.PENDING_SUBMIT and self._now_ms >= order.active_ms:
                await self._activate(order)
                if order.status.is_terminal:
                    continue
            if (
                order.expiry_ms is not None
                and self._now_ms >= order.expiry_ms
                and not order.status.is_terminal
            ):
                await self._finalize(order, OrderStatus.EXPIRED)
                continue
            if (
                order.cancel_effective_ms is not None
                and self._now_ms >= order.cancel_effective_ms
                and not order.status.is_terminal
            ):
                await self._finalize(order, OrderStatus.CANCELED)

    async def _activate(self, order: _PaperOrder) -> None:
        token_key = order.token_id.value
        if self._is_stale(token_key):
            # Fail closed at activation: a taker cannot fill; a maker cannot be
            # posted safely (crossing cannot be verified).
            await self._finalize(
                order,
                OrderStatus.CANCELED if order.is_taker else OrderStatus.REJECTED,
            )
            return
        snapshot = self._books[token_key].snapshot
        assert snapshot is not None
        if order.is_taker:
            await self._execute_taker(order, snapshot)
            return
        if self._would_cross(order.side, order.limit_price, snapshot):
            await self._finalize(order, OrderStatus.REJECTED)
            return
        order.queue_ahead = self._resting_at_price(order.side, order.limit_price, snapshot)
        order.status = OrderStatus.OPEN
        order.updated_ms = self._now_ms
        await self._persist_order(order)

    async def _execute_taker(self, order: _PaperOrder, snapshot: OrderBookSnapshot) -> None:
        tick = self._tokens[order.token_id.value].tick.value
        slip = self._config.expected_slippage_bps.as_fraction()
        levels = snapshot.asks if order.side is OrderSide.BUY else snapshot.bids
        plan: list[tuple[ProbabilityPrice, Decimal]] = []
        remaining = order.remaining
        with localcontext(computation_context()):
            for level in levels:
                if remaining <= 0:
                    break
                if order.side is OrderSide.BUY:
                    effective = round_up_to_tick(level.price.value * (_ONE + slip), tick)
                    if effective > order.limit_price.value:
                        break
                else:
                    effective = round_down_to_tick(level.price.value * (_ONE - slip), tick)
                    if effective < order.limit_price.value:
                        break
                take = level.size.value if level.size.value < remaining else remaining
                plan.append((ProbabilityPrice(effective), take))
                remaining -= take
        fillable = sum((size for _, size in plan), _ZERO)
        if order.tif is TimeInForce.FOK and fillable < order.original:
            # All-or-none: nothing fills, the order is killed.
            await self._finalize(order, OrderStatus.CANCELED)
            return
        for price, size in plan:
            await self._record_fill(order, price, Shares(round_shares(size)), maker=False)
        # IOC/FAK: any unfilled remainder is killed; a full fill is FILLED.
        final = (
            OrderStatus.FILLED
            if order.filled >= order.original
            else OrderStatus.CANCELED
        )
        await self._finalize(order, final)

    async def _match_trades(
        self, token_id: TokenId, trades: tuple[object, ...]
    ) -> None:
        from polymarket_pair_bot.execution.types import TradeTick

        typed: list[TradeTick] = [t for t in trades if isinstance(t, TradeTick)]
        fresh = [t for t in typed if t.trade_id not in self._seen_trades]
        if not fresh:
            return
        resting = [
            order
            for order in self._ordered_orders()
            if order.token_id.value == token_id.value
            and not order.is_taker
            and order.status in (OrderStatus.OPEN, OrderStatus.PARTIALLY_FILLED)
        ]
        for order in resting:
            for trade in fresh:
                if order.status.is_terminal or order.remaining <= 0:
                    break
                if not self._trade_reaches(order, trade.price):
                    continue
                volume = trade.size.value
                if order.queue_ahead > 0:
                    consumed = order.queue_ahead if order.queue_ahead < volume else volume
                    order.queue_ahead -= consumed
                    volume -= consumed
                if volume <= 0:
                    continue
                # Missed-fill gate models being stepped over on fast moves.
                if not self._draw_probability(self._config.maker_fill_probability):
                    continue
                take = volume if volume < order.remaining else order.remaining
                await self._record_fill(
                    order, order.limit_price, Shares(round_shares(take)), maker=True
                )
            if not order.status.is_terminal:
                if order.filled >= order.original:
                    await self._finalize(order, OrderStatus.FILLED)
                elif order.filled > 0:
                    order.status = OrderStatus.PARTIALLY_FILLED
                    order.updated_ms = self._now_ms
                    await self._persist_order(order)
        self._seen_trades.update(t.trade_id for t in fresh)

    async def _record_fill(
        self,
        order: _PaperOrder,
        price: ProbabilityPrice,
        size: Shares,
        *,
        maker: bool,
    ) -> None:
        if size.value <= 0:
            return
        order.fill_seq += 1
        fill_id = FillId(f"{order.order_id.value}:f{order.fill_seq}")
        with localcontext(computation_context()):
            notional = price.value * size.value
        fee_bps = self._config.maker_fee_bps if maker else self._config.taker_fee_bps
        fee = taker_fee(CollateralAmount(notional), fee_bps)
        fill = Fill(
            fill_id=fill_id,
            order_id=order.order_id,
            token_id=order.token_id,
            side=order.side,
            price=price,
            size=size,
            fee=fee,
            filled_at=UnixTimestamp(self._now_ms // 1000),
        )
        newly = await self._repos.fills.insert_idempotent(fill)
        if not newly:
            return
        self._fills.append(fill)
        order.filled += size.value
        order.fee_paid += fee.value
        order.updated_ms = self._now_ms

    async def _finalize(self, order: _PaperOrder, status: OrderStatus) -> None:
        order.status = status
        order.updated_ms = self._now_ms
        await self._persist_order(order)

    async def _reject(
        self, intent: OrderIntent, order_id: OrderId, reason: str
    ) -> SubmitAck:
        order = _PaperOrder(
            order_id=order_id,
            intent=intent,
            market_id=intent.market_id,
            token_id=intent.token_id,
            side=intent.side,
            tif=intent.time_in_force,
            limit_price=intent.limit_price,
            original=intent.size.value,
            created_ms=self._now_ms,
            active_ms=self._now_ms,
            is_taker=is_taker_tif(intent.time_in_force),
            status=OrderStatus.REJECTED,
            updated_ms=self._now_ms,
        )
        self._orders[order_id.value] = order
        await self._persist_intent(intent)
        await self._persist_order(order)
        return SubmitAck(intent.intent_id, SubmitOutcome.REJECTED, order.entity(), reason)

    # ------------------------------------------------------------------ #
    # Internal: helpers
    # ------------------------------------------------------------------ #
    def _make_order(
        self, intent: OrderIntent, order_id: OrderId, *, taker: bool, unknown: bool
    ) -> _PaperOrder:
        active_ms = self._now_ms + self._config.ack_latency.draw(self._rng)
        expiry_ms: int | None = None
        if intent.time_in_force is TimeInForce.GTD:
            expiry_ms = active_ms + self._config.gtd_ttl_ms
        return _PaperOrder(
            order_id=order_id,
            intent=intent,
            market_id=intent.market_id,
            token_id=intent.token_id,
            side=intent.side,
            tif=intent.time_in_force,
            limit_price=intent.limit_price,
            original=intent.size.value,
            created_ms=self._now_ms,
            active_ms=active_ms,
            is_taker=taker,
            expiry_ms=expiry_ms,
            unknown=unknown,
            updated_ms=self._now_ms,
        )

    def _ordered_orders(self) -> list[_PaperOrder]:
        """Orders in a stable, deterministic processing order."""
        return sorted(
            self._orders.values(), key=lambda o: (o.created_ms, o.order_id.value)
        )

    def _is_stale(self, token_key: str) -> bool:
        book = self._books.get(token_key)
        if book is None or book.snapshot is None or not book.live:
            return True
        return (self._now_ms - book.last_update_ms) > self._config.stale_after_ms

    @staticmethod
    def _is_tick_aligned(price: Decimal, tick: Decimal) -> bool:
        with localcontext(computation_context()):
            steps = price / tick
            return steps == steps.to_integral_value()

    @staticmethod
    def _would_cross(
        side: OrderSide, price: ProbabilityPrice, snapshot: OrderBookSnapshot
    ) -> bool:
        if side is OrderSide.BUY:
            best_ask = snapshot.best_ask
            return best_ask is not None and price.value >= best_ask.value
        best_bid = snapshot.best_bid
        return best_bid is not None and price.value <= best_bid.value

    @staticmethod
    def _resting_at_price(
        side: OrderSide, price: ProbabilityPrice, snapshot: OrderBookSnapshot
    ) -> Decimal:
        levels = snapshot.bids if side is OrderSide.BUY else snapshot.asks
        for level in levels:
            if level.price.value == price.value:
                return level.size.value
        return _ZERO

    @staticmethod
    def _trade_reaches(order: _PaperOrder, trade_price: ProbabilityPrice) -> bool:
        if order.side is OrderSide.BUY:
            return trade_price.value <= order.limit_price.value
        return trade_price.value >= order.limit_price.value

    def _draw_probability(self, probability: Decimal) -> bool:
        """Deterministic Bernoulli draw using integer micro-probability units.

        Avoids binary floats on the probability path: compares a seeded integer
        draw in ``[0, 1_000_000)`` against the scaled probability.
        """
        if probability <= _ZERO:
            return False
        if probability >= _ONE:
            return True
        threshold = int((probability * _PROB_SCALE).to_integral_value(rounding=ROUND_FLOOR))
        return self._rng.randrange(1_000_000) < threshold

    @staticmethod
    def _outcome_for(order: _PaperOrder) -> SubmitOutcome:
        if order.status is OrderStatus.REJECTED:
            return SubmitOutcome.REJECTED
        if order.unknown or order.status is OrderStatus.UNKNOWN:
            return SubmitOutcome.UNKNOWN
        return SubmitOutcome.ACCEPTED

    async def _persist_intent(self, intent: OrderIntent) -> None:
        await self._repos.intents.add(intent)

    async def _persist_order(self, order: _PaperOrder) -> None:
        await self._repos.orders.upsert(order.entity())


__all__ = ["PaperExecutionAdapter"]
