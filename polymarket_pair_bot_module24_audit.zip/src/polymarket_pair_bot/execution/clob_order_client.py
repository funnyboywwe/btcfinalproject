"""Blocked concrete live order client over the official CLOB package.

The official Polymarket CLOB Python package's exact order-placement, signing,
cancel and query surface cannot be verified in this environment (offline; the
package is not installed). Following the project's safety rule -- "if package
behavior cannot be verified, add a blocked adapter method with a clear
explanation instead of guessing" -- every method here raises
:class:`UnsupportedLiveOperationError` with a specific, secret-free message.

This mirrors the auth module's ``ClobAuthenticatedReader`` blocked-adapter
pattern. When the package surface is verified, each method should be implemented
by (a) lazily importing the package via :func:`load_clob_package`, (b) signing
and sending, and (c) validating the raw payload into the ``live_models`` types
BEFORE returning. Until then the adapter fails closed and never guesses an API.
"""

from __future__ import annotations

from typing import Any

from polymarket_pair_bot.domain.value_objects import CollateralAmount
from polymarket_pair_bot.execution.errors import UnsupportedLiveOperationError
from polymarket_pair_bot.execution.live_models import (
    CancelResult,
    FillRecord,
    OpenOrderRecord,
    OrderPlacement,
    OrderStateView,
)
from polymarket_pair_bot.execution.live_ports import LiveOrderRequest

_UNVERIFIED = (
    "the official CLOB package surface is not verified in this environment; "
    "a real implementation must sign, send, and validate the response before "
    "returning"
)


def load_clob_package() -> Any:
    """Lazily import the official CLOB package.

    Import is deferred so the module graph does not depend on the package being
    installed. Raises :class:`UnsupportedLiveOperationError` (never a bare
    ImportError) so callers uniformly fail closed.
    """
    try:  # pragma: no cover - exercised only where the package is installed
        import py_clob_client  # type: ignore[import-not-found]
    except ImportError as exc:
        raise UnsupportedLiveOperationError(
            "import_clob_package",
            "install and pin the official py-clob-client, then verify its "
            "order-placement and query surface before enabling live writes",
        ) from exc
    return py_clob_client


class ClobOrderClient:
    """BLOCKED :class:`LiveOrderClient`. Every operation fails closed.

    Signing is intended to happen INSIDE this client so key material never
    leaves the adapter boundary; no key is accepted or stored here while the
    client is blocked.
    """

    async def place_order(self, request: LiveOrderRequest) -> OrderPlacement:
        raise UnsupportedLiveOperationError("place_order", _UNVERIFIED)

    async def cancel_order(self, order_id: str) -> CancelResult:
        raise UnsupportedLiveOperationError("cancel_order", _UNVERIFIED)

    async def cancel_market_orders(self, market_id: str) -> tuple[CancelResult, ...]:
        raise UnsupportedLiveOperationError("cancel_market_orders", _UNVERIFIED)

    async def cancel_all_orders(self) -> tuple[CancelResult, ...]:
        raise UnsupportedLiveOperationError("cancel_all_orders", _UNVERIFIED)

    async def get_open_orders(
        self, *, market_id: str | None = None
    ) -> tuple[OpenOrderRecord, ...]:
        raise UnsupportedLiveOperationError("get_open_orders", _UNVERIFIED)

    async def get_order(self, order_id: str) -> OrderStateView | None:
        raise UnsupportedLiveOperationError("get_order", _UNVERIFIED)

    async def get_fills(
        self, *, order_id: str | None = None, market_id: str | None = None
    ) -> tuple[FillRecord, ...]:
        raise UnsupportedLiveOperationError("get_fills", _UNVERIFIED)


class BlockedAllowanceProvider:
    """BLOCKED collateral/allowance provider (on-chain reads are Module 20).

    Returns ``None`` for both values so the adapter fails closed: an order whose
    collateral and allowance cannot be verified is rejected, never sent.
    """

    async def available_collateral(self) -> CollateralAmount | None:
        return None

    async def spender_allowance(self) -> CollateralAmount | None:
        return None


__all__ = ["BlockedAllowanceProvider", "ClobOrderClient", "load_clob_package"]
