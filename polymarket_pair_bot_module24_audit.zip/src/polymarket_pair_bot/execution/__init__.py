"""Execution adapters (Module 11+).

Paper and live order execution live behind a single :class:`ExecutionAdapter`
protocol so higher layers can swap implementations without change. Both the
deterministic :class:`PaperExecutionAdapter` and the guarded
:class:`LiveExecutionAdapter` implement that interface.

The live path is inert by default: real submission requires LIVE_TRADING on,
PAPER_TRADING off, execution leadership, healthy data, a recent consistent
reconciliation, a clear kill switch and an approved risk decision. Wrapping the
live client with :class:`DryRunOrderClient` guarantees no real write endpoint is
ever reached. Nothing here asserts the strategy is profitable.
"""

from __future__ import annotations

from polymarket_pair_bot.execution.clob_order_client import (
    BlockedAllowanceProvider,
    ClobOrderClient,
    load_clob_package,
)
from polymarket_pair_bot.execution.dry_run import DryRunOrderClient
from polymarket_pair_bot.execution.errors import (
    ExchangeErrorClass,
    ExchangeRejectedError,
    LiveExecutionError,
    SubmissionTimeoutError,
    UnsupportedLiveOperationError,
    classify_exchange_error,
)
from polymarket_pair_bot.execution.paper import PaperExecutionAdapter
from polymarket_pair_bot.execution.ports import (
    ExecutionAdapter,
    ExecutionPersistence,
)
from polymarket_pair_bot.execution.lifecycle import (
    FillApplication,
    OrderLifecycleManager,
)
from polymarket_pair_bot.execution.live import LiveExecutionAdapter, ReplaceResult
from polymarket_pair_bot.execution.live_models import (
    CancelResult,
    FillRecord,
    OpenOrderRecord,
    OrderPlacement,
    OrderStateView,
)
from polymarket_pair_bot.execution.live_ports import (
    CollateralAllowanceProvider,
    LiveOrderClient,
    LiveOrderRequest,
    RiskDecisionProvider,
)
from polymarket_pair_bot.execution.submission_gate import (
    LiveSubmissionGate,
    SubmissionGateDecision,
)
from polymarket_pair_bot.execution.types import (
    CancelAck,
    CancelBatchAck,
    CancelOutcome,
    LatencyDistribution,
    MarketEvent,
    PaperExecutionConfig,
    SubmitAck,
    SubmitOutcome,
    TradeTick,
    is_taker_tif,
)

__all__ = [
    "BlockedAllowanceProvider",
    "CancelAck",
    "CancelBatchAck",
    "CancelOutcome",
    "CancelResult",
    "ClobOrderClient",
    "CollateralAllowanceProvider",
    "DryRunOrderClient",
    "ExchangeErrorClass",
    "ExchangeRejectedError",
    "ExecutionAdapter",
    "ExecutionPersistence",
    "FillApplication",
    "FillRecord",
    "LatencyDistribution",
    "LiveExecutionAdapter",
    "LiveExecutionError",
    "LiveOrderClient",
    "LiveOrderRequest",
    "LiveSubmissionGate",
    "MarketEvent",
    "OpenOrderRecord",
    "OrderLifecycleManager",
    "OrderPlacement",
    "OrderStateView",
    "PaperExecutionAdapter",
    "PaperExecutionConfig",
    "ReplaceResult",
    "RiskDecisionProvider",
    "SubmissionGateDecision",
    "SubmissionTimeoutError",
    "SubmitAck",
    "SubmitOutcome",
    "TradeTick",
    "UnsupportedLiveOperationError",
    "classify_exchange_error",
    "is_taker_tif",
]
