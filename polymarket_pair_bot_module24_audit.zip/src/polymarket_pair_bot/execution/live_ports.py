"""Ports (typed protocols) for the live execution adapter (Module 14).

These abstractions are the ONLY seam through which the live adapter touches the
official Polymarket CLOB package, wallet signing, on-chain allowance data, and
the centralized risk engine's persisted decisions. Keeping them here enforces
dependency inversion: the adapter and the order-lifecycle manager depend only on
interfaces, never on ``py_clob_client``, ``web3``, HTTP/WS clients, SQLAlchemy
models, or environment variables.

Concrete implementations:

* :class:`~polymarket_pair_bot.execution.clob_order_client.ClobOrderClient`
  is a BLOCKED implementation (mirrors the auth module) because the exact
  package surface cannot be verified offline.
* :class:`~polymarket_pair_bot.execution.dry_run.DryRunOrderClient` wraps any
  client and guarantees no real write endpoint is reached.
* Tests provide in-memory fakes.

All boundary values are the runtime-validated models in ``live_models`` or the
domain value objects (``Decimal``-backed, never binary floats).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import OrderIntent, RiskDecision
from polymarket_pair_bot.domain.value_objects import CollateralAmount, MarketId
from polymarket_pair_bot.execution.live_models import (
    CancelResult,
    FillRecord,
    OpenOrderRecord,
    OrderPlacement,
    OrderStateView,
)


@dataclass(frozen=True, slots=True)
class LiveOrderRequest:
    """A fully-specified request to place one order through the official client.

    ``post_only`` is derived from the intent's time-in-force by the adapter
    (GTC/GTD are post-only maker orders; IOC/FOK are taker orders). The
    ``idempotency_key`` is the client-generated key used both for the exchange
    request and for the local first-writer-wins idempotency guard.
    """

    intent: OrderIntent
    idempotency_key: str
    post_only: bool


@runtime_checkable
class LiveOrderClient(Protocol):
    """Adapter over the official CLOB package's order read/write surface.

    Only the operations verified as supported by the installed package are
    exposed: post-only GTC, post-only GTD (when safe), FOK and FAK placement;
    cancel one/market/all; and query open orders / individual order / fills.
    Signing happens INSIDE the concrete client (the adapter never handles key
    material). Implementations must validate every raw payload into the
    ``live_models`` types before returning.
    """

    async def place_order(self, request: LiveOrderRequest) -> OrderPlacement:
        """Sign and submit one order. An ack here is NEVER a fill."""
        ...

    async def cancel_order(self, order_id: str) -> CancelResult:
        """Cancel a single resting order (allowed even when kill switch on)."""
        ...

    async def cancel_market_orders(self, market_id: str) -> tuple[CancelResult, ...]:
        """Cancel all resting orders for one market."""
        ...

    async def cancel_all_orders(self) -> tuple[CancelResult, ...]:
        """Cancel all resting orders for the controlled wallet."""
        ...

    async def get_open_orders(
        self, *, market_id: str | None = None
    ) -> tuple[OpenOrderRecord, ...]:
        """Query currently-open orders (authoritative reconciliation source)."""
        ...

    async def get_order(self, order_id: str) -> OrderStateView | None:
        """Query a single order by exchange id, or None if unknown."""
        ...

    async def get_fills(
        self, *, order_id: str | None = None, market_id: str | None = None
    ) -> tuple[FillRecord, ...]:
        """Query authoritative fills, optionally scoped by order or market."""
        ...


@runtime_checkable
class CollateralAllowanceProvider(Protocol):
    """Read-only source of spendable collateral and spender allowance (USD).

    Returning ``None`` means the value could not be established. The adapter
    fails closed on ``None`` (an order that cannot be validated is rejected).
    The authoritative on-chain implementation is Module 20; until then a blocked
    provider returns ``None`` for both.
    """

    async def available_collateral(self) -> CollateralAmount | None:
        """Spendable USDC collateral, or None if unknown."""
        ...

    async def spender_allowance(self) -> CollateralAmount | None:
        """Approved allowance for the CTF/exchange spender, or None if unknown."""
        ...


@runtime_checkable
class RiskDecisionProvider(Protocol):
    """Supplies the approved :class:`RiskDecision` for a given order intent.

    Every intent must pass through the centralized risk engine (Module 13); the
    adapter never evaluates risk itself. Returning ``None`` (or a non-approved
    decision) blocks submission. In production this reads the persisted risk
    decision keyed to the intent; tests inject a fake.
    """

    async def decision_for(self, intent: OrderIntent) -> RiskDecision | None: ...


@runtime_checkable
class FeedHealthView(Protocol):
    """Minimal freshness/health view of the market-data feeds."""

    async def feeds_healthy(self) -> bool: ...


@dataclass(frozen=True, slots=True)
class ReconciliationView:
    """Point-in-time view of the most recent reconciliation run.

    ``as_of_s`` is UNIX seconds (UTC). Mirrors the shape provided by the risk
    layer's reconciliation status provider without coupling to it.
    """

    is_consistent: bool
    as_of_s: int


@runtime_checkable
class ReconciliationStatusView(Protocol):
    """Supplies the latest reconciliation result, or None if never run."""

    async def latest_reconciliation(self) -> ReconciliationView | None: ...


@runtime_checkable
class KillSwitchView(Protocol):
    """Fail-closed view of the global kill switch (active if unreadable)."""

    async def is_active(self) -> bool: ...


@dataclass(frozen=True, slots=True)
class MarketExecutionContext:
    """Static per-market execution context needed for validation.

    Tick sizes are ``Decimal``-backed via the domain value objects registered
    with the adapter; this record correlates a token to its owning market.
    """

    market_id: MarketId


__all__ = [
    "CollateralAllowanceProvider",
    "FeedHealthView",
    "KillSwitchView",
    "LiveOrderClient",
    "LiveOrderRequest",
    "MarketExecutionContext",
    "ReconciliationStatusView",
    "ReconciliationView",
    "RiskDecisionProvider",
]
