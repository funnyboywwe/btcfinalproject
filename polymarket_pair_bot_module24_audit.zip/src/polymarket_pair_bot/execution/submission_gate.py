"""Live submission gate: every precondition for placing a real order (Module 14).

A live order may be submitted only when ALL of the following hold:

* ``LIVE_TRADING`` is true and ``PAPER_TRADING`` is false;
* this process holds execution leadership (the execution gate is enabled);
* the market-data feeds are healthy (fresh);
* a recent, consistent reconciliation exists;
* the global kill switch is clear;
* the risk engine approved the specific order intent.

The gate is fail-closed: any unreadable or missing signal blocks submission. It
depends only on the abstract views in ``live_ports`` (dependency inversion) and
performs no order I/O itself. Cancellation is intentionally NOT gated here --
cancelling resting orders must remain possible even when the kill switch is on.
"""

from __future__ import annotations

from dataclasses import dataclass

from polymarket_pair_bot.domain.entities import RiskDecision
from polymarket_pair_bot.execution.live_ports import (
    FeedHealthView,
    KillSwitchView,
    ReconciliationStatusView,
)
from polymarket_pair_bot.observability.logging import get_logger

from polymarket_pair_bot.domain.coordination import ExecutionGateView

_LOG = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class SubmissionGateDecision:
    """Outcome of a submission-gate evaluation.

    ``blockers`` lists every failed precondition (secret-free, human readable).
    An empty tuple means submission is authorized.
    """

    allowed: bool
    blockers: tuple[str, ...]

    def reason_summary(self) -> str:
        if self.allowed:
            return "submission authorized"
        return "submission blocked: " + "; ".join(self.blockers)


class LiveSubmissionGate:
    """Evaluates all preconditions required before a live order submission."""

    def __init__(
        self,
        *,
        live_trading: bool,
        paper_trading: bool,
        execution_gate: ExecutionGateView,
        kill_switch: KillSwitchView,
        feeds: FeedHealthView,
        reconciliation: ReconciliationStatusView,
        reconciliation_max_age_seconds: int,
    ) -> None:
        if reconciliation_max_age_seconds <= 0:
            raise ValueError("reconciliation_max_age_seconds must be positive")
        self._live_trading = live_trading
        self._paper_trading = paper_trading
        self._execution_gate = execution_gate
        self._kill_switch = kill_switch
        self._feeds = feeds
        self._reconciliation = reconciliation
        self._recon_max_age = reconciliation_max_age_seconds

    async def authorize(
        self, *, now_s: int, risk_decision: RiskDecision | None
    ) -> SubmissionGateDecision:
        """Evaluate every precondition. Never raises; failures become blockers."""
        blockers: list[str] = []

        if not self._live_trading:
            blockers.append("LIVE_TRADING is not enabled")
        if self._paper_trading:
            blockers.append("PAPER_TRADING is still enabled")

        if not self._execution_gate.is_enabled:
            reason = self._execution_gate.reason or "not execution leader"
            blockers.append(f"execution leadership not held ({reason})")

        if await self._kill_switch_active():
            blockers.append("kill switch is active")

        if not await self._feeds_healthy():
            blockers.append("market-data feeds are not healthy")

        blockers.extend(await self._reconciliation_blockers(now_s))

        if risk_decision is None:
            blockers.append("no risk decision for intent")
        elif not risk_decision.approved:
            blockers.append(f"risk engine rejected intent ({risk_decision.reason})")

        allowed = not blockers
        if not allowed:
            _LOG.warning(
                "live_submission_gate.blocked", extra={"blockers": list(blockers)}
            )
        return SubmissionGateDecision(allowed=allowed, blockers=tuple(blockers))

    async def _kill_switch_active(self) -> bool:
        try:
            return await self._kill_switch.is_active()
        except Exception:  # noqa: BLE001 - fail closed on any read failure
            _LOG.error("live_submission_gate.kill_switch_unreadable")
            return True

    async def _feeds_healthy(self) -> bool:
        try:
            return await self._feeds.feeds_healthy()
        except Exception:  # noqa: BLE001 - fail closed on any read failure
            _LOG.error("live_submission_gate.feed_health_unreadable")
            return False

    async def _reconciliation_blockers(self, now_s: int) -> list[str]:
        try:
            latest = await self._reconciliation.latest_reconciliation()
        except Exception:  # noqa: BLE001 - fail closed on any read failure
            _LOG.error("live_submission_gate.reconciliation_unreadable")
            return ["reconciliation status unreadable"]
        if latest is None:
            return ["no successful reconciliation on record"]
        if not latest.is_consistent:
            return ["most recent reconciliation was not consistent"]
        age = now_s - latest.as_of_s
        if age < 0 or age > self._recon_max_age:
            return [f"reconciliation is stale ({age}s > {self._recon_max_age}s)"]
        return []


__all__ = ["LiveSubmissionGate", "SubmissionGateDecision"]
