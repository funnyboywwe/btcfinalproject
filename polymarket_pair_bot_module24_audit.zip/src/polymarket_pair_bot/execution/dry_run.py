"""Dry-run interceptor for the live order client (Module 14).

The interceptor wraps any :class:`LiveOrderClient` and GUARANTEES that no real
write endpoint is reached: ``place_order`` and every cancel are intercepted and
satisfied locally with synthetic, clearly-labelled results. This is the
mechanism that lets development commands and automated tests exercise the full
live code path while never mutating a real exchange (safety requirements 17 and
19).

A synthetic acknowledgement is deliberately an acknowledgement only -- never a
fill. Read queries delegate to the wrapped client when one is supplied
(typically a blocked or fake client) and otherwise return empty results.
"""

from __future__ import annotations

from polymarket_pair_bot.domain.enums import OrderStatus
from polymarket_pair_bot.execution.live_models import (
    CancelResult,
    FillRecord,
    OpenOrderRecord,
    OrderPlacement,
    OrderStateView,
)
from polymarket_pair_bot.execution.live_ports import LiveOrderClient, LiveOrderRequest
from polymarket_pair_bot.execution.types import CancelOutcome
from polymarket_pair_bot.observability.logging import get_logger

_LOG = get_logger(__name__)

_DRY_RUN_PREFIX = "dryrun-"


class DryRunOrderClient:
    """A :class:`LiveOrderClient` that never reaches a real write endpoint.

    Writes are intercepted and answered with synthetic results derived from the
    request. Reads are delegated to ``inner`` when provided; with no inner
    client the dry-run world has no resting orders or fills, so reads are empty.
    """

    def __init__(self, inner: LiveOrderClient | None = None) -> None:
        self._inner = inner

    @staticmethod
    def synthetic_order_id(idempotency_key: str) -> str:
        """Deterministic, clearly-labelled id for an intercepted order."""
        return f"{_DRY_RUN_PREFIX}{idempotency_key}"

    async def place_order(self, request: LiveOrderRequest) -> OrderPlacement:
        order_id = self.synthetic_order_id(request.idempotency_key)
        _LOG.info(
            "dry_run.place_order.intercepted",
            extra={
                "intent_id": request.intent.intent_id,
                "order_id": order_id,
                "post_only": request.post_only,
            },
        )
        # Acknowledged, working, and explicitly NOT filled.
        return OrderPlacement(order_id=order_id, status=OrderStatus.ACKNOWLEDGED)

    async def cancel_order(self, order_id: str) -> CancelResult:
        _LOG.info("dry_run.cancel_order.intercepted", extra={"order_id": order_id})
        return CancelResult(
            order_id=order_id,
            outcome=CancelOutcome.ACCEPTED,
            reason="dry-run: cancel intercepted, not sent",
        )

    async def cancel_market_orders(self, market_id: str) -> tuple[CancelResult, ...]:
        _LOG.info(
            "dry_run.cancel_market_orders.intercepted", extra={"market_id": market_id}
        )
        return ()

    async def cancel_all_orders(self) -> tuple[CancelResult, ...]:
        _LOG.info("dry_run.cancel_all_orders.intercepted")
        return ()

    async def get_open_orders(
        self, *, market_id: str | None = None
    ) -> tuple[OpenOrderRecord, ...]:
        if self._inner is None:
            return ()
        return await self._inner.get_open_orders(market_id=market_id)

    async def get_order(self, order_id: str) -> OrderStateView | None:
        if self._inner is None:
            return None
        return await self._inner.get_order(order_id)

    async def get_fills(
        self, *, order_id: str | None = None, market_id: str | None = None
    ) -> tuple[FillRecord, ...]:
        if self._inner is None:
            return ()
        return await self._inner.get_fills(order_id=order_id, market_id=market_id)


__all__ = ["DryRunOrderClient"]
