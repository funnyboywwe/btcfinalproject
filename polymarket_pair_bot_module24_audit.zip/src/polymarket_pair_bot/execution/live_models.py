"""Runtime-validated views of external CLOB responses (Module 14).

The official Polymarket CLOB package returns loosely-typed payloads. Every value
that crosses the :class:`~polymarket_pair_bot.execution.live_ports.LiveOrderClient`
boundary is normalised into one of the Pydantic models below so that:

* external data is validated at runtime (safety requirement);
* monetary / price / quantity values are ``Decimal`` and can never be built from
  a binary float (``_to_decimal`` rejects floats, matching the auth module);
* only documented fields are represented -- unknown fields are rejected
  (``extra="forbid"``) so we never silently depend on an invented field.

Mapping raw package payloads into these models is the responsibility of the
concrete (blocked) client; tests construct them directly, which still exercises
the validation. Nothing here performs I/O.
"""

from __future__ import annotations

from decimal import Decimal

from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from polymarket_pair_bot.domain.enums import OrderSide, OrderStatus
from polymarket_pair_bot.domain.precision import coerce_decimal
from polymarket_pair_bot.execution.types import CancelOutcome

_MODEL = ConfigDict(frozen=True, extra="forbid")


def _to_decimal(value: Decimal | int | str) -> Decimal:
    """Coerce to Decimal, rejecting binary floats and bools."""
    return coerce_decimal(value)


class OrderPlacement(BaseModel):
    """Validated response to an order placement request.

    An acknowledgement is NOT a fill. ``status`` reflects the exchange-reported
    lifecycle state; ``filled_size`` is only meaningful when the exchange
    authoritatively reports matched size (e.g. an immediate FOK/FAK match). A
    non-zero ``filled_size`` still requires authoritative fill records to be
    processed via the lifecycle manager before any pairing decision.
    """

    model_config = _MODEL

    order_id: str | None = None
    status: OrderStatus
    filled_size: Decimal = Decimal(0)
    error_code: str | None = None
    error_message: str | None = None

    _v_filled = field_validator("filled_size", mode="before")(_to_decimal)

    @field_validator("filled_size")
    @classmethod
    def _non_negative(cls, value: Decimal) -> Decimal:
        if value < 0:
            raise ValueError("filled_size must be non-negative")
        return value

    @model_validator(mode="after")
    def _check_consistency(self) -> "OrderPlacement":
        # A resting/working or filled order must carry an id we can track.
        if self.status is not OrderStatus.REJECTED and self.order_id is None:
            raise ValueError("order_id is required unless the order was rejected")
        if self.status is OrderStatus.REJECTED and self.filled_size != 0:
            raise ValueError("a rejected order cannot report a filled size")
        return self

    @property
    def is_rejected(self) -> bool:
        return self.status is OrderStatus.REJECTED


class OrderStateView(BaseModel):
    """Validated view of a single order queried from the exchange."""

    model_config = _MODEL

    order_id: str
    status: OrderStatus
    original_size: Decimal
    filled_size: Decimal = Decimal(0)
    price: Decimal | None = None

    _v_original = field_validator("original_size", mode="before")(_to_decimal)
    _v_filled = field_validator("filled_size", mode="before")(_to_decimal)
    _v_price = field_validator("price", mode="before")(
        lambda v: None if v is None else _to_decimal(v)
    )

    @model_validator(mode="after")
    def _check_sizes(self) -> "OrderStateView":
        if self.original_size < 0:
            raise ValueError("original_size must be non-negative")
        if self.filled_size < 0:
            raise ValueError("filled_size must be non-negative")
        if self.filled_size > self.original_size:
            raise ValueError("filled_size cannot exceed original_size")
        return self


class OpenOrderRecord(BaseModel):
    """Validated view of an open (working) order queried from the exchange."""

    model_config = _MODEL

    order_id: str
    token_id: str
    side: OrderSide
    status: OrderStatus
    price: Decimal
    original_size: Decimal
    filled_size: Decimal = Decimal(0)
    market_id: str | None = None

    _v_price = field_validator("price", mode="before")(_to_decimal)
    _v_original = field_validator("original_size", mode="before")(_to_decimal)
    _v_filled = field_validator("filled_size", mode="before")(_to_decimal)

    @model_validator(mode="after")
    def _check_sizes(self) -> "OpenOrderRecord":
        if self.filled_size > self.original_size:
            raise ValueError("filled_size cannot exceed original_size")
        return self


class FillRecord(BaseModel):
    """Validated authoritative fill record (from query or user stream).

    Fill messages are NOT assumed unique; de-duplication by ``fill_id`` happens
    in the lifecycle manager. ``filled_at_s`` is UNIX seconds (UTC); when the
    source omits a timestamp the lifecycle manager stamps it from the clock.
    """

    model_config = _MODEL

    fill_id: str
    order_id: str
    token_id: str
    side: OrderSide
    price: Decimal
    size: Decimal
    fee: Decimal = Decimal(0)
    filled_at_s: int | None = None

    _v_price = field_validator("price", mode="before")(_to_decimal)
    _v_size = field_validator("size", mode="before")(_to_decimal)
    _v_fee = field_validator("fee", mode="before")(_to_decimal)

    @model_validator(mode="after")
    def _check(self) -> "FillRecord":
        if self.size <= 0:
            raise ValueError("fill size must be strictly positive")
        if self.fee < 0:
            raise ValueError("fill fee must be non-negative")
        if self.filled_at_s is not None and self.filled_at_s < 0:
            raise ValueError("filled_at_s must be non-negative")
        return self


class CancelResult(BaseModel):
    """Validated response to a cancel request for a single order."""

    model_config = _MODEL

    order_id: str
    outcome: CancelOutcome
    reason: str | None = None


__all__ = [
    "CancelResult",
    "FillRecord",
    "OpenOrderRecord",
    "OrderPlacement",
    "OrderStateView",
]
