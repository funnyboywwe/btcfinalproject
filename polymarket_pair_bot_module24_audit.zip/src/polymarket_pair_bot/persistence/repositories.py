"""SQLAlchemy implementations of the domain repository protocols.

Each repository operates on a single :class:`AsyncSession`; a
:class:`SqlAlchemyUnitOfWork` owns that session and the surrounding transaction
so that order-state, fill and inventory writes commit atomically.

Idempotency is enforced at the database level: inserts that must not duplicate
use PostgreSQL ``INSERT ... ON CONFLICT DO NOTHING`` and report whether a row
was actually inserted.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from types import TracebackType

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    CtfOperation,
    ExchangeOrder,
    Fill,
    InventorySnapshot,
    MarketWindow,
    MatchedPair,
    OrderIntent,
    PairOpportunity,
    ReconciliationResult,
    RiskDecision,
)
from polymarket_pair_bot.domain.enums import OrderStatus
from polymarket_pair_bot.domain.repositories import JsonValue
from polymarket_pair_bot.domain.value_objects import (
    FillId,
    MarketId,
    OrderId,
    UnixTimestamp,
)
from polymarket_pair_bot.persistence import mappers
from polymarket_pair_bot.persistence.models import (
    BlockchainTransactionRow,
    CtfOperationRow,
    ExchangeOrderRow,
    FillRow,
    InventorySnapshotRow,
    KillSwitchEventRow,
    MarketRow,
    MarketWindowRow,
    MatchedPairRow,
    OrderIntentRow,
    PairOpportunityRow,
    ReconciliationDiscrepancyRow,
    ReconciliationRunRow,
    RiskEventRow,
    SystemEventRow,
)

_TERMINAL_OR_OPEN = {
    OrderStatus.PENDING_SUBMIT,
    OrderStatus.SUBMITTED,
    OrderStatus.ACKNOWLEDGED,
    OrderStatus.OPEN,
    OrderStatus.PARTIALLY_FILLED,
    OrderStatus.UNKNOWN,
}


class MarketRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert_market(self, market: BinaryMarket) -> None:
        row = mappers.market_to_row(market)
        await self._session.merge(row)

    async def get_market(self, market_id: MarketId) -> BinaryMarket | None:
        market_row = await self._session.get(MarketRow, market_id.value)
        window_row = await self._session.get(MarketWindowRow, market_id.value)
        if market_row is None or window_row is None:
            return None
        return mappers.market_from_row(market_row, window_row)


class MarketWindowRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert_window(self, window: MarketWindow) -> None:
        await self._session.merge(mappers.window_to_row(window))

    async def get_window(self, market_id: MarketId) -> MarketWindow | None:
        row = await self._session.get(MarketWindowRow, market_id.value)
        return None if row is None else mappers.window_from_row(row)


class OrderIntentRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, intent: OrderIntent) -> bool:
        stmt = (
            pg_insert(OrderIntentRow)
            .values(
                intent_id=intent.intent_id,
                market_id=intent.market_id.value,
                token_id=intent.token_id.value,
                side=intent.side.value,
                limit_price=intent.limit_price.value,
                size=intent.size.value,
                time_in_force=intent.time_in_force.value,
                created_at=intent.created_at.value,
            )
            .on_conflict_do_nothing(index_elements=["intent_id"])
        )
        result = await self._session.execute(stmt)
        return bool(result.rowcount)

    async def get(self, intent_id: str) -> OrderIntent | None:
        row = await self._session.get(OrderIntentRow, intent_id)
        return None if row is None else mappers.intent_from_row(row)


class ExchangeOrderRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert(self, order: ExchangeOrder) -> None:
        existing = await self._session.get(ExchangeOrderRow, order.order_id.value)
        market_id = (
            MarketId(existing.market_id)
            if existing is not None
            else MarketId(order.token_id.value)
        )
        row = mappers.order_to_row(order, market_id=market_id)
        await self._session.merge(row)

    async def upsert_for_market(
        self, order: ExchangeOrder, market_id: MarketId
    ) -> None:
        await self._session.merge(mappers.order_to_row(order, market_id=market_id))

    async def get(self, order_id: OrderId) -> ExchangeOrder | None:
        row = await self._session.get(ExchangeOrderRow, order_id.value)
        return None if row is None else mappers.order_from_row(row)

    async def list_open(self, market_id: MarketId) -> Sequence[ExchangeOrder]:
        stmt = select(ExchangeOrderRow).where(
            ExchangeOrderRow.market_id == market_id.value,
            ExchangeOrderRow.status.in_([s.value for s in _TERMINAL_OR_OPEN]),
        )
        rows = (await self._session.execute(stmt)).scalars().all()
        return [mappers.order_from_row(r) for r in rows]

    async def list_open_all(self) -> Sequence[ExchangeOrder]:
        """Return every non-terminal local order across all markets.

        Additive interface method (Module 15): authoritative reconciliation must
        enumerate all locally-open orders (independent of market) to detect
        local-open orders that no longer exist on the exchange. Mirrors
        ``list_open`` without the market filter. The shared domain
        ``ExchangeOrderRepository`` Protocol is intentionally left unchanged;
        reconciliation depends on the narrow ``OpenOrderEnumerator`` Protocol,
        which this implementation satisfies structurally.
        """
        stmt = select(ExchangeOrderRow).where(
            ExchangeOrderRow.status.in_([s.value for s in _TERMINAL_OR_OPEN]),
        )
        rows = (await self._session.execute(stmt)).scalars().all()
        return [mappers.order_from_row(r) for r in rows]


class FillRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def insert_idempotent(self, fill: Fill) -> bool:
        stmt = (
            pg_insert(FillRow)
            .values(
                fill_id=fill.fill_id.value,
                order_id=fill.order_id.value,
                token_id=fill.token_id.value,
                side=fill.side.value,
                price=fill.price.value,
                size=fill.size.value,
                fee=fill.fee.value,
                filled_at=fill.filled_at.value,
            )
            .on_conflict_do_nothing(index_elements=["fill_id"])
        )
        result = await self._session.execute(stmt)
        return bool(result.rowcount)

    async def get(self, fill_id: FillId) -> Fill | None:
        row = await self._session.get(FillRow, fill_id.value)
        return None if row is None else mappers.fill_from_row(row)

    async def list_for_order(self, order_id: OrderId) -> Sequence[Fill]:
        stmt = select(FillRow).where(FillRow.order_id == order_id.value)
        rows = (await self._session.execute(stmt)).scalars().all()
        return [mappers.fill_from_row(r) for r in rows]


class InventoryRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def append_snapshot(self, snapshot: InventorySnapshot) -> int:
        row = mappers.inventory_to_row(snapshot)
        self._session.add(row)
        await self._session.flush()
        return row.id

    async def get_latest(self, market_id: MarketId) -> InventorySnapshot | None:
        stmt = (
            select(InventorySnapshotRow)
            .where(InventorySnapshotRow.market_id == market_id.value)
            .order_by(
                InventorySnapshotRow.as_of.desc(), InventorySnapshotRow.id.desc()
            )
            .limit(1)
        )
        row = (await self._session.execute(stmt)).scalars().first()
        return None if row is None else mappers.inventory_from_row(row)


class PairOpportunityRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, opportunity: PairOpportunity) -> int:
        row = mappers.opportunity_to_row(opportunity)
        self._session.add(row)
        await self._session.flush()
        return row.id

    async def list_recent(
        self, market_id: MarketId, *, limit: int = 100
    ) -> Sequence[PairOpportunity]:
        stmt = (
            select(PairOpportunityRow)
            .where(PairOpportunityRow.market_id == market_id.value)
            .order_by(PairOpportunityRow.as_of.desc(), PairOpportunityRow.id.desc())
            .limit(limit)
        )
        rows = (await self._session.execute(stmt)).scalars().all()
        return [mappers.opportunity_from_row(r) for r in rows]


class MatchedPairRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add(self, pair: MatchedPair) -> int:
        row = mappers.matched_pair_to_row(pair)
        self._session.add(row)
        await self._session.flush()
        return row.id

    async def list_for_market(self, market_id: MarketId) -> Sequence[MatchedPair]:
        stmt = select(MatchedPairRow).where(
            MatchedPairRow.market_id == market_id.value
        )
        rows = (await self._session.execute(stmt)).scalars().all()
        return [mappers.matched_pair_from_row(r) for r in rows]


class CtfOperationRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def upsert(self, operation: CtfOperation) -> None:
        await self._session.merge(mappers.ctf_to_row(operation))

    async def get(self, operation_id: str) -> CtfOperation | None:
        row = await self._session.get(CtfOperationRow, operation_id)
        return None if row is None else mappers.ctf_from_row(row)


class BlockchainTransactionRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def record(
        self,
        *,
        operation_key: str,
        chain_id: int,
        status: str,
        created_at: UnixTimestamp,
        operation_id: str | None = None,
        tx_hash: str | None = None,
    ) -> bool:
        stmt = (
            pg_insert(BlockchainTransactionRow)
            .values(
                operation_key=operation_key,
                chain_id=chain_id,
                status=status,
                operation_id=operation_id,
                tx_hash=tx_hash,
                created_at=created_at.value,
            )
            .on_conflict_do_nothing(index_elements=["operation_key"])
        )
        result = await self._session.execute(stmt)
        return bool(result.rowcount)

    async def get(self, operation_key: str) -> Mapping[str, JsonValue] | None:
        stmt = select(BlockchainTransactionRow).where(
            BlockchainTransactionRow.operation_key == operation_key
        )
        row = (await self._session.execute(stmt)).scalars().first()
        if row is None:
            return None
        return {
            "operation_key": row.operation_key,
            "chain_id": row.chain_id,
            "status": row.status,
            "operation_id": row.operation_id,
            "tx_hash": row.tx_hash,
            "created_at": row.created_at,
        }


class ReconciliationRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def record_run(self, result: ReconciliationResult) -> int:
        run = ReconciliationRunRow(
            status=result.status.value,
            as_of=result.as_of.value,
        )
        actions = list(result.recommended_actions)
        for index, description in enumerate(result.discrepancies):
            action = actions[index] if index < len(actions) else None
            run.discrepancies.append(
                ReconciliationDiscrepancyRow(
                    description=description, recommended_action=action
                )
            )
        self._session.add(run)
        await self._session.flush()
        return run.id


class RiskEventRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def record(self, decision: RiskDecision) -> bool:
        stmt = (
            pg_insert(RiskEventRow)
            .values(
                decision_id=decision.decision_id,
                verdict=decision.verdict.value,
                reason=decision.reason,
                approved_size=decision.approved_size.value,
                decided_at=decision.decided_at.value,
            )
            .on_conflict_do_nothing(index_elements=["decision_id"])
        )
        result = await self._session.execute(stmt)
        return bool(result.rowcount)

    async def get(self, decision_id: str) -> RiskDecision | None:
        row = await self._session.get(RiskEventRow, decision_id)
        return None if row is None else mappers.risk_from_row(row)


class KillSwitchEventRepositoryImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def record(
        self,
        *,
        key: str,
        active: bool,
        reason: str,
        created_at: UnixTimestamp,
        actor: str | None = None,
    ) -> int:
        row = KillSwitchEventRow(
            key=key,
            active=active,
            reason=reason,
            actor=actor,
            created_at=created_at.value,
        )
        self._session.add(row)
        await self._session.flush()
        return row.id


class AuditJournalImpl:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def append_event(
        self,
        *,
        event_type: str,
        severity: str,
        created_at: UnixTimestamp,
        payload: Mapping[str, JsonValue] | None = None,
    ) -> int:
        row = SystemEventRow(
            event_type=event_type,
            severity=severity,
            payload=dict(payload or {}),
            created_at=created_at.value,
        )
        self._session.add(row)
        await self._session.flush()
        return row.id


class SqlAlchemyUnitOfWork:
    """A transactional unit of work backed by a single async session.

    Usage::

        async with SqlAlchemyUnitOfWork(session_factory) as uow:
            await uow.orders.upsert(order)
            newly = await uow.record_fill_and_update_inventory(fill, snapshot)
            await uow.commit()

    Leaving the ``async with`` block without calling :meth:`commit` rolls back.
    """

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory
        self._session: AsyncSession | None = None
        self._committed = False

    async def __aenter__(self) -> SqlAlchemyUnitOfWork:
        self._session = self._session_factory()
        self._committed = False
        self._bind_repositories(self._session)
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        assert self._session is not None
        try:
            if exc_type is not None or not self._committed:
                await self._session.rollback()
        finally:
            await self._session.close()
            self._session = None

    def _bind_repositories(self, session: AsyncSession) -> None:
        self.markets = MarketRepositoryImpl(session)
        self.windows = MarketWindowRepositoryImpl(session)
        self.intents = OrderIntentRepositoryImpl(session)
        self.orders = ExchangeOrderRepositoryImpl(session)
        self.fills = FillRepositoryImpl(session)
        self.inventory = InventoryRepositoryImpl(session)
        self.opportunities = PairOpportunityRepositoryImpl(session)
        self.matched_pairs = MatchedPairRepositoryImpl(session)
        self.ctf_operations = CtfOperationRepositoryImpl(session)
        self.blockchain = BlockchainTransactionRepositoryImpl(session)
        self.reconciliation = ReconciliationRepositoryImpl(session)
        self.risk_events = RiskEventRepositoryImpl(session)
        self.kill_switch = KillSwitchEventRepositoryImpl(session)
        self.audit = AuditJournalImpl(session)

    @property
    def session(self) -> AsyncSession:
        if self._session is None:
            raise RuntimeError("unit of work is not active")
        return self._session

    async def commit(self) -> None:
        await self.session.commit()
        self._committed = True

    async def rollback(self) -> None:
        await self.session.rollback()

    async def record_fill_and_update_inventory(
        self,
        fill: Fill,
        resulting_inventory: InventorySnapshot,
        order: ExchangeOrder | None = None,
    ) -> bool:
        """Atomically record a fill and, only if new, apply inventory + order.

        The fill is inserted with ``ON CONFLICT DO NOTHING``; the inventory
        snapshot (and optional order-state update) are only written when the
        fill was newly inserted. Everything happens in the same transaction, so
        a duplicate fill leaves inventory untouched and the caller can commit
        without side effects.
        """
        newly_inserted = await self.fills.insert_idempotent(fill)
        if not newly_inserted:
            return False
        if order is not None:
            await self.orders.upsert(order)
        await self.inventory.append_snapshot(resulting_inventory)
        return True


def create_unit_of_work_factory(
    session_factory: async_sessionmaker[AsyncSession],
) -> Callable[[], SqlAlchemyUnitOfWork]:
    """Return a zero-argument callable that opens a new unit of work."""

    def _factory() -> SqlAlchemyUnitOfWork:
        return SqlAlchemyUnitOfWork(session_factory)

    return _factory


__all__ = [
    "AuditJournalImpl",
    "BlockchainTransactionRepositoryImpl",
    "CtfOperationRepositoryImpl",
    "ExchangeOrderRepositoryImpl",
    "FillRepositoryImpl",
    "InventoryRepositoryImpl",
    "KillSwitchEventRepositoryImpl",
    "MarketRepositoryImpl",
    "MarketWindowRepositoryImpl",
    "MatchedPairRepositoryImpl",
    "OrderIntentRepositoryImpl",
    "PairOpportunityRepositoryImpl",
    "ReconciliationRepositoryImpl",
    "RiskEventRepositoryImpl",
    "SqlAlchemyUnitOfWork",
    "create_unit_of_work_factory",
]
