"""PostgreSQL persistence (Module 3).

Authoritative records live here; the bot rebuilds its position from persisted
state after a crash or partial fill. The domain layer defines repository
protocols (:mod:`polymarket_pair_bot.domain.repositories`); this package
provides their SQLAlchemy 2 async implementations, the ORM models, the async
engine/session factory, the transactional unit of work, and operator admin
tools (migrate / health-check / reset / retention).

Importing this package pulls in SQLAlchemy; domain and strategy code must depend
on the domain protocols, never on this package.
"""

from __future__ import annotations

from polymarket_pair_bot.persistence.base import Base
from polymarket_pair_bot.persistence.engine import (
    create_engine_from_dsn,
    create_session_factory,
)
from polymarket_pair_bot.persistence.repositories import (
    SqlAlchemyUnitOfWork,
    create_unit_of_work_factory,
)

__all__ = [
    "Base",
    "SqlAlchemyUnitOfWork",
    "create_engine_from_dsn",
    "create_session_factory",
    "create_unit_of_work_factory",
]
