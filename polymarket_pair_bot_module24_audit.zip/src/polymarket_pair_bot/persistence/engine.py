"""Async engine / session-factory construction.

The DSN is supplied by the caller (from :class:`PostgresSettings`); this module
never reads environment variables directly, keeping configuration ownership in
the config layer. The engine uses asyncpg and never logs the DSN.
"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)


def create_engine_from_dsn(
    dsn: str,
    *,
    echo: bool = False,
    pool_size: int = 5,
) -> AsyncEngine:
    """Create an async engine from a ``postgresql+asyncpg://`` DSN.

    ``pool_pre_ping`` is enabled so stale connections fail fast and are
    recycled rather than surfacing mid-transaction.
    """
    return create_async_engine(
        dsn,
        echo=echo,
        pool_pre_ping=True,
        pool_size=pool_size,
        future=True,
    )


def create_session_factory(
    engine: AsyncEngine,
) -> async_sessionmaker[AsyncSession]:
    """Create a session factory that does not expire attributes on commit.

    ``expire_on_commit=False`` lets mapped rows be read after commit without a
    lazy refresh, which is important for async code paths.
    """
    return async_sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )


__all__ = ["create_engine_from_dsn", "create_session_factory"]
