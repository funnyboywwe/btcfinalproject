"""Pure conversions between domain entities and ORM rows.

All numeric values move as :class:`decimal.Decimal` (from the domain value
objects' ``.value``) into ``NUMERIC`` columns and back, so no binary float is
ever introduced. These functions contain no I/O.
"""

from __future__ import annotations

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    CtfOperation,
    ExchangeOrder,
    Fill,
    InventorySnapshot,
    MarketWindow,
    MatchedPair,
    OrderIntent,
    OutcomeToken,
    PairOpportunity,
    Position,
    RiskDecision,
)
from polymarket_pair_bot.domain.enums import (
    CtfOperationStatus,
    CtfOperationType,
    OrderSide,
    OrderStatus,
    OutcomeSide,
    RiskVerdict,
    TimeInForce,
)
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    ConditionId,
    FeeAmount,
    FillId,
    MarketId,
    OrderId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TickSize,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.persistence.models import (
    CtfOperationRow,
    ExchangeOrderRow,
    FillRow,
    InventorySnapshotRow,
    MarketRow,
    MarketWindowRow,
    MatchedPairRow,
    OrderIntentRow,
    PairOpportunityRow,
    RiskEventRow,
)


# --------------------------------------------------------------------------- #
# Market / window
# --------------------------------------------------------------------------- #
def market_to_row(market: BinaryMarket) -> MarketRow:
    return MarketRow(
        market_id=market.market_id.value,
        condition_id=market.condition_id.value,
        up_token_id=market.up_token.token_id.value,
        down_token_id=market.down_token.token_id.value,
        up_tick_size=market.up_token.tick_size.value,
        down_tick_size=market.down_token.tick_size.value,
    )


def market_from_row(row: MarketRow, window: MarketWindowRow) -> BinaryMarket:
    market_id = MarketId(row.market_id)
    condition_id = ConditionId(row.condition_id)
    return BinaryMarket(
        market_id=market_id,
        condition_id=condition_id,
        window=window_from_row(window),
        up_token=OutcomeToken(
            token_id=TokenId(row.up_token_id),
            side=OutcomeSide.UP,
            market_id=market_id,
            tick_size=TickSize(row.up_tick_size),
        ),
        down_token=OutcomeToken(
            token_id=TokenId(row.down_token_id),
            side=OutcomeSide.DOWN,
            market_id=market_id,
            tick_size=TickSize(row.down_tick_size),
        ),
    )


def window_to_row(window: MarketWindow) -> MarketWindowRow:
    return MarketWindowRow(
        market_id=window.market_id.value,
        condition_id=window.condition_id.value,
        open_time=window.open_time.value,
        close_time=window.close_time.value,
    )


def window_from_row(row: MarketWindowRow) -> MarketWindow:
    return MarketWindow(
        market_id=MarketId(row.market_id),
        condition_id=ConditionId(row.condition_id),
        open_time=UnixTimestamp(row.open_time),
        close_time=UnixTimestamp(row.close_time),
    )


# --------------------------------------------------------------------------- #
# Order intent / exchange order / fill
# --------------------------------------------------------------------------- #
def intent_to_row(intent: OrderIntent) -> OrderIntentRow:
    return OrderIntentRow(
        intent_id=intent.intent_id,
        market_id=intent.market_id.value,
        token_id=intent.token_id.value,
        side=intent.side.value,
        limit_price=intent.limit_price.value,
        size=intent.size.value,
        time_in_force=intent.time_in_force.value,
        created_at=intent.created_at.value,
    )


def intent_from_row(row: OrderIntentRow) -> OrderIntent:
    return OrderIntent(
        intent_id=row.intent_id,
        market_id=MarketId(row.market_id),
        token_id=TokenId(row.token_id),
        side=OrderSide(row.side),
        limit_price=ProbabilityPrice(row.limit_price),
        size=Shares(row.size),
        time_in_force=TimeInForce(row.time_in_force),
        created_at=UnixTimestamp(row.created_at),
    )


def order_to_row(order: ExchangeOrder, *, market_id: MarketId) -> ExchangeOrderRow:
    return ExchangeOrderRow(
        order_id=order.order_id.value,
        intent_id=order.intent_id,
        token_id=order.token_id.value,
        market_id=market_id.value,
        side=order.side.value,
        limit_price=order.limit_price.value,
        original_size=order.original_size.value,
        filled_size=order.filled_size.value,
        status=order.status.value,
        created_at=order.created_at.value,
        updated_at=order.updated_at.value,
    )


def order_from_row(row: ExchangeOrderRow) -> ExchangeOrder:
    return ExchangeOrder(
        order_id=OrderId(row.order_id),
        intent_id=row.intent_id,
        token_id=TokenId(row.token_id),
        side=OrderSide(row.side),
        limit_price=ProbabilityPrice(row.limit_price),
        original_size=Shares(row.original_size),
        filled_size=Shares(row.filled_size),
        status=OrderStatus(row.status),
        created_at=UnixTimestamp(row.created_at),
        updated_at=UnixTimestamp(row.updated_at),
    )


def fill_to_row(fill: Fill) -> FillRow:
    return FillRow(
        fill_id=fill.fill_id.value,
        order_id=fill.order_id.value,
        token_id=fill.token_id.value,
        side=fill.side.value,
        price=fill.price.value,
        size=fill.size.value,
        fee=fill.fee.value,
        filled_at=fill.filled_at.value,
    )


def fill_from_row(row: FillRow) -> Fill:
    return Fill(
        fill_id=FillId(row.fill_id),
        order_id=OrderId(row.order_id),
        token_id=TokenId(row.token_id),
        side=OrderSide(row.side),
        price=ProbabilityPrice(row.price),
        size=Shares(row.size),
        fee=FeeAmount(row.fee),
        filled_at=UnixTimestamp(row.filled_at),
    )


# --------------------------------------------------------------------------- #
# Inventory
# --------------------------------------------------------------------------- #
def inventory_to_row(snapshot: InventorySnapshot) -> InventorySnapshotRow:
    return InventorySnapshotRow(
        market_id=snapshot.market_id.value,
        up_token_id=snapshot.up_position.token_id.value,
        up_quantity=snapshot.up_position.quantity.value,
        up_average_price=snapshot.up_position.average_price.value,
        up_fees_paid=snapshot.up_position.fees_paid.value,
        down_token_id=snapshot.down_position.token_id.value,
        down_quantity=snapshot.down_position.quantity.value,
        down_average_price=snapshot.down_position.average_price.value,
        down_fees_paid=snapshot.down_position.fees_paid.value,
        matched_pairs=snapshot.matched_pairs.value,
        as_of=snapshot.as_of.value,
    )


def inventory_from_row(row: InventorySnapshotRow) -> InventorySnapshot:
    return InventorySnapshot(
        market_id=MarketId(row.market_id),
        up_position=Position(
            token_id=TokenId(row.up_token_id),
            side=OutcomeSide.UP,
            quantity=Shares(row.up_quantity),
            average_price=ProbabilityPrice(row.up_average_price),
            fees_paid=FeeAmount(row.up_fees_paid),
        ),
        down_position=Position(
            token_id=TokenId(row.down_token_id),
            side=OutcomeSide.DOWN,
            quantity=Shares(row.down_quantity),
            average_price=ProbabilityPrice(row.down_average_price),
            fees_paid=FeeAmount(row.down_fees_paid),
        ),
        matched_pairs=Shares(row.matched_pairs),
        as_of=UnixTimestamp(row.as_of),
    )


# --------------------------------------------------------------------------- #
# Opportunities / matched pairs
# --------------------------------------------------------------------------- #
def opportunity_to_row(opportunity: PairOpportunity) -> PairOpportunityRow:
    return PairOpportunityRow(
        market_id=opportunity.market_id.value,
        size=opportunity.size.value,
        up_price=opportunity.up_price.value,
        down_price=opportunity.down_price.value,
        effective_pair_cost=opportunity.effective_pair_cost.value,
        max_pair_cost=opportunity.max_pair_cost.value,
        within_threshold=opportunity.is_within_threshold,
        as_of=opportunity.as_of.value,
    )


def opportunity_from_row(row: PairOpportunityRow) -> PairOpportunity:
    return PairOpportunity(
        market_id=MarketId(row.market_id),
        size=Shares(row.size),
        up_price=ProbabilityPrice(row.up_price),
        down_price=ProbabilityPrice(row.down_price),
        effective_pair_cost=CollateralAmount(row.effective_pair_cost),
        max_pair_cost=CollateralAmount(row.max_pair_cost),
        as_of=UnixTimestamp(row.as_of),
    )


def matched_pair_to_row(pair: MatchedPair) -> MatchedPairRow:
    return MatchedPairRow(
        market_id=pair.market_id.value,
        condition_id=pair.condition_id.value,
        quantity=pair.quantity.value,
        up_cost=pair.up_cost.value,
        down_cost=pair.down_cost.value,
        fees=pair.fees.value,
        locked_value=pair.locked_value.value,
        net_profit=pair.net_profit.value,
        created_at=pair.created_at.value,
    )


def matched_pair_from_row(row: MatchedPairRow) -> MatchedPair:
    return MatchedPair(
        market_id=MarketId(row.market_id),
        condition_id=ConditionId(row.condition_id),
        quantity=Shares(row.quantity),
        up_cost=CollateralAmount(row.up_cost),
        down_cost=CollateralAmount(row.down_cost),
        fees=FeeAmount(row.fees),
        locked_value=CollateralAmount(row.locked_value),
        net_profit=ProfitAmount(row.net_profit),
        created_at=UnixTimestamp(row.created_at),
    )


# --------------------------------------------------------------------------- #
# CTF operations / risk
# --------------------------------------------------------------------------- #
def ctf_to_row(operation: CtfOperation) -> CtfOperationRow:
    return CtfOperationRow(
        operation_id=operation.operation_id,
        operation_type=operation.operation_type.value,
        condition_id=operation.condition_id.value,
        quantity=operation.quantity.value,
        collateral=operation.collateral.value,
        status=operation.status.value,
        created_at=operation.created_at.value,
    )


def ctf_from_row(row: CtfOperationRow) -> CtfOperation:
    return CtfOperation(
        operation_id=row.operation_id,
        operation_type=CtfOperationType(row.operation_type),
        condition_id=ConditionId(row.condition_id),
        quantity=Shares(row.quantity),
        collateral=CollateralAmount(row.collateral),
        status=CtfOperationStatus(row.status),
        created_at=UnixTimestamp(row.created_at),
    )


def risk_to_row(decision: RiskDecision) -> RiskEventRow:
    return RiskEventRow(
        decision_id=decision.decision_id,
        verdict=decision.verdict.value,
        reason=decision.reason,
        approved_size=decision.approved_size.value,
        decided_at=decision.decided_at.value,
    )


def risk_from_row(row: RiskEventRow) -> RiskDecision:
    return RiskDecision(
        decision_id=row.decision_id,
        verdict=RiskVerdict(row.verdict),
        reason=row.reason,
        decided_at=UnixTimestamp(row.decided_at),
        approved_size=Shares(row.approved_size),
    )


__all__ = [
    "ctf_from_row",
    "ctf_to_row",
    "fill_from_row",
    "fill_to_row",
    "intent_from_row",
    "intent_to_row",
    "inventory_from_row",
    "inventory_to_row",
    "market_from_row",
    "market_to_row",
    "matched_pair_from_row",
    "matched_pair_to_row",
    "opportunity_from_row",
    "opportunity_to_row",
    "order_from_row",
    "order_to_row",
    "risk_from_row",
    "risk_to_row",
    "window_from_row",
    "window_to_row",
]
