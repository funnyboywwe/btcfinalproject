"""SQLAlchemy implementation of the inventory :class:`MarketFillJournal` port.

This is infrastructure: it may import SQLAlchemy. It provides read-only access
to the confirmed-fill journal for one market, returning fills in deterministic
``(filled_at, fill_id)`` order so an inventory rebuild is reproducible.

It does not modify any existing domain repository protocol; it satisfies the
new :class:`~polymarket_pair_bot.inventory.ports.MarketFillJournal` port so the
inventory layer stays dependency-inverted.
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from polymarket_pair_bot.domain.entities import BinaryMarket, Fill
from polymarket_pair_bot.persistence import mappers
from polymarket_pair_bot.persistence.models import FillRow


class MarketFillJournalImpl:
    """Read-only confirmed-fill journal backed by the ``fills`` table.

    Args:
        session_factory: async session maker; each call opens a short-lived
            read-only session.
    """

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def list_market_fills(self, market: BinaryMarket) -> Sequence[Fill]:
        """Return every confirmed fill for the market's Up/Down tokens.

        Ordered by ``(filled_at, fill_id)`` for a deterministic rebuild.
        """
        token_ids = (market.up_token.token_id.value, market.down_token.token_id.value)
        stmt = (
            select(FillRow)
            .where(FillRow.token_id.in_(token_ids))
            .order_by(FillRow.filled_at.asc(), FillRow.fill_id.asc())
        )
        async with self._session_factory() as session:
            rows = (await session.execute(stmt)).scalars().all()
        return [mappers.fill_from_row(row) for row in rows]


__all__ = ["MarketFillJournalImpl"]
