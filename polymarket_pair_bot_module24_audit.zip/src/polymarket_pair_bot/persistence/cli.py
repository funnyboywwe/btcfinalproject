"""Command-line entry point for database operations.

Usage::

    python -m polymarket_pair_bot.persistence.cli migrate
    python -m polymarket_pair_bot.persistence.cli health
    python -m polymarket_pair_bot.persistence.cli reset
    python -m polymarket_pair_bot.persistence.cli retention
    python -m polymarket_pair_bot.persistence.cli counts

Output is plain text and never includes the DSN or any secret.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from collections.abc import Sequence

from polymarket_pair_bot.config import load_config
from polymarket_pair_bot.persistence import admin


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-db",
        description="Database migration and maintenance commands.",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("migrate", help="Apply all migrations up to head")
    sub.add_parser("health", help="Check connectivity and current revision")
    sub.add_parser("reset", help="Drop and recreate all tables (dev/test only)")
    sub.add_parser("retention", help="Delete rows older than retention windows")
    sub.add_parser("counts", help="Print row counts per table")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    config = load_config()

    if args.command == "migrate":
        admin.migrate_to_head(config)
        print("migrations applied to head")
        return 0
    if args.command == "health":
        report = asyncio.run(admin.health_check(config))
        print(
            f"ok={report.ok} detail={report.detail} "
            f"revision={report.current_revision}"
        )
        return 0 if report.ok else 1
    if args.command == "reset":
        asyncio.run(admin.reset_schema(config))
        print("schema reset (dropped and recreated)")
        return 0
    if args.command == "retention":
        deleted = asyncio.run(admin.apply_retention(config))
        for table, count in deleted.items():
            print(f"{table}: deleted {count}")
        return 0
    if args.command == "counts":
        counts = asyncio.run(admin.table_counts(config))
        for table, count in counts.items():
            print(f"{table}: {count}")
        return 0
    return 2


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
