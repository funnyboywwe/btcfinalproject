"""Standalone async repository for recorder snapshot summaries (Module 7).

This is infrastructure code (it may import SQLAlchemy). It deliberately does
*not* extend the domain ``UnitOfWork`` protocol: the recorder is a separate
research tool with its own persistence port (``recorder.ports.SummarySink``),
so wiring it through the trading unit-of-work would broaden that interface
unnecessarily. Instead :class:`PostgresSummarySink` drives this repository via
a plain async session factory.

Inserts are idempotent: ``ON CONFLICT (window_id, sequence) DO NOTHING`` means
re-processing the same Parquet file (e.g. after a crash) never duplicates rows.
This table stores market-data summaries only -- never an order, fill, or any
trading decision.
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from polymarket_pair_bot.domain.recording import RecordedSnapshotSummary
from polymarket_pair_bot.persistence.models import MarketDataSnapshotRow

_COLUMNS: tuple[str, ...] = (
    "window_id",
    "market_slug",
    "sequence",
    "capture_epoch",
    "trigger_reasons",
    "up_token_id",
    "down_token_id",
    "up_status",
    "down_status",
    "up_best_bid",
    "up_best_ask",
    "up_spread",
    "down_best_bid",
    "down_best_ask",
    "down_spread",
    "executable_pair_cost",
    "pair_cost_level",
    "up_is_live",
    "down_is_live",
    "any_stale",
    "any_crossed",
    "up_exchange_timestamp_ms",
    "down_exchange_timestamp_ms",
)


def summary_to_values(summary: RecordedSnapshotSummary) -> dict[str, object]:
    """Project a summary DTO into a column->value mapping for insertion."""
    return {name: getattr(summary, name) for name in _COLUMNS}


def row_to_summary(row: MarketDataSnapshotRow) -> RecordedSnapshotSummary:
    """Rebuild the pure summary DTO from a persisted row."""
    return RecordedSnapshotSummary(
        window_id=row.window_id,
        market_slug=row.market_slug,
        sequence=row.sequence,
        capture_epoch=row.capture_epoch,
        trigger_reasons=row.trigger_reasons,
        up_token_id=row.up_token_id,
        down_token_id=row.down_token_id,
        up_status=row.up_status,
        down_status=row.down_status,
        up_best_bid=row.up_best_bid,
        up_best_ask=row.up_best_ask,
        up_spread=row.up_spread,
        down_best_bid=row.down_best_bid,
        down_best_ask=row.down_best_ask,
        down_spread=row.down_spread,
        executable_pair_cost=row.executable_pair_cost,
        pair_cost_level=row.pair_cost_level,
        up_is_live=row.up_is_live,
        down_is_live=row.down_is_live,
        any_stale=row.any_stale,
        any_crossed=row.any_crossed,
        up_exchange_timestamp_ms=row.up_exchange_timestamp_ms,
        down_exchange_timestamp_ms=row.down_exchange_timestamp_ms,
    )


class MarketDataSnapshotRepositoryImpl:
    """Async repository over :class:`MarketDataSnapshotRow`.

    Operates on a single :class:`AsyncSession`; the caller owns the
    transaction (commit/rollback), mirroring the trading repositories.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add_many(self, summaries: Sequence[RecordedSnapshotSummary]) -> int:
        """Idempotently insert a batch of summaries.

        Returns the number of rows actually inserted (conflicts are ignored).
        """
        if not summaries:
            return 0
        values = [summary_to_values(summary) for summary in summaries]
        statement = (
            pg_insert(MarketDataSnapshotRow)
            .values(values)
            .on_conflict_do_nothing(
                constraint="uq_market_data_snapshots_window_sequence"
            )
            .returning(MarketDataSnapshotRow.id)
        )
        result = await self._session.execute(statement)
        return len(result.scalars().all())

    async def list_window(
        self,
        window_id: str,
        *,
        limit: int | None = None,
    ) -> list[RecordedSnapshotSummary]:
        """Return summaries for a window ordered by (capture_epoch, sequence)."""
        statement = (
            select(MarketDataSnapshotRow)
            .where(MarketDataSnapshotRow.window_id == window_id)
            .order_by(
                MarketDataSnapshotRow.capture_epoch,
                MarketDataSnapshotRow.sequence,
            )
        )
        if limit is not None:
            statement = statement.limit(limit)
        result = await self._session.execute(statement)
        return [row_to_summary(row) for row in result.scalars().all()]

    async def list_range(
        self,
        *,
        start_epoch: int,
        end_epoch: int,
        limit: int | None = None,
    ) -> list[RecordedSnapshotSummary]:
        """Return summaries whose capture_epoch is within [start, end]."""
        statement = (
            select(MarketDataSnapshotRow)
            .where(MarketDataSnapshotRow.capture_epoch >= start_epoch)
            .where(MarketDataSnapshotRow.capture_epoch <= end_epoch)
            .order_by(
                MarketDataSnapshotRow.window_id,
                MarketDataSnapshotRow.capture_epoch,
                MarketDataSnapshotRow.sequence,
            )
        )
        if limit is not None:
            statement = statement.limit(limit)
        result = await self._session.execute(statement)
        return [row_to_summary(row) for row in result.scalars().all()]


__all__ = [
    "MarketDataSnapshotRepositoryImpl",
    "row_to_summary",
    "summary_to_values",
]
