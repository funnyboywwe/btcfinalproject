"""SQLAlchemy declarative base, metadata naming convention, and column types.

This module is the only place that defines the ORM ``metadata`` object; Alembic
and every ORM model share it. A deterministic constraint naming convention is
configured so migrations and autogenerate produce stable, predictable names.

Monetary, price and quantity columns use ``NUMERIC`` (fixed-point) so values
round-trip as :class:`decimal.Decimal` and are **never** stored as binary
floats. Domain timestamps (integer seconds, UTC) are stored as ``BIGINT``; a
separate server-side ``recorded_at`` (``TIMESTAMPTZ``) records ingestion time
for retention.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Annotated

from sqlalchemy import BigInteger, DateTime, MetaData, Numeric, func
from sqlalchemy.orm import DeclarativeBase, mapped_column

# Deterministic names for indexes/constraints so Alembic diffs stay stable.
NAMING_CONVENTION = {
    "ix": "ix_%(table_name)s_%(column_0_name)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

# Fixed-point column widths. Scale 6 matches the domain quantum (1e-6).
# Prices/probabilities live in [0, 1]; quantities/USD may be large.
PRICE_NUMERIC = Numeric(precision=12, scale=6)
SHARES_NUMERIC = Numeric(precision=30, scale=6)
USD_NUMERIC = Numeric(precision=30, scale=6)
PROFIT_NUMERIC = Numeric(precision=30, scale=6)
BPS_NUMERIC = Numeric(precision=18, scale=4)

# Reusable annotated column types (SQLAlchemy 2 typed mapping).
DecimalPrice = Annotated[Decimal, mapped_column(PRICE_NUMERIC)]
DecimalShares = Annotated[Decimal, mapped_column(SHARES_NUMERIC)]
DecimalUsd = Annotated[Decimal, mapped_column(USD_NUMERIC)]
DecimalProfit = Annotated[Decimal, mapped_column(PROFIT_NUMERIC)]
UnixSeconds = Annotated[int, mapped_column(BigInteger)]


class Base(DeclarativeBase):
    """Declarative base carrying the shared, convention-named metadata."""

    metadata = MetaData(naming_convention=NAMING_CONVENTION)


def recorded_at_column() -> object:
    """Return a server-defaulted ``TIMESTAMPTZ`` ingestion-time column.

    Used for retention on high-volume tables. Ingestion time is set by the
    database, independent of any domain timestamp supplied by the caller.
    """
    return mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        index=True,
    )


__all__ = [
    "Base",
    "BPS_NUMERIC",
    "DecimalPrice",
    "DecimalProfit",
    "DecimalShares",
    "DecimalUsd",
    "NAMING_CONVENTION",
    "PRICE_NUMERIC",
    "PROFIT_NUMERIC",
    "SHARES_NUMERIC",
    "USD_NUMERIC",
    "UnixSeconds",
    "recorded_at_column",
    "datetime",
]
