"""Shared primitives usable from any layer (health state, common types)."""
