"""Application health-state primitives and health-check contracts.

This module is intentionally dependency-light: it imports only the standard
library so it is safe to import from any layer (domain, app, infrastructure).
Nothing here performs I/O.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable


class HealthState(str, Enum):
    """Coarse lifecycle health of the whole application."""

    STARTING = "starting"
    READY = "ready"
    DEGRADED = "degraded"
    STOPPING = "stopping"


@dataclass(frozen=True, slots=True)
class HealthSnapshot:
    """Immutable point-in-time view of the application's health."""

    state: HealthState
    detail: str
    updated_at: datetime


@dataclass(frozen=True, slots=True)
class HealthCheckResult:
    """Result of a single dependency probe.

    ``detail`` must never contain secrets or connection strings; use short,
    non-sensitive descriptions only.
    """

    healthy: bool
    detail: str = ""


@runtime_checkable
class HealthCheck(Protocol):
    """Structural interface for a dependency health probe."""

    @property
    def name(self) -> str: ...

    async def check(self) -> HealthCheckResult: ...


class HealthTracker:
    """Async-safe holder for the current application health state."""

    def __init__(self, initial: HealthState = HealthState.STARTING) -> None:
        self._state = initial
        self._detail = ""
        self._updated_at = _utcnow()
        self._lock = asyncio.Lock()

    @property
    def state(self) -> HealthState:
        """Return the current state without blocking."""
        return self._state

    def snapshot(self) -> HealthSnapshot:
        """Return an immutable snapshot of the current health."""
        return HealthSnapshot(self._state, self._detail, self._updated_at)

    async def set(self, state: HealthState, detail: str = "") -> HealthSnapshot:
        """Atomically update the state and return the new snapshot."""
        async with self._lock:
            self._state = state
            self._detail = detail
            self._updated_at = _utcnow()
            return HealthSnapshot(self._state, self._detail, self._updated_at)


def _utcnow() -> datetime:
    return datetime.now(UTC)
