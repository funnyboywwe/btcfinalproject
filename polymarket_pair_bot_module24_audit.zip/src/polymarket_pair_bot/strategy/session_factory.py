"""Composition helpers for the pair-accumulation state machine (Module 18).

These builders translate typed configuration (:class:`StateMachineSettings`,
:class:`PairStrategySettings`) into the infrastructure-free
:class:`SessionLimits` the machine reasons against, and assemble a
:class:`PairAccumulationStateMachine` from already-constructed ports.

The factory itself performs no I/O and constructs no concrete adapters: the
production :class:`SessionStore` (SQLAlchemy), :class:`MergePort` (CTF service),
risk, reconciliation and kill-switch adapters are wired at the application
composition layer and passed in here. This keeps the strategy package free of
SQLAlchemy / HTTP / blockchain imports (dependency inversion).
"""

from __future__ import annotations

from decimal import Decimal

from polymarket_pair_bot.config.models import (
    PairStrategySettings,
    StateMachineSettings,
)
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    Shares,
    TickSize,
)
from polymarket_pair_bot.execution.ports import ExecutionAdapter
from polymarket_pair_bot.strategy.detector import DetectorConfig, PairDetector
from polymarket_pair_bot.strategy.engine import EngineParameters
from polymarket_pair_bot.strategy.session_machine import (
    PairAccumulationStateMachine,
)
from polymarket_pair_bot.strategy.session_models import SessionLimits
from polymarket_pair_bot.strategy.session_ports import (
    KillSwitchPort,
    MergePort,
    ReconciliationPort,
    RiskApprovalPort,
    SessionStore,
)


def build_session_limits(
    *,
    state_machine: StateMachineSettings,
    strategy: PairStrategySettings,
    engine_parameters: EngineParameters,
) -> SessionLimits:
    """Build :class:`SessionLimits` from typed settings and engine parameters.

    The maximum effective pair cost and the conservative overhead are sourced
    from the strategy settings / engine so the machine and the detector share
    exactly one budget definition.
    """
    return SessionLimits(
        target_pair_size=Shares(state_machine.target_pair_size_tokens),
        first_leg_cutoff_seconds=state_machine.first_leg_cutoff_seconds,
        mandatory_cancel_seconds=state_machine.mandatory_cancel_seconds,
        max_unmatched_shares=Shares(state_machine.max_unmatched_shares),
        max_unmatched_seconds=state_machine.max_unmatched_seconds,
        unmatched_warning_ratio=state_machine.unmatched_warning_ratio,
        merge_min_net_value=CollateralAmount(state_machine.merge_min_net_value_usd),
        max_effective_pair_cost=CollateralAmount(strategy.max_effective_pair_cost_usd),
        overhead=engine_parameters.overhead,
        reconcile_on_uncertain=state_machine.reconcile_on_uncertain,
        processed_id_history=state_machine.processed_id_history,
    )


def build_pair_detector(
    *,
    strategy: PairStrategySettings,
    tick_size: TickSize,
    min_seconds_to_close: int,
) -> PairDetector:
    """Build a pure :class:`PairDetector` for the state machine to consult."""
    engine_parameters = EngineParameters.from_strategy_settings(
        strategy,
        tick_size,
        min_seconds_to_close=min_seconds_to_close,
    )
    return PairDetector(config=DetectorConfig(engine_parameters=engine_parameters))


def build_state_machine(
    *,
    state_machine_settings: StateMachineSettings,
    strategy: PairStrategySettings,
    tick_size: TickSize,
    store: SessionStore,
    execution: ExecutionAdapter,
    risk: RiskApprovalPort,
    merge: MergePort,
    reconciliation: ReconciliationPort,
    kill_switch: KillSwitchPort,
    detector: PairDetector | None = None,
) -> PairAccumulationStateMachine:
    """Assemble a :class:`PairAccumulationStateMachine` from ports and config.

    ``detector`` may be supplied for full control; otherwise one is built from
    the strategy settings using the same budget the limits are derived from.
    """
    if detector is None:
        detector = build_pair_detector(
            strategy=strategy,
            tick_size=tick_size,
            min_seconds_to_close=state_machine_settings.first_leg_cutoff_seconds,
        )
    limits = build_session_limits(
        state_machine=state_machine_settings,
        strategy=strategy,
        engine_parameters=detector.config.engine_parameters,
    )
    return PairAccumulationStateMachine(
        store=store,
        execution=execution,
        risk=risk,
        merge=merge,
        reconciliation=reconciliation,
        kill_switch=kill_switch,
        detector=detector,
        limits=limits,
    )


__all__ = [
    "build_pair_detector",
    "build_session_limits",
    "build_state_machine",
]
