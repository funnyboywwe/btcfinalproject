"""Event types that drive the pair-accumulation state machine (Module 18).

The machine is strictly event-driven (requirement 2): it never polls or spawns
its own background tasks. An outer supervisor (a later module) feeds it typed,
validated :class:`SessionEvent` instances and applies the returned transitions.

Each event carries an ``event_id`` that is unique per logical occurrence; the
machine uses it to make processing idempotent (requirement 3). Events are pure,
immutable data (domain value objects only); they never carry secrets and never
perform I/O.
"""

from __future__ import annotations

from dataclasses import dataclass

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    Fill,
    OrderBookSnapshot,
    ReconciliationResult,
)
from polymarket_pair_bot.domain.enums import CtfOperationStatus
from polymarket_pair_bot.domain.value_objects import MarketId, Shares, UnixTimestamp
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger


@dataclass(frozen=True, slots=True)
class SessionEvent:
    """Base type for every state-machine stimulus.

    Fields:
        event_id: unique, stable id for this occurrence (idempotency key).
        market_id: the market/session this event pertains to.
        occurred_at: wall-clock instant the event describes (UTC seconds).
    """

    event_id: str
    market_id: MarketId
    occurred_at: UnixTimestamp

    def __post_init__(self) -> None:
        if not self.event_id.strip():
            raise ValueError("event_id must not be empty")


@dataclass(frozen=True, slots=True)
class MarketValidatedEvent(SessionEvent):
    """A BTC 5-minute market has been discovered and validated (requirement 5).

    Creates the session (``DISCOVERED``) and begins book synchronization.
    """

    market: BinaryMarket


@dataclass(frozen=True, slots=True)
class BooksUpdatedEvent(SessionEvent):
    """Fresh (or stale) Up/Down books observed for the market (requirement 5).

    ``up_is_fresh`` / ``down_is_fresh`` fold together the feed-liveness and
    freshness checks performed upstream (Modules 6/7). ``feed_live`` is the raw
    transport liveness. ``seconds_to_close`` is whole seconds until the window
    closes. A book may be ``None`` during an outage (fail closed).
    """

    market: BinaryMarket
    up_book: OrderBookSnapshot | None
    down_book: OrderBookSnapshot | None
    up_is_fresh: bool
    down_is_fresh: bool
    feed_live: bool
    seconds_to_close: int

    @property
    def books_fresh(self) -> bool:
        return (
            self.feed_live
            and self.up_is_fresh
            and self.down_is_fresh
            and self.up_book is not None
            and self.down_book is not None
        )


@dataclass(frozen=True, slots=True)
class FillConfirmedEvent(SessionEvent):
    """An authoritative, confirmed fill (never an ack) for this market.

    Fills are NOT assumed unique; the machine de-duplicates by ``fill.fill_id``
    (requirement 3). Only confirmed fills move inventory.
    """

    market: BinaryMarket
    fill: Fill


@dataclass(frozen=True, slots=True)
class LimitCheckEvent(SessionEvent):
    """Periodic check of unmatched size and age against limits (requirements 8/9)."""

    market: BinaryMarket


@dataclass(frozen=True, slots=True)
class MergeEvaluateEvent(SessionEvent):
    """Evaluate whether a CTF merge of matched pairs is economical (requirement 10)."""

    market: BinaryMarket


@dataclass(frozen=True, slots=True)
class MergeResultEvent(SessionEvent):
    """Authoritative outcome of a submitted CTF merge (requirement 10).

    ``UNKNOWN`` is never treated as success; it routes to reconciliation.
    """

    operation_id: str
    status: CtfOperationStatus
    quantity: Shares


@dataclass(frozen=True, slots=True)
class WindowClosingEvent(SessionEvent):
    """The market window is approaching close (requirements 11/12).

    Used to cancel resting passive orders before close and to stop opening new
    first legs.
    """

    market: BinaryMarket
    seconds_to_close: int


@dataclass(frozen=True, slots=True)
class KillSwitchEvent(SessionEvent):
    """The global kill switch has been activated (fail closed).

    Cancellation of resting orders remains possible; no new orders are placed.
    """

    reason: str


@dataclass(frozen=True, slots=True)
class UncertainEvent(SessionEvent):
    """An uncertain / unknown external outcome (requirement 13).

    Examples: a timed-out submission, an unknown order status, a user-stream
    reconnect. The machine cancels where safe, reconciles, and stops.
    """

    reason: str
    trigger: ReconciliationTrigger


@dataclass(frozen=True, slots=True)
class ReconciledEvent(SessionEvent):
    """An authoritative reconciliation result has been produced (requirement 13).

    A consistent result lets a stopped session resume; any discrepancy halts it.
    """

    result: ReconciliationResult


__all__ = [
    "BooksUpdatedEvent",
    "FillConfirmedEvent",
    "KillSwitchEvent",
    "LimitCheckEvent",
    "MarketValidatedEvent",
    "MergeEvaluateEvent",
    "MergeResultEvent",
    "ReconciledEvent",
    "SessionEvent",
    "UncertainEvent",
    "WindowClosingEvent",
]
