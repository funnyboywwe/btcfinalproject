"""Executable VWAP, fee and pair-cost calculation engine (Module 8).

Pure module - no I/O, no network, no database, no env reads, no side effects.
All monetary values are Decimal or domain value objects. No binary floats for
monetary quantities. Conservative rounding: fees UP, profit DOWN.

Makes NO profitability claim.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, localcontext
from enum import Enum
from typing import TYPE_CHECKING

from polymarket_pair_bot.domain.arithmetic import (
    ExecutableVwap,
    executable_vwap,
    taker_fee,
)
from polymarket_pair_bot.domain.entities import OrderBookSnapshot
from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.precision import (
    DOLLAR,
    computation_context,
    round_down_to_tick,
    round_fee_up,
    round_profit_down,
    round_shares,
)
from polymarket_pair_bot.domain.value_objects import (
    BasisPoints,
    CollateralAmount,
    FeeAmount,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    TickSize,
)

if TYPE_CHECKING:
    from polymarket_pair_bot.config.models import PairStrategySettings


@dataclass(frozen=True, slots=True)
class FeeParameters:
    """Fee model for order execution.

    Polymarket CLOB typically charges taker fees and zero maker fees.
    All values are Decimal-backed; no binary floats.
    """
    taker_fee_bps: BasisPoints
    maker_fee_bps: BasisPoints = field(
        default_factory=lambda: BasisPoints(Decimal(0))
    )


@dataclass(frozen=True, slots=True)
class EngineParameters:
    """All configuration knobs for one pair-cost evaluation.

    Monetary fields are domain value objects (Decimal-backed). Durations and
    counts are plain int (never monetary). Conservative: max_effective_pair_cost
    must be strictly below $1 (the CTF redemption value).
    """
    fee_parameters: FeeParameters
    slippage_reserve: CollateralAmount
    merge_gas_overhead: CollateralAmount
    safety_reserve: CollateralAmount
    max_effective_pair_cost: CollateralAmount
    required_net_profit: ProfitAmount
    min_book_depth: Shares
    min_seconds_to_close: int
    tick_size: TickSize

    def __post_init__(self) -> None:
        if self.min_seconds_to_close < 0:
            raise ValueError("min_seconds_to_close must be non-negative")
        if self.max_effective_pair_cost.value >= DOLLAR:
            raise ValueError(
                "max_effective_pair_cost must be < 1 USD"
            )

    @property
    def overhead(self) -> CollateralAmount:
        """Non-fee overhead per pair: slippage + gas + safety (rounds UP)."""
        with localcontext(computation_context()):
            total = (
                self.slippage_reserve.value
                + self.merge_gas_overhead.value
                + self.safety_reserve.value
            )
        return CollateralAmount(round_fee_up(total))

    @classmethod
    def from_strategy_settings(
        cls,
        strategy: "PairStrategySettings",
        tick_size: TickSize,
        *,
        min_book_depth: Shares | None = None,
        min_seconds_to_close: int = 60,
        required_net_profit: ProfitAmount | None = None,
    ) -> "EngineParameters":
        """Build from PairStrategySettings. No pydantic-settings import here."""
        fee_params = FeeParameters(
            taker_fee_bps=BasisPoints(strategy.assumed_taker_fee_bps),
        )
        with localcontext(computation_context()):
            slippage_usd = strategy.assumed_slippage_bps * Decimal("0.0001")
        return cls(
            fee_parameters=fee_params,
            slippage_reserve=CollateralAmount(round_fee_up(slippage_usd)),
            merge_gas_overhead=CollateralAmount(strategy.merge_gas_overhead_usd),
            safety_reserve=CollateralAmount(strategy.safety_reserve_usd),
            max_effective_pair_cost=CollateralAmount(
                strategy.max_effective_pair_cost_usd
            ),
            required_net_profit=required_net_profit
            if required_net_profit is not None
            else ProfitAmount(Decimal(0)),
            min_book_depth=min_book_depth
            if min_book_depth is not None
            else Shares(strategy.min_pair_size_tokens),
            min_seconds_to_close=min_seconds_to_close,
            tick_size=tick_size,
        )


@dataclass(frozen=True, slots=True)
class InventorySummary:
    """Caller-supplied snapshot of confirmed position.

    Only confirmed fills count. Intents, acknowledged orders, partial fills
    are NEVER a matched pair.
    """
    unmatched_up: Shares
    unmatched_down: Shares
    matched_pairs: Shares

    @classmethod
    def empty(cls) -> "InventorySummary":
        return cls(
            unmatched_up=Shares(Decimal(0)),
            unmatched_down=Shares(Decimal(0)),
            matched_pairs=Shares(Decimal(0)),
        )


@dataclass(frozen=True, slots=True)
class DepthAssessment:
    """Ask-side depth check for one outcome token."""
    side: OutcomeSide
    available: Shares
    required: Shares
    is_sufficient: bool
    levels_consumed: int


@dataclass(frozen=True, slots=True)
class TickSensitivity:
    """Net profit after N adverse ticks on both sides simultaneously.

    Each extra tick costs 2 * N * tick * quantity more. Both sides move
    simultaneously (conservative scenario).
    """
    ticks: int
    cost_increase: CollateralAmount
    adjusted_net_profit: ProfitAmount
    remains_viable: bool


class PairOpportunityResult(str, Enum):
    """Classification of the evaluated pair-cost snapshot."""
    OBSERVATION_ONLY = "observation_only"
    PASSIVE_FIRST_LEG = "passive_first_leg"
    PASSIVE_SECOND_LEG = "passive_second_leg"
    IMMEDIATE_TWO_LEG = "immediate_two_leg"
    MATCHED_PAIR = "matched_pair"
    REJECTED = "rejected"


@dataclass(frozen=True, slots=True)
class PairCostResult:
    """Complete, immutable output of one pair-cost engine evaluation.

    Every input, intermediate result and rejection reason is preserved.
    No field contains a secret or credential.
    """
    # inputs
    target_quantity: Shares
    parameters: EngineParameters
    inventory: InventorySummary
    seconds_to_close: int
    up_is_fresh: bool
    down_is_fresh: bool

    # per-side VWAP (ask-side walk for taker fills)
    up_vwap: ExecutableVwap
    down_vwap: ExecutableVwap

    # max executable quantity (min of each side's filled)
    max_executable_quantity: Shares

    # taker acquisition costs (at VWAP ask prices)
    up_taker_cost: CollateralAmount
    down_taker_cost: CollateralAmount

    # maker acquisition costs (at best-bid prices); None when no bids
    up_maker_cost: CollateralAmount | None
    down_maker_cost: CollateralAmount | None

    # fee estimates
    taker_fee_up: FeeAmount
    taker_fee_down: FeeAmount
    total_taker_fee: FeeAmount

    # effective pair costs
    effective_pair_cost_taker: CollateralAmount
    effective_pair_cost_maker: CollateralAmount | None

    # profit (taker scenario)
    gross_profit: ProfitAmount   # $1 - up_taker_cost - down_taker_cost
    net_profit: ProfitAmount     # $1 - effective_pair_cost_taker

    # max acceptable prices (tick-aligned, None when not computable)
    max_first_leg_price: ProbabilityPrice | None
    max_second_leg_price: ProbabilityPrice | None

    # sensitivity (1, 2, 3 adverse ticks on both sides)
    tick_sensitivity: tuple[TickSensitivity, TickSensitivity, TickSensitivity]

    # depth
    up_depth: DepthAssessment
    down_depth: DepthAssessment

    # classification
    result: PairOpportunityResult
    rejection_reasons: tuple[str, ...]

    @property
    def is_rejected(self) -> bool:
        return self.result is PairOpportunityResult.REJECTED

    @property
    def is_actionable(self) -> bool:
        return self.result not in (
            PairOpportunityResult.REJECTED,
            PairOpportunityResult.OBSERVATION_ONLY,
        )

    @property
    def is_immediate_candidate(self) -> bool:
        return self.result is PairOpportunityResult.IMMEDIATE_TWO_LEG


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _empty_vwap(requested: Shares) -> ExecutableVwap:
    return ExecutableVwap(
        average_price=None,
        filled=Shares(Decimal(0)),
        requested=requested,
        is_complete=False,
    )


def _assess_depth(
    book: OrderBookSnapshot | None,
    side: OutcomeSide,
    required: Shares,
) -> DepthAssessment:
    if book is None:
        return DepthAssessment(side=side, available=Shares(Decimal(0)),
                               required=required, is_sufficient=False,
                               levels_consumed=0)
    target = required.value
    total = Decimal(0)
    levels_consumed = 0
    for level in book.asks:
        if total >= target:
            break
        take = level.size.value if level.size.value < (target - total) else (target - total)
        total += take
        levels_consumed += 1
    with localcontext(computation_context()):
        available_dec = round_shares(total)
    available = Shares(available_dec)
    return DepthAssessment(
        side=side, available=available, required=required,
        is_sufficient=available.value >= target, levels_consumed=levels_consumed,
    )


def _cost(vwap: ExecutableVwap, quantity: Shares) -> CollateralAmount:
    if vwap.average_price is None or quantity.value <= 0:
        return CollateralAmount(Decimal(0))
    with localcontext(computation_context()):
        notional = vwap.average_price.value * quantity.value
    return CollateralAmount(round_profit_down(notional))


def _maker_cost(
    book: OrderBookSnapshot | None,
    quantity: Shares,
) -> CollateralAmount | None:
    if book is None or not book.bids:
        return None
    best_bid = book.bids[0].price
    with localcontext(computation_context()):
        notional = best_bid.value * quantity.value
    return CollateralAmount(round_profit_down(notional))


def _compute_effective_pair_cost(
    up_cost: CollateralAmount,
    down_cost: CollateralAmount,
    fee_bps: BasisPoints,
    overhead: CollateralAmount,
) -> CollateralAmount:
    """(up + down) * (1 + fee_fraction) + overhead, rounded UP."""
    with localcontext(computation_context()):
        total_notional = up_cost.value + down_cost.value
        fee_amount = total_notional * fee_bps.as_fraction()
        total = total_notional + fee_amount + overhead.value
    return CollateralAmount(round_fee_up(total))


def _compute_max_price(
    *,
    max_cost: Decimal,
    overhead: Decimal,
    fee_fraction: Decimal,
    qty: Decimal,
    other_leg_cost: Decimal,
    tick: Decimal,
) -> ProbabilityPrice | None:
    """Solve for max this_price such that total effective cost <= max_cost.

    Formula: (this_price*qty + other_leg_cost) * (1+fee) + overhead <= max_cost
    Result is rounded DOWN to the nearest tick.
    """
    if qty <= 0:
        return None
    with localcontext(computation_context()):
        budget = (max_cost - overhead) / (1 + fee_fraction)
        max_leg_cost = budget - other_leg_cost
        max_price = max_leg_cost / qty
    if max_price <= 0:
        return None
    rounded = round_down_to_tick(max_price, tick)
    if rounded <= 0:
        return None
    try:
        return ProbabilityPrice(rounded)
    except ValueError:
        return None


def _tick_sensitivity(
    net_profit: ProfitAmount,
    quantity: Shares,
    tick_size: TickSize,
    required_net_profit: ProfitAmount,
    ticks: int,
) -> TickSensitivity:
    """Net profit after N adverse ticks on both sides: cost increases 2*N*tick*qty."""
    with localcontext(computation_context()):
        increase = Decimal(2) * Decimal(ticks) * tick_size.value * quantity.value
        adjusted = net_profit.value - increase
    cost_increase = CollateralAmount(round_fee_up(increase))
    adjusted_profit = ProfitAmount(round_profit_down(adjusted))
    return TickSensitivity(
        ticks=ticks,
        cost_increase=cost_increase,
        adjusted_net_profit=adjusted_profit,
        remains_viable=adjusted_profit.value >= required_net_profit.value,
    )


def _classify(
    *,
    rejection_reasons: list[str],
    inventory: InventorySummary,
    target_quantity: Shares,
    effective_pair_cost_taker: CollateralAmount,
    effective_pair_cost_maker: CollateralAmount | None,
    net_profit: ProfitAmount,
    parameters: EngineParameters,
) -> PairOpportunityResult:
    if rejection_reasons:
        return PairOpportunityResult.REJECTED

    target = target_quantity.value
    max_cost = parameters.max_effective_pair_cost.value
    req_profit = parameters.required_net_profit.value

    # MATCHED_PAIR: existing inventory covers both sides
    if (
        inventory.unmatched_up.value >= target
        and inventory.unmatched_down.value >= target
    ):
        return PairOpportunityResult.MATCHED_PAIR

    # PASSIVE_SECOND_LEG: one side already filled, need the other
    if inventory.unmatched_up.value >= target and inventory.unmatched_down.value < target:
        return PairOpportunityResult.PASSIVE_SECOND_LEG
    if inventory.unmatched_down.value >= target and inventory.unmatched_up.value < target:
        return PairOpportunityResult.PASSIVE_SECOND_LEG

    # IMMEDIATE_TWO_LEG: taker cost within budget and profit meets threshold
    if (
        effective_pair_cost_taker.value <= max_cost
        and net_profit.value >= req_profit
    ):
        return PairOpportunityResult.IMMEDIATE_TWO_LEG

    # PASSIVE_FIRST_LEG: taker too expensive, maker would be within budget
    if (
        effective_pair_cost_maker is not None
        and effective_pair_cost_maker.value <= max_cost
    ):
        return PairOpportunityResult.PASSIVE_FIRST_LEG

    return PairOpportunityResult.OBSERVATION_ONLY


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def evaluate_pair_cost(
    up_book: OrderBookSnapshot | None,
    down_book: OrderBookSnapshot | None,
    *,
    target_quantity: Shares,
    inventory: InventorySummary,
    parameters: EngineParameters,
    seconds_to_close: int,
    up_is_fresh: bool,
    down_is_fresh: bool,
) -> PairCostResult:
    """Evaluate the all-in cost and opportunity classification for a pair trade.

    Pure and synchronous - call freely from the event loop without await.
    All monetary values are Decimal-backed. No binary floats for monetary use.
    Makes NO profitability claim.
    """
    target_quantity.require_positive()

    rejection_reasons: list[str] = []

    # --- Staleness / availability checks (fail-closed) ---
    if up_book is None:
        rejection_reasons.append("up_book: feed unavailable (no snapshot)")
    if not up_is_fresh:
        rejection_reasons.append("up_book: feed is stale or not live")
    if down_book is None:
        rejection_reasons.append("down_book: feed unavailable (no snapshot)")
    if not down_is_fresh:
        rejection_reasons.append("down_book: feed is stale or not live")

    if seconds_to_close < parameters.min_seconds_to_close:
        rejection_reasons.append(
            f"window_too_close: {seconds_to_close}s < "
            f"min {parameters.min_seconds_to_close}s to close"
        )

    # --- Depth assessments (always computed for observability) ---
    up_depth = _assess_depth(up_book, OutcomeSide.UP, target_quantity)
    down_depth = _assess_depth(down_book, OutcomeSide.DOWN, target_quantity)

    if not up_depth.is_sufficient:
        rejection_reasons.append(
            f"up_depth_insufficient: available "
            f"{up_depth.available.value} < required {target_quantity.value}"
        )
    if not down_depth.is_sufficient:
        rejection_reasons.append(
            f"down_depth_insufficient: available "
            f"{down_depth.available.value} < required {target_quantity.value}"
        )

    # min_book_depth guard
    if up_book is not None and up_depth.available.value < parameters.min_book_depth.value:
        msg = (
            f"up_book_below_min_depth: "
            f"{up_depth.available.value} < min {parameters.min_book_depth.value}"
        )
        if msg not in rejection_reasons:
            rejection_reasons.append(msg)
    if down_book is not None and down_depth.available.value < parameters.min_book_depth.value:
        msg = (
            f"down_book_below_min_depth: "
            f"{down_depth.available.value} < min {parameters.min_book_depth.value}"
        )
        if msg not in rejection_reasons:
            rejection_reasons.append(msg)

    # --- VWAP computations ---
    if up_book is not None and up_book.asks:
        up_vwap = executable_vwap(up_book.asks, target_quantity)
    else:
        up_vwap = _empty_vwap(target_quantity)

    if down_book is not None and down_book.asks:
        down_vwap = executable_vwap(down_book.asks, target_quantity)
    else:
        down_vwap = _empty_vwap(target_quantity)

    # --- Max executable quantity ---
    with localcontext(computation_context()):
        max_exec_raw = round_shares(
            min(up_vwap.filled.value, down_vwap.filled.value)
        )
    max_executable_quantity = Shares(max_exec_raw)

    # --- Taker acquisition costs (TOTAL position, for capital reporting) ---
    up_taker_cost = _cost(up_vwap, target_quantity)
    down_taker_cost = _cost(down_vwap, target_quantity)

    # --- Maker acquisition costs (TOTAL position, for capital reporting) ---
    up_maker_cost = _maker_cost(up_book, target_quantity)
    down_maker_cost = _maker_cost(down_book, target_quantity)

    # --- Fee estimates on TOTAL position notional ---
    fee_bps = parameters.fee_parameters.taker_fee_bps
    taker_fee_up = taker_fee(up_taker_cost, fee_bps)
    taker_fee_down = taker_fee(down_taker_cost, fee_bps)
    with localcontext(computation_context()):
        total_fee_raw = taker_fee_up.value + taker_fee_down.value
    total_taker_fee = FeeAmount(round_fee_up(total_fee_raw))

    # --- PER-PAIR prices (from VWAP; compare against max_effective_pair_cost which is per pair) ---
    with localcontext(computation_context()):
        up_price_per_pair = (
            up_vwap.average_price.value if up_vwap.average_price is not None
            else Decimal(0)
        )
        down_price_per_pair = (
            down_vwap.average_price.value if down_vwap.average_price is not None
            else Decimal(0)
        )

    # Maker per-pair prices (best bid = cost if posting maker order)
    up_bid_per_pair: Decimal | None = None
    if up_book is not None and up_book.bids:
        up_bid_per_pair = up_book.bids[0].price.value
    down_bid_per_pair: Decimal | None = None
    if down_book is not None and down_book.bids:
        down_bid_per_pair = down_book.bids[0].price.value

    # --- Effective pair cost (PER PAIR; compare against max_effective_pair_cost) ---
    overhead = parameters.overhead
    effective_pc_taker = _compute_effective_pair_cost(
        CollateralAmount(round_profit_down(up_price_per_pair)),
        CollateralAmount(round_profit_down(down_price_per_pair)),
        fee_bps,
        overhead,
    )

    effective_pc_maker: CollateralAmount | None = None
    if up_bid_per_pair is not None and down_bid_per_pair is not None:
        maker_fee_bps = parameters.fee_parameters.maker_fee_bps
        effective_pc_maker = _compute_effective_pair_cost(
            CollateralAmount(round_profit_down(up_bid_per_pair)),
            CollateralAmount(round_profit_down(down_bid_per_pair)),
            maker_fee_bps,
            overhead,
        )

    # --- Profit (PER PAIR; compare against required_net_profit) ---
    with localcontext(computation_context()):
        gross_raw = DOLLAR - up_price_per_pair - down_price_per_pair
        net_raw = DOLLAR - effective_pc_taker.value
    gross_profit = ProfitAmount(round_profit_down(gross_raw))
    net_profit = ProfitAmount(round_profit_down(net_raw))

    # --- Max acceptable prices ---
    qty = target_quantity.value
    fee_fraction = fee_bps.as_fraction()
    max_cost = parameters.max_effective_pair_cost.value
    overhead_val = overhead.value

    max_first_leg_price: ProbabilityPrice | None = None
    if down_vwap.average_price is not None and qty > 0:
        down_cost_for_max = down_vwap.average_price.value * qty
        max_first_leg_price = _compute_max_price(
            max_cost=max_cost, overhead=overhead_val,
            fee_fraction=fee_fraction, qty=qty,
            other_leg_cost=down_cost_for_max, tick=parameters.tick_size.value,
        )

    max_second_leg_price: ProbabilityPrice | None = None
    if up_vwap.average_price is not None and qty > 0:
        up_cost_for_max = up_vwap.average_price.value * qty
        max_second_leg_price = _compute_max_price(
            max_cost=max_cost, overhead=overhead_val,
            fee_fraction=fee_fraction, qty=qty,
            other_leg_cost=up_cost_for_max, tick=parameters.tick_size.value,
        )

    # --- Tick sensitivity (PER PAIR) ---
    # Each adverse tick on both sides increases per-pair cost by 2 * tick.
    _one_pair = Shares(Decimal(1))
    tick_sensitivity = (
        _tick_sensitivity(net_profit, _one_pair, parameters.tick_size,
                          parameters.required_net_profit, 1),
        _tick_sensitivity(net_profit, _one_pair, parameters.tick_size,
                          parameters.required_net_profit, 2),
        _tick_sensitivity(net_profit, _one_pair, parameters.tick_size,
                          parameters.required_net_profit, 3),
    )

    # --- Classify ---
    result = _classify(
        rejection_reasons=rejection_reasons,
        inventory=inventory,
        target_quantity=target_quantity,
        effective_pair_cost_taker=effective_pc_taker,
        effective_pair_cost_maker=effective_pc_maker,
        net_profit=net_profit,
        parameters=parameters,
    )

    return PairCostResult(
        target_quantity=target_quantity,
        parameters=parameters,
        inventory=inventory,
        seconds_to_close=seconds_to_close,
        up_is_fresh=up_is_fresh,
        down_is_fresh=down_is_fresh,
        up_vwap=up_vwap,
        down_vwap=down_vwap,
        max_executable_quantity=max_executable_quantity,
        up_taker_cost=up_taker_cost,
        down_taker_cost=down_taker_cost,
        up_maker_cost=up_maker_cost,
        down_maker_cost=down_maker_cost,
        taker_fee_up=taker_fee_up,
        taker_fee_down=taker_fee_down,
        total_taker_fee=total_taker_fee,
        effective_pair_cost_taker=effective_pc_taker,
        effective_pair_cost_maker=effective_pc_maker,
        gross_profit=gross_profit,
        net_profit=net_profit,
        max_first_leg_price=max_first_leg_price,
        max_second_leg_price=max_second_leg_price,
        tick_sensitivity=tick_sensitivity,
        up_depth=up_depth,
        down_depth=down_depth,
        result=result,
        rejection_reasons=tuple(rejection_reasons),
    )


__all__ = [
    "DepthAssessment",
    "EngineParameters",
    "FeeParameters",
    "InventorySummary",
    "PairCostResult",
    "PairOpportunityResult",
    "TickSensitivity",
    "evaluate_pair_cost",
]
