"""Typed ports the pair-accumulation state machine depends on (Module 18).

The machine follows strict dependency inversion (a module-boundary rule): it
talks only to the abstract :class:`typing.Protocol` interfaces defined here plus
the execution :class:`ExecutionAdapter` (which paper AND live adapters both
implement, so the SAME machine drives either -- requirement 14). It NEVER
imports SQLAlchemy models, HTTP/WebSocket/blockchain clients, environment
variables, or concrete live execution / CTF classes. Composition-layer adapters
(a later module) bind these ports to the risk engine, the CTF operation service,
the reconciliation service and the persistence unit of work.

All methods are asynchronous and cancellation-safe. No port carries a secret.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    ReconciliationResult,
    RiskDecision,
)
from polymarket_pair_bot.domain.enums import CtfOperationStatus, RiskVerdict
from polymarket_pair_bot.domain.value_objects import (
    MarketId,
    ProfitAmount,
    Shares,
    UnixTimestamp,
)
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.strategy.detector import RiskInput
from polymarket_pair_bot.strategy.session_models import (
    PairSessionSnapshot,
    SessionTransition,
)


class ApprovalKind(str, Enum):
    """Why the machine is asking risk for approval (mapped to OperationKind by
    the composition-layer adapter)."""

    FIRST_LEG = "first_leg"
    SECOND_LEG = "second_leg"
    HEDGE = "hedge"
    MERGE = "merge"


@dataclass(frozen=True, slots=True)
class RiskApprovalRequest:
    """What the machine knows when asking for approval.

    The adapter enriches this with capital / feed / gas state before calling
    the centralized risk engine, so every order intent is risk-gated
    (requirement 7 and a global safety rule).
    """

    request_id: str
    kind: ApprovalKind
    market_id: MarketId
    desired_size: Shares
    seconds_to_close: int
    occurred_at: UnixTimestamp
    opening_first_leg: bool = False
    expected_pair_edge: ProfitAmount | None = None
    unmatched_shares: Shares | None = None
    oldest_unmatched_age_seconds: int | None = None


@dataclass(frozen=True, slots=True)
class RiskApprovalResult:
    """The centralized risk engine's verdict, projected for the machine.

    ``decision`` is the persisted domain :class:`RiskDecision` (used to bind a
    CTF merge to its authorizing decision). ``approved`` is a strict AND of the
    verdict being APPROVE and a strictly positive ``approved_size``; the machine
    fails closed otherwise.
    """

    approved: bool
    approved_size: Shares
    reason: str
    decision: RiskDecision

    def to_risk_input(self, as_of: UnixTimestamp) -> RiskInput:
        """Project to the detector's abstract :class:`RiskInput`.

        A non-approval always yields a REJECT with zero size so the pure
        detector cannot approve a candidate (fail closed).
        """
        if self.approved and self.approved_size.is_positive:
            return RiskInput(
                verdict=RiskVerdict.APPROVE,
                max_pair_size=self.approved_size,
                reason=self.reason or "risk_approved",
                as_of=as_of,
            )
        return RiskInput(
            verdict=RiskVerdict.REJECT,
            max_pair_size=Shares(Decimal(0)),
            reason=self.reason or "risk_rejected",
            as_of=as_of,
        )


@dataclass(frozen=True, slots=True)
class MergeOutcome:
    """Authoritative result of a CTF merge attempt.

    ``UNKNOWN`` is never treated as success; the machine routes it to
    reconciliation.
    """

    operation_id: str
    status: CtfOperationStatus
    quantity: Shares
    mergeable: Shares
    detail: str = ""


@runtime_checkable
class SessionStore(Protocol):
    """Durable, restart-safe persistence for session state (requirements 1, 4).

    ``save`` MUST persist the snapshot and the transition audit row atomically
    so a crash can never drop a transition or leave a torn snapshot. ``load``
    returns the authoritative latest snapshot the machine rebuilds from.
    """

    async def load(self, market_id: MarketId) -> PairSessionSnapshot | None: ...

    async def save(
        self, snapshot: PairSessionSnapshot, transition: SessionTransition
    ) -> None: ...


@runtime_checkable
class RiskApprovalPort(Protocol):
    """Adapter over the centralized risk engine (requirement 7)."""

    async def evaluate(self, request: RiskApprovalRequest) -> RiskApprovalResult: ...


@runtime_checkable
class MergePort(Protocol):
    """Adapter over the CTF split/merge/redeem service (requirement 10)."""

    async def mergeable(self, market: BinaryMarket) -> Shares:
        """Confirmed on-chain quantity that could be merged right now."""
        ...

    async def merge(
        self,
        *,
        market: BinaryMarket,
        quantity: Shares,
        risk_decision: RiskDecision,
    ) -> MergeOutcome:
        """Submit a CTF merge for ``quantity`` complete pairs."""
        ...


@runtime_checkable
class ReconciliationPort(Protocol):
    """Adapter over the reconciliation service (requirement 13)."""

    async def reconcile(self, trigger: ReconciliationTrigger) -> ReconciliationResult: ...


@runtime_checkable
class KillSwitchPort(Protocol):
    """Read-only view of the composite global kill switch (fail closed)."""

    async def is_active(self) -> bool: ...


__all__ = [
    "ApprovalKind",
    "KillSwitchPort",
    "MergeOutcome",
    "MergePort",
    "ReconciliationPort",
    "RiskApprovalPort",
    "RiskApprovalRequest",
    "RiskApprovalResult",
    "SessionStore",
]
