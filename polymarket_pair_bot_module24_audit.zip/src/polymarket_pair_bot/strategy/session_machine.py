"""Restartable pair-accumulation state machine (Module 18).

This is the orchestration brain that turns validated markets, fresh books,
confirmed fills and operational events into risk-gated acquisition, hedging and
CTF-merge actions for ONE BTC 5-minute market session. It is deliberately:

* **event-driven** (requirement 2): the only entry point is ``process(event)``.
  It spawns no background tasks; an outer supervisor feeds it events.
* **idempotent** (requirement 3): every event carries an ``event_id`` and every
  fill an ``fill_id``; both are de-duplicated so replays are safe.
* **restartable** (requirement 4): all state lives in a persisted
  :class:`PairSessionSnapshot`; ``restore`` rebuilds from the authoritative
  store, and every transition is persisted before it is observable.
* **fail-closed**: uncertain outcomes cancel-where-safe, reconcile and stop;
  the kill switch halts new orders while still allowing cancellation.
* **adapter-agnostic** (requirement 14): it depends only on the abstract
  :class:`ExecutionAdapter` and the ports in ``session_ports`` -- the SAME
  machine drives the paper simulator or the live adapter unchanged.

All monetary maths uses ``Decimal`` / domain value objects. This module makes
NO profitability claim: ``locked_net_profit`` is an accounting figure that may
be negative.
"""

from __future__ import annotations

import asyncio
from decimal import Decimal

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    Fill,
    OrderIntent,
)
from polymarket_pair_bot.domain.enums import (
    OrderSide,
    OutcomeSide,
    CtfOperationStatus,
    TimeInForce,
)
from polymarket_pair_bot.domain.precision import DOLLAR
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    MarketId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    UnixTimestamp,
)
from polymarket_pair_bot.execution.ports import ExecutionAdapter
from polymarket_pair_bot.execution.types import SubmitOutcome
from polymarket_pair_bot.reconciliation.triggers import ReconciliationTrigger
from polymarket_pair_bot.strategy.detector import (
    DetectorAction,
    ExecutionRole,
    PairCandidate,
    PairDetector,
)
from polymarket_pair_bot.strategy.session_events import (
    BooksUpdatedEvent,
    FillConfirmedEvent,
    KillSwitchEvent,
    LimitCheckEvent,
    MarketValidatedEvent,
    MergeEvaluateEvent,
    MergeResultEvent,
    ReconciledEvent,
    SessionEvent,
    UncertainEvent,
    WindowClosingEvent,
)
from polymarket_pair_bot.strategy.session_models import (
    PairSessionSnapshot,
    SessionLimits,
    SessionTransition,
    TransitionOutcome,
)
from polymarket_pair_bot.strategy.session_ports import (
    ApprovalKind,
    KillSwitchPort,
    MergePort,
    ReconciliationPort,
    RiskApprovalPort,
    RiskApprovalRequest,
    RiskApprovalResult,
    SessionStore,
)
from polymarket_pair_bot.strategy.session_states import SessionState, is_allowed

_ZERO = Decimal(0)


class _Step:
    """Mutable working result of one event handler (internal only)."""

    __slots__ = ("snapshot", "target", "actions", "reason")

    def __init__(
        self,
        snapshot: PairSessionSnapshot,
        target: SessionState,
        reason: str,
    ) -> None:
        self.snapshot = snapshot
        self.target = target
        self.reason = reason
        self.actions: list[str] = []

    def act(self, action: str) -> None:
        self.actions.append(action)


class PairAccumulationStateMachine:
    """Drives one market's pair-accumulation session via persisted transitions.

    A single instance may drive many markets concurrently at the event level:
    each session is keyed by ``market_id`` and its state is loaded/persisted
    independently. A per-market :class:`asyncio.Lock` serializes the
    read-modify-write for a single market so concurrent same-market events can
    never lose an update; different markets still run concurrently. This is
    defense-in-depth -- single-writer ownership (one execution leader per
    wallet) is also enforced upstream by the coordination module.
    """

    def __init__(
        self,
        *,
        store: SessionStore,
        execution: ExecutionAdapter,
        risk: RiskApprovalPort,
        merge: MergePort,
        reconciliation: ReconciliationPort,
        kill_switch: KillSwitchPort,
        detector: PairDetector,
        limits: SessionLimits,
    ) -> None:
        self._store = store
        self._execution = execution
        self._risk = risk
        self._merge = merge
        self._reconciliation = reconciliation
        self._kill_switch = kill_switch
        self._detector = detector
        self._limits = limits
        self._cache: dict[str, PairSessionSnapshot] = {}
        # Per-market lock serializing each market's cache read-modify-write.
        # Different markets still run concurrently; the same market is
        # serialized so concurrent events can never lose an update. Defense in
        # depth: single-writer ownership is also enforced upstream.
        self._locks: dict[str, asyncio.Lock] = {}

    def _lock_for(self, market_id: MarketId) -> asyncio.Lock:
        """Return the per-market lock, creating it on first use."""
        lock = self._locks.get(market_id.value)
        if lock is None:
            lock = asyncio.Lock()
            self._locks[market_id.value] = lock
        return lock

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    async def restore(self, market_id: MarketId) -> PairSessionSnapshot | None:
        """Load the authoritative snapshot for ``market_id`` (requirement 4)."""
        async with self._lock_for(market_id):
            snapshot = await self._store.load(market_id)
            if snapshot is not None:
                self._cache[market_id.value] = snapshot
            return snapshot

    async def process(self, event: SessionEvent) -> TransitionOutcome:
        """Feed one event to the session and return the resulting transition.

        Serialized per market so concurrent same-market events cannot interleave
        their cache read-modify-write; different markets run concurrently.
        """
        async with self._lock_for(event.market_id):
            return await self._process_locked(event)

    async def _process_locked(self, event: SessionEvent) -> TransitionOutcome:
        snapshot = await self._load(event.market_id)
        previous_state = snapshot.state

        # Idempotent replay: an already-processed event never re-applies.
        if snapshot.has_processed_event(event.event_id):
            return TransitionOutcome(
                market_id=event.market_id,
                previous_state=previous_state,
                snapshot=snapshot,
                transition=None,
                actions=("idempotent_replay",),
                idempotent_replay=True,
            )

        # A closed session is terminal and ignores further events.
        if snapshot.state.is_terminal:
            return TransitionOutcome(
                market_id=event.market_id,
                previous_state=previous_state,
                snapshot=snapshot,
                transition=None,
                actions=("terminal_ignored",),
            )

        step = await self._dispatch(event, snapshot)
        return await self._finalize(previous_state, event, step)

    # ------------------------------------------------------------------ #
    # Internal: loading & finalizing
    # ------------------------------------------------------------------ #
    async def _load(self, market_id: MarketId) -> PairSessionSnapshot:
        cached = self._cache.get(market_id.value)
        if cached is not None:
            return cached
        loaded = await self._store.load(market_id)
        if loaded is None:
            loaded = PairSessionSnapshot(
                market_id=market_id, state=SessionState.DISCOVERED
            )
        self._cache[market_id.value] = loaded
        return loaded

    async def _finalize(
        self,
        previous_state: SessionState,
        event: SessionEvent,
        step: _Step,
    ) -> TransitionOutcome:
        target = step.target
        actions = list(step.actions)
        reason = step.reason
        # Fail closed on any illegal transition the handlers did not intend.
        if not is_allowed(previous_state, target):
            actions.append(f"illegal_transition:{previous_state.value}->{target.value}")
            target = SessionState.HALTED
            reason = "illegal_transition"

        changed = target is not previous_state or bool(actions)
        if not changed:
            # Genuine no-op: keep the cached snapshot as-is.
            self._cache[event.market_id.value] = step.snapshot
            return TransitionOutcome(
                market_id=event.market_id,
                previous_state=previous_state,
                snapshot=step.snapshot,
                transition=None,
            )

        version = step.snapshot.version + 1
        finalized = step.snapshot.evolve(
            state=target,
            version=version,
            updated_at=event.occurred_at.value,
            last_event_id=event.event_id,
            processed_event_ids=step.snapshot.record_event(
                event.event_id, history=self._limits.processed_id_history
            ),
        )
        transition = SessionTransition(
            market_id=event.market_id,
            from_state=previous_state,
            to_state=target,
            event_id=event.event_id,
            event_type=type(event).__name__,
            occurred_at=event.occurred_at.value,
            version=version,
            reason=reason,
            actions=tuple(actions),
        )
        await self._store.save(finalized, transition)
        self._cache[event.market_id.value] = finalized
        return TransitionOutcome(
            market_id=event.market_id,
            previous_state=previous_state,
            snapshot=finalized,
            transition=transition,
            actions=tuple(actions),
        )

    # ------------------------------------------------------------------ #
    # Internal: dispatch
    # ------------------------------------------------------------------ #
    async def _dispatch(
        self, event: SessionEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        if isinstance(event, KillSwitchEvent):
            return await self._on_kill_switch(event, snapshot)
        if isinstance(event, UncertainEvent):
            return await self._on_uncertain(event, snapshot)
        if isinstance(event, ReconciledEvent):
            return self._on_reconciled(event, snapshot)
        if isinstance(event, MarketValidatedEvent):
            return self._on_market_validated(event, snapshot)
        if isinstance(event, BooksUpdatedEvent):
            return await self._on_books(event, snapshot)
        if isinstance(event, FillConfirmedEvent):
            return await self._on_fill(event, snapshot)
        if isinstance(event, LimitCheckEvent):
            return await self._on_limit_check(event, snapshot)
        if isinstance(event, MergeEvaluateEvent):
            return await self._on_merge_evaluate(event, snapshot)
        if isinstance(event, MergeResultEvent):
            return self._on_merge_result(event, snapshot)
        if isinstance(event, WindowClosingEvent):
            return await self._on_window_closing(event, snapshot)
        return _Step(snapshot, snapshot.state, "unhandled_event")

    # ------------------------------------------------------------------ #
    # Universal handlers (any active state)
    # ------------------------------------------------------------------ #
    async def _on_kill_switch(
        self, event: KillSwitchEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        step = _Step(snapshot, SessionState.HALTED, f"kill_switch: {event.reason}")
        # Cancellation must remain possible while the kill switch is on.
        await self._execution.cancel_market_orders(snapshot.market_id)
        step.act("cancel_market_orders")
        step.act("halted")
        return step

    async def _on_uncertain(
        self, event: UncertainEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        step = _Step(
            snapshot,
            SessionState.RECONCILIATION_REQUIRED,
            f"uncertain: {event.reason}",
        )
        await self._execution.cancel_market_orders(snapshot.market_id)
        step.act("cancel_market_orders")
        if self._limits.reconcile_on_uncertain:
            result = await self._reconciliation.reconcile(event.trigger)
            step.act(f"reconciled:{result.status.value}")
        return step

    def _on_reconciled(
        self, event: ReconciledEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        if snapshot.state is not SessionState.RECONCILIATION_REQUIRED:
            return _Step(snapshot, snapshot.state, "reconciled_ignored")
        if not event.result.is_consistent:
            step = _Step(snapshot, SessionState.HALTED, "reconcile_discrepancy")
            step.act("halted")
            return step
        # Consistent: resume at a safe state. A reconnect always requires a
        # fresh book sync before trading resumes (requirement 5).
        if snapshot.matched_pairs.value > 0 and not snapshot.has_unmatched:
            target = SessionState.MATCHED_PAIR
        elif snapshot.has_unmatched:
            target = SessionState.UNMATCHED_INVENTORY
        else:
            target = SessionState.BOOK_SYNCING
        step = _Step(snapshot, target, "reconcile_consistent_resume")
        step.act(f"resume:{target.value}")
        return step

    # ------------------------------------------------------------------ #
    # Lifecycle handlers
    # ------------------------------------------------------------------ #
    def _on_market_validated(
        self, event: MarketValidatedEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        if snapshot.state is SessionState.DISCOVERED:
            step = _Step(snapshot, SessionState.BOOK_SYNCING, "market_validated")
            step.act("begin_book_sync")
            return step
        return _Step(snapshot, snapshot.state, "market_already_validated")

    async def _on_books(
        self, event: BooksUpdatedEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        state = snapshot.state
        # Fail closed on stale / disconnected feed (requirement 5).
        if not event.books_fresh:
            if state.holds_unmatched or state.holds_matched:
                # A disconnect while exposed is an uncertain event: cancel,
                # reconcile and stop (requirements 9/13).
                step = _Step(
                    snapshot,
                    SessionState.RECONCILIATION_REQUIRED,
                    "feed_stale_while_exposed",
                )
                await self._execution.cancel_market_orders(snapshot.market_id)
                step.act("cancel_market_orders")
                if self._limits.reconcile_on_uncertain:
                    result = await self._reconciliation.reconcile(
                        ReconciliationTrigger.USER_STREAM_RECONNECT
                    )
                    step.act(f"reconciled:{result.status.value}")
                return step
            if state in (
                SessionState.DISCOVERED,
                SessionState.READY,
                SessionState.WAITING_FOR_EDGE,
            ):
                return _Step(snapshot, SessionState.BOOK_SYNCING, "awaiting_fresh_books")
            return _Step(snapshot, state, "books_stale_noop")

        # Books are fresh from here on.
        if state in (SessionState.DISCOVERED, SessionState.BOOK_SYNCING):
            state = SessionState.READY
            snapshot = snapshot  # state applied on the step below

        if state in (SessionState.READY, SessionState.WAITING_FOR_EDGE):
            return await self._drive_first_leg(event, snapshot, entered_ready=state)
        if state is SessionState.FIRST_LEG_OPEN:
            return await self._maybe_cancel_near_close(event, snapshot)
        if state in (
            SessionState.UNMATCHED_INVENTORY,
            SessionState.SECOND_LEG_OPEN,
        ):
            return await self._drive_second_leg(event, snapshot)
        # MATCHED_PAIR / MERGE_* ignore book updates.
        return _Step(snapshot, state, "books_noop")

    async def _drive_first_leg(
        self,
        event: BooksUpdatedEvent,
        snapshot: PairSessionSnapshot,
        *,
        entered_ready: SessionState,
    ) -> _Step:
        stc = event.seconds_to_close
        # Cancel resting orders once inside the mandatory-cancel window
        # (requirement 12); when flat there is nothing to acquire.
        if stc <= self._limits.mandatory_cancel_seconds:
            step = _Step(snapshot, SessionState.WAITING_FOR_EDGE, "mandatory_cancel_window")
            await self._execution.cancel_market_orders(snapshot.market_id)
            step.act("cancel_market_orders")
            return step
        # Stop opening NEW first legs after the cutoff (requirement 11).
        if stc <= self._limits.first_leg_cutoff_seconds:
            return _Step(snapshot, SessionState.WAITING_FOR_EDGE, "past_first_leg_cutoff")

        approval = await self._approve(
            snapshot,
            kind=ApprovalKind.FIRST_LEG,
            size=self._limits.target_pair_size,
            seconds_to_close=stc,
            occurred_at=event.occurred_at,
            opening_first_leg=True,
        )
        detection = self._detector.evaluate(
            market=event.market,
            up_book=event.up_book,
            down_book=event.down_book,
            inventory=snapshot.inventory_summary(),
            target_quantity=self._limits.target_pair_size,
            now=event.occurred_at,
            up_is_fresh=event.up_is_fresh,
            down_is_fresh=event.down_is_fresh,
            risk_input=approval.to_risk_input(event.occurred_at),
        )
        approved = detection.approved_candidates
        if not approved:
            return _Step(snapshot, SessionState.WAITING_FOR_EDGE, "no_opportunity")
        if detection.action is DetectorAction.IMMEDIATE_TWO_LEG:
            return await self._submit_immediate(event, snapshot, approved)
        # PASSIVE_FIRST_LEG: post one resting maker leg.
        candidate = approved[0]
        step = _Step(snapshot, SessionState.FIRST_LEG_OPEN, "passive_first_leg")
        await self._submit(event.market, candidate, event.occurred_at, step)
        return step

    async def _drive_second_leg(
        self, event: BooksUpdatedEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        stc = event.seconds_to_close
        if stc <= self._limits.mandatory_cancel_seconds:
            # Cancel passive completion attempts before close; the unmatched
            # leg now needs a hedge or an unwind (requirement 9/12).
            return await self._attempt_hedge(
                event.market, snapshot, event.occurred_at, stc, reason="close_window"
            )
        approval = await self._approve(
            snapshot,
            kind=ApprovalKind.SECOND_LEG,
            size=Shares(snapshot.shortfall) if snapshot.shortfall > 0 else self._limits.target_pair_size,
            seconds_to_close=stc,
            occurred_at=event.occurred_at,
        )
        detection = self._detector.evaluate(
            market=event.market,
            up_book=event.up_book,
            down_book=event.down_book,
            inventory=snapshot.inventory_summary(),
            target_quantity=self._limits.target_pair_size,
            now=event.occurred_at,
            up_is_fresh=event.up_is_fresh,
            down_is_fresh=event.down_is_fresh,
            risk_input=approval.to_risk_input(event.occurred_at),
        )
        approved = detection.approved_candidates
        if not approved:
            return _Step(snapshot, snapshot.state, "second_leg_unavailable")
        candidate = approved[0]
        step = _Step(snapshot, SessionState.SECOND_LEG_OPEN, "passive_second_leg")
        await self._submit(event.market, candidate, event.occurred_at, step)
        return step

    async def _maybe_cancel_near_close(
        self, event: BooksUpdatedEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        if event.seconds_to_close <= self._limits.mandatory_cancel_seconds:
            step = _Step(
                snapshot, SessionState.WAITING_FOR_EDGE, "cancel_first_leg_near_close"
            )
            await self._execution.cancel_market_orders(snapshot.market_id)
            step.act("cancel_market_orders")
            return step
        return _Step(snapshot, snapshot.state, "awaiting_first_leg_fill")

    # ------------------------------------------------------------------ #
    # Fill handling
    # ------------------------------------------------------------------ #
    async def _on_fill(
        self, event: FillConfirmedEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        applied, newly_matched, side = self._apply_confirmed_fill(
            snapshot, event.market, event.fill
        )
        if applied is snapshot:
            return _Step(snapshot, snapshot.state, "duplicate_fill_ignored")

        # First leg just created directional unmatched exposure.
        if (
            snapshot.state
            in (
                SessionState.FIRST_LEG_OPEN,
                SessionState.READY,
                SessionState.WAITING_FOR_EDGE,
            )
            and newly_matched == _ZERO
        ):
            applied = self._on_first_leg_fill(applied, side, event.occurred_at)
            step = _Step(applied, SessionState.UNMATCHED_INVENTORY, "first_leg_filled")
            # Freeze exposure: cancel any remaining first-leg passive order.
            await self._execution.cancel_market_orders(snapshot.market_id)
            step.act("cancel_remaining_first_leg")
            step.act(f"unmatched:{side.value}:{event.fill.size.value}")
            if applied.max_second_leg_price is not None:
                step.act(f"max_second_leg_price:{applied.max_second_leg_price.value}")
            return step

        # A pair (or more) just completed.
        if newly_matched > _ZERO and not applied.has_unmatched:
            applied = self._recompute_locked_profit(applied)
            step = _Step(applied, SessionState.MATCHED_PAIR, "pair_matched")
            step.act(f"matched_pairs:{applied.matched_pairs.value}")
            return step

        # Partial completion: still unmatched, keep completing.
        step = _Step(applied, snapshot.state, "partial_fill_applied")
        step.act(f"newly_matched:{newly_matched}")
        return step

    def _apply_confirmed_fill(
        self, snapshot: PairSessionSnapshot, market: BinaryMarket, fill: Fill
    ) -> tuple[PairSessionSnapshot, Decimal, OutcomeSide]:
        side = self._side_for(market, fill)
        if snapshot.has_processed_fill(fill.fill_id.value):
            return snapshot, _ZERO, side
        cost = fill.notional.value + fill.fee.value
        updated, newly_matched = snapshot.apply_fill(
            side=side, quantity=fill.size.value, cost=cost
        )
        updated = updated.evolve(
            processed_fill_ids=snapshot.record_fill(
                fill.fill_id.value, history=self._limits.processed_id_history
            )
        )
        return updated, newly_matched, side

    def _on_first_leg_fill(
        self,
        snapshot: PairSessionSnapshot,
        side: OutcomeSide,
        now: UnixTimestamp,
    ) -> PairSessionSnapshot:
        # Requirement 8: record the first-leg side/time and compute the maximum
        # price we may pay on the second leg while keeping the pair in budget.
        snapshot = snapshot.evolve(first_leg_side=side, first_leg_filled_at=now.value)
        max_price = self._max_second_leg_price(snapshot)
        return snapshot.evolve(max_second_leg_price=max_price)

    def _max_second_leg_price(
        self, snapshot: PairSessionSnapshot
    ) -> ProbabilityPrice | None:
        avg = snapshot.first_leg_avg_price()
        if avg is None:
            return None
        budget = self._limits.max_effective_pair_cost.value
        overhead = self._limits.overhead.value
        raw = budget - overhead - avg
        if raw <= 0 or raw > 1:
            return None if raw <= 0 else ProbabilityPrice(Decimal(1))
        return ProbabilityPrice(raw)

    def _recompute_locked_profit(
        self, snapshot: PairSessionSnapshot
    ) -> PairSessionSnapshot:
        # Requirement 10: locked net profit of confirmed matched pairs.
        # Conservative: charge the full per-pair overhead against each matched
        # pair. This is an accounting figure and may be negative.
        pairs = snapshot.matched_pairs.value
        locked_value = pairs * DOLLAR
        overhead = self._limits.overhead.value * pairs
        net = locked_value - snapshot.matched_cost.value - overhead
        return snapshot.evolve(locked_net_profit=ProfitAmount(net))

    # ------------------------------------------------------------------ #
    # Limit monitoring + hedging (requirements 8/9)
    # ------------------------------------------------------------------ #
    async def _on_limit_check(
        self, event: LimitCheckEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        if not snapshot.has_unmatched:
            return _Step(snapshot, snapshot.state, "no_unmatched")
        size = snapshot.unmatched_size
        opened = snapshot.first_leg_filled_at
        age = event.occurred_at.value - opened if opened is not None else 0
        hard = (
            size >= self._limits.max_unmatched_shares.value
            or age >= self._limits.max_unmatched_seconds
        )
        warn = (
            Decimal(size) >= self._limits.warning_shares
            or Decimal(age) >= self._limits.warning_seconds
        )
        if not (hard or warn):
            return _Step(snapshot, snapshot.state, "within_limits")
        reason = "hard_limit_breach" if hard else "limit_warning"
        return await self._attempt_hedge(
            event.market, snapshot, event.occurred_at, None, reason=reason
        )

    async def _attempt_hedge(
        self,
        market: BinaryMarket,
        snapshot: PairSessionSnapshot,
        now: UnixTimestamp,
        seconds_to_close: int | None,
        *,
        reason: str,
    ) -> _Step:
        # Cancel remaining passive orders first (requirement 9).
        await self._execution.cancel_market_orders(market.market_id)
        missing = snapshot.missing_side()
        shortfall = snapshot.shortfall
        if missing is None or shortfall <= 0:
            # Already balanced; nothing to hedge.
            return _Step(snapshot, snapshot.state, "nothing_to_hedge")
        if snapshot.max_second_leg_price is None:
            step = _Step(snapshot, SessionState.UNWIND_REQUIRED, "no_safe_hedge_price")
            step.act("cancel_market_orders")
            return step
        stc = seconds_to_close if seconds_to_close is not None else 0
        approval = await self._approve(
            snapshot,
            kind=ApprovalKind.HEDGE,
            size=Shares(shortfall),
            seconds_to_close=stc,
            occurred_at=now,
        )
        if not approval.approved:
            step = _Step(snapshot, SessionState.UNWIND_REQUIRED, f"hedge_not_approved:{reason}")
            step.act("cancel_market_orders")
            step.act(f"risk:{approval.reason}")
            return step
        size = min(shortfall, approval.approved_size.value)
        intent = OrderIntent(
            intent_id=f"{market.market_id.value}:hedge:{missing.value}:{now.value}",
            market_id=market.market_id,
            token_id=market.token_for(missing).token_id,
            side=OrderSide.BUY,
            limit_price=snapshot.max_second_leg_price,
            size=Shares(size),
            time_in_force=TimeInForce.FOK,
            created_at=now,
        )
        ack = await self._execution.submit_order(intent)
        step = _Step(snapshot, snapshot.state, f"hedge_attempt:{reason}")
        step.act("cancel_market_orders")
        step.act(f"hedge_submit:{ack.outcome.value}")
        if ack.outcome is SubmitOutcome.UNKNOWN:
            # Do not assume anything about a timed-out submission.
            step.target = SessionState.RECONCILIATION_REQUIRED
            step.reason = "hedge_unknown_submission"
            if self._limits.reconcile_on_uncertain:
                result = await self._reconciliation.reconcile(
                    ReconciliationTrigger.UNKNOWN_SUBMISSION
                )
                step.act(f"reconciled:{result.status.value}")
            return step
        if ack.outcome is SubmitOutcome.REJECTED:
            step.target = SessionState.UNWIND_REQUIRED
            step.reason = "hedge_rejected"
            return step
        # Accepted: confirm via AUTHORITATIVE fills (ack is never a fill).
        fills = await self._execution.get_fills(order_id=ack.order.order_id)
        working = step.snapshot
        for fill in fills:
            working, _matched, _side = self._apply_confirmed_fill(working, market, fill)
        step.snapshot = working
        if working.has_unmatched:
            step.target = SessionState.UNWIND_REQUIRED
            step.reason = "hedge_failed_incomplete"
            step.act("hedge_incomplete")
            return step
        working = self._recompute_locked_profit(working)
        step.snapshot = working
        step.target = SessionState.MATCHED_PAIR
        step.reason = "hedge_completed_pair"
        step.act("hedge_success")
        return step

    # ------------------------------------------------------------------ #
    # Merge handling (requirement 10)
    # ------------------------------------------------------------------ #
    async def _on_merge_evaluate(
        self, event: MergeEvaluateEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        if snapshot.matched_pairs.value <= 0:
            return _Step(snapshot, snapshot.state, "no_matched_pairs")
        snapshot = self._recompute_locked_profit(snapshot)
        if snapshot.state is SessionState.MATCHED_PAIR:
            economical = (
                snapshot.locked_net_profit is not None
                and snapshot.locked_net_profit.value
                >= self._limits.merge_min_net_value.value
            )
            if not economical:
                return _Step(snapshot, SessionState.MATCHED_PAIR, "merge_not_economical")
            step = _Step(snapshot, SessionState.MERGE_PENDING, "merge_scheduled")
            step.act("merge_pending")
            return step
        if snapshot.state is SessionState.MERGE_PENDING:
            return await self._try_submit_merge(event, snapshot)
        return _Step(snapshot, snapshot.state, "merge_evaluate_noop")

    async def _try_submit_merge(
        self, event: MergeEvaluateEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        mergeable = await self._merge.mergeable(event.market)
        pairs = snapshot.matched_pairs.value
        if mergeable.value <= 0 or mergeable.value < pairs:
            # Wait for the on-chain confirmed balance to catch up.
            step = _Step(snapshot, SessionState.MERGE_PENDING, "awaiting_mergeable_balance")
            step.act(f"mergeable:{mergeable.value}")
            return step
        approval = await self._approve(
            snapshot,
            kind=ApprovalKind.MERGE,
            size=snapshot.matched_pairs,
            seconds_to_close=0,
            occurred_at=event.occurred_at,
        )
        if not approval.approved:
            step = _Step(snapshot, SessionState.MERGE_PENDING, "merge_not_approved")
            step.act(f"risk:{approval.reason}")
            return step
        outcome = await self._merge.merge(
            market=event.market,
            quantity=snapshot.matched_pairs,
            risk_decision=approval.decision,
        )
        snapshot = snapshot.evolve(merge_operation_id=outcome.operation_id)
        step = _Step(snapshot, SessionState.MERGING, "merge_submitted")
        step.act(f"merge:{outcome.status.value}")
        if outcome.status is CtfOperationStatus.CONFIRMED:
            step.snapshot = self._close_after_merge(snapshot)
            step.target = SessionState.CLOSED
            step.reason = "merge_confirmed"
            return step
        if outcome.status is CtfOperationStatus.FAILED:
            step.target = SessionState.MERGE_PENDING
            step.reason = "merge_failed_retry"
            return step
        if outcome.status is CtfOperationStatus.UNKNOWN:
            step.target = SessionState.RECONCILIATION_REQUIRED
            step.reason = "merge_unknown"
            if self._limits.reconcile_on_uncertain:
                result = await self._reconciliation.reconcile(
                    ReconciliationTrigger.POST_MERGE
                )
                step.act(f"reconciled:{result.status.value}")
            return step
        # SUBMITTED / PENDING: await a MergeResultEvent.
        return step

    def _on_merge_result(
        self, event: MergeResultEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        if snapshot.state is not SessionState.MERGING:
            return _Step(snapshot, snapshot.state, "merge_result_ignored")
        if event.status is CtfOperationStatus.CONFIRMED:
            step = _Step(
                self._close_after_merge(snapshot), SessionState.CLOSED, "merge_confirmed"
            )
            step.act("closed")
            return step
        if event.status is CtfOperationStatus.FAILED:
            step = _Step(snapshot, SessionState.MERGE_PENDING, "merge_failed_retry")
            step.act("merge_retry")
            return step
        # UNKNOWN / anything else: reconcile.
        step = _Step(
            snapshot, SessionState.RECONCILIATION_REQUIRED, "merge_result_unknown"
        )
        step.act("merge_unknown")
        return step

    def _close_after_merge(self, snapshot: PairSessionSnapshot) -> PairSessionSnapshot:
        # The matched pairs have been merged back into collateral; the session
        # is now flat. locked_net_profit is retained as the realized figure.
        return snapshot.evolve(
            matched_pairs=Shares(_ZERO),
            matched_cost=CollateralAmount(_ZERO),
        )

    # ------------------------------------------------------------------ #
    # Window closing (requirements 11/12)
    # ------------------------------------------------------------------ #
    async def _on_window_closing(
        self, event: WindowClosingEvent, snapshot: PairSessionSnapshot
    ) -> _Step:
        # Always cancel resting passive orders before close.
        await self._execution.cancel_market_orders(snapshot.market_id)
        if snapshot.has_unmatched:
            step = _Step(snapshot, SessionState.UNWIND_REQUIRED, "unmatched_at_close")
            step.act("cancel_market_orders")
            return step
        if snapshot.matched_pairs.value > 0:
            snapshot = self._recompute_locked_profit(snapshot)
            step = _Step(snapshot, SessionState.MERGE_PENDING, "matched_pairs_await_merge")
            step.act("cancel_market_orders")
            step.act("schedule_merge_after_close")
            return step
        step = _Step(snapshot, SessionState.CLOSED, "closed_flat")
        step.act("cancel_market_orders")
        return step

    # ------------------------------------------------------------------ #
    # Shared helpers
    # ------------------------------------------------------------------ #
    async def _approve(
        self,
        snapshot: PairSessionSnapshot,
        *,
        kind: ApprovalKind,
        size: Shares,
        seconds_to_close: int,
        occurred_at: UnixTimestamp,
        opening_first_leg: bool = False,
    ) -> RiskApprovalResult:
        opened = snapshot.first_leg_filled_at
        age = occurred_at.value - opened if opened is not None else None
        request = RiskApprovalRequest(
            request_id=f"{snapshot.market_id.value}:{kind.value}:{occurred_at.value}",
            kind=kind,
            market_id=snapshot.market_id,
            desired_size=size,
            seconds_to_close=seconds_to_close,
            occurred_at=occurred_at,
            opening_first_leg=opening_first_leg,
            unmatched_shares=Shares(snapshot.unmatched_size),
            oldest_unmatched_age_seconds=age,
        )
        return await self._risk.evaluate(request)

    async def _submit(
        self,
        market: BinaryMarket,
        candidate: PairCandidate,
        now: UnixTimestamp,
        step: _Step,
    ) -> None:
        tif = (
            TimeInForce.FOK
            if candidate.role is ExecutionRole.TAKER
            else TimeInForce.GTC
        )
        intent = OrderIntent(
            intent_id=(
                f"{market.market_id.value}:{candidate.side.value}:"
                f"{candidate.role.value}:{now.value}"
            ),
            market_id=market.market_id,
            token_id=market.token_for(candidate.side).token_id,
            side=OrderSide.BUY,
            limit_price=candidate.proposed_price,
            size=candidate.proposed_quantity,
            time_in_force=tif,
            created_at=now,
        )
        ack = await self._execution.submit_order(intent)
        step.act(f"submit:{candidate.side.value}:{ack.outcome.value}")
        if ack.outcome is SubmitOutcome.UNKNOWN:
            step.target = SessionState.RECONCILIATION_REQUIRED
            step.reason = "submit_unknown"
            if self._limits.reconcile_on_uncertain:
                await self._reconciliation.reconcile(
                    ReconciliationTrigger.UNKNOWN_SUBMISSION
                )
                step.act("reconciled")

    async def _submit_immediate(
        self,
        event: BooksUpdatedEvent,
        snapshot: PairSessionSnapshot,
        candidates: tuple[PairCandidate, ...],
    ) -> _Step:
        step = _Step(snapshot, snapshot.state, "immediate_two_leg")
        working = snapshot
        for candidate in candidates:
            intent = OrderIntent(
                intent_id=(
                    f"{event.market.market_id.value}:{candidate.side.value}:"
                    f"taker:{event.occurred_at.value}"
                ),
                market_id=event.market.market_id,
                token_id=event.market.token_for(candidate.side).token_id,
                side=OrderSide.BUY,
                limit_price=candidate.proposed_price,
                size=candidate.proposed_quantity,
                time_in_force=TimeInForce.FOK,
                created_at=event.occurred_at,
            )
            ack = await self._execution.submit_order(intent)
            step.act(f"submit:{candidate.side.value}:{ack.outcome.value}")
            if ack.outcome is SubmitOutcome.UNKNOWN:
                step.target = SessionState.RECONCILIATION_REQUIRED
                step.reason = "submit_unknown"
                return step
            if ack.outcome is SubmitOutcome.ACCEPTED:
                fills = await self._execution.get_fills(order_id=ack.order.order_id)
                for fill in fills:
                    working, _m, _s = self._apply_confirmed_fill(
                        working, event.market, fill
                    )
        step.snapshot = working
        if not working.has_unmatched and working.matched_pairs.value > 0:
            step.snapshot = self._recompute_locked_profit(working)
            step.target = SessionState.MATCHED_PAIR
            step.reason = "immediate_matched"
        elif working.has_unmatched:
            working = self._on_first_leg_fill(
                working, working.first_leg_side or OutcomeSide.UP, event.occurred_at
            )
            step.snapshot = working
            step.target = SessionState.UNMATCHED_INVENTORY
            step.reason = "immediate_partial"
        else:
            step.target = SessionState.WAITING_FOR_EDGE
            step.reason = "immediate_no_fill"
        return step

    def _side_for(self, market: BinaryMarket, fill: Fill) -> OutcomeSide:
        if fill.token_id == market.up_token.token_id:
            return OutcomeSide.UP
        if fill.token_id == market.down_token.token_id:
            return OutcomeSide.DOWN
        raise ValueError(
            "fill token does not belong to this market's Up/Down tokens"
        )


__all__ = ["PairAccumulationStateMachine"]
