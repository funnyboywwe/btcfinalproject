"""Pair-opportunity detector (architecture item 10; requested as "Module 9").

This module turns a single :func:`evaluate_pair_cost` engine evaluation into
concrete, fully-annotated acquisition *candidates*. It is:

* **pure** -- no I/O, no network, no database, no env reads, no clock reads,
  no mutation of its inputs and no other side effects;
* **deterministic** -- identical inputs always produce an equal
  :class:`DetectionResult` (the caller supplies ``now`` explicitly);
* **non-executing** -- it never submits, cancels or mutates orders. It only
  describes what *could* be proposed.

The detector cannot mark a candidate as approved unless risk-engine input is
supplied. The centralized risk engine is architecture item 13 and is **not**
implemented here; the detector depends only on the abstract :class:`RiskInput`
value object (dependency inversion). When no risk input is available the
detector fails closed: candidates are still described but none are approved.

All monetary values are ``Decimal`` / domain value objects -- never binary
floats. Makes NO profitability claim: an ``expected_net_edge`` is a modeled
quantity against a configured threshold, not a promise of profit.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, localcontext
from enum import Enum

from polymarket_pair_bot.domain.entities import (
    BinaryMarket,
    MarketWindow,
    OrderBookSnapshot,
)
from polymarket_pair_bot.domain.enums import OutcomeSide, RiskVerdict
from polymarket_pair_bot.domain.precision import (
    DOLLAR,
    computation_context,
    round_profit_down,
)
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    MarketId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
    UnixTimestamp,
)
from polymarket_pair_bot.strategy.engine import (
    EngineParameters,
    InventorySummary,
    PairCostResult,
    PairOpportunityResult,
    evaluate_pair_cost,
)


class ExecutionRole(str, Enum):
    """Whether a proposed leg would rest passively or cross the spread.

    * ``MAKER`` -- post a resting buy order (provides liquidity; typically zero
      fee on Polymarket CLOB). Fill is not guaranteed.
    * ``TAKER`` -- cross the spread against resting asks (consumes liquidity;
      pays the taker fee). Fill is immediate up to available depth.
    """

    MAKER = "maker"
    TAKER = "taker"


class DetectorAction(str, Enum):
    """The five mutually-exclusive situations the detector classifies.

    These map directly onto the engine's :class:`PairOpportunityResult`:

    * ``PASSIVE_FIRST_LEG`` -- neither leg held; taker cost is above budget but
      a passive maker bid on one leg would be within budget.
    * ``PASSIVE_SECOND_LEG`` -- one leg already held as unmatched inventory;
      acquire the missing leg to complete a pair.
    * ``IMMEDIATE_TWO_LEG`` -- both legs are takeable now within budget and the
      modeled net edge meets the threshold.
    * ``MATCHED_INVENTORY`` -- enough of both legs is already held; no
      acquisition is proposed (a later module performs the CTF merge).
    * ``NO_TRADE`` -- rejected (stale/thin/too close to close) or merely an
      observation that is not actionable.
    """

    PASSIVE_FIRST_LEG = "passive_first_leg"
    PASSIVE_SECOND_LEG = "passive_second_leg"
    IMMEDIATE_TWO_LEG = "immediate_two_leg"
    MATCHED_INVENTORY = "matched_inventory"
    NO_TRADE = "no_trade"


_ACTION_BY_ENGINE: dict[PairOpportunityResult, DetectorAction] = {
    PairOpportunityResult.PASSIVE_FIRST_LEG: DetectorAction.PASSIVE_FIRST_LEG,
    PairOpportunityResult.PASSIVE_SECOND_LEG: DetectorAction.PASSIVE_SECOND_LEG,
    PairOpportunityResult.IMMEDIATE_TWO_LEG: DetectorAction.IMMEDIATE_TWO_LEG,
    PairOpportunityResult.MATCHED_PAIR: DetectorAction.MATCHED_INVENTORY,
    PairOpportunityResult.REJECTED: DetectorAction.NO_TRADE,
    PairOpportunityResult.OBSERVATION_ONLY: DetectorAction.NO_TRADE,
}


@dataclass(frozen=True, slots=True)
class RiskInput:
    """Abstract, caller-supplied snapshot of centralized risk-engine state.

    The detector consumes this instead of calling the risk engine directly
    (dependency inversion). The concrete engine (architecture item 13) will
    build it from live limits and kill-switch state. The detector cannot
    approve a candidate unless an instance is provided *and* the verdict is
    ``APPROVE`` with a positive ``max_pair_size``.

    Fields:
        verdict: APPROVE or REJECT.
        max_pair_size: maximum pair quantity risk currently permits (Shares,
            >= 0). Approved candidate sizes are clamped to this.
        reason: secret-free human-readable justification.
        as_of: time the risk snapshot was produced (UnixTimestamp).
    """

    verdict: RiskVerdict
    max_pair_size: Shares
    reason: str
    as_of: UnixTimestamp

    def __post_init__(self) -> None:
        if not self.reason.strip():
            raise ValueError("risk input reason must not be empty")
        if self.verdict is RiskVerdict.REJECT and self.max_pair_size.value != 0:
            raise ValueError("a rejecting risk input must carry zero max_pair_size")


@dataclass(frozen=True, slots=True)
class DetectorConfig:
    """Detector configuration.

    Fields:
        engine_parameters: parameters handed to the pair-cost engine.
        passive_order_ttl_seconds: lifetime of a proposed passive maker order
            before it must be cancelled/re-evaluated.
        taker_order_ttl_seconds: lifetime of a proposed immediate taker order
            (kept short: a taker quote goes stale almost immediately).

    Deadlines are always capped at the market window close time so the detector
    never proposes an order that would outlive its market.
    """

    engine_parameters: EngineParameters
    passive_order_ttl_seconds: int = 30
    taker_order_ttl_seconds: int = 5

    def __post_init__(self) -> None:
        if self.passive_order_ttl_seconds <= 0:
            raise ValueError("passive_order_ttl_seconds must be positive")
        if self.taker_order_ttl_seconds <= 0:
            raise ValueError("taker_order_ttl_seconds must be positive")


@dataclass(frozen=True, slots=True)
class PairCandidate:
    """A single proposed order leg with every field the spec requires.

    A candidate is a *proposal only*. ``approved`` is True only when valid
    risk-engine input authorized it; an unapproved candidate must never be
    executed by any downstream module.

    Fields:
        market_id / window: the market and its 5-minute window.
        side: the outcome (UP/DOWN) this leg would buy.
        role: expected MAKER/TAKER execution role.
        proposed_price: limit price for the leg (ProbabilityPrice). For makers
            this is the resting bid; for takers this is the executable VWAP.
        proposed_quantity: leg size (Shares); clamped to the risk-approved size
            when ``approved`` is True.
        matched_inventory: currently confirmed matched pairs (Shares).
        unmatched_up / unmatched_down: current directional unmatched exposure.
        effective_pair_cost: modeled all-in per-pair cost for this role.
        expected_net_edge: modeled ``$1 - effective_pair_cost`` (may be a loss).
        required_hedge_depth: additional shares that must still be acquired on
            the opposite outcome to complete a matched pair of this size.
        book_age_seconds: age of this leg's order book at ``now`` (freshness
            metadata; a duration, never money). ``None`` if the book is absent.
        seconds_to_close: whole seconds until the window closes.
        cancel_deadline: latest time this proposal remains valid (UnixTimestamp).
        approved: True only when risk input authorized this candidate.
        approval_reason: secret-free explanation of the approval decision.
        rejection_reasons: complete engine rejection reasons (empty when
            actionable).
    """

    market_id: MarketId
    window: MarketWindow
    side: OutcomeSide
    role: ExecutionRole
    proposed_price: ProbabilityPrice
    proposed_quantity: Shares
    matched_inventory: Shares
    unmatched_up: Shares
    unmatched_down: Shares
    effective_pair_cost: CollateralAmount
    expected_net_edge: ProfitAmount
    required_hedge_depth: Shares
    book_age_seconds: int | None
    seconds_to_close: int
    cancel_deadline: UnixTimestamp
    approved: bool
    approval_reason: str
    rejection_reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class DetectionResult:
    """Complete, immutable output of one detector evaluation.

    Preserves the full engine :class:`PairCostResult` for observability plus
    the classified action, the concrete candidates, and the risk-gate outcome.
    No field contains a secret.
    """

    market_id: MarketId
    window: MarketWindow
    action: DetectorAction
    candidates: tuple[PairCandidate, ...]
    matched_inventory: Shares
    unmatched_up: Shares
    unmatched_down: Shares
    effective_pair_cost: CollateralAmount
    effective_pair_cost_maker: CollateralAmount | None
    expected_net_edge: ProfitAmount
    seconds_to_close: int
    up_book_age_seconds: int | None
    down_book_age_seconds: int | None
    risk_input_available: bool
    approved: bool
    rejection_reasons: tuple[str, ...]
    engine_result: PairOpportunityResult
    cost_result: PairCostResult
    evaluated_at: UnixTimestamp

    @property
    def has_candidates(self) -> bool:
        return len(self.candidates) > 0

    @property
    def approved_candidates(self) -> tuple[PairCandidate, ...]:
        return tuple(c for c in self.candidates if c.approved)


# --------------------------------------------------------------------------- #
# Pure helpers
# --------------------------------------------------------------------------- #
def _seconds_to_close(close_time: UnixTimestamp, now: UnixTimestamp) -> int:
    remaining = close_time.value - now.value
    return remaining if remaining > 0 else 0


def _book_age(book: OrderBookSnapshot | None, now: UnixTimestamp) -> int | None:
    if book is None:
        return None
    age = now.value - book.as_of.value
    return age if age > 0 else 0


def _deadline(now: UnixTimestamp, ttl_seconds: int, close_time: UnixTimestamp) -> UnixTimestamp:
    raw = now.value + ttl_seconds
    capped = raw if raw < close_time.value else close_time.value
    return UnixTimestamp(capped if capped > now.value else now.value)


def _best_bid(book: OrderBookSnapshot | None) -> ProbabilityPrice | None:
    if book is None or not book.bids:
        return None
    return book.bids[0].price


def _best_ask(book: OrderBookSnapshot | None) -> ProbabilityPrice | None:
    if book is None or not book.asks:
        return None
    return book.asks[0].price


def _maker_price(
    best_bid: ProbabilityPrice | None,
    ceiling: ProbabilityPrice | None,
) -> ProbabilityPrice | None:
    """Choose a resting maker bid price.

    Join the front of the book at the best bid, but never post above the
    engine's per-leg price ceiling (which keeps the pair within budget). When
    the book has no bids, post at the ceiling if one exists.
    """
    if best_bid is None and ceiling is None:
        return None
    if best_bid is None:
        return ceiling
    if ceiling is None:
        return best_bid
    return best_bid if best_bid.value <= ceiling.value else ceiling


def _maker_net_edge(pair_cost: CollateralAmount) -> ProfitAmount:
    with localcontext(computation_context()):
        raw = DOLLAR - pair_cost.value
    return ProfitAmount(round_profit_down(raw))


def _hedge_depth(proposed_qty: Shares, opposite_unmatched: Shares) -> Shares:
    """Shares still required on the opposite outcome to complete the pair."""
    remaining = proposed_qty.value - opposite_unmatched.value
    return Shares(remaining if remaining > 0 else Decimal(0))


def _clamp_to_risk(desired: Shares, approved: bool, risk_input: RiskInput | None) -> Shares:
    if approved and risk_input is not None and risk_input.max_pair_size.value < desired.value:
        return risk_input.max_pair_size
    return desired


class PairDetector:
    """Pure pair-opportunity detector wrapping the pair-cost engine."""

    def __init__(self, config: DetectorConfig) -> None:
        self._config = config

    @property
    def config(self) -> DetectorConfig:
        return self._config

    def evaluate(
        self,
        *,
        market: BinaryMarket,
        up_book: OrderBookSnapshot | None,
        down_book: OrderBookSnapshot | None,
        inventory: InventorySummary,
        target_quantity: Shares,
        now: UnixTimestamp,
        up_is_fresh: bool,
        down_is_fresh: bool,
        risk_input: RiskInput | None,
    ) -> DetectionResult:
        """Classify the current pair opportunity and describe candidates.

        Pure and synchronous: safe to call directly from the event loop without
        ``await``. Deterministic for identical inputs. Performs no side effects
        and does not submit orders.
        """
        target_quantity.require_positive()
        window = market.window
        seconds_to_close = _seconds_to_close(window.close_time, now)

        cost = evaluate_pair_cost(
            up_book,
            down_book,
            target_quantity=target_quantity,
            inventory=inventory,
            parameters=self._config.engine_parameters,
            seconds_to_close=seconds_to_close,
            up_is_fresh=up_is_fresh,
            down_is_fresh=down_is_fresh,
        )
        action = _ACTION_BY_ENGINE[cost.result]
        up_age = _book_age(up_book, now)
        down_age = _book_age(down_book, now)

        approved, approval_reason = self._approve(action, risk_input)

        candidates = self._build_candidates(
            market=market,
            up_book=up_book,
            down_book=down_book,
            inventory=inventory,
            target_quantity=target_quantity,
            now=now,
            cost=cost,
            action=action,
            approved=approved,
            approval_reason=approval_reason,
            up_age=up_age,
            down_age=down_age,
            seconds_to_close=seconds_to_close,
            risk_input=risk_input,
        )

        return DetectionResult(
            market_id=market.market_id,
            window=window,
            action=action,
            candidates=candidates,
            matched_inventory=inventory.matched_pairs,
            unmatched_up=inventory.unmatched_up,
            unmatched_down=inventory.unmatched_down,
            effective_pair_cost=cost.effective_pair_cost_taker,
            effective_pair_cost_maker=cost.effective_pair_cost_maker,
            expected_net_edge=cost.net_profit,
            seconds_to_close=seconds_to_close,
            up_book_age_seconds=up_age,
            down_book_age_seconds=down_age,
            risk_input_available=risk_input is not None,
            approved=approved,
            rejection_reasons=cost.rejection_reasons,
            engine_result=cost.result,
            cost_result=cost,
            evaluated_at=now,
        )

    # -- approval ---------------------------------------------------------- #
    def _approve(
        self,
        action: DetectorAction,
        risk_input: RiskInput | None,
    ) -> tuple[bool, str]:
        if risk_input is None:
            return (
                False,
                "risk_input_unavailable: detector cannot approve without risk-engine input",
            )
        if action in (DetectorAction.NO_TRADE, DetectorAction.MATCHED_INVENTORY):
            return False, "not_actionable: no acquisition to approve"
        if risk_input.verdict is RiskVerdict.REJECT:
            return False, f"risk_rejected: {risk_input.reason}"
        if risk_input.max_pair_size.value <= 0:
            return False, "risk_zero_size: risk-approved size is zero"
        return True, "risk_approved"

    # -- candidate construction ------------------------------------------- #
    def _build_candidates(
        self,
        *,
        market: BinaryMarket,
        up_book: OrderBookSnapshot | None,
        down_book: OrderBookSnapshot | None,
        inventory: InventorySummary,
        target_quantity: Shares,
        now: UnixTimestamp,
        cost: PairCostResult,
        action: DetectorAction,
        approved: bool,
        approval_reason: str,
        up_age: int | None,
        down_age: int | None,
        seconds_to_close: int,
        risk_input: RiskInput | None,
    ) -> tuple[PairCandidate, ...]:
        if action is DetectorAction.IMMEDIATE_TWO_LEG:
            return self._immediate_two_leg(
                market=market,
                inventory=inventory,
                target_quantity=target_quantity,
                now=now,
                cost=cost,
                approved=approved,
                approval_reason=approval_reason,
                up_age=up_age,
                down_age=down_age,
                seconds_to_close=seconds_to_close,
                risk_input=risk_input,
            )
        if action is DetectorAction.PASSIVE_FIRST_LEG:
            return self._passive_first_leg(
                market=market,
                up_book=up_book,
                down_book=down_book,
                inventory=inventory,
                target_quantity=target_quantity,
                now=now,
                cost=cost,
                approved=approved,
                approval_reason=approval_reason,
                up_age=up_age,
                down_age=down_age,
                seconds_to_close=seconds_to_close,
                risk_input=risk_input,
            )
        if action is DetectorAction.PASSIVE_SECOND_LEG:
            return self._passive_second_leg(
                market=market,
                up_book=up_book,
                down_book=down_book,
                inventory=inventory,
                target_quantity=target_quantity,
                now=now,
                cost=cost,
                approved=approved,
                approval_reason=approval_reason,
                up_age=up_age,
                down_age=down_age,
                seconds_to_close=seconds_to_close,
                risk_input=risk_input,
            )
        # MATCHED_INVENTORY and NO_TRADE propose nothing.
        return ()

    def _make_candidate(
        self,
        *,
        market: BinaryMarket,
        side: OutcomeSide,
        role: ExecutionRole,
        price: ProbabilityPrice,
        desired_qty: Shares,
        hedge_depth: Shares,
        pair_cost: CollateralAmount,
        net_edge: ProfitAmount,
        inventory: InventorySummary,
        now: UnixTimestamp,
        book_age: int | None,
        seconds_to_close: int,
        approved: bool,
        approval_reason: str,
        rejection_reasons: tuple[str, ...],
        risk_input: RiskInput | None,
    ) -> PairCandidate:
        ttl = (
            self._config.taker_order_ttl_seconds
            if role is ExecutionRole.TAKER
            else self._config.passive_order_ttl_seconds
        )
        return PairCandidate(
            market_id=market.market_id,
            window=market.window,
            side=side,
            role=role,
            proposed_price=price,
            proposed_quantity=_clamp_to_risk(desired_qty, approved, risk_input),
            matched_inventory=inventory.matched_pairs,
            unmatched_up=inventory.unmatched_up,
            unmatched_down=inventory.unmatched_down,
            effective_pair_cost=pair_cost,
            expected_net_edge=net_edge,
            required_hedge_depth=hedge_depth,
            book_age_seconds=book_age,
            seconds_to_close=seconds_to_close,
            cancel_deadline=_deadline(now, ttl, market.window.close_time),
            approved=approved,
            approval_reason=approval_reason,
            rejection_reasons=rejection_reasons,
        )

    def _immediate_two_leg(
        self,
        *,
        market: BinaryMarket,
        inventory: InventorySummary,
        target_quantity: Shares,
        now: UnixTimestamp,
        cost: PairCostResult,
        approved: bool,
        approval_reason: str,
        up_age: int | None,
        down_age: int | None,
        seconds_to_close: int,
        risk_input: RiskInput | None,
    ) -> tuple[PairCandidate, ...]:
        up_price = cost.up_vwap.average_price
        down_price = cost.down_vwap.average_price
        if up_price is None or down_price is None:
            return ()
        exec_qty = cost.max_executable_quantity
        desired = exec_qty if exec_qty.value < target_quantity.value else target_quantity
        up_leg = self._make_candidate(
            market=market,
            side=OutcomeSide.UP,
            role=ExecutionRole.TAKER,
            price=up_price,
            desired_qty=desired,
            hedge_depth=_hedge_depth(desired, inventory.unmatched_down),
            pair_cost=cost.effective_pair_cost_taker,
            net_edge=cost.net_profit,
            inventory=inventory,
            now=now,
            book_age=up_age,
            seconds_to_close=seconds_to_close,
            approved=approved,
            approval_reason=approval_reason,
            rejection_reasons=cost.rejection_reasons,
            risk_input=risk_input,
        )
        down_leg = self._make_candidate(
            market=market,
            side=OutcomeSide.DOWN,
            role=ExecutionRole.TAKER,
            price=down_price,
            desired_qty=desired,
            hedge_depth=_hedge_depth(desired, inventory.unmatched_up),
            pair_cost=cost.effective_pair_cost_taker,
            net_edge=cost.net_profit,
            inventory=inventory,
            now=now,
            book_age=down_age,
            seconds_to_close=seconds_to_close,
            approved=approved,
            approval_reason=approval_reason,
            rejection_reasons=cost.rejection_reasons,
            risk_input=risk_input,
        )
        return (up_leg, down_leg)

    def _passive_first_leg(
        self,
        *,
        market: BinaryMarket,
        up_book: OrderBookSnapshot | None,
        down_book: OrderBookSnapshot | None,
        inventory: InventorySummary,
        target_quantity: Shares,
        now: UnixTimestamp,
        cost: PairCostResult,
        approved: bool,
        approval_reason: str,
        up_age: int | None,
        down_age: int | None,
        seconds_to_close: int,
        risk_input: RiskInput | None,
    ) -> tuple[PairCandidate, ...]:
        maker_cost = cost.effective_pair_cost_maker
        if maker_cost is None:
            return ()
        side = _cheaper_maker_side(cost.up_maker_cost, cost.down_maker_cost)
        if side is OutcomeSide.UP:
            book, book_age, opposite = up_book, up_age, inventory.unmatched_down
        else:
            book, book_age, opposite = down_book, down_age, inventory.unmatched_up
        price = _maker_price(_best_bid(book), cost.max_first_leg_price)
        if price is None:
            return ()
        candidate = self._make_candidate(
            market=market,
            side=side,
            role=ExecutionRole.MAKER,
            price=price,
            desired_qty=target_quantity,
            hedge_depth=_hedge_depth(target_quantity, opposite),
            pair_cost=maker_cost,
            net_edge=_maker_net_edge(maker_cost),
            inventory=inventory,
            now=now,
            book_age=book_age,
            seconds_to_close=seconds_to_close,
            approved=approved,
            approval_reason=approval_reason,
            rejection_reasons=cost.rejection_reasons,
            risk_input=risk_input,
        )
        return (candidate,)

    def _passive_second_leg(
        self,
        *,
        market: BinaryMarket,
        up_book: OrderBookSnapshot | None,
        down_book: OrderBookSnapshot | None,
        inventory: InventorySummary,
        target_quantity: Shares,
        now: UnixTimestamp,
        cost: PairCostResult,
        approved: bool,
        approval_reason: str,
        up_age: int | None,
        down_age: int | None,
        seconds_to_close: int,
        risk_input: RiskInput | None,
    ) -> tuple[PairCandidate, ...]:
        # The missing side is the one whose unmatched inventory is short.
        if inventory.unmatched_up.value >= target_quantity.value:
            side = OutcomeSide.DOWN
            book, book_age = down_book, down_age
            held = inventory.unmatched_down
            vwap_price = cost.down_vwap.average_price
            opposite_held = inventory.unmatched_up
        else:
            side = OutcomeSide.UP
            book, book_age = up_book, up_age
            held = inventory.unmatched_up
            vwap_price = cost.up_vwap.average_price
            opposite_held = inventory.unmatched_down

        shortfall_dec = target_quantity.value - held.value
        desired = Shares(shortfall_dec if shortfall_dec > 0 else Decimal(0))

        ceiling = cost.max_second_leg_price
        best_ask = _best_ask(book)
        depth_ok = (
            cost.down_depth.is_sufficient
            if side is OutcomeSide.DOWN
            else cost.up_depth.is_sufficient
        )
        taker_feasible = (
            vwap_price is not None
            and ceiling is not None
            and best_ask is not None
            and best_ask.value <= ceiling.value
            and depth_ok
        )
        if taker_feasible and vwap_price is not None:
            role = ExecutionRole.TAKER
            price: ProbabilityPrice | None = vwap_price
            pair_cost = cost.effective_pair_cost_taker
            net_edge = cost.net_profit
        else:
            role = ExecutionRole.MAKER
            price = _maker_price(_best_bid(book), ceiling)
            pair_cost = cost.effective_pair_cost_maker or cost.effective_pair_cost_taker
            net_edge = _maker_net_edge(pair_cost)
        if price is None:
            return ()
        candidate = self._make_candidate(
            market=market,
            side=side,
            role=role,
            price=price,
            desired_qty=desired,
            hedge_depth=_hedge_depth(desired, opposite_held),
            pair_cost=pair_cost,
            net_edge=net_edge,
            inventory=inventory,
            now=now,
            book_age=book_age,
            seconds_to_close=seconds_to_close,
            approved=approved,
            approval_reason=approval_reason,
            rejection_reasons=cost.rejection_reasons,
            risk_input=risk_input,
        )
        return (candidate,)


def _cheaper_maker_side(
    up_maker_cost: CollateralAmount | None,
    down_maker_cost: CollateralAmount | None,
) -> OutcomeSide:
    """Pick the leg to post passively first: the cheaper resting side.

    Deterministic tie-break to UP. When one side has no maker cost, choose the
    side that does.
    """
    if up_maker_cost is None and down_maker_cost is None:
        return OutcomeSide.UP
    if up_maker_cost is None:
        return OutcomeSide.DOWN
    if down_maker_cost is None:
        return OutcomeSide.UP
    return OutcomeSide.UP if up_maker_cost.value <= down_maker_cost.value else OutcomeSide.DOWN


__all__ = [
    "DetectionResult",
    "DetectorAction",
    "DetectorConfig",
    "ExecutionRole",
    "PairCandidate",
    "PairDetector",
    "RiskInput",
]
