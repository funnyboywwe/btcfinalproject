"""Pair-accumulation session states and the legal transition table (Module 18).

This module is pure: it imports only the standard library. It defines the 14
lifecycle states of a single BTC 5-minute pair-accumulation session and the
directed graph of legal transitions. The state machine validates every move
against :data:`ALLOWED_TRANSITIONS` so an illegal transition fails closed
(routed to :attr:`SessionState.HALTED`) rather than silently corrupting state.

Nothing in this module asserts the strategy is profitable.
"""

from __future__ import annotations

from enum import Enum


class SessionState(str, Enum):
    """The lifecycle of one pair-accumulation session.

    Ordering of the enum members follows the nominal happy path, but the real
    control flow is defined by :data:`ALLOWED_TRANSITIONS`.
    """

    DISCOVERED = "discovered"
    BOOK_SYNCING = "book_syncing"
    READY = "ready"
    WAITING_FOR_EDGE = "waiting_for_edge"
    FIRST_LEG_OPEN = "first_leg_open"
    UNMATCHED_INVENTORY = "unmatched_inventory"
    SECOND_LEG_OPEN = "second_leg_open"
    MATCHED_PAIR = "matched_pair"
    MERGE_PENDING = "merge_pending"
    MERGING = "merging"
    CLOSED = "closed"
    UNWIND_REQUIRED = "unwind_required"
    RECONCILIATION_REQUIRED = "reconciliation_required"
    HALTED = "halted"

    @property
    def is_terminal(self) -> bool:
        """A terminal state never transitions again for this session."""
        return self is SessionState.CLOSED

    @property
    def needs_attention(self) -> bool:
        """States that require operator / reconciliation intervention."""
        return self in _ATTENTION

    @property
    def holds_unmatched(self) -> bool:
        """States in which directional unmatched exposure may exist."""
        return self in _HOLDS_UNMATCHED

    @property
    def holds_matched(self) -> bool:
        """States in which confirmed matched pairs are held awaiting merge."""
        return self in _HOLDS_MATCHED


_ATTENTION: frozenset[SessionState] = frozenset(
    {
        SessionState.UNWIND_REQUIRED,
        SessionState.RECONCILIATION_REQUIRED,
        SessionState.HALTED,
    }
)

_HOLDS_UNMATCHED: frozenset[SessionState] = frozenset(
    {
        SessionState.FIRST_LEG_OPEN,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.SECOND_LEG_OPEN,
    }
)

_HOLDS_MATCHED: frozenset[SessionState] = frozenset(
    {
        SessionState.MATCHED_PAIR,
        SessionState.MERGE_PENDING,
        SessionState.MERGING,
    }
)

# Any active (non-terminal) state may be forced to HALTED (kill switch) or to
# RECONCILIATION_REQUIRED (uncertain event); those universal edges are added
# programmatically below so the explicit table stays readable.
_BASE_TRANSITIONS: dict[SessionState, set[SessionState]] = {
    SessionState.DISCOVERED: {SessionState.BOOK_SYNCING},
    SessionState.BOOK_SYNCING: {
        SessionState.READY,
        SessionState.BOOK_SYNCING,
        SessionState.WAITING_FOR_EDGE,
        SessionState.FIRST_LEG_OPEN,
        SessionState.SECOND_LEG_OPEN,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.MATCHED_PAIR,
        SessionState.CLOSED,
    },
    SessionState.READY: {
        SessionState.WAITING_FOR_EDGE,
        SessionState.FIRST_LEG_OPEN,
        SessionState.SECOND_LEG_OPEN,
        SessionState.MATCHED_PAIR,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.BOOK_SYNCING,
        SessionState.CLOSED,
    },
    SessionState.WAITING_FOR_EDGE: {
        SessionState.WAITING_FOR_EDGE,
        SessionState.READY,
        SessionState.FIRST_LEG_OPEN,
        SessionState.SECOND_LEG_OPEN,
        SessionState.MATCHED_PAIR,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.BOOK_SYNCING,
        SessionState.CLOSED,
    },
    SessionState.FIRST_LEG_OPEN: {
        SessionState.FIRST_LEG_OPEN,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.WAITING_FOR_EDGE,
        SessionState.MATCHED_PAIR,
        SessionState.UNWIND_REQUIRED,
        SessionState.CLOSED,
    },
    SessionState.UNMATCHED_INVENTORY: {
        SessionState.UNMATCHED_INVENTORY,
        SessionState.SECOND_LEG_OPEN,
        SessionState.MATCHED_PAIR,
        SessionState.UNWIND_REQUIRED,
    },
    SessionState.SECOND_LEG_OPEN: {
        SessionState.SECOND_LEG_OPEN,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.MATCHED_PAIR,
        SessionState.UNWIND_REQUIRED,
    },
    SessionState.MATCHED_PAIR: {
        SessionState.MATCHED_PAIR,
        SessionState.MERGE_PENDING,
        SessionState.WAITING_FOR_EDGE,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.CLOSED,
    },
    SessionState.MERGE_PENDING: {
        SessionState.MERGE_PENDING,
        SessionState.MERGING,
        SessionState.MATCHED_PAIR,
        SessionState.CLOSED,
    },
    SessionState.MERGING: {
        SessionState.MERGING,
        SessionState.CLOSED,
        SessionState.MERGE_PENDING,
        SessionState.MATCHED_PAIR,
    },
    SessionState.UNWIND_REQUIRED: {
        SessionState.UNWIND_REQUIRED,
        SessionState.MATCHED_PAIR,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.CLOSED,
    },
    SessionState.RECONCILIATION_REQUIRED: {
        SessionState.RECONCILIATION_REQUIRED,
        SessionState.READY,
        SessionState.BOOK_SYNCING,
        SessionState.WAITING_FOR_EDGE,
        SessionState.UNMATCHED_INVENTORY,
        SessionState.MATCHED_PAIR,
        SessionState.UNWIND_REQUIRED,
        SessionState.CLOSED,
    },
    SessionState.HALTED: {
        SessionState.HALTED,
        SessionState.RECONCILIATION_REQUIRED,
        SessionState.CLOSED,
    },
    SessionState.CLOSED: set(),
}


def _build_allowed() -> dict[SessionState, frozenset[SessionState]]:
    allowed: dict[SessionState, set[SessionState]] = {
        state: set(targets) for state, targets in _BASE_TRANSITIONS.items()
    }
    for state in SessionState:
        if state.is_terminal:
            continue
        # Fail-closed universal edges: any active state may be halted or sent
        # for reconciliation.
        allowed[state].add(SessionState.HALTED)
        allowed[state].add(SessionState.RECONCILIATION_REQUIRED)
    return {state: frozenset(targets) for state, targets in allowed.items()}


ALLOWED_TRANSITIONS: dict[SessionState, frozenset[SessionState]] = _build_allowed()


def is_allowed(source: SessionState, target: SessionState) -> bool:
    """Return ``True`` if ``source -> target`` is a legal transition.

    A self-loop (``source is target``) is always allowed: it represents an
    in-state update (e.g. applying a fill that does not yet complete a pair).
    """
    if source is target:
        return True
    return target in ALLOWED_TRANSITIONS.get(source, frozenset())


__all__ = ["ALLOWED_TRANSITIONS", "SessionState", "is_allowed"]
