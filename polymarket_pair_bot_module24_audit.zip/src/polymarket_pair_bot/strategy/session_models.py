"""Persisted session state and derived value types (Module 18).

A :class:`PairSessionSnapshot` is the complete, serializable state of one
pair-accumulation session. It is the authoritative record the machine restores
from after a restart (requirement 4) and rebuilds inventory from; every
transition persists a fresh snapshot plus a :class:`SessionTransition` audit
row (requirement 1).

All monetary / quantity fields are domain value objects (``Decimal``-backed);
durations are integer seconds. No field holds a secret. Nothing here asserts
the strategy is profitable.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from decimal import Decimal

from polymarket_pair_bot.domain.enums import OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    CollateralAmount,
    MarketId,
    ProbabilityPrice,
    ProfitAmount,
    Shares,
)
from polymarket_pair_bot.strategy.engine import InventorySummary
from polymarket_pair_bot.strategy.session_states import SessionState

_ZERO = Decimal(0)


def _shares(value: Decimal) -> Shares:
    return Shares(value if value > 0 else _ZERO)


def _collateral(value: Decimal) -> CollateralAmount:
    return CollateralAmount(value if value > 0 else _ZERO)


@dataclass(frozen=True, slots=True)
class SessionLimits:
    """Pure, infrastructure-free limit set the machine reasons against.

    Built by the factory from :class:`StateMachineSettings`, the pair-strategy
    settings and the engine parameters, so the machine never reads
    configuration or the environment directly (dependency inversion).
    """

    target_pair_size: Shares
    first_leg_cutoff_seconds: int
    mandatory_cancel_seconds: int
    max_unmatched_shares: Shares
    max_unmatched_seconds: int
    unmatched_warning_ratio: Decimal
    merge_min_net_value: CollateralAmount
    max_effective_pair_cost: CollateralAmount
    overhead: CollateralAmount
    reconcile_on_uncertain: bool = True
    processed_id_history: int = 512

    def __post_init__(self) -> None:
        self.target_pair_size.require_positive()
        if self.first_leg_cutoff_seconds <= 0:
            raise ValueError("first_leg_cutoff_seconds must be positive")
        if self.mandatory_cancel_seconds < 0:
            raise ValueError("mandatory_cancel_seconds must be non-negative")
        if self.max_unmatched_seconds <= 0:
            raise ValueError("max_unmatched_seconds must be positive")
        if not (Decimal(0) < self.unmatched_warning_ratio <= Decimal(1)):
            raise ValueError("unmatched_warning_ratio must be in (0, 1]")
        if self.processed_id_history <= 0:
            raise ValueError("processed_id_history must be positive")

    @property
    def warning_shares(self) -> Decimal:
        return self.max_unmatched_shares.value * self.unmatched_warning_ratio

    @property
    def warning_seconds(self) -> Decimal:
        return Decimal(self.max_unmatched_seconds) * self.unmatched_warning_ratio


@dataclass(frozen=True, slots=True)
class PairSessionSnapshot:
    """The authoritative, restorable state of one session.

    Inventory is tracked as directional unmatched quantities plus completed
    matched pairs; a pair is only ever counted once BOTH sides are confirmed
    filled in equal quantity (the strategy invariant). Per-side cost basis
    (acquisition notional + fees) is tracked so the maximum second-leg cost and
    the locked net profit can be computed conservatively.
    """

    market_id: MarketId
    state: SessionState
    unmatched_up: Shares = field(default_factory=lambda: Shares(_ZERO))
    unmatched_down: Shares = field(default_factory=lambda: Shares(_ZERO))
    matched_pairs: Shares = field(default_factory=lambda: Shares(_ZERO))
    unmatched_up_cost: CollateralAmount = field(
        default_factory=lambda: CollateralAmount(_ZERO)
    )
    unmatched_down_cost: CollateralAmount = field(
        default_factory=lambda: CollateralAmount(_ZERO)
    )
    matched_cost: CollateralAmount = field(
        default_factory=lambda: CollateralAmount(_ZERO)
    )
    first_leg_side: OutcomeSide | None = None
    max_second_leg_price: ProbabilityPrice | None = None
    first_leg_filled_at: int | None = None
    locked_net_profit: ProfitAmount | None = None
    merge_operation_id: str | None = None
    version: int = 0
    updated_at: int = 0
    last_event_id: str | None = None
    processed_event_ids: tuple[str, ...] = ()
    processed_fill_ids: tuple[str, ...] = ()

    def inventory_summary(self) -> InventorySummary:
        """Project to the engine/detector :class:`InventorySummary`."""
        return InventorySummary(
            unmatched_up=self.unmatched_up,
            unmatched_down=self.unmatched_down,
            matched_pairs=self.matched_pairs,
        )

    @property
    def unmatched_size(self) -> Decimal:
        """Largest directional unmatched exposure (conservative)."""
        return max(self.unmatched_up.value, self.unmatched_down.value)

    @property
    def is_flat(self) -> bool:
        return (
            self.unmatched_up.value == _ZERO
            and self.unmatched_down.value == _ZERO
            and self.matched_pairs.value == _ZERO
        )

    @property
    def has_unmatched(self) -> bool:
        return self.unmatched_size > _ZERO

    def missing_side(self) -> OutcomeSide | None:
        """The outcome that must still be acquired to balance the pair.

        Returns the side currently *short* relative to the other, or ``None``
        when the two unmatched sides are already equal.
        """
        if self.unmatched_up.value > self.unmatched_down.value:
            return OutcomeSide.DOWN
        if self.unmatched_down.value > self.unmatched_up.value:
            return OutcomeSide.UP
        return None

    @property
    def shortfall(self) -> Decimal:
        """Shares needed on the missing side to complete the pair."""
        return abs(self.unmatched_up.value - self.unmatched_down.value)

    def first_leg_avg_price(self) -> Decimal | None:
        """Average acquisition price of the current unmatched (first) leg."""
        if self.first_leg_side is OutcomeSide.UP and self.unmatched_up.value > 0:
            return self.unmatched_up_cost.value / self.unmatched_up.value
        if self.first_leg_side is OutcomeSide.DOWN and self.unmatched_down.value > 0:
            return self.unmatched_down_cost.value / self.unmatched_down.value
        return None

    def apply_fill(
        self, *, side: OutcomeSide, quantity: Decimal, cost: Decimal
    ) -> tuple[PairSessionSnapshot, Decimal]:
        """Return a new snapshot with a confirmed fill applied.

        ``cost`` is the fully-loaded acquisition cost of the fill (price *
        size + fee), in USD. Any freshly-completed pairs are moved into
        ``matched_pairs`` (with proportional cost basis) and the number of
        newly matched shares is returned. Caller is responsible for fill-id
        de-duplication before calling this.
        """
        up = self.unmatched_up.value
        down = self.unmatched_down.value
        up_cost = self.unmatched_up_cost.value
        down_cost = self.unmatched_down_cost.value
        if side is OutcomeSide.UP:
            up += quantity
            up_cost += cost
        else:
            down += quantity
            down_cost += cost
        newly_matched = min(up, down)
        matched_cost = self.matched_cost.value
        if newly_matched > 0:
            up_avg = up_cost / up if up > 0 else _ZERO
            down_avg = down_cost / down if down > 0 else _ZERO
            up_moved = up_avg * newly_matched
            down_moved = down_avg * newly_matched
            matched_cost += up_moved + down_moved
            up -= newly_matched
            down -= newly_matched
            up_cost -= up_moved
            down_cost -= down_moved
        updated = replace(
            self,
            unmatched_up=_shares(up),
            unmatched_down=_shares(down),
            unmatched_up_cost=_collateral(up_cost),
            unmatched_down_cost=_collateral(down_cost),
            matched_pairs=Shares(self.matched_pairs.value + newly_matched),
            matched_cost=_collateral(matched_cost),
        )
        return updated, newly_matched

    def has_processed_event(self, event_id: str) -> bool:
        return event_id in self.processed_event_ids

    def has_processed_fill(self, fill_id: str) -> bool:
        return fill_id in self.processed_fill_ids

    def record_event(self, event_id: str, *, history: int) -> tuple[str, ...]:
        if event_id in self.processed_event_ids:
            return self.processed_event_ids
        return (*self.processed_event_ids, event_id)[-history:]

    def record_fill(self, fill_id: str, *, history: int) -> tuple[str, ...]:
        if fill_id in self.processed_fill_ids:
            return self.processed_fill_ids
        return (*self.processed_fill_ids, fill_id)[-history:]

    def evolve(self, **changes: object) -> PairSessionSnapshot:
        """Return a copy with ``changes`` applied (typed passthrough)."""
        return replace(self, **changes)  # type: ignore[arg-type]


@dataclass(frozen=True, slots=True)
class SessionTransition:
    """An immutable audit record of a single state transition (requirement 1)."""

    market_id: MarketId
    from_state: SessionState
    to_state: SessionState
    event_id: str
    event_type: str
    occurred_at: int
    version: int
    reason: str
    actions: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class TransitionOutcome:
    """Result of feeding one event to the machine.

    ``transition`` is ``None`` for an idempotent replay (already-processed
    event) or a genuine no-op; ``changed`` is ``True`` only when the persisted
    state advanced.
    """

    market_id: MarketId
    previous_state: SessionState
    snapshot: PairSessionSnapshot
    transition: SessionTransition | None
    actions: tuple[str, ...] = ()
    idempotent_replay: bool = False

    @property
    def state(self) -> SessionState:
        return self.snapshot.state

    @property
    def changed(self) -> bool:
        return self.transition is not None


__all__ = [
    "PairSessionSnapshot",
    "SessionLimits",
    "SessionTransition",
    "TransitionOutcome",
]
