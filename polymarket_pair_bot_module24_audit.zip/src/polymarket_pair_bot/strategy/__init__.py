"""Strategy layer: VWAP/fee engine (Module 8), pair-opportunity detector
(Module 10), and pair-accumulation state machine (Module 22).

Module 8: :func:`~polymarket_pair_bot.strategy.engine.evaluate_pair_cost` and
its immutable result types.

Module 10 (this addition): the pure :class:`~polymarket_pair_bot.strategy.detector.PairDetector`
plus the asynchronous observation-persistence consumer in
:mod:`polymarket_pair_bot.strategy.observations`.

Public API
----------

All names below are importable directly from this package::

    from polymarket_pair_bot.strategy import (
        evaluate_pair_cost,
        EngineParameters,
        FeeParameters,
        InventorySummary,
        PairCostResult,
        PairOpportunityResult,
        DepthAssessment,
        TickSensitivity,
        PairDetector,
        DetectorConfig,
        DetectorAction,
        ExecutionRole,
        PairCandidate,
        DetectionResult,
        RiskInput,
        DetectionObservation,
        CandidateObservation,
        ObservationConsumer,
        ObservationConsumerMetrics,
        ObservationOverflowPolicy,
        ObservationSink,
        observation_from_result,
    )
"""
from polymarket_pair_bot.strategy.detector import (
    DetectionResult,
    DetectorAction,
    DetectorConfig,
    ExecutionRole,
    PairCandidate,
    PairDetector,
    RiskInput,
)
from polymarket_pair_bot.strategy.engine import (
    DepthAssessment,
    EngineParameters,
    FeeParameters,
    InventorySummary,
    PairCostResult,
    PairOpportunityResult,
    TickSensitivity,
    evaluate_pair_cost,
)
from polymarket_pair_bot.strategy.observations import (
    CandidateObservation,
    DetectionObservation,
    ObservationConsumer,
    ObservationConsumerMetrics,
    ObservationOverflowPolicy,
    ObservationSink,
    observation_from_result,
)
from polymarket_pair_bot.strategy.session_events import (
    BooksUpdatedEvent,
    FillConfirmedEvent,
    KillSwitchEvent,
    LimitCheckEvent,
    MarketValidatedEvent,
    MergeEvaluateEvent,
    MergeResultEvent,
    ReconciledEvent,
    SessionEvent,
    UncertainEvent,
    WindowClosingEvent,
)
from polymarket_pair_bot.strategy.session_factory import (
    build_pair_detector,
    build_session_limits,
    build_state_machine,
)
from polymarket_pair_bot.strategy.session_machine import (
    PairAccumulationStateMachine,
)
from polymarket_pair_bot.strategy.session_models import (
    PairSessionSnapshot,
    SessionLimits,
    SessionTransition,
    TransitionOutcome,
)
from polymarket_pair_bot.strategy.session_ports import (
    ApprovalKind,
    KillSwitchPort,
    MergeOutcome,
    MergePort,
    ReconciliationPort,
    RiskApprovalPort,
    RiskApprovalRequest,
    RiskApprovalResult,
    SessionStore,
)
from polymarket_pair_bot.strategy.session_states import (
    ALLOWED_TRANSITIONS,
    SessionState,
    is_allowed,
)

__all__ = [
    "CandidateObservation",
    "DepthAssessment",
    "DetectionObservation",
    "DetectionResult",
    "DetectorAction",
    "DetectorConfig",
    "EngineParameters",
    "ExecutionRole",
    "FeeParameters",
    "InventorySummary",
    "ObservationConsumer",
    "ObservationConsumerMetrics",
    "ObservationOverflowPolicy",
    "ObservationSink",
    "PairCandidate",
    "PairCostResult",
    "PairDetector",
    "PairOpportunityResult",
    "RiskInput",
    "TickSensitivity",
    "evaluate_pair_cost",
    "observation_from_result",
    "ALLOWED_TRANSITIONS",
    "ApprovalKind",
    "BooksUpdatedEvent",
    "FillConfirmedEvent",
    "KillSwitchEvent",
    "KillSwitchPort",
    "LimitCheckEvent",
    "MarketValidatedEvent",
    "MergeEvaluateEvent",
    "MergeOutcome",
    "MergePort",
    "MergeResultEvent",
    "PairAccumulationStateMachine",
    "PairSessionSnapshot",
    "ReconciledEvent",
    "ReconciliationPort",
    "RiskApprovalPort",
    "RiskApprovalRequest",
    "RiskApprovalResult",
    "SessionEvent",
    "SessionLimits",
    "SessionState",
    "SessionStore",
    "SessionTransition",
    "TransitionOutcome",
    "UncertainEvent",
    "WindowClosingEvent",
    "build_pair_detector",
    "build_session_limits",
    "build_state_machine",
    "is_allowed",
]
