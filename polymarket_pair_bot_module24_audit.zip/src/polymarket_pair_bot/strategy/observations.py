"""Asynchronous persistence of detector observations (architecture item 10).

The :class:`~polymarket_pair_bot.strategy.detector.PairDetector` is pure and
must perform no side effects, so persisting what it observed is delegated to a
**separate consumer** running as its own supervised asyncio task. The detector
(or its caller) produces an immutable, secret-free :class:`DetectionObservation`
and hands it to :class:`ObservationConsumer.submit`; a single writer loop drains
a bounded queue in batches and writes to an abstract :class:`ObservationSink`.

Dependency inversion: this module depends only on the ``ObservationSink``
Protocol -- never on SQLAlchemy, HTTP, WebSocket or blockchain clients. Concrete
sinks (PostgreSQL / Parquet) are supplied at wiring time by a later module,
exactly as the market-data recorder supplies its sinks.

Asyncio safety: the queue is bounded, the writer batch is bounded, the loop is
cancellation-safe, shutdown is graceful (remaining items are flushed and the
sink is always closed), and no untracked background tasks are created here.

Monetary values are carried as exact decimal *strings* (never binary floats).
Nothing in this module asserts profitability.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass
from enum import Enum
from typing import Protocol, runtime_checkable

from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.strategy.detector import DetectionResult

_LOGGER = get_logger("strategy.observations")

Sleeper = Callable[[float], Awaitable[None]]
JsonValue = str | int | bool | None | list["JsonValue"] | dict[str, "JsonValue"]


@dataclass(frozen=True, slots=True)
class CandidateObservation:
    """Secret-free, serializable projection of one proposed candidate leg."""

    side: str
    role: str
    proposed_price: str
    proposed_quantity: str
    required_hedge_depth: str
    effective_pair_cost: str
    expected_net_edge: str
    cancel_deadline_epoch: int
    approved: bool

    def as_dict(self) -> dict[str, JsonValue]:
        return {
            "side": self.side,
            "role": self.role,
            "proposed_price": self.proposed_price,
            "proposed_quantity": self.proposed_quantity,
            "required_hedge_depth": self.required_hedge_depth,
            "effective_pair_cost": self.effective_pair_cost,
            "expected_net_edge": self.expected_net_edge,
            "cancel_deadline_epoch": self.cancel_deadline_epoch,
            "approved": self.approved,
        }


@dataclass(frozen=True, slots=True)
class DetectionObservation:
    """Immutable, secret-free record of one detector evaluation for storage.

    All monetary quantities are exact decimal strings; durations/counts are
    integers. This type crosses the persistence boundary and therefore holds no
    domain value objects and no credentials.
    """

    market_id: str
    window_open_epoch: int
    window_close_epoch: int
    evaluated_at_epoch: int
    action: str
    engine_result: str
    matched_inventory: str
    unmatched_up: str
    unmatched_down: str
    effective_pair_cost: str
    effective_pair_cost_maker: str | None
    expected_net_edge: str
    seconds_to_close: int
    up_book_age_seconds: int | None
    down_book_age_seconds: int | None
    risk_input_available: bool
    approved: bool
    candidate_count: int
    candidates: tuple[CandidateObservation, ...]
    rejection_reasons: tuple[str, ...]

    def as_dict(self) -> dict[str, JsonValue]:
        return {
            "market_id": self.market_id,
            "window_open_epoch": self.window_open_epoch,
            "window_close_epoch": self.window_close_epoch,
            "evaluated_at_epoch": self.evaluated_at_epoch,
            "action": self.action,
            "engine_result": self.engine_result,
            "matched_inventory": self.matched_inventory,
            "unmatched_up": self.unmatched_up,
            "unmatched_down": self.unmatched_down,
            "effective_pair_cost": self.effective_pair_cost,
            "effective_pair_cost_maker": self.effective_pair_cost_maker,
            "expected_net_edge": self.expected_net_edge,
            "seconds_to_close": self.seconds_to_close,
            "up_book_age_seconds": self.up_book_age_seconds,
            "down_book_age_seconds": self.down_book_age_seconds,
            "risk_input_available": self.risk_input_available,
            "approved": self.approved,
            "candidate_count": self.candidate_count,
            "candidates": [c.as_dict() for c in self.candidates],
            "rejection_reasons": list(self.rejection_reasons),
        }


def observation_from_result(result: DetectionResult) -> DetectionObservation:
    """Project a :class:`DetectionResult` into a storable observation."""
    candidates = tuple(
        CandidateObservation(
            side=candidate.side.value,
            role=candidate.role.value,
            proposed_price=str(candidate.proposed_price),
            proposed_quantity=str(candidate.proposed_quantity),
            required_hedge_depth=str(candidate.required_hedge_depth),
            effective_pair_cost=str(candidate.effective_pair_cost),
            expected_net_edge=str(candidate.expected_net_edge),
            cancel_deadline_epoch=candidate.cancel_deadline.value,
            approved=candidate.approved,
        )
        for candidate in result.candidates
    )
    maker_cost = result.effective_pair_cost_maker
    return DetectionObservation(
        market_id=result.market_id.value,
        window_open_epoch=result.window.open_time.value,
        window_close_epoch=result.window.close_time.value,
        evaluated_at_epoch=result.evaluated_at.value,
        action=result.action.value,
        engine_result=result.engine_result.value,
        matched_inventory=str(result.matched_inventory),
        unmatched_up=str(result.unmatched_up),
        unmatched_down=str(result.unmatched_down),
        effective_pair_cost=str(result.effective_pair_cost),
        effective_pair_cost_maker=None if maker_cost is None else str(maker_cost),
        expected_net_edge=str(result.expected_net_edge),
        seconds_to_close=result.seconds_to_close,
        up_book_age_seconds=result.up_book_age_seconds,
        down_book_age_seconds=result.down_book_age_seconds,
        risk_input_available=result.risk_input_available,
        approved=result.approved,
        candidate_count=len(candidates),
        candidates=candidates,
        rejection_reasons=result.rejection_reasons,
    )


class ObservationOverflowPolicy(str, Enum):
    """What to do when the bounded observation queue is full on ``submit``.

    * ``DROP_OLDEST`` -- evict the oldest queued observation, enqueue the new
      one (favor freshness; recommended for a high-volume detector).
    * ``DROP_NEWEST`` -- discard the incoming observation (keep the backlog).
    * ``BLOCK`` -- await space (applies backpressure to the producer only).
    """

    DROP_OLDEST = "drop_oldest"
    DROP_NEWEST = "drop_newest"
    BLOCK = "block"


@runtime_checkable
class ObservationSink(Protocol):
    """Abstract async sink for detector observations.

    Implementations must be cancellation-safe and must never perform blocking
    I/O directly on the event loop (offload to threads where appropriate).
    """

    async def write_batch(self, observations: Sequence[DetectionObservation]) -> int:
        """Persist a batch of observations; return the number written."""
        ...

    async def flush(self) -> None:
        """Flush any buffered data to durable storage."""
        ...

    async def aclose(self) -> None:
        """Flush and release resources. Must be idempotent."""
        ...


@dataclass(slots=True)
class ObservationConsumerMetrics:
    """Mutable counters describing consumer activity (Prometheus deferred)."""

    submitted: int = 0
    enqueued: int = 0
    written: int = 0
    dropped: int = 0
    overflows: int = 0
    write_errors: int = 0
    batches: int = 0
    flushes: int = 0

    def as_dict(self) -> dict[str, int]:
        return {
            "submitted": self.submitted,
            "enqueued": self.enqueued,
            "written": self.written,
            "dropped": self.dropped,
            "overflows": self.overflows,
            "write_errors": self.write_errors,
            "batches": self.batches,
            "flushes": self.flushes,
        }


class ObservationConsumer:
    """Bounded-queue, single-writer async consumer for detector observations.

    Producer side: ``await submit(observation)`` (non-blocking except under the
    ``BLOCK`` overflow policy). Consumer side: ``await run()`` drains the queue
    in bounded batches until :meth:`request_stop` is called and the queue is
    empty, then flushes and closes the sink. ``run`` is intended to be launched
    as one supervised task by the owning service.
    """

    def __init__(
        self,
        *,
        sink: ObservationSink,
        max_queue_size: int = 1000,
        batch_size: int = 64,
        drain_timeout_seconds: float = 0.5,
        policy: ObservationOverflowPolicy = ObservationOverflowPolicy.DROP_OLDEST,
        metrics: ObservationConsumerMetrics | None = None,
    ) -> None:
        if max_queue_size < 1:
            raise ValueError("max_queue_size must be >= 1")
        if batch_size < 1:
            raise ValueError("batch_size must be >= 1")
        if drain_timeout_seconds <= 0:
            raise ValueError("drain_timeout_seconds must be positive")
        self._sink = sink
        self._batch_size = batch_size
        self._drain_timeout = drain_timeout_seconds
        self._policy = policy
        self._metrics = metrics or ObservationConsumerMetrics()
        self._queue: asyncio.Queue[DetectionObservation] = asyncio.Queue(
            maxsize=max_queue_size
        )
        self._stop = asyncio.Event()
        self._closed = False

    @property
    def metrics(self) -> ObservationConsumerMetrics:
        return self._metrics

    def qsize(self) -> int:
        return self._queue.qsize()

    def request_stop(self) -> None:
        """Signal the writer to drain remaining items, flush and close."""
        self._stop.set()

    async def submit(self, observation: DetectionObservation) -> bool:
        """Offer an observation to the bounded queue via the overflow policy.

        Returns True when enqueued, False when dropped. Only ``BLOCK`` may
        suspend the caller.
        """
        self._metrics.submitted += 1
        try:
            self._queue.put_nowait(observation)
            self._metrics.enqueued += 1
            return True
        except asyncio.QueueFull:
            self._metrics.overflows += 1

        if self._policy is ObservationOverflowPolicy.DROP_NEWEST:
            self._metrics.dropped += 1
            return False

        if self._policy is ObservationOverflowPolicy.DROP_OLDEST:
            try:
                self._queue.get_nowait()
                self._queue.task_done()
                self._metrics.dropped += 1
            except asyncio.QueueEmpty:  # pragma: no cover - drained concurrently
                pass
            try:
                self._queue.put_nowait(observation)
                self._metrics.enqueued += 1
                return True
            except asyncio.QueueFull:  # pragma: no cover - refilled concurrently
                self._metrics.dropped += 1
                return False

        # BLOCK: backpressure the producer only.
        await self._queue.put(observation)
        self._metrics.enqueued += 1
        return True

    async def run(self) -> None:
        """Drain and persist until stopped, then flush and close the sink.

        Single-use: create one consumer per run. ``run`` deliberately does NOT
        clear the stop event, so a ``request_stop`` issued before the task is
        scheduled (e.g. when producers enqueue without yielding) is honored.
        """
        _LOGGER.info("observation_consumer_starting")
        try:
            while not (self._stop.is_set() and self._queue.empty()):
                batch = await self._drain_batch()
                if batch:
                    await self._write(batch)
        finally:
            remaining = self._drain_nowait()
            if remaining:
                await self._write(remaining)
            await self._flush_and_close()
        _LOGGER.info("observation_consumer_stopped", extra=self._metrics.as_dict())

    async def _drain_batch(self) -> list[DetectionObservation]:
        batch: list[DetectionObservation] = []
        try:
            first = await asyncio.wait_for(self._queue.get(), timeout=self._drain_timeout)
        except asyncio.TimeoutError:
            return batch
        batch.append(first)
        self._queue.task_done()
        while len(batch) < self._batch_size:
            try:
                item = self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            batch.append(item)
            self._queue.task_done()
        return batch

    def _drain_nowait(self) -> list[DetectionObservation]:
        batch: list[DetectionObservation] = []
        while True:
            try:
                item = self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            batch.append(item)
            self._queue.task_done()
        return batch

    async def _write(self, batch: Sequence[DetectionObservation]) -> None:
        try:
            written = await self._sink.write_batch(batch)
            self._metrics.written += written
            self._metrics.batches += 1
        except asyncio.CancelledError:
            raise
        except Exception:
            # Best-effort: never let a sink failure crash the writer loop.
            self._metrics.write_errors += 1
            _LOGGER.exception("observation_write_failed", extra={"batch_size": len(batch)})

    async def _flush_and_close(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            await self._sink.flush()
            self._metrics.flushes += 1
        except asyncio.CancelledError:
            raise
        except Exception:
            self._metrics.write_errors += 1
            _LOGGER.exception("observation_flush_failed")
        finally:
            await self._sink.aclose()


__all__ = [
    "CandidateObservation",
    "DetectionObservation",
    "ObservationConsumer",
    "ObservationConsumerMetrics",
    "ObservationOverflowPolicy",
    "ObservationSink",
    "observation_from_result",
]
