"""Prometheus-backed metrics sink for Module 20 (observability).

:class:`PrometheusMetricsSink` implements the existing ``MetricsSink`` protocol
(``incr`` / ``gauge`` / ``observe`` -- see
:mod:`polymarket_pair_bot.orchestrator.ports`) so it is a drop-in replacement
for :class:`NullMetricsSink` anywhere in the pipeline. It additionally exposes
typed, self-documenting helper methods for the well-known metrics defined in
:mod:`polymarket_pair_bot.observability.metric_names`.

Safety / robustness:

* ``prometheus_client`` is imported lazily inside ``__init__`` so importing this
  module never requires the package to be installed (mirrors the lazy-import
  pattern used by ``observability.health_checks``).
* Metrics are non-critical: **no** method here ever raises. A metrics failure
  must never be able to take down a trading task. Failures are logged at debug
  level and swallowed.
* Every collector lives in a private :class:`~prometheus_client.CollectorRegistry`
  (never the global default) so instances are isolated and tests are
  deterministic.
* Monetary values enter as :class:`decimal.Decimal` and are converted to
  ``float`` only here, at the export boundary; they are never read back into a
  financial calculation.
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.observability.metric_names import (
    METRIC_SPECS,
    MetricKind,
    MetricSpec,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from prometheus_client import CollectorRegistry

_log = get_logger(__name__)

_DEFAULT_NAMESPACE = "ppb"


def _strip_total(name: str) -> str:
    """Drop a trailing ``_total`` so counters are not double-suffixed."""
    return name[:-6] if name.endswith("_total") else name


def _to_float(value: Decimal | float | int) -> float:
    """Convert a monetary/quantity value to float at the export boundary."""
    return float(value)


class PrometheusMetricsSink:
    """A never-raising Prometheus metrics sink.

    Implements the structural ``MetricsSink`` protocol and pre-registers the
    Module 20 metric catalog. Unknown metric names passed through the generic
    ``incr`` / ``gauge`` / ``observe`` methods are created on demand with a
    label set inferred from the first call (so existing orchestrator metrics
    such as ``orchestrator_degraded_total`` keep working unchanged).
    """

    def __init__(
        self,
        *,
        namespace: str = _DEFAULT_NAMESPACE,
        registry: CollectorRegistry | None = None,
        include_process_metrics: bool = True,
    ) -> None:
        import prometheus_client

        self._client = prometheus_client
        self._namespace = namespace.strip("_") or _DEFAULT_NAMESPACE
        self._registry: CollectorRegistry = registry or prometheus_client.CollectorRegistry()
        # base_name -> (collector, kind, labelnames)
        self._collectors: dict[str, tuple[Any, MetricKind, tuple[str, ...]]] = {}

        if include_process_metrics:
            self._register_process_collectors()
        for spec in METRIC_SPECS:
            self._ensure(spec.name, spec.kind, tuple(spec.labelnames), spec=spec)

    # -- registry access --------------------------------------------------

    @property
    def registry(self) -> CollectorRegistry:
        """Return the private collector registry backing this sink."""
        return self._registry

    @property
    def namespace(self) -> str:
        """Return the Prometheus namespace prefix applied to every metric."""
        return self._namespace

    def render(self) -> tuple[bytes, str]:
        """Return ``(exposition_bytes, content_type)`` for the /metrics endpoint."""
        try:
            payload = self._client.generate_latest(self._registry)
            content_type: str = self._client.CONTENT_TYPE_LATEST
            return payload, content_type
        except Exception:  # noqa: BLE001 - metrics rendering must never raise
            _log.exception("metrics_render_failed")
            return b"", "text/plain; charset=utf-8"

    # -- generic MetricsSink protocol ------------------------------------

    def incr(self, name: str, value: float = 1.0, **labels: str) -> None:
        base = _strip_total(name)
        collector = self._ensure(base, MetricKind.COUNTER, tuple(sorted(labels)))
        self._apply(collector, base, labels, lambda c: c.inc(value))

    def gauge(self, name: str, value: float, **labels: str) -> None:
        collector = self._ensure(name, MetricKind.GAUGE, tuple(sorted(labels)))
        self._apply(collector, name, labels, lambda c: c.set(value))

    def observe(self, name: str, value: float, **labels: str) -> None:
        collector = self._ensure(name, MetricKind.HISTOGRAM, tuple(sorted(labels)))
        self._apply(collector, name, labels, lambda c: c.observe(value))

    # -- typed helpers: freshness ----------------------------------------

    def set_market_ws_age(self, seconds: float) -> None:
        self.gauge("market_websocket_age_seconds", float(seconds))

    def set_user_ws_age(self, seconds: float) -> None:
        self.gauge("user_websocket_age_seconds", float(seconds))

    def set_order_book_age(self, outcome: str, seconds: float) -> None:
        self.gauge("order_book_age_seconds", float(seconds), outcome=outcome)

    def set_event_loop_lag(self, seconds: float) -> None:
        self.gauge("event_loop_lag_seconds", float(seconds))

    # -- typed helpers: latency ------------------------------------------

    def observe_processing_latency(self, seconds: float) -> None:
        self.observe("processing_latency_seconds", float(seconds))

    def observe_rest_latency(self, operation: str, seconds: float) -> None:
        self.observe("rest_latency_seconds", float(seconds), operation=operation)

    def observe_rpc_latency(self, method: str, seconds: float) -> None:
        self.observe("rpc_latency_seconds", float(seconds), method=method)

    def observe_cancel_latency(self, seconds: float) -> None:
        self.observe("cancel_latency_seconds", float(seconds))

    # -- typed helpers: reconnects / detection ---------------------------

    def incr_reconnect(self, stream: str) -> None:
        self.incr("reconnects", 1.0, stream=stream)

    def incr_opportunity(self, count: int = 1) -> None:
        self.incr("opportunities_detected", float(count))

    def set_expected_pair_edge(self, edge_usd: Decimal | float) -> None:
        self.gauge("expected_pair_edge_usd", _to_float(edge_usd))

    # -- typed helpers: order lifecycle ----------------------------------

    def incr_order_submission(self, outcome: str, mode: str) -> None:
        self.incr("order_submissions", 1.0, outcome=outcome, mode=mode)

    def incr_order_rejection(self, reason: str) -> None:
        self.incr("order_rejections", 1.0, reason=reason)

    def incr_partial_fill(self, count: int = 1) -> None:
        self.incr("partial_fills", float(count))

    def incr_maker_fill(self, count: int = 1) -> None:
        self.incr("maker_fills", float(count))

    def incr_taker_fill(self, count: int = 1) -> None:
        self.incr("taker_fills", float(count))

    # -- typed helpers: inventory / matched pairs ------------------------

    def set_unmatched_shares(self, outcome: str, shares: Decimal | float) -> None:
        self.gauge("unmatched_shares", _to_float(shares), outcome=outcome)

    def set_unmatched_duration(self, seconds: float) -> None:
        self.gauge("unmatched_duration_seconds", float(seconds))

    def incr_matched_pairs(self, count: int = 1) -> None:
        self.incr("matched_pairs", float(count))

    def incr_merge_transaction(self, status: str) -> None:
        self.incr("merge_transactions", 1.0, status=status)

    # -- typed helpers: P&L / cost ---------------------------------------

    def set_gross_pnl(self, usd: Decimal | float) -> None:
        self.gauge("gross_pnl_usd", _to_float(usd))

    def set_realized_net_pnl(self, usd: Decimal | float) -> None:
        self.gauge("realized_net_pnl_usd", _to_float(usd))

    def add_fees(self, usd: Decimal | float) -> None:
        amount = _to_float(usd)
        if amount < 0:
            _log.debug("ignoring_negative_fee_increment", extra={"amount": amount})
            return
        self.incr("fees_usd", amount)

    def add_slippage(self, usd: Decimal | float) -> None:
        amount = _to_float(usd)
        if amount < 0:
            _log.debug("ignoring_negative_slippage_increment", extra={"amount": amount})
            return
        self.incr("slippage_usd", amount)

    # -- typed helpers: risk / safety ------------------------------------

    def incr_risk_rejection(self, rule: str) -> None:
        self.incr("risk_rejections", 1.0, rule=rule)

    def set_kill_switch(self, active: bool) -> None:
        self.gauge("kill_switch_active", 1.0 if active else 0.0)

    def incr_reconciliation_difference(self, kind: str) -> None:
        self.incr("reconciliation_differences", 1.0, kind=kind)

    # -- internals --------------------------------------------------------

    def _register_process_collectors(self) -> None:
        """Register standard process metrics (exposes process_start_time_seconds).

        ``ProcessCollector`` provides ``process_start_time_seconds`` which the
        process-restart alert relies on. Registration never raises.
        """
        try:
            self._client.ProcessCollector(registry=self._registry)
            self._client.PlatformCollector(registry=self._registry)
        except Exception:  # noqa: BLE001 - optional; platform dependent
            _log.debug("process_collector_unavailable")

    def _ensure(
        self,
        base: str,
        kind: MetricKind,
        labelnames: tuple[str, ...],
        *,
        spec: MetricSpec | None = None,
    ) -> Any | None:
        """Return an existing collector or lazily create it. Never raises."""
        existing = self._collectors.get(base)
        if existing is not None:
            return existing[0]
        try:
            collector = self._create(base, kind, labelnames, spec)
        except Exception:  # noqa: BLE001 - creation must never raise
            _log.debug("metric_create_failed", extra={"metric": base, "kind": kind.value})
            return None
        self._collectors[base] = (collector, kind, labelnames)
        return collector

    def _create(
        self,
        base: str,
        kind: MetricKind,
        labelnames: tuple[str, ...],
        spec: MetricSpec | None,
    ) -> Any:
        documentation = spec.documentation if spec else f"Auto-registered {kind.value} {base}."
        names = spec.labelnames if spec else labelnames
        if kind is MetricKind.COUNTER:
            return self._client.Counter(
                base,
                documentation,
                labelnames=names,
                namespace=self._namespace,
                registry=self._registry,
            )
        if kind is MetricKind.GAUGE:
            return self._client.Gauge(
                base,
                documentation,
                labelnames=names,
                namespace=self._namespace,
                registry=self._registry,
            )
        buckets = spec.buckets if (spec and spec.buckets) else None
        kwargs: dict[str, Any] = {
            "labelnames": names,
            "namespace": self._namespace,
            "registry": self._registry,
        }
        if buckets is not None:
            kwargs["buckets"] = buckets
        return self._client.Histogram(base, documentation, **kwargs)

    def _apply(
        self,
        collector: Any | None,
        base: str,
        labels: dict[str, str],
        op: Any,
    ) -> None:
        """Apply ``op`` to the (optionally labelled) collector; never raises."""
        if collector is None:
            return
        meta = self._collectors.get(base)
        try:
            if meta is not None and meta[2]:
                child = collector.labels(**{k: labels[k] for k in meta[2]})
                op(child)
            elif labels:
                # Labels supplied for a metric declared without them: ignore the
                # labels rather than raise.
                op(collector)
            else:
                op(collector)
        except Exception:  # noqa: BLE001 - metric updates must never raise
            _log.debug("metric_update_failed", extra={"metric": base})


def create_metrics_sink(
    *,
    namespace: str = _DEFAULT_NAMESPACE,
    registry: CollectorRegistry | None = None,
) -> PrometheusMetricsSink:
    """Build a :class:`PrometheusMetricsSink` with a private registry."""
    return PrometheusMetricsSink(namespace=namespace, registry=registry)


__all__ = ["PrometheusMetricsSink", "create_metrics_sink"]
