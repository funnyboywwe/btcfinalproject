"""Structured JSON logging with automatic secret redaction.

Module 0 uses the Python standard library ``logging`` module with a custom JSON
formatter and redaction filter. This keeps runtime logging free of any
import-time third-party dependency, which is also why the application can start
and emit logs before optional infrastructure is available.
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any

from polymarket_pair_bot.security.redaction import redact_mapping, redact_text

# Attributes present on a vanilla LogRecord; anything else is user context.
_RESERVED_ATTRS: frozenset[str] = frozenset(logging.makeLogRecord({}).__dict__) | {
    "message",
    "asctime",
    "taskName",
}


class JsonFormatter(logging.Formatter):
    """Render log records as single-line JSON with redacted secrets."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        context = {
            key: value
            for key, value in record.__dict__.items()
            if key not in _RESERVED_ATTRS
        }
        if context:
            payload["context"] = context
        redacted = redact_mapping(payload)
        return json.dumps(redacted, default=_json_default, separators=(",", ":"))


class RedactionFilter(logging.Filter):
    """Redact secret-looking substrings in the raw message template."""

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = redact_text(record.msg)
        return True


def _json_default(value: Any) -> str:
    return str(value)


def configure_logging(*, level: str = "INFO", json_output: bool = True) -> None:
    """Install a single stdout handler with JSON formatting and redaction."""
    root = logging.getLogger()
    root.setLevel(level.upper())
    for existing in list(root.handlers):
        root.removeHandler(existing)
    handler: logging.Handler = logging.StreamHandler(stream=sys.stdout)
    handler.addFilter(RedactionFilter())
    if json_output:
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
        )
    root.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced logger."""
    return logging.getLogger(name)
