"""Private FastAPI operator API for Module 20 (observability).

Exposes four endpoints on the private operator API:

* ``GET /health/live``     -- liveness (always 200 while the process responds).
* ``GET /health/ready``    -- readiness (200 ready / 503 not ready; fail closed).
* ``GET /health/details``  -- combined non-secret diagnostics (200).
* ``GET /metrics``         -- Prometheus exposition (private by default).

FastAPI/Starlette are imported lazily inside the factory so importing this
module never requires the web stack. The response *content* is produced by
:class:`polymarket_pair_bot.observability.health.OperatorHealth`, which is fully
testable without FastAPI.

Privacy: this app only serves diagnostics; it is bound to a private interface by
:class:`polymarket_pair_bot.observability.server.OperatorApiService` (default
``127.0.0.1``). It never exposes secrets and never accepts write operations.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from polymarket_pair_bot.observability.health import OperatorHealth
from polymarket_pair_bot.observability.logging import get_logger

if TYPE_CHECKING:  # pragma: no cover - typing only
    from fastapi import FastAPI

_log = get_logger(__name__)

# ``(exposition_bytes, content_type)`` provider for /metrics.
MetricsRenderer = Callable[[], tuple[bytes, str]]


def create_operator_app(
    *,
    health: OperatorHealth,
    metrics_renderer: MetricsRenderer | None = None,
    metrics_path: str = "/metrics",
    health_prefix: str = "/health",
    title: str = "polymarket-pair-bot operator API",
) -> FastAPI:
    """Build the private operator :class:`fastapi.FastAPI` application.

    Args:
        health: response builder for the health endpoints.
        metrics_renderer: callable returning ``(bytes, content_type)`` for the
            Prometheus exposition. If ``None`` the /metrics route returns 404.
        metrics_path: path for the Prometheus endpoint (default ``/metrics``).
        health_prefix: path prefix for the health endpoints.
        title: OpenAPI title.
    """
    from fastapi import FastAPI, Response
    from fastapi.responses import JSONResponse

    app = FastAPI(title=title, docs_url=None, redoc_url=None, openapi_url=None)

    @app.get(f"{health_prefix}/live")
    async def health_live() -> JSONResponse:
        result = health.live()
        return JSONResponse(status_code=result.status_code, content=result.body)

    @app.get(f"{health_prefix}/ready")
    async def health_ready() -> JSONResponse:
        result = await health.ready()
        return JSONResponse(status_code=result.status_code, content=result.body)

    if health.expose_details:

        @app.get(f"{health_prefix}/details")
        async def health_details() -> JSONResponse:
            result = await health.details()
            return JSONResponse(status_code=result.status_code, content=result.body)

    @app.get(metrics_path)
    async def metrics() -> Response:
        if metrics_renderer is None:
            return Response(status_code=404, content=b"metrics disabled")
        payload, content_type = metrics_renderer()
        return Response(content=payload, media_type=content_type)

    _log.info(
        "operator_api_app_created",
        extra={
            "metrics": metrics_renderer is not None,
            "details": health.expose_details,
        },
    )
    return app


def _unused_typing_anchor() -> Any:  # pragma: no cover - keeps Any import used
    return None


__all__ = ["MetricsRenderer", "create_operator_app"]
