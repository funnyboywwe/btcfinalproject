"""Prometheus alert-rule definitions for Module 20 (observability).

The alert catalog is pure data (standard library only) so it can be asserted on
in tests without any third-party dependency. ``render_rules_document`` builds a
Prometheus ``groups`` structure; ``to_yaml`` serialises it (PyYAML imported
lazily).

Thresholds are derived from the already-validated :class:`AppConfig` so alerts
stay consistent with the runtime limits (stale-book seconds, user-stream
freshness, unmatched-duration limit, daily-loss limit). Metric references are
namespaced to match the exported series (e.g. ``ppb_order_book_age_seconds``).

No alert expression, annotation, or label contains a secret.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:  # pragma: no cover - typing only
    from polymarket_pair_bot.config.settings import AppConfig


@dataclass(frozen=True, slots=True)
class AlertRule:
    """A single Prometheus alerting rule (non-secret)."""

    name: str
    expr: str
    for_duration: str
    severity: str
    summary: str
    description: str
    labels: dict[str, str] = field(default_factory=dict)

    def to_prometheus(self) -> dict[str, Any]:
        """Render this rule as a Prometheus rule mapping."""
        merged_labels = {"severity": self.severity, **self.labels}
        return {
            "alert": self.name,
            "expr": self.expr,
            "for": self.for_duration,
            "labels": merged_labels,
            "annotations": {
                "summary": self.summary,
                "description": self.description,
            },
        }


def _q(namespace: str, base: str) -> str:
    """Return the namespaced series name for a base metric name."""
    ns = namespace.strip("_") or "ppb"
    return f"{ns}_{base}"


def default_alert_rules(
    *,
    namespace: str = "ppb",
    stale_book_seconds: float = 5.0,
    stale_user_seconds: float = 30.0,
    unmatched_duration_seconds: int = 120,
    daily_loss_usd: Decimal | float = 50,
) -> tuple[AlertRule, ...]:
    """Build the required alert rules with thresholds materialised.

    Covers every alert required by Module 20: stale books, stale user stream,
    unmatched-duration breach, unknown order, balance mismatch, failed merge,
    process restart, daily loss, kill switch, and RPC disagreement.
    """
    book_age = _q(namespace, "order_book_age_seconds")
    user_age = _q(namespace, "user_websocket_age_seconds")
    unmatched_age = _q(namespace, "unmatched_duration_seconds")
    recon_diff = _q(namespace, "reconciliation_differences_total")
    merges = _q(namespace, "merge_transactions_total")
    net_pnl = _q(namespace, "realized_net_pnl_usd")
    kill_switch = _q(namespace, "kill_switch_active")
    # process_start_time_seconds is exported by the client ProcessCollector and
    # is NOT namespaced.
    proc_start = "process_start_time_seconds"
    loss_limit = f"{Decimal(str(daily_loss_usd))}"

    return (
        AlertRule(
            name="StaleOrderBooks",
            expr=f"{book_age} > {stale_book_seconds}",
            for_duration="30s",
            severity="critical",
            summary="Order book is stale",
            description=(
                "A local Up/Down order book has not updated within the freshness "
                "window; pricing must not use stale books (fail closed)."
            ),
        ),
        AlertRule(
            name="StaleUserStream",
            expr=f"{user_age} > {stale_user_seconds}",
            for_duration="30s",
            severity="critical",
            summary="Authenticated user stream is stale",
            description=(
                "The authenticated user WebSocket has not delivered a message "
                "within its freshness window; order/fill state may be unknown."
            ),
        ),
        AlertRule(
            name="UnmatchedDurationBreach",
            expr=f"{unmatched_age} > {unmatched_duration_seconds}",
            for_duration="0s",
            severity="critical",
            summary="Unmatched position exceeded its duration limit",
            description=(
                "Directional unmatched exposure has exceeded the configured "
                "maximum duration; the position should be hedged or unwound."
            ),
        ),
        AlertRule(
            name="UnknownOrderDetected",
            expr=f'increase({recon_diff}{{kind="unknown_order"}}[5m]) > 0',
            for_duration="0s",
            severity="critical",
            summary="Unknown order requires reconciliation",
            description=(
                "Reconciliation found an order with unknown status; new trading "
                "must remain halted until the account is proven consistent."
            ),
        ),
        AlertRule(
            name="BalanceMismatch",
            expr=f'increase({recon_diff}{{kind="balance_mismatch"}}[5m]) > 0',
            for_duration="0s",
            severity="critical",
            summary="Balance mismatch detected",
            description=(
                "Local expected balances disagree with authoritative on-chain / "
                "exchange balances; reconcile before resuming trading."
            ),
        ),
        AlertRule(
            name="FailedMerge",
            expr=f'increase({merges}{{status="failed"}}[10m]) > 0',
            for_duration="0s",
            severity="warning",
            summary="CTF merge transaction failed",
            description=(
                "A conditional-token merge failed; collateral recovery for the "
                "affected pair(s) did not complete."
            ),
        ),
        AlertRule(
            name="ProcessRestart",
            expr=f"changes({proc_start}[15m]) > 0",
            for_duration="0s",
            severity="warning",
            summary="Process restarted",
            description=(
                "The bot process start time changed within the last 15 minutes, "
                "indicating a restart; verify a clean authoritative resync."
            ),
        ),
        AlertRule(
            name="DailyLossLimit",
            expr=f"{net_pnl} < -{loss_limit}",
            for_duration="0s",
            severity="critical",
            summary="Daily loss limit breached",
            description=(
                "Realized net P&L has fallen below the negative daily loss limit; "
                "the kill switch should engage and halt new trading."
            ),
        ),
        AlertRule(
            name="KillSwitchActive",
            expr=f"{kill_switch} == 1",
            for_duration="0s",
            severity="warning",
            summary="Global kill switch is active",
            description=(
                "The global kill switch is engaged; new order submission is "
                "blocked while cancellation remains permitted."
            ),
        ),
        AlertRule(
            name="RpcDisagreement",
            expr=f'increase({recon_diff}{{kind="rpc_disagreement"}}[5m]) > 0',
            for_duration="0s",
            severity="critical",
            summary="Polygon RPC endpoints disagree",
            description=(
                "Primary and secondary Polygon RPC reads disagreed; on-chain "
                "state is uncertain and must be treated as fail-closed."
            ),
        ),
    )


def default_alert_rules_from_config(config: AppConfig) -> tuple[AlertRule, ...]:
    """Build alert rules using thresholds sourced from :class:`AppConfig`."""
    return default_alert_rules(
        namespace=config.monitoring.prometheus_namespace,
        stale_book_seconds=config.market_data.stale_after_seconds,
        stale_user_seconds=config.polymarket_auth.user_stream_freshness_seconds,
        unmatched_duration_seconds=config.risk.max_unmatched_duration_seconds,
        daily_loss_usd=config.risk.daily_loss_limit_usd,
    )


def render_rules_document(
    rules: tuple[AlertRule, ...],
    *,
    group_name: str = "polymarket_pair_bot",
) -> dict[str, Any]:
    """Render a Prometheus rules document (``groups`` mapping) from ``rules``."""
    return {
        "groups": [
            {
                "name": group_name,
                "rules": [rule.to_prometheus() for rule in rules],
            }
        ]
    }


def to_yaml(document: dict[str, Any]) -> str:
    """Serialise a rules document to YAML (PyYAML imported lazily)."""
    import yaml

    return yaml.safe_dump(document, sort_keys=False, default_flow_style=False)


__all__ = [
    "AlertRule",
    "default_alert_rules",
    "default_alert_rules_from_config",
    "render_rules_document",
    "to_yaml",
]
