"""Infrastructure health checks for PostgreSQL and Redis.

These are the only Module 0 components that touch external systems, and they do
so strictly for liveness probing (no trading logic). Third-party drivers are
imported lazily inside ``check`` so importing this module never requires the
drivers to be installed, and domain code stays free of infrastructure imports.

Probes never raise and never include connection strings or credentials in their
detail text.
"""

from __future__ import annotations

import asyncio

from polymarket_pair_bot.shared.health import HealthCheckResult


class PostgresHealthCheck:
    """Verify PostgreSQL connectivity with a lightweight ``SELECT 1``."""

    def __init__(self, dsn: str, *, timeout: float = 5.0) -> None:
        self._dsn = dsn
        self._timeout = timeout

    @property
    def name(self) -> str:
        return "postgres"

    async def check(self) -> HealthCheckResult:
        from sqlalchemy import text
        from sqlalchemy.ext.asyncio import create_async_engine

        engine = create_async_engine(self._dsn, pool_pre_ping=True)
        try:
            async with asyncio.timeout(self._timeout):
                async with engine.connect() as conn:
                    await conn.execute(text("SELECT 1"))
            return HealthCheckResult(healthy=True, detail="select 1 ok")
        except Exception as exc:  # noqa: BLE001 - report unhealthy, never raise
            return HealthCheckResult(healthy=False, detail=type(exc).__name__)
        finally:
            await engine.dispose()


class RedisHealthCheck:
    """Verify Redis connectivity with a ``PING``."""

    def __init__(self, url: str, *, timeout: float = 5.0) -> None:
        self._url = url
        self._timeout = timeout

    @property
    def name(self) -> str:
        return "redis"

    async def check(self) -> HealthCheckResult:
        import redis.asyncio as redis

        client = redis.from_url(self._url)
        try:
            async with asyncio.timeout(self._timeout):
                pong = await client.ping()
            return HealthCheckResult(healthy=bool(pong), detail="ping ok")
        except Exception as exc:  # noqa: BLE001 - report unhealthy, never raise
            return HealthCheckResult(healthy=False, detail=type(exc).__name__)
        finally:
            await client.aclose()
