"""Operator health/readiness aggregation for Module 20 (observability).

This module builds the *response bodies* for the private operator API's health
endpoints WITHOUT importing FastAPI, so the transition logic is fully unit
testable with only the standard library. :mod:`observability.api` is a thin
HTTP shell over :class:`OperatorHealth`.

Dependency inversion (a module-boundary rule): this module depends only on
small structural :class:`typing.Protocol` interfaces, never on concrete
orchestrator classes. The orchestrator's ``HealthTracker`` structurally
satisfies :class:`LivenessProbe` and its ``ReadinessProbe`` structurally
satisfies :class:`ReadinessEvaluator`.

Safety:

* No response body ever contains a secret. Non-secret config is injected via a
  ``config_view`` callable (the app passes ``AppConfig.health_public_view``),
  and the details body is additionally passed through the redaction filter as
  defence in depth.
* Readiness **fails closed**: any error while evaluating readiness yields
  ``ready=False`` (HTTP 503), never a false positive.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.security.redaction import redact_mapping
from polymarket_pair_bot.shared.health import HealthSnapshot, HealthState

_log = get_logger(__name__)


@runtime_checkable
class LivenessProbe(Protocol):
    """Structural interface for a liveness source (HealthTracker satisfies it)."""

    def snapshot(self) -> HealthSnapshot: ...


@runtime_checkable
class ReadinessOutcome(Protocol):
    """Structural shape of a readiness result (ReadinessReport satisfies it)."""

    @property
    def ready(self) -> bool: ...

    @property
    def checks(self) -> Mapping[str, bool]: ...

    @property
    def detail(self) -> Mapping[str, str]: ...


@runtime_checkable
class ReadinessEvaluator(Protocol):
    """Structural interface for an async readiness probe."""

    async def evaluate(self) -> ReadinessOutcome: ...


@dataclass(frozen=True, slots=True)
class ReadinessStatus:
    """Concrete :class:`ReadinessOutcome` used by the fail-closed fallback."""

    ready: bool
    checks: dict[str, bool] = field(default_factory=dict)
    detail: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class EndpointResult:
    """An HTTP-agnostic endpoint result (status code + JSON-able body)."""

    status_code: int
    body: dict[str, Any]


class LivenessOnlyReadiness:
    """Fallback readiness evaluator used when no full probe is injected.

    Fails closed: ``ready`` is true only when health is exactly READY. This is
    deliberately conservative -- production deployments should inject the
    orchestrator's full ``ReadinessProbe`` (kill switch, execution block,
    dependency probes, restored session).
    """

    def __init__(self, liveness: LivenessProbe) -> None:
        self._liveness = liveness

    async def evaluate(self) -> ReadinessOutcome:
        state = self._liveness.snapshot().state
        ready = state is HealthState.READY
        return ReadinessStatus(
            ready=ready,
            checks={"health": ready},
            detail={"health": state.value},
        )


class OperatorHealth:
    """Builds bodies/status codes for /health/live, /health/ready, /health/details."""

    def __init__(
        self,
        *,
        liveness: LivenessProbe,
        readiness: ReadinessEvaluator | None = None,
        config_view: Callable[[], Mapping[str, Any]] | None = None,
        version: str = "unknown",
        expose_details: bool = True,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self._liveness = liveness
        self._readiness: ReadinessEvaluator = readiness or LivenessOnlyReadiness(liveness)
        self._config_view = config_view or (lambda: {})
        self._version = version
        self._expose_details = expose_details
        self._monotonic = monotonic
        self._started_at = monotonic()

    @property
    def expose_details(self) -> bool:
        """Whether the /health/details endpoint should be served."""
        return self._expose_details

    def _uptime_seconds(self) -> float:
        return max(0.0, self._monotonic() - self._started_at)

    def live(self) -> EndpointResult:
        """Liveness: 200 while the process can respond, regardless of readiness."""
        snapshot = self._liveness.snapshot()
        return EndpointResult(
            status_code=200,
            body={"status": "alive", "state": snapshot.state.value},
        )

    async def ready(self) -> EndpointResult:
        """Readiness: 200 only when ready; 503 otherwise. Fails closed on error."""
        try:
            outcome = await self._readiness.evaluate()
            ready = bool(outcome.ready)
            checks = dict(outcome.checks)
            detail = dict(outcome.detail)
        except Exception as exc:  # noqa: BLE001 - fail closed on any error
            _log.warning("readiness_evaluation_failed", extra={"error": type(exc).__name__})
            ready = False
            checks = {"readiness_probe": False}
            detail = {"readiness_probe": f"error:{type(exc).__name__}"}
        state = self._liveness.snapshot().state
        return EndpointResult(
            status_code=200 if ready else 503,
            body={
                "ready": ready,
                "state": state.value,
                "checks": checks,
                "detail": detail,
            },
        )

    async def details(self) -> EndpointResult:
        """Combined, non-secret diagnostic view. Always 200."""
        snapshot = self._liveness.snapshot()
        readiness = await self.ready()
        body: dict[str, Any] = {
            "version": self._version,
            "state": snapshot.state.value,
            "detail": snapshot.detail,
            "updated_at": snapshot.updated_at.isoformat(),
            "uptime_seconds": round(self._uptime_seconds(), 3),
            "ready": readiness.body["ready"],
            "checks": readiness.body["checks"],
            "readiness_detail": readiness.body["detail"],
            "config": dict(self._config_view()),
        }
        # Defence in depth: never leak a secret even if config_view regresses.
        safe_body: dict[str, Any] = redact_mapping(body)
        return EndpointResult(status_code=200, body=safe_body)


__all__ = [
    "EndpointResult",
    "LivenessOnlyReadiness",
    "LivenessProbe",
    "OperatorHealth",
    "ReadinessEvaluator",
    "ReadinessOutcome",
    "ReadinessStatus",
]
