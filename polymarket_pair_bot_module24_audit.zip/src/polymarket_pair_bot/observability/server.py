"""Uvicorn-backed private operator API service for Module 20 (observability).

:class:`OperatorApiService` implements the application ``Service`` protocol
(``name`` / ``start`` / ``stop``) so it can be supervised by the existing
lifecycle manager alongside trading services. It serves the private operator
FastAPI app (health + metrics) on a private interface.

Safety / robustness:

* ``uvicorn`` is imported lazily inside ``start`` so importing this module never
  requires the web stack.
* The HTTP server binds to ``application.operator_api_host`` (default
  ``127.0.0.1``) so metrics/health are **private by default** (requirement 3).
* Observability must never take down trading: a failure to start the HTTP
  server is logged and swallowed (fail-open for the *diagnostics* surface).
  Readiness itself still fails closed independently of this server.
* The server runs in a single tracked, cancellation-safe task; ``stop`` requests
  a graceful shutdown bounded by a timeout.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from polymarket_pair_bot.observability.logging import get_logger

if TYPE_CHECKING:  # pragma: no cover - typing only
    from fastapi import FastAPI

_log = get_logger(__name__)


class OperatorApiService:
    """Serve the private operator FastAPI app via uvicorn as a lifecycle service."""

    def __init__(
        self,
        *,
        app: FastAPI,
        host: str = "127.0.0.1",
        port: int = 8081,
        shutdown_timeout: float = 5.0,
        name: str = "operator-api",
    ) -> None:
        self._app = app
        self._host = host
        self._port = port
        self._shutdown_timeout = shutdown_timeout
        self._name = name
        self._server: Any | None = None
        self._task: asyncio.Task[None] | None = None

    @property
    def name(self) -> str:
        """Return the service name used by the lifecycle manager."""
        return self._name

    async def start(self) -> None:
        """Start the uvicorn server in a supervised task (fail-open on error)."""
        try:
            import uvicorn
        except Exception:  # noqa: BLE001 - diagnostics must not block trading
            _log.warning("operator_api_uvicorn_unavailable")
            return
        config = uvicorn.Config(
            self._app,
            host=self._host,
            port=self._port,
            log_config=None,
            access_log=False,
            lifespan="off",
        )
        self._server = uvicorn.Server(config)
        # ``install_signal_handlers`` must be false: signals are owned by the
        # top-level lifecycle manager, not this embedded server.
        self._server.install_signal_handlers = False
        self._task = asyncio.create_task(self._serve(), name=self._name)
        _log.info(
            "operator_api_started",
            extra={"host": self._host, "port": self._port},
        )

    async def _serve(self) -> None:
        assert self._server is not None
        try:
            await self._server.serve()
        except asyncio.CancelledError:  # pragma: no cover - cooperative cancel
            raise
        except Exception:  # noqa: BLE001 - never let the HTTP server crash trading
            _log.exception("operator_api_crashed")

    async def stop(self) -> None:
        """Request a graceful shutdown; bounded and safe if never started."""
        if self._server is not None:
            self._server.should_exit = True
        task = self._task
        if task is None:
            return
        try:
            await asyncio.wait_for(asyncio.shield(task), timeout=self._shutdown_timeout)
        except TimeoutError:
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 - shutdown must not raise
            _log.debug("operator_api_stop_error")
        finally:
            self._task = None
            _log.info("operator_api_stopped")


__all__ = ["OperatorApiService"]
