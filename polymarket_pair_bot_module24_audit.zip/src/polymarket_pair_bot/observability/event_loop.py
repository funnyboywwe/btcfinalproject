"""Event-loop lag monitor for Module 20 (observability).

Measures asyncio scheduling drift: it sleeps for a fixed interval and reports
how much longer than requested the wake-up actually took. Sustained lag means
the event loop is being starved (e.g. an accidental blocking call), which is an
operational red flag for a latency-sensitive trading bot.

The monitor implements the application ``Service`` protocol and runs a single
tracked, cancellation-safe task with a bounded loop. It only *reads* the clock
and *writes* one gauge; it never touches trading state.
"""

from __future__ import annotations

import asyncio
from typing import Protocol

from polymarket_pair_bot.observability.logging import get_logger

_log = get_logger(__name__)


class LagSink(Protocol):
    """Minimal structural sink for reporting event-loop lag."""

    def set_event_loop_lag(self, seconds: float) -> None: ...


class EventLoopLagMonitor:
    """Periodically sample event-loop lag and publish it to a metrics sink."""

    def __init__(
        self,
        *,
        metrics: LagSink,
        poll_interval_seconds: float = 0.25,
        name: str = "event-loop-lag-monitor",
    ) -> None:
        if poll_interval_seconds <= 0:
            raise ValueError("poll_interval_seconds must be > 0")
        self._metrics = metrics
        self._interval = poll_interval_seconds
        self._name = name
        self._task: asyncio.Task[None] | None = None

    @property
    def name(self) -> str:
        """Return the service name used by the lifecycle manager."""
        return self._name

    async def start(self) -> None:
        """Launch the sampling task (idempotent)."""
        if self._task is not None:
            return
        self._task = asyncio.create_task(self._run(), name=self._name)
        _log.info("event_loop_lag_monitor_started", extra={"interval": self._interval})

    async def _run(self) -> None:
        loop = asyncio.get_running_loop()
        try:
            while True:
                scheduled = loop.time()
                await asyncio.sleep(self._interval)
                drift = loop.time() - scheduled - self._interval
                lag = drift if drift > 0.0 else 0.0
                try:
                    self._metrics.set_event_loop_lag(lag)
                except Exception:  # noqa: BLE001 - metrics must never crash the loop
                    _log.debug("event_loop_lag_publish_failed")
        except asyncio.CancelledError:  # pragma: no cover - cooperative cancel
            raise

    async def stop(self) -> None:
        """Cancel the sampling task; safe if never started."""
        task = self._task
        if task is None:
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        finally:
            self._task = None
            _log.info("event_loop_lag_monitor_stopped")


__all__ = ["EventLoopLagMonitor", "LagSink"]
