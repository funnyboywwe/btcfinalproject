"""Logging, metrics, health checks, and alerts.

Module 20 (observability) adds:

* :mod:`~polymarket_pair_bot.observability.metric_names` -- the Prometheus
  metric catalog (stdlib only).
* :mod:`~polymarket_pair_bot.observability.metrics` -- a never-raising
  :class:`PrometheusMetricsSink` implementing the ``MetricsSink`` protocol.
* :mod:`~polymarket_pair_bot.observability.health` -- non-secret operator
  health/readiness response building (no FastAPI dependency).
* :mod:`~polymarket_pair_bot.observability.api` / ``server`` -- the private
  operator FastAPI app and its uvicorn lifecycle service.
* :mod:`~polymarket_pair_bot.observability.event_loop` -- the event-loop lag
  monitor.
* :mod:`~polymarket_pair_bot.observability.alerts` -- Prometheus alert rules.

Third-party dependencies (prometheus_client, fastapi, uvicorn, PyYAML) are
imported lazily inside the components, so importing this package is cheap and
free of side effects. The ``factory`` and ``cli`` helpers additionally depend on
``AppConfig`` and should be imported directly when needed.
"""

from polymarket_pair_bot.observability.alerts import (
    AlertRule,
    default_alert_rules,
    default_alert_rules_from_config,
    render_rules_document,
)
from polymarket_pair_bot.observability.event_loop import EventLoopLagMonitor
from polymarket_pair_bot.observability.health import (
    EndpointResult,
    LivenessOnlyReadiness,
    OperatorHealth,
    ReadinessStatus,
)
from polymarket_pair_bot.observability.metric_names import (
    METRIC_SPECS,
    MetricKind,
    MetricSpec,
)
from polymarket_pair_bot.observability.metrics import (
    PrometheusMetricsSink,
    create_metrics_sink,
)
from polymarket_pair_bot.observability.server import OperatorApiService

__all__ = [
    "METRIC_SPECS",
    "AlertRule",
    "EndpointResult",
    "EventLoopLagMonitor",
    "LivenessOnlyReadiness",
    "MetricKind",
    "MetricSpec",
    "OperatorApiService",
    "OperatorHealth",
    "PrometheusMetricsSink",
    "ReadinessStatus",
    "create_metrics_sink",
    "default_alert_rules",
    "default_alert_rules_from_config",
    "render_rules_document",
]
