"""Read-only CLI for Module 20 observability.

Provides ``render-alert-rules``: materialise the Prometheus alerting rules from
the current configuration and print them (or write them to a file). This command
performs no network I/O and never places an order; it only reads config and
writes a local YAML file.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from polymarket_pair_bot.config.settings import load_config
from polymarket_pair_bot.observability.alerts import (
    default_alert_rules_from_config,
    render_rules_document,
    to_yaml,
)


def add_arguments(parser: argparse.ArgumentParser) -> None:
    """Register CLI arguments for ``render-alert-rules``."""
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        default=None,
        help="Write the rules YAML to this path instead of stdout.",
    )
    parser.add_argument(
        "--group-name",
        default="polymarket_pair_bot",
        help="Prometheus rule group name (default: polymarket_pair_bot).",
    )


def run(args: argparse.Namespace) -> int:
    """Render the alert rules and print or write them. Returns an exit code."""
    config = load_config()
    rules = default_alert_rules_from_config(config)
    document = render_rules_document(rules, group_name=args.group_name)
    yaml_text = to_yaml(document)
    output: Path | None = args.output
    if output is None:
        print(yaml_text, end="")
        return 0
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(yaml_text, encoding="utf-8")
    print(f"Wrote {len(rules)} alert rules to {output}")
    return 0


__all__ = ["add_arguments", "run"]
