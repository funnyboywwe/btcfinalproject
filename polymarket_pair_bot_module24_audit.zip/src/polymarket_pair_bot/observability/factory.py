"""Composition helpers that wire Module 20 observability from ``AppConfig``.

This is the (thin) composition layer: it is allowed to know about ``AppConfig``
and to assemble the metrics sink, the operator health responder, the FastAPI
app, the uvicorn service, and the event-loop lag monitor. Lower-level modules
(``metrics``, ``health``, ``api``, ``server``, ``event_loop``) stay decoupled and
depend only on small protocols.

All heavy third-party imports (prometheus_client, fastapi, uvicorn) remain lazy
inside the components, so importing this module is cheap and side-effect free.
"""

from __future__ import annotations

from importlib import metadata

from polymarket_pair_bot.config.settings import AppConfig
from polymarket_pair_bot.observability.event_loop import EventLoopLagMonitor
from polymarket_pair_bot.observability.health import (
    LivenessProbe,
    OperatorHealth,
    ReadinessEvaluator,
)
from polymarket_pair_bot.observability.metrics import (
    PrometheusMetricsSink,
    create_metrics_sink,
)
from polymarket_pair_bot.observability.server import OperatorApiService


def _package_version() -> str:
    try:
        return metadata.version("polymarket-pair-bot")
    except Exception:  # noqa: BLE001 - version is best-effort, never fatal
        return "unknown"


def build_metrics_sink(config: AppConfig) -> PrometheusMetricsSink:
    """Build the Prometheus metrics sink using the configured namespace."""
    return create_metrics_sink(namespace=config.monitoring.prometheus_namespace)


def build_operator_health(
    config: AppConfig,
    *,
    liveness: LivenessProbe,
    readiness: ReadinessEvaluator | None = None,
) -> OperatorHealth:
    """Build the operator health responder from config + injected probes."""
    return OperatorHealth(
        liveness=liveness,
        readiness=readiness,
        config_view=config.health_public_view,
        version=_package_version(),
        expose_details=True,
    )


def build_operator_api_service(
    config: AppConfig,
    *,
    liveness: LivenessProbe,
    readiness: ReadinessEvaluator | None = None,
    metrics: PrometheusMetricsSink | None = None,
) -> OperatorApiService:
    """Assemble the private operator API service (health + metrics).

    FastAPI is imported lazily by ``create_operator_app`` here so the rest of
    the composition stays importable without the web stack.
    """
    from polymarket_pair_bot.observability.api import create_operator_app

    health = build_operator_health(config, liveness=liveness, readiness=readiness)
    renderer = metrics.render if metrics is not None else None
    app = create_operator_app(health=health, metrics_renderer=renderer)
    return OperatorApiService(
        app=app,
        host=config.application.operator_api_host,
        port=config.application.operator_api_port,
        shutdown_timeout=config.application.shutdown_timeout_seconds,
    )


def build_event_loop_monitor(
    config: AppConfig,
    *,
    metrics: PrometheusMetricsSink,
) -> EventLoopLagMonitor:
    """Build the event-loop lag monitor bound to the metrics sink."""
    return EventLoopLagMonitor(
        metrics=metrics,
        poll_interval_seconds=config.monitoring.event_loop_lag_poll_seconds,
    )


__all__ = [
    "build_event_loop_monitor",
    "build_metrics_sink",
    "build_operator_api_service",
    "build_operator_health",
]
