"""Prometheus metric catalog for Module 20 (observability).

This module is intentionally dependency-light: it imports only the standard
library so the *catalog* (metric names, kinds, label sets, help text, buckets)
can be imported and asserted on without the Prometheus client installed. The
concrete collectors are built from this catalog by
:mod:`polymarket_pair_bot.observability.metrics`, which lazily imports
``prometheus_client``.

Design notes / safety:

* Metric values are a lossy *observability projection*. Monetary quantities are
  computed elsewhere with :class:`decimal.Decimal` (never binary floats); they
  are converted to ``float`` only here at the Prometheus export boundary and are
  never read back into a financial calculation.
* Label sets are deliberately low-cardinality. In particular the rotating BTC
  5-minute ``market_id`` is **never** used as a label (a new market every five
  minutes would explode series cardinality); only bounded dimensions such as
  ``outcome`` (up/down), ``stream`` (market/user) and coarse status strings are
  used.
* Counter base names do NOT carry the ``_total`` suffix: ``prometheus_client``
  appends it automatically when exposing the sample.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

__all__ = [
    "AGE_BUCKETS",
    "LATENCY_BUCKETS",
    "METRIC_SPECS",
    "MetricKind",
    "MetricSpec",
    "spec_by_name",
]


class MetricKind(str, Enum):
    """The Prometheus collector kind a metric maps to."""

    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"


@dataclass(frozen=True, slots=True)
class MetricSpec:
    """A declarative description of one metric.

    Attributes:
        name: base metric name WITHOUT the Prometheus namespace prefix and,
            for counters, WITHOUT the ``_total`` suffix.
        kind: the collector kind (counter/gauge/histogram).
        documentation: human-readable help string (never contains secrets).
        labelnames: fixed, low-cardinality label names for the metric.
        buckets: histogram buckets (seconds); ``None`` for non-histograms.
    """

    name: str
    kind: MetricKind
    documentation: str
    labelnames: tuple[str, ...] = ()
    buckets: tuple[float, ...] | None = None


# Latency buckets (seconds) suitable for sub-second network / processing work
# up to a few seconds of tail latency.
LATENCY_BUCKETS: tuple[float, ...] = (
    0.001,
    0.005,
    0.01,
    0.025,
    0.05,
    0.1,
    0.25,
    0.5,
    1.0,
    2.5,
    5.0,
    10.0,
)

# Age buckets (seconds) for freshness histograms if ever needed.
AGE_BUCKETS: tuple[float, ...] = (0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0)


METRIC_SPECS: tuple[MetricSpec, ...] = (
    # -- Freshness / age gauges ------------------------------------------
    MetricSpec(
        "market_websocket_age_seconds",
        MetricKind.GAUGE,
        "Seconds since the last message on the public market-data WebSocket.",
    ),
    MetricSpec(
        "user_websocket_age_seconds",
        MetricKind.GAUGE,
        "Seconds since the last message on the authenticated user WebSocket.",
    ),
    MetricSpec(
        "order_book_age_seconds",
        MetricKind.GAUGE,
        "Seconds since the local order book was last updated.",
        labelnames=("outcome",),
    ),
    MetricSpec(
        "event_loop_lag_seconds",
        MetricKind.GAUGE,
        "Observed asyncio event-loop scheduling lag (drift) in seconds.",
    ),
    # -- Latency histograms ----------------------------------------------
    MetricSpec(
        "processing_latency_seconds",
        MetricKind.HISTOGRAM,
        "End-to-end latency to process one market/session event.",
        buckets=LATENCY_BUCKETS,
    ),
    MetricSpec(
        "rest_latency_seconds",
        MetricKind.HISTOGRAM,
        "Latency of authenticated/public REST calls (seconds).",
        labelnames=("operation",),
        buckets=LATENCY_BUCKETS,
    ),
    MetricSpec(
        "rpc_latency_seconds",
        MetricKind.HISTOGRAM,
        "Latency of Polygon JSON-RPC reads (seconds).",
        labelnames=("method",),
        buckets=LATENCY_BUCKETS,
    ),
    MetricSpec(
        "cancel_latency_seconds",
        MetricKind.HISTOGRAM,
        "Latency between requesting and confirming an order cancellation.",
        buckets=LATENCY_BUCKETS,
    ),
    # -- Reconnects / discovery counters ---------------------------------
    MetricSpec(
        "reconnects",
        MetricKind.COUNTER,
        "WebSocket reconnects, by stream (market/user).",
        labelnames=("stream",),
    ),
    MetricSpec(
        "opportunities_detected",
        MetricKind.COUNTER,
        "Pair opportunities detected by the detector (not necessarily traded).",
    ),
    MetricSpec(
        "expected_pair_edge_usd",
        MetricKind.GAUGE,
        "Most recent expected pair edge in USD (1 - effective_pair_cost).",
    ),
    # -- Order lifecycle counters ----------------------------------------
    MetricSpec(
        "order_submissions",
        MetricKind.COUNTER,
        "Order submissions attempted, by outcome and execution mode.",
        labelnames=("outcome", "mode"),
    ),
    MetricSpec(
        "order_rejections",
        MetricKind.COUNTER,
        "Order submissions rejected, by reason.",
        labelnames=("reason",),
    ),
    MetricSpec(
        "partial_fills",
        MetricKind.COUNTER,
        "Partial fill events observed (never treated as a matched pair).",
    ),
    MetricSpec(
        "maker_fills",
        MetricKind.COUNTER,
        "Maker fill events observed.",
    ),
    MetricSpec(
        "taker_fills",
        MetricKind.COUNTER,
        "Taker fill events observed.",
    ),
    # -- Inventory / matched-pair gauges & counters ----------------------
    MetricSpec(
        "unmatched_shares",
        MetricKind.GAUGE,
        "Current directional unmatched outcome-token shares, by outcome.",
        labelnames=("outcome",),
    ),
    MetricSpec(
        "unmatched_duration_seconds",
        MetricKind.GAUGE,
        "Age in seconds of the oldest currently unmatched position.",
    ),
    MetricSpec(
        "matched_pairs",
        MetricKind.COUNTER,
        "Confirmed matched Up/Down pairs (equal confirmed-filled quantities).",
    ),
    MetricSpec(
        "merge_transactions",
        MetricKind.COUNTER,
        "CTF merge transactions, by status (submitted/confirmed/failed).",
        labelnames=("status",),
    ),
    # -- P&L / cost gauges & counters (USD; float is an export projection)
    MetricSpec(
        "gross_pnl_usd",
        MetricKind.GAUGE,
        "Gross P&L in USD before fees/slippage (observability projection).",
    ),
    MetricSpec(
        "realized_net_pnl_usd",
        MetricKind.GAUGE,
        "Realized net P&L in USD after fees/slippage (observability projection).",
    ),
    MetricSpec(
        "fees_usd",
        MetricKind.COUNTER,
        "Cumulative taker/maker fees paid in USD (observability projection).",
    ),
    MetricSpec(
        "slippage_usd",
        MetricKind.COUNTER,
        "Cumulative realized slippage in USD (observability projection).",
    ),
    # -- Risk / safety ---------------------------------------------------
    MetricSpec(
        "risk_rejections",
        MetricKind.COUNTER,
        "Order intents rejected by the centralized risk engine, by rule.",
        labelnames=("rule",),
    ),
    MetricSpec(
        "kill_switch_active",
        MetricKind.GAUGE,
        "Global kill switch state (1 = active/blocking, 0 = inactive).",
    ),
    MetricSpec(
        "reconciliation_differences",
        MetricKind.COUNTER,
        "Reconciliation differences detected, by kind (e.g. unknown_order).",
        labelnames=("kind",),
    ),
)


def spec_by_name(name: str) -> MetricSpec | None:
    """Return the :class:`MetricSpec` for ``name`` (base name) or ``None``."""
    for spec in METRIC_SPECS:
        if spec.name == name:
            return spec
    return None
