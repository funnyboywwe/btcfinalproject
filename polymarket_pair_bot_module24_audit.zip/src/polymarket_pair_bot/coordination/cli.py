"""Operator CLI for coordination state.

Usage::

    python -m polymarket_pair_bot.coordination.cli leader
    python -m polymarket_pair_bot.coordination.cli kill-switch status
    python -m polymarket_pair_bot.coordination.cli kill-switch activate \
        --reason "manual halt" --actor ops
    python -m polymarket_pair_bot.coordination.cli kill-switch deactivate \
        --actor ops

Activating/deactivating the kill switch performs a **dual write**: the
authoritative append-only event is journaled in PostgreSQL first (Module 3),
then the Redis fast-cache is updated. Redis is never the only permanent audit
store. Output never includes secrets, DSNs or connection URLs.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from collections.abc import Sequence
from datetime import UTC, datetime

from polymarket_pair_bot.config import AppConfig, load_config
from polymarket_pair_bot.coordination.factory import build_redis_coordination
from polymarket_pair_bot.domain.coordination import KillSwitchState


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="polymarket-pair-bot-coord",
        description="Inspect coordination state and control the kill switch.",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("leader", help="Show the current execution-leader owner")

    ks = sub.add_parser("kill-switch", help="Inspect or control the kill switch")
    ks_sub = ks.add_subparsers(dest="ks_command", required=True)
    ks_sub.add_parser("status", help="Show current kill-switch state")
    activate = ks_sub.add_parser("activate", help="Activate the kill switch")
    activate.add_argument("--reason", required=True, help="Why it is being set")
    activate.add_argument("--actor", default=None, help="Who is setting it")
    deactivate = ks_sub.add_parser("deactivate", help="Deactivate the kill switch")
    deactivate.add_argument("--actor", default=None, help="Who is clearing it")
    return parser


def _now() -> int:
    return int(datetime.now(tz=UTC).timestamp())


def _print_state(state: KillSwitchState) -> None:
    print(
        f"kill_switch active={state.active} reason={state.reason!r} "
        f"actor={state.actor!r} updated_at={state.updated_at}"
    )


async def _journal_kill_switch(
    config: AppConfig, *, active: bool, reason: str, actor: str | None, at: int
) -> bool:
    """Best-effort authoritative journal write to PostgreSQL.

    Returns True on success. A DB failure must not prevent activating the
    switch, but it is reported so the operator knows the audit write failed.
    """
    try:
        from polymarket_pair_bot.persistence.engine import (
            create_engine_from_dsn,
            create_session_factory,
        )
        from polymarket_pair_bot.persistence.repositories import (
            SqlAlchemyUnitOfWork,
        )

        engine = create_engine_from_dsn(config.postgres.dsn, echo=False)
        try:
            session_factory = create_session_factory(engine)
            async with SqlAlchemyUnitOfWork(session_factory) as uow:
                await uow.kill_switch.record(
                    key=config.risk.kill_switch_key,
                    active=active,
                    reason=reason,
                    created_at=at,
                    actor=actor,
                )
                await uow.commit()
        finally:
            await engine.dispose()
        return True
    except Exception as exc:  # noqa: BLE001 - report, never crash the CLI
        print(f"WARNING: kill-switch journal write failed: {type(exc).__name__}")
        return False


async def _run(config: AppConfig, args: argparse.Namespace) -> int:
    coordination = build_redis_coordination(config)
    try:
        if args.command == "leader":
            owner = await coordination.leader.current_owner()
            scope = coordination.leader.scope
            if owner is None:
                print(f"leader scope={scope} owner=<none> (no active leader)")
            else:
                is_self = owner == coordination.identity.token
                print(f"leader scope={scope} owner={owner} is_self={is_self}")
            return 0

        if args.command == "kill-switch":
            if args.ks_command == "status":
                _print_state(await coordination.kill_switch.get_state())
                return 0
            at = _now()
            if args.ks_command == "activate":
                await _journal_kill_switch(
                    config,
                    active=True,
                    reason=args.reason,
                    actor=args.actor,
                    at=at,
                )
                state = await coordination.kill_switch.activate(
                    reason=args.reason, actor=args.actor, at=at
                )
                _print_state(state)
                return 0
            if args.ks_command == "deactivate":
                await _journal_kill_switch(
                    config, active=False, reason="", actor=args.actor, at=at
                )
                state = await coordination.kill_switch.deactivate(
                    actor=args.actor, at=at
                )
                _print_state(state)
                return 0
        return 2
    finally:
        await coordination.aclose()


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    config = load_config()
    return asyncio.run(_run(config, args))


if __name__ == "__main__":  # pragma: no cover - thin CLI shim
    sys.exit(main())
