"""Wiring helpers that assemble the Redis-backed coordination stack.

These helpers are the composition boundary: they import redis-py (lazily via
:func:`create_redis_client`) and hand back objects typed against the domain
protocols so the rest of the app depends only on interfaces.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from polymarket_pair_bot.config import AppConfig
from polymarket_pair_bot.coordination.cache import RedisMarketMetadataCache
from polymarket_pair_bot.coordination.counters import RedisRiskCounters
from polymarket_pair_bot.coordination.heartbeat import RedisHeartbeatStore
from polymarket_pair_bot.coordination.identity import (
    build_process_identity,
    execution_scope,
)
from polymarket_pair_bot.coordination.idempotency import RedisIdempotencyStore
from polymarket_pair_bot.coordination.keys import RedisKeys
from polymarket_pair_bot.coordination.kill_switch import RedisKillSwitchCache
from polymarket_pair_bot.coordination.leader import RedisLeaderLease
from polymarket_pair_bot.coordination.redis_client import create_redis_client
from polymarket_pair_bot.domain.coordination import ProcessIdentity

if TYPE_CHECKING:  # pragma: no cover - typing only
    from redis.asyncio import Redis


@dataclass(frozen=True)
class RedisCoordination:
    """Assembled coordination stack (all typed as domain protocols)."""

    client: Redis
    identity: ProcessIdentity
    keys: RedisKeys
    leader: RedisLeaderLease
    kill_switch: RedisKillSwitchCache
    market_metadata: RedisMarketMetadataCache
    risk_counters: RedisRiskCounters
    idempotency: RedisIdempotencyStore
    heartbeats: RedisHeartbeatStore

    async def aclose(self) -> None:
        """Close the underlying Redis connection pool."""
        await self.client.aclose()


def build_redis_coordination(
    config: AppConfig,
    *,
    identity: ProcessIdentity | None = None,
    client: Redis | None = None,
) -> RedisCoordination:
    """Assemble the full Redis coordination stack from configuration.

    A pre-built ``client`` may be injected for tests; otherwise one is created
    from the (secret) Redis URL. ``identity`` defaults to a fresh per-process
    identity.
    """
    coord = config.coordination
    redis_client = client or create_redis_client(
        config.redis.url,
        operation_timeout_seconds=coord.redis_operation_timeout_seconds,
    )
    proc = identity or build_process_identity()
    keys = RedisKeys(config.redis.redis_namespace)
    return RedisCoordination(
        client=redis_client,
        identity=proc,
        keys=keys,
        leader=RedisLeaderLease(
            redis_client,
            keys,
            scope=execution_scope(config),
            token=proc.token,
            ttl_seconds=coord.leader_lease_ttl_seconds,
        ),
        kill_switch=RedisKillSwitchCache(
            redis_client, key=config.risk.kill_switch_key
        ),
        market_metadata=RedisMarketMetadataCache(
            redis_client,
            keys,
            default_ttl_seconds=coord.market_metadata_ttl_seconds,
        ),
        risk_counters=RedisRiskCounters(redis_client, keys),
        idempotency=RedisIdempotencyStore(redis_client, keys),
        heartbeats=RedisHeartbeatStore(redis_client, keys),
    )


__all__ = ["RedisCoordination", "build_redis_coordination"]
