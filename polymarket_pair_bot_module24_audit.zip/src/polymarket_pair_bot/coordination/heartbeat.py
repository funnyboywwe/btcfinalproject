"""Redis-backed application heartbeats.

Each component periodically writes a TTL-expiring key. If a component stops
beating, its key expires and ``is_alive`` returns ``False`` -- a lightweight
liveness signal for the operator dashboard and supervisors. Heartbeats are
ephemeral by design and are never an audit record.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polymarket_pair_bot.coordination.keys import RedisKeys
from polymarket_pair_bot.coordination.redis_client import guard

if TYPE_CHECKING:  # pragma: no cover - typing only
    from redis.asyncio import Redis


class RedisHeartbeatStore:
    """Implements the domain ``HeartbeatStore`` protocol against Redis."""

    def __init__(self, client: Redis, keys: RedisKeys) -> None:
        self._client = client
        self._keys = keys

    async def beat(
        self, component: str, *, ttl_seconds: int, detail: str = ""
    ) -> None:
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        await guard(
            self._client.set(self._keys.heartbeat(component), detail, ex=ttl_seconds)
        )

    async def is_alive(self, component: str) -> bool:
        value = await guard(self._client.exists(self._keys.heartbeat(component)))
        return int(value) > 0

    async def get_detail(self, component: str) -> str | None:
        value = await guard(self._client.get(self._keys.heartbeat(component)))
        return None if value is None else str(value)


__all__ = ["RedisHeartbeatStore"]
