"""Redis-backed distributed execution-leader lease.

Exactly one process may hold the lease for a given scope (one wallet == one
scope). The lease is a single Redis key set with ``NX`` and a short ``PX`` TTL;
the value is this process's unique owner token. Renewal and release are
ownership-verified via atomic Lua scripts (compare-and-extend / compare-and-
delete) so a process can never renew or delete a lease it no longer owns -- for
example after its lease expired and another process took over.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polymarket_pair_bot.coordination.keys import RedisKeys
from polymarket_pair_bot.coordination.redis_client import guard

if TYPE_CHECKING:  # pragma: no cover - typing only
    from redis.asyncio import Redis

# Extend the TTL only if we still own the key. Returns 1 on success, 0 if not.
_RENEW_LUA = """
if redis.call('get', KEYS[1]) == ARGV[1] then
    return redis.call('pexpire', KEYS[1], ARGV[2])
else
    return 0
end
"""

# Delete the key only if we still own it. Returns 1 on delete, 0 otherwise.
_RELEASE_LUA = """
if redis.call('get', KEYS[1]) == ARGV[1] then
    return redis.call('del', KEYS[1])
else
    return 0
end
"""


class RedisLeaderLease:
    """Implements the domain ``LeaderElector`` protocol against Redis."""

    def __init__(
        self,
        client: Redis,
        keys: RedisKeys,
        *,
        scope: str,
        token: str,
        ttl_seconds: float,
    ) -> None:
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        self._client = client
        self._key = keys.leader(scope)
        self._scope = scope
        self._token = token
        self._ttl_ms = int(ttl_seconds * 1000)

    @property
    def scope(self) -> str:
        return self._scope

    @property
    def token(self) -> str:
        return self._token

    async def acquire(self) -> bool:
        """Acquire the lease if unheld. True only if this process now owns it."""
        result = await guard(
            self._client.set(self._key, self._token, nx=True, px=self._ttl_ms)
        )
        return bool(result)

    async def renew(self) -> bool:
        """Extend the TTL, verifying ownership atomically."""
        result = await guard(
            self._client.eval(_RENEW_LUA, 1, self._key, self._token, self._ttl_ms)
        )
        return int(result) == 1

    async def release(self) -> None:
        """Release the lease only if still owned by this process."""
        await guard(
            self._client.eval(_RELEASE_LUA, 1, self._key, self._token)
        )

    async def current_owner(self) -> str | None:
        """Return the current owner token, or None if the lease is unheld."""
        value = await guard(self._client.get(self._key))
        if value is None:
            return None
        return str(value)


__all__ = ["RedisLeaderLease"]
