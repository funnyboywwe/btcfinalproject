"""Execution gate: the single source of truth for "may this process trade?".

The gate starts **disabled** (fail closed). Only the confirmed execution leader
enables it; losing leadership, a Redis failure, or shutdown disables it. Any
live order-submission path (added in a later module) must consult the gate and
refuse when it is disabled.

The boolean is a plain attribute (atomic to read/write under CPython); reads are
lock-free so hot paths never block. ``reason`` is advisory context for logging
and the operator CLI.
"""

from __future__ import annotations

from dataclasses import dataclass

from polymarket_pair_bot.domain.coordination import ExecutionGateView


@dataclass(frozen=True, slots=True)
class ExecutionGateSnapshot:
    """Immutable snapshot of the gate for health/operator views."""

    enabled: bool
    reason: str


class ExecutionGate(ExecutionGateView):
    """Concrete, in-process execution gate (starts disabled / fail closed)."""

    def __init__(self) -> None:
        self._enabled = False
        self._reason = "initialized (standby, read-only)"

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @property
    def reason(self) -> str:
        return self._reason

    def enable(self, reason: str = "execution leader") -> None:
        """Allow live order submission (leader only)."""
        self._reason = reason
        self._enabled = True

    def disable(self, reason: str) -> None:
        """Immediately forbid new order submission. Idempotent and safe."""
        self._enabled = False
        self._reason = reason

    def snapshot(self) -> ExecutionGateSnapshot:
        return ExecutionGateSnapshot(enabled=self._enabled, reason=self._reason)


__all__ = ["ExecutionGate", "ExecutionGateSnapshot"]
