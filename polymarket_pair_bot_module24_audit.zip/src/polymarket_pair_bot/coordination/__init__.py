"""Redis coordination and leader election (Module 4).

Provides the distributed execution-leader lease, persistent kill-switch cache,
short-lived market metadata cache, risk counters, idempotency keys and
application heartbeats. Domain code depends only on the protocols in
``polymarket_pair_bot.domain.coordination``; the concrete implementations here
are the only place redis-py is used.
"""

from __future__ import annotations

from polymarket_pair_bot.coordination.cache import RedisMarketMetadataCache
from polymarket_pair_bot.coordination.coordinator import (
    LeadershipCoordinator,
    LoggingLeadershipObserver,
)
from polymarket_pair_bot.coordination.counters import RedisRiskCounters
from polymarket_pair_bot.coordination.factory import (
    RedisCoordination,
    build_redis_coordination,
)
from polymarket_pair_bot.coordination.gate import (
    ExecutionGate,
    ExecutionGateSnapshot,
)
from polymarket_pair_bot.coordination.heartbeat import RedisHeartbeatStore
from polymarket_pair_bot.coordination.identity import (
    build_process_identity,
    execution_scope,
    requires_execution_leader,
)
from polymarket_pair_bot.coordination.idempotency import RedisIdempotencyStore
from polymarket_pair_bot.coordination.keys import RedisKeys
from polymarket_pair_bot.coordination.kill_switch import RedisKillSwitchCache
from polymarket_pair_bot.coordination.leader import RedisLeaderLease
from polymarket_pair_bot.coordination.redis_client import (
    create_redis_client,
    guard,
)

__all__ = [
    "ExecutionGate",
    "ExecutionGateSnapshot",
    "LeadershipCoordinator",
    "LoggingLeadershipObserver",
    "RedisCoordination",
    "RedisHeartbeatStore",
    "RedisIdempotencyStore",
    "RedisKeys",
    "RedisKillSwitchCache",
    "RedisLeaderLease",
    "RedisMarketMetadataCache",
    "RedisRiskCounters",
    "build_process_identity",
    "build_redis_coordination",
    "create_redis_client",
    "execution_scope",
    "guard",
    "requires_execution_leader",
]
