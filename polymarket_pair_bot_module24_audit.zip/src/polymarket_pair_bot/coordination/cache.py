"""Short-lived market metadata cache backed by Redis.

Cached entries carry a short TTL and are **never** treated as the source of
truth (PostgreSQL is). Cached JSON is validated on read with a Pydantic v2
model; malformed entries are treated as a cache miss (fail closed) so corrupt
or version-skewed cache data can never propagate into the domain.

Tick sizes round-trip as strings and are parsed to ``Decimal`` (never binary
floats).
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict, ValidationError, field_validator

from polymarket_pair_bot.coordination.keys import RedisKeys
from polymarket_pair_bot.coordination.redis_client import guard
from polymarket_pair_bot.domain.coordination import MarketMetadata

if TYPE_CHECKING:  # pragma: no cover - typing only
    from redis.asyncio import Redis


class _CachedMarketMetadata(BaseModel):
    """Validated wire form of :class:`MarketMetadata` for cache round-trips."""

    model_config = ConfigDict(extra="forbid")

    market_id: str
    condition_id: str
    up_token_id: str
    down_token_id: str
    up_tick_size: Decimal
    down_tick_size: Decimal
    close_time: int
    fetched_at: int

    @field_validator("up_tick_size", "down_tick_size")
    @classmethod
    def _finite_non_negative(cls, value: Decimal) -> Decimal:
        if not value.is_finite() or value < 0:
            raise ValueError("tick size must be a finite, non-negative decimal")
        return value

    @classmethod
    def from_domain(cls, meta: MarketMetadata) -> _CachedMarketMetadata:
        return cls(
            market_id=meta.market_id,
            condition_id=meta.condition_id,
            up_token_id=meta.up_token_id,
            down_token_id=meta.down_token_id,
            up_tick_size=meta.up_tick_size,
            down_tick_size=meta.down_tick_size,
            close_time=meta.close_time,
            fetched_at=meta.fetched_at,
        )

    def to_domain(self) -> MarketMetadata:
        return MarketMetadata(
            market_id=self.market_id,
            condition_id=self.condition_id,
            up_token_id=self.up_token_id,
            down_token_id=self.down_token_id,
            up_tick_size=self.up_tick_size,
            down_tick_size=self.down_tick_size,
            close_time=self.close_time,
            fetched_at=self.fetched_at,
        )


class RedisMarketMetadataCache:
    """Implements the domain ``MarketMetadataCache`` protocol against Redis."""

    def __init__(
        self,
        client: Redis,
        keys: RedisKeys,
        *,
        default_ttl_seconds: int,
    ) -> None:
        if default_ttl_seconds <= 0:
            raise ValueError("default_ttl_seconds must be positive")
        self._client = client
        self._keys = keys
        self._default_ttl = default_ttl_seconds

    async def get(self, market_id: str) -> MarketMetadata | None:
        raw = await guard(self._client.get(self._keys.market_metadata(market_id)))
        if raw is None:
            return None
        try:
            return _CachedMarketMetadata.model_validate_json(raw).to_domain()
        except ValidationError:
            # Corrupt/skewed cache entry: treat as a miss, never propagate.
            return None

    async def put(
        self, metadata: MarketMetadata, *, ttl_seconds: int | None = None
    ) -> None:
        ttl = ttl_seconds if ttl_seconds is not None else self._default_ttl
        if ttl <= 0:
            raise ValueError("ttl_seconds must be positive")
        payload = _CachedMarketMetadata.from_domain(metadata).model_dump_json()
        await guard(
            self._client.set(
                self._keys.market_metadata(metadata.market_id), payload, ex=ttl
            )
        )


__all__ = ["RedisMarketMetadataCache"]
