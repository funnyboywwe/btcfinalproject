"""Redis client construction and error translation.

The redis-py asynchronous client is created with conservative socket timeouts
so a hung Redis never blocks the event loop indefinitely. All coordination
stores route their calls through :func:`guard` so redis-py / timeout errors are
translated into :class:`RedisUnavailableError`; callers can then fail closed
(disable execution) without leaking driver internals.

``decode_responses=True`` is used so values round-trip as ``str``.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable
from typing import TYPE_CHECKING, TypeVar

from polymarket_pair_bot.domain.coordination import RedisUnavailableError

if TYPE_CHECKING:  # pragma: no cover - typing only
    from redis.asyncio import Redis

_T = TypeVar("_T")


def create_redis_client(
    url: str,
    *,
    operation_timeout_seconds: float = 2.0,
) -> Redis:
    """Create an asyncio Redis client with bounded socket timeouts.

    Imported lazily so importing this module never requires redis-py to be
    installed (mirrors the health-check module).
    """
    import redis.asyncio as redis

    return redis.from_url(
        url,
        decode_responses=True,
        socket_timeout=operation_timeout_seconds,
        socket_connect_timeout=operation_timeout_seconds,
        health_check_interval=30,
    )


async def guard(awaitable: Awaitable[_T]) -> _T:
    """Await a redis-py coroutine, translating failures to a domain error.

    Any driver error, connection error or timeout becomes
    :class:`RedisUnavailableError` so the coordination layer can fail closed
    without importing redis-py exception types at call sites.
    """
    try:
        return await awaitable
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # noqa: BLE001 - translate to a single domain error
        raise RedisUnavailableError(type(exc).__name__) from exc


__all__ = ["create_redis_client", "guard"]
