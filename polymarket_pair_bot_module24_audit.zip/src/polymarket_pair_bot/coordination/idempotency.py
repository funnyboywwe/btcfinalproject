"""Redis-backed first-writer-wins idempotency keys.

A claim is an atomic ``SET key value NX EX ttl``. The first caller for a key
receives ``True`` (proceed exactly once); every later caller within the TTL
receives ``False`` (already handled). This backs the idempotency requirement
for state-changing operations without being the permanent record -- the
authoritative dedupe/audit lives in PostgreSQL (e.g. unique fill IDs).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polymarket_pair_bot.coordination.keys import RedisKeys
from polymarket_pair_bot.coordination.redis_client import guard

if TYPE_CHECKING:  # pragma: no cover - typing only
    from redis.asyncio import Redis

_CLAIMED = "1"


class RedisIdempotencyStore:
    """Implements the domain ``IdempotencyStore`` protocol against Redis."""

    def __init__(self, client: Redis, keys: RedisKeys) -> None:
        self._client = client
        self._keys = keys

    async def claim(self, key: str, *, ttl_seconds: int) -> bool:
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        result = await guard(
            self._client.set(
                self._keys.idempotency(key), _CLAIMED, nx=True, ex=ttl_seconds
            )
        )
        return bool(result)

    async def is_claimed(self, key: str) -> bool:
        value = await guard(self._client.get(self._keys.idempotency(key)))
        return value is not None


__all__ = ["RedisIdempotencyStore"]
