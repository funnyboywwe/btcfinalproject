"""Process identity and execution-scope helpers.

The lease owner token is derived from a stable per-process identity
(``host:pid:uuid``). It contains no secrets and is safe to log / display.

The execution *scope* identifies the wallet a leader controls. Live mode keys
the scope by the configured funder address so distinct wallets elect distinct
leaders; non-live modes use a fixed placeholder (there is no wallet to guard).
"""

from __future__ import annotations

import os
import socket
import uuid

from polymarket_pair_bot.config import AppConfig
from polymarket_pair_bot.domain.coordination import ProcessIdentity

_DEFAULT_SCOPE = "paper-or-recorder"


def build_process_identity() -> ProcessIdentity:
    """Construct a unique, log-safe identity for this process."""
    return ProcessIdentity(
        process_id=uuid.uuid4().hex,
        hostname=socket.gethostname(),
        pid=os.getpid(),
    )


def execution_scope(config: AppConfig) -> str:
    """Return the leadership scope for the wallet this process would control.

    Uses the funder address (lower-cased) only as a routing label; it is a
    public address, never a secret. Falls back to a fixed non-live placeholder.
    """
    if config.application.live_trading:
        funder = config.wallet.polymarket_funder_address
        if funder:
            return f"wallet:{funder.lower()}"
    return _DEFAULT_SCOPE


def requires_execution_leader(config: AppConfig) -> bool:
    """Only live trading requires a single execution leader over a wallet.

    Paper and recorder modes touch no wallet and may run without leadership.
    """
    return config.application.live_trading


__all__ = [
    "build_process_identity",
    "execution_scope",
    "requires_execution_leader",
]
