"""Deterministic, namespaced Redis key builder.

All coordination keys are derived from a single namespace so that multiple
environments (dev/staging/prod) can safely share one Redis instance. Keys never
contain secrets.
"""

from __future__ import annotations


class RedisKeys:
    """Build namespaced keys for every coordination concern."""

    def __init__(self, namespace: str) -> None:
        self._ns = namespace.rstrip(":") or "ppb"

    @property
    def namespace(self) -> str:
        return self._ns

    def _key(self, *parts: str) -> str:
        return ":".join((self._ns, *parts))

    def leader(self, scope: str) -> str:
        """Execution-leader lease key for a wallet/execution scope."""
        return self._key("leader", scope)

    def market_metadata(self, market_id: str) -> str:
        return self._key("market", "meta", market_id)

    def risk_counter(self, name: str) -> str:
        return self._key("risk", "counter", name)

    def idempotency(self, key: str) -> str:
        return self._key("idem", key)

    def heartbeat(self, component: str) -> str:
        return self._key("heartbeat", component)


__all__ = ["RedisKeys"]
