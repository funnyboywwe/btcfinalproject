"""Execution-leadership coordinator (async service).

Drives a single background loop that:

* tries to acquire the lease while a standby;
* periodically renews the lease (ownership-verified) while leader;
* on gaining leadership: enables the execution gate and calls
  ``observer.on_promoted``;
* on losing leadership (renewal failed, or Redis unavailable): **immediately**
  disables the execution gate (new orders off), then calls
  ``observer.on_demoted`` so the execution layer can safely cancel resting
  orders and reconcile.

Safety properties:

* Starts in the standby (gate-disabled) state -> fail closed.
* A Redis failure demotes and keeps the gate disabled -> live trading disabled.
* The loop is a single tracked task; ``stop`` cancels it cleanly, releases the
  lease if owned, and disables the gate. No untracked background tasks.

This module performs no order submission and imports no execution/live classes;
reactions are delegated through the ``LeadershipObserver`` port.
"""

from __future__ import annotations

import asyncio
import contextlib

from polymarket_pair_bot.coordination.gate import ExecutionGate
from polymarket_pair_bot.domain.coordination import (
    LeaderElector,
    LeadershipObserver,
    RedisUnavailableError,
)
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.shared.health import HealthState, HealthTracker

_log = get_logger(__name__)


class LoggingLeadershipObserver:
    """Safe default observer that only logs promotion/demotion.

    Concrete safe-cancellation and reconciliation are wired by later modules
    (order lifecycle / reconciliation). Until then this observer performs no
    trading actions; the execution gate alone enforces that no new orders are
    submitted while not leader.
    """

    async def on_promoted(self) -> None:
        _log.info("leadership_promoted")

    async def on_demoted(self, reason: str) -> None:
        _log.warning(
            "leadership_demoted",
            extra={
                "reason": reason,
                "note": "new orders disabled; cancellation/reconciliation "
                "handled by later modules",
            },
        )


class LeadershipCoordinator:
    """Coordinates the execution-leader lease and the execution gate.

    Implements the app ``Service`` protocol (``name``/``start``/``stop``).
    """

    def __init__(
        self,
        elector: LeaderElector,
        gate: ExecutionGate,
        observer: LeadershipObserver,
        *,
        renew_interval_seconds: float,
        health: HealthTracker | None = None,
    ) -> None:
        if renew_interval_seconds <= 0:
            raise ValueError("renew_interval_seconds must be positive")
        self._elector = elector
        self._gate = gate
        self._observer = observer
        self._interval = renew_interval_seconds
        self._health = health
        self._is_leader = False
        self._stopping = asyncio.Event()
        self._loop_task: asyncio.Task[None] | None = None

    @property
    def name(self) -> str:
        return "leadership-coordinator"

    @property
    def is_leader(self) -> bool:
        return self._is_leader

    async def start(self) -> None:
        """Begin as standby (gate disabled), attempt one acquire, then loop."""
        self._gate.disable("standby (read-only) until leadership acquired")
        self._stopping.clear()
        # One eager attempt so a fresh single process becomes leader promptly.
        await self._try_once()
        self._loop_task = asyncio.create_task(
            self._run_loop(), name="leadership-loop"
        )

    async def stop(self) -> None:
        """Stop the loop, release the lease if owned, and disable the gate."""
        self._stopping.set()
        if self._loop_task is not None:
            self._loop_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._loop_task
            self._loop_task = None
        self._gate.disable("coordinator stopped")
        if self._is_leader:
            self._is_leader = False
            with contextlib.suppress(RedisUnavailableError):
                await self._elector.release()

    async def _run_loop(self) -> None:
        while not self._stopping.is_set():
            await self._try_once()
            await self._sleep_interval()

    async def _sleep_interval(self) -> None:
        # Sleep for the renew interval but wake immediately on shutdown.
        with contextlib.suppress(TimeoutError):
            await asyncio.wait_for(self._stopping.wait(), timeout=self._interval)

    async def _try_once(self) -> None:
        """One acquire-or-renew step, translating Redis failure to demotion."""
        try:
            if self._is_leader:
                renewed = await self._elector.renew()
                if not renewed:
                    await self._demote("lease-lost")
            else:
                acquired = await self._elector.acquire()
                if acquired:
                    await self._promote()
        except RedisUnavailableError as exc:
            await self._on_redis_error(str(exc))

    async def _promote(self) -> None:
        self._is_leader = True
        self._gate.enable("execution leader")
        _log.info("leadership_acquired", extra={"scope": self._elector.scope})
        if self._health is not None:
            await self._health.set(HealthState.READY, "execution leader")
        await self._observer.on_promoted()

    async def _demote(self, reason: str) -> None:
        # Disable new orders FIRST (immediate), then notify the observer.
        was_leader = self._is_leader
        self._is_leader = False
        self._gate.disable(f"not leader: {reason}")
        if was_leader:
            _log.warning(
                "leadership_lost",
                extra={"scope": self._elector.scope, "reason": reason},
            )
            await self._observer.on_demoted(reason)

    async def _on_redis_error(self, detail: str) -> None:
        # Fail closed: Redis unavailable => cannot be a trusted leader.
        _log.error("coordination_redis_unavailable", extra={"detail": detail})
        if self._health is not None:
            await self._health.set(HealthState.DEGRADED, "redis unavailable")
        await self._demote("redis-unavailable")


__all__ = ["LeadershipCoordinator", "LoggingLeadershipObserver"]
