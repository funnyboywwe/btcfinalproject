"""Redis-backed atomic risk counters.

Counters are integers incremented atomically with ``INCRBY``. When a TTL is
supplied the key's expiry is (re)set so rolling windows (e.g. a daily loss
counter) prune themselves. Monetary counters MUST use integer base units (e.g.
USDC micro-units); binary floats are never accepted.

These counters are an operational convenience for fast limit checks; they are
not the authoritative accounting record (PostgreSQL is).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polymarket_pair_bot.coordination.keys import RedisKeys
from polymarket_pair_bot.coordination.redis_client import guard

if TYPE_CHECKING:  # pragma: no cover - typing only
    from redis.asyncio import Redis


class RedisRiskCounters:
    """Implements the domain ``RiskCounterStore`` protocol against Redis."""

    def __init__(self, client: Redis, keys: RedisKeys) -> None:
        self._client = client
        self._keys = keys

    async def increment(
        self, name: str, amount: int = 1, *, ttl_seconds: int | None = None
    ) -> int:
        if not isinstance(amount, int):  # defensive: forbid float base units
            raise TypeError("counter amount must be an int (integer base units)")
        key = self._keys.risk_counter(name)
        new_value = int(await guard(self._client.incrby(key, amount)))
        if ttl_seconds is not None:
            if ttl_seconds <= 0:
                raise ValueError("ttl_seconds must be positive")
            await guard(self._client.expire(key, ttl_seconds))
        return new_value

    async def get(self, name: str) -> int:
        value = await guard(self._client.get(self._keys.risk_counter(name)))
        return int(value) if value is not None else 0

    async def reset(self, name: str) -> None:
        await guard(self._client.delete(self._keys.risk_counter(name)))


__all__ = ["RedisRiskCounters"]
