"""Redis-backed persistent kill-switch cache.

The kill switch is stored as a Redis hash with **no TTL** (persistent) so it
survives restarts and is instantly visible to every process. Redis is only the
fast cache: the authoritative, append-only audit journal lives in PostgreSQL
(``kill_switch_events``, Module 3). The operator CLI writes both.

Fail closed: if the cached state cannot be read, callers should treat the switch
as *active* (handled by the CLI/consumers), never assume it is off.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from polymarket_pair_bot.coordination.redis_client import guard
from polymarket_pair_bot.domain.coordination import KillSwitchState

if TYPE_CHECKING:  # pragma: no cover - typing only
    from redis.asyncio import Redis

_ACTIVE = "active"
_REASON = "reason"
_ACTOR = "actor"
_UPDATED_AT = "updated_at"


class RedisKillSwitchCache:
    """Implements the domain ``KillSwitchStore`` protocol against Redis."""

    def __init__(self, client: Redis, *, key: str) -> None:
        self._client = client
        self._key = key

    async def get_state(self) -> KillSwitchState:
        raw = await guard(self._client.hgetall(self._key))
        if not raw:
            return KillSwitchState(active=False)
        return _decode_state(raw)

    async def is_active(self) -> bool:
        value = await guard(self._client.hget(self._key, _ACTIVE))
        return value == "1"

    async def activate(
        self, *, reason: str, actor: str | None, at: int
    ) -> KillSwitchState:
        return await self._write(active=True, reason=reason, actor=actor, at=at)

    async def deactivate(self, *, actor: str | None, at: int) -> KillSwitchState:
        return await self._write(active=False, reason="", actor=actor, at=at)

    async def _write(
        self, *, active: bool, reason: str, actor: str | None, at: int
    ) -> KillSwitchState:
        mapping = {
            _ACTIVE: "1" if active else "0",
            _REASON: reason,
            _ACTOR: actor or "",
            _UPDATED_AT: str(at),
        }
        await guard(self._client.hset(self._key, mapping=mapping))
        return KillSwitchState(
            active=active, reason=reason, actor=actor, updated_at=at
        )


def _decode_state(raw: dict[str, str]) -> KillSwitchState:
    updated_raw = raw.get(_UPDATED_AT) or ""
    updated_at = int(updated_raw) if updated_raw.isdigit() else None
    actor = raw.get(_ACTOR) or None
    return KillSwitchState(
        active=raw.get(_ACTIVE) == "1",
        reason=raw.get(_REASON, ""),
        actor=actor,
        updated_at=updated_at,
    )


__all__ = ["RedisKillSwitchCache"]
