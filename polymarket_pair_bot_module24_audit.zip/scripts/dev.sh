#!/usr/bin/env bash
# Convenience wrapper around the common developer quality gates.
# Usage: scripts/dev.sh [check|test|lint|format|typecheck]
set -euo pipefail

cmd="${1:-check}"

case "$cmd" in
  check)
    uv run ruff format --check .
    uv run ruff check .
    uv run mypy src
    uv run pytest
    ;;
  test)      uv run pytest ;;
  lint)      uv run ruff check . ;;
  format)    uv run ruff format . ;;
  typecheck) uv run mypy src ;;
  *)
    echo "Unknown command: $cmd" >&2
    echo "Usage: scripts/dev.sh [check|test|lint|format|typecheck]" >&2
    exit 2
    ;;
esac
