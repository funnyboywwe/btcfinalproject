"""Manually probe local infrastructure health.

Usage (with infra running):
    uv run python scripts/healthcheck.py

Exits non-zero if any dependency is unhealthy. Prints redaction-safe JSON only.
"""

from __future__ import annotations

import asyncio
import json
import sys

from polymarket_pair_bot.config.settings import load_config
from polymarket_pair_bot.observability.health_checks import (
    PostgresHealthCheck,
    RedisHealthCheck,
)
from polymarket_pair_bot.shared.health import HealthCheck


async def _main() -> int:
    config = load_config()
    checks: list[HealthCheck] = [
        PostgresHealthCheck(config.postgres.dsn),
        RedisHealthCheck(config.redis.url),
    ]
    all_ok = True
    report: dict[str, dict[str, object]] = {}
    for check in checks:
        result = await check.check()
        report[check.name] = {"healthy": result.healthy, "detail": result.detail}
        all_ok = all_ok and result.healthy
    print(json.dumps(report, separators=(",", ":")))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(_main()))
