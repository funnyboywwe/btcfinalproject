# Module 21 — Private read-only operator dashboard

A private, **read-only** operator dashboard served by FastAPI. It renders a
server-side HTML view (plus a JSON snapshot endpoint) of operator-relevant state
so a human can supervise the bot without any ability to trade from the UI.

> The dashboard is **informational only**. It exposes **no trade controls** and
> makes **no profitability claim**. "Cost margin" is the distance of the
> effective pair cost below the $1 break-even identity, not an expected profit.

## What it displays

Active BTC market · opening/closing times · time remaining · Up & Down
top-of-book · depth · data freshness · pair-cost breakdown · opportunity
decision · inventory · matched quantity · unmatched quantity & age · open orders
· recent fills · merge status · risk status · kill-switch status · reconciliation
status · daily P&L · API & RPC health.

`matched quantity` counts **confirmed fills only**. Submitted, acknowledged,
open, or partially-filled orders are never treated as a matched pair.

## Endpoints (all GET, read-only)

| Path            | Auth | Description                                   |
| --------------- | ---- | --------------------------------------------- |
| `/` `/dashboard`| yes* | Server-rendered HTML dashboard.               |
| `/api/snapshot` | yes* | JSON of the same non-secret snapshot.         |
| `/healthz`      | no   | Trivial dashboard liveness (`{"status":"ok"}`).|

\* Auth applies only when a token is configured (see below). There are **no**
POST/PUT/PATCH/DELETE routes.

## Security model

1. **Read-only** — no write routes, no forms, no buttons (requirements 1 & 2).
2. **No secrets** — the view-models contain no secret fields; the JSON payload
   is additionally passed through the redaction filter as defence in depth
   (requirement 3).
3. **Private binding by default** — binds to `127.0.0.1` (requirement 4). Expose
   it beyond loopback only over a VPN or SSH tunnel.
4. **Authentication (requirement 5)** — an OPTIONAL shared bearer token
   (`DASHBOARD_AUTH_TOKEN`). When set it is required on `/` and `/api/snapshot`
   (`Authorization: Bearer <token>` or `?token=<token>`), compared in constant
   time, and **never logged or rendered**. When unset, the dashboard logs a
   warning and relies purely on network isolation — **VPN-only access** is then
   mandatory (do not bind to a public interface without a token).
5. **Output escaping (requirement 6)** — every displayed external value is
   HTML-escaped by the renderer.

### VPN-only access (when no token is set)

- Keep `DASHBOARD_HOST=127.0.0.1`.
- Reach the dashboard via SSH tunnel, e.g.
  `ssh -L 8082:127.0.0.1:8082 vps` then browse `http://127.0.0.1:8082/`, or
- Place it behind a WireGuard/Tailscale interface and bind to that private IP.
- Never expose the port on a public interface without also setting a token.

## Configuration (`DashboardSettings`, additive)

| Env var                     | Default             | Meaning                                  |
| --------------------------- | ------------------- | ---------------------------------------- |
| `DASHBOARD_ENABLED`         | `false`             | Register the service in the lifecycle.   |
| `DASHBOARD_HOST`            | `127.0.0.1`         | Bind address (keep private).             |
| `DASHBOARD_PORT`            | `8082`              | Bind port.                               |
| `DASHBOARD_AUTH_TOKEN`      | _(unset)_           | Optional shared bearer token (secret).   |
| `DASHBOARD_REFRESH_SECONDS` | `5`                 | HTML auto-refresh cadence.               |
| `DASHBOARD_RECENT_FILLS`    | `20`                | Recent-fills row cap.                    |
| `DASHBOARD_TITLE`           | `Operator dashboard`| Page title.                              |

## Architecture (dependency inversion)

```
dashboard/
  models.py     # Pydantic v2 read-models (Decimal money); no secrets
  ports.py      # DashboardDataProvider protocol (async snapshot())
  provider.py   # PlaceholderDashboardProvider (empty, read-only skeleton)
  render.py     # stdlib html.escape server-side renderer (no extra deps)
  auth.py       # optional constant-time bearer-token gate
  api.py        # FastAPI factory (GET-only; fastapi imported lazily)
  factory.py    # compose from AppConfig; reuses OperatorApiService (uvicorn)
  cli.py        # `render-dashboard` (offline HTML render; no server/network)
```

The dashboard depends only on the `DashboardDataProvider` protocol. A later
module can supply a live aggregator (reading authoritative inventory, kill
switch, reconciliation, RPC health, P&L) without the dashboard importing any
persistence / HTTP / websocket / blockchain classes. Until then the placeholder
provider returns an empty snapshot with fail-closed defaults (stale freshness,
blocked risk, active kill switch) and a clear "awaiting live data" banner.

The HTML renderer intentionally uses the standard library (`html.escape`) rather
than Jinja2 so escaping is explicit and auditable in one place and the dashboard
adds **no new third-party dependency**.

## Running

Enabled as a lifecycle service (private, off by default):

```bash
DASHBOARD_ENABLED=true DASHBOARD_AUTH_TOKEN=$(openssl rand -hex 24) \
  uv run polymarket-pair-bot
# then, over an SSH tunnel or VPN, open http://127.0.0.1:8082/
```

Offline one-shot HTML render (no server, no network, no orders):

```bash
uv run polymarket-pair-bot render-dashboard --output /tmp/dashboard.html
```

## Tests

- `tests/unit/test_dashboard_render.py` — escaping of hostile external strings,
  required sections, badges, read-only markup, refresh flooring.
- `tests/unit/test_dashboard_auth.py` — disabled/enabled auth; missing/invalid/
  valid token; header vs query extraction; constant-time compare.
- `tests/unit/test_dashboard_models_provider.py` — Decimal→string JSON
  precision, unknown-field rejection, placeholder snapshot defaults, no
  secret-like keys.
- `tests/integration/test_dashboard_api.py` — FastAPI `TestClient`: GET-only
  surface, 401 without token / 200 with it, escaped HTML, JSON shape, liveness.
