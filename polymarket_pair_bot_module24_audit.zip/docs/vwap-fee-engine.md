# Module 8 — VWAP, Fee & Pair-Cost Engine

## Overview

The pair-cost engine is a **pure, synchronous, side-effect-free** function that
evaluates the all-in cost of acquiring a complete Up/Down pair of BTC 5-minute
outcome tokens. It produces a fully immutable `PairCostResult` containing every
input, intermediate result, and rejection reason.

The engine makes **no profitability claim**. It reports a net profit figure
for information; callers must decide whether to act on it.

## Entry point

```python
from polymarket_pair_bot.strategy.engine import evaluate_pair_cost

result = evaluate_pair_cost(
    up_book,          # OrderBookSnapshot | None
    down_book,        # OrderBookSnapshot | None
    target_quantity=Shares(Decimal("10")),
    inventory=InventorySummary.empty(),
    parameters=EngineParameters.from_strategy_settings(
        strategy_settings, tick_size, min_seconds_to_close=60
    ),
    seconds_to_close=180,
    up_is_fresh=True,
    down_is_fresh=True,
)
```

## Per-pair vs total semantics

| Field | Scope | Notes |
|---|---|---|
| `up_taker_cost` | **Total position** | price × target_quantity |
| `down_taker_cost` | **Total position** | price × target_quantity |
| `up_maker_cost` | **Total position** | best_bid × target_quantity |
| `down_maker_cost` | **Total position** | best_bid × target_quantity |
| `taker_fee_up` | **Total position** | fee on total UP notional |
| `taker_fee_down` | **Total position** | fee on total DOWN notional |
| `total_taker_fee` | **Total position** | sum of both |
| `effective_pair_cost_taker` | **Per pair** | compare vs `max_effective_pair_cost` |
| `effective_pair_cost_maker` | **Per pair** | maker scenario |
| `gross_profit` | **Per pair** | $1 − up_price − down_price |
| `net_profit` | **Per pair** | $1 − effective_pair_cost_taker |
| `tick_sensitivity[N].cost_increase` | **Per pair** | 2 × (N+1) × tick |
| `tick_sensitivity[N].adjusted_net_profit` | **Per pair** | net_profit − cost_increase |
| `max_first_leg_price` | **Per share** | max price to post for UP |
| `max_second_leg_price` | **Per share** | max price to post for DOWN |

The split keeps accounting clean: `effective_pair_cost` is always comparable
against the $1 CTF redemption value per pair; total costs tell you how much
capital to deploy.

## Effective pair cost formula

```
effective_pair_cost_taker =
    (up_vwap_price + down_vwap_price) × (1 + taker_fee_fraction)
    + slippage_reserve
    + merge_gas_overhead
    + safety_reserve
```

All monetary arithmetic uses Python `Decimal` with 28-digit precision
(`computation_context`). Fees and overhead round **up** (conservative cost);
profit rounds **down** (conservative gain).

## Max acceptable price formulas

```
max_first_leg_price =
    floor_to_tick(
        (max_effective_pair_cost − overhead) / (1 + fee_fraction)
        − down_vwap_price
    )

max_second_leg_price =
    floor_to_tick(
        (max_effective_pair_cost − overhead) / (1 + fee_fraction)
        − up_vwap_price
    )
```

`None` is returned when the other leg's price exceeds the budget (no room for
this leg) or the book is unavailable.

## Tick sensitivity

Both legs move adversely by N ticks simultaneously (conservative):

```
cost_increase_per_pair[N] = 2 × N × tick_size
adjusted_net_profit[N]   = net_profit_per_pair − cost_increase_per_pair[N]
remains_viable[N]         = adjusted_net_profit[N] >= required_net_profit
```

Three sensitivity entries are always present (N = 1, 2, 3).

## Classification logic

Evaluation order (first matching rule wins):

1. **REJECTED** — any rejection reason present (stale book, insufficient depth,
   window too close, unavailable book).
2. **MATCHED_PAIR** — existing confirmed inventory covers both sides ≥ target.
3. **PASSIVE_SECOND_LEG** — one side has ≥ target confirmed inventory; post the
   other side passively.
4. **IMMEDIATE_TWO_LEG** — taker effective pair cost ≤ max budget AND net profit
   ≥ required threshold.
5. **PASSIVE_FIRST_LEG** — taker too expensive; maker pair cost ≤ max budget
   (post both sides passively at bid).
6. **OBSERVATION_ONLY** — books are valid and fresh but cost exceeds all thresholds.

## Rejection conditions

| Condition | Reason string |
|---|---|
| Book `None` | `up_book: feed unavailable` |
| `up_is_fresh = False` | `up_book: feed is stale or not live` |
| Book `None` | `down_book: feed unavailable` |
| `down_is_fresh = False` | `down_book: feed is stale or not live` |
| `seconds_to_close < min` | `window_too_close: …` |
| Available depth < required | `up_depth_insufficient: …` |
| Available depth < required | `down_depth_insufficient: …` |
| Available depth < `min_book_depth` | `up_book_below_min_depth: …` |
| Available depth < `min_book_depth` | `down_book_below_min_depth: …` |

Multiple reasons are accumulated (fail closed).

## Configuration

`EngineParameters` can be built from `PairStrategySettings` and a runtime
`TickSize`:

```python
params = EngineParameters.from_strategy_settings(
    settings,
    tick_size=TickSize(Decimal("0.01")),
    min_book_depth=Shares(Decimal("5")),
    min_seconds_to_close=60,
    required_net_profit=ProfitAmount(Decimal("0.001")),
)
```

`max_effective_pair_cost` must be strictly below $1.00 (enforced in
`__post_init__` — rejects at construction time, not at runtime).

## Dependency purity

The engine imports only:
- `polymarket_pair_bot.domain.*` — pure domain types
- Python standard library (`decimal`, `dataclasses`, `enum`)

No SQLAlchemy, httpx, WebSockets, blockchain clients, pydantic-settings,
or any I/O dependency. Safe to call from the event loop without await.

## Files

| File | Role |
|---|---|
| `src/polymarket_pair_bot/strategy/engine.py` | Engine implementation |
| `src/polymarket_pair_bot/strategy/__init__.py` | Public re-exports |
| `tests/fixtures/engine.py` | Synthetic order-book test fixtures |
| `tests/unit/test_engine.py` | Extensive unit + Hypothesis tests |
| `docs/vwap-fee-engine.md` | This document |
