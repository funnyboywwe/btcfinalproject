# Polymarket authentication and read-only account access (Module 15)

This module authenticates to Polymarket and exposes **read-only** access to the
trading account: open orders, order status, fills/trades, balances and (where
reportable) allowances. It also provides the authenticated readiness state and
a reconnecting, de-duplicating authenticated user-stream driver (the concrete
authenticated WebSocket connection belongs to Module 16).

It implements **no** order submission, cancellation, split/merge/redeem or any
other state-changing operation. The diagnostics command is strictly read-only
and `LIVE_TRADING` remains disabled.

> No profitability is claimed or implied. This module only reads account state.

## Important: the live CLOB adapter is a blocked adapter

The official Polymarket CLOB Python package could not be installed or inspected
in this environment (the sandbox has no network access). Per the project's
safety rules — *"if package behavior cannot be verified, add a blocked adapter
method with a clear explanation instead of guessing"* — the live adapter does
**not** guess the package's method names or response shapes. Instead:

- `auth/clob_adapter.py` implements the same `AuthenticatedAccountReader`
  interface, but every live read raises a typed
  `UnsupportedAuthOperationError(operation, detail)` naming the exact operation
  and the concrete step required to wire it once the installed package API has
  been inspected;
- `initialize_authenticated_client(...)` and the authenticated user-stream
  connection factory are likewise blocked with typed errors;
- `load_clob_package()` lazily imports `py_clob_client` and raises the same
  typed error if it is absent, so importing this module never requires the
  package.

Everything that does **not** depend on the unverified package — configuration,
identity/address validation, credential loading and redaction, the Pydantic
adapters, readiness, dedup, the reconnect/freshness state machine, the paper
stub reader, and the diagnostics service/CLI — is fully implemented and tested.

## Dependency inversion

The strategy/service layer depends only on abstract protocols in
`auth/ports.py`:

- `AuthenticatedAccountReader` — read-only account access (open orders, order
  status, trades, balances, allowances, plus `aclose`);
- `UserStreamConnection` / `UserStreamConnectionFactory` — an authenticated
  user-stream transport.

Two readers implement the *same* interface (paper/live parity, as required):

| Reader | Module | Behavior |
| --- | --- | --- |
| `StubAccountReader` | this module | In-memory, deterministic, empty by default; used in paper/dev and tests. No network, never mutates. |
| `ClobAuthenticatedReader` | this module (blocked) | Live reader whose reads raise a typed unsupported-operation error until the CLOB API is verified. |

`auth/factory.build_account_reader(config)` selects the reader by run mode:
paper/dev (`LIVE_TRADING` disabled) → `StubAccountReader`; live → the blocked
`ClobAuthenticatedReader`. Importing `polymarket_pair_bot.auth` never pulls in
`py_clob_client`, `eth_account`, `httpx` or `websockets`; the live adapter,
factory and CLI are intentionally *not* re-exported from the package root.

## Signature types and identity (requirements 1, 3)

`auth/addresses.build_account_identity(...)` validates the signer and funder
addresses (EVM `0x` + 40 hex, lowercased) and the chain id, and accepts any of
the documented `SignatureType` values already defined in `config/enums.py`
(`EOA=0`, `POLY_PROXY=1`, `POLY_GNOSIS_SAFE=2`). Invalid input raises a typed
`AddressValidationError`.

The signer address may be provided directly (`POLYMARKET_SIGNER_ADDRESS`) or
derived from the configured private key. Derivation is done by
`derive_signer_address(...)`, which lazily imports `eth_account`; if the library
is unavailable it raises `UnsupportedAuthOperationError` rather than guessing.
The private key is never logged or echoed, even in errors.

## Credentials (requirements 2, 8)

`auth/credentials.py` defines:

- `ApiCredentials` — a frozen model of the CLOB L2 API key/secret/passphrase
  held as `SecretStr`. Its `__str__`/`__repr__` are redacted, and
  `as_header_material()` is the single, explicit accessor for the raw values;
- `ConfigCredentialProvider` — loads credentials from
  `PolymarketAuthSettings`; if any are missing it raises `CredentialError`
  listing the **environment variable names** (never any values);
- `DerivedCredentialProvider` — blocked (deriving/rotating API credentials
  requires the verified CLOB API), raising `UnsupportedAuthOperationError`.

Secrets, private keys and complete signed payloads are never logged.

## Pydantic adapters (requirements 6, 7)

`auth/models.py` are the bot's own normalized, frozen (`extra="forbid"`) views:
`AccountIdentity`, `OpenOrderView`, `OrderStatusView`, `TradeFillView`,
`BalanceView`, `AllowanceView` and the aggregate `AccountSnapshot`. Only fields
the bot uses are modeled — no undocumented API fields are invented. All money,
prices and quantities are `Decimal`: a before-validator refuses binary floats
outright (surfaced as a clean `ValidationError`), prices are constrained to
`[0, 1]`, sizes are non-negative, `size_matched ≤ original_size`, and
`available ≤ total`. An order is treated as complete only when its status is
`FILLED` — never on ack/open/partial.

## Readiness (requirement 10)

`auth/readiness.py` provides an async-safe `AuthReadinessTracker` over the
states `UNINITIALIZED → CREDENTIALS_LOADED → CLIENT_READY → STREAM_LIVE`, plus
`DEGRADED` and `CLOSED`. A snapshot reports `is_ready` (client or stream ready)
and `stream_is_fresh(now, max_age_seconds)`. Freshness **fails closed**: if no
stream message has been observed, the stream is never considered fresh.

## User stream: reconnect, freshness and dedup (requirement 9)

`auth/user_stream.ReconnectingUserStream` drives any `UserStreamConnection`
with the required safety behaviors:

- **freshness** — each `receive()` is bounded by `freshness_seconds`; a timeout
  raises `StaleUserStreamError` and forces a reconnect;
- **fresh authoritative sync on reconnect** — the optional `resync` callback
  runs immediately after every (re)connect;
- **bounded retries** — after `max_reconnects` failures it raises
  `StaleUserStreamError` and fails closed;
- **de-duplication** — messages are keyed (by an id field, else a stable repr)
  and deduped through a `BoundedDedupCache`, because fills are not unique;
- **cancellation-safe / graceful shutdown** — the connection is always closed
  in a `finally` block, and `stop()` requests a cooperative shutdown. Backoff
  is deterministic and bounded.

## Read-only diagnostics (requirements 11, 12, 13, 14)

`auth/service.AuthenticationService.diagnose()` performs a read-only sweep
(open orders → trades → balances → allowances) and returns a validated
`AccountSnapshot`. It never submits or cancels anything (the reader protocol
exposes no such methods). If the reader cannot report allowances it records
`allowances_supported=False` with an explanatory note instead of failing. On a
blocked live read it re-raises the typed error; on other failures it degrades
readiness and raises `AuthConnectionError`.

The CLI is read-only and never enables live trading:

```bash
python -m polymarket_pair_bot.auth.cli diagnose
```

It prints a non-secret summary (addresses, signature type, chain id, and counts
of open orders / fills / balances / allowances). Exit codes: `0` success, `2`
configuration error (prints the missing, non-secret field names), `3` a
required operation is blocked (CLOB API not verified locally). In paper/dev
mode it reports the empty stub account; wiring the live path requires the
verified CLOB package.

## Interface changes

All changes are **additive** and confined to `config/models.py`:

- `WalletSettings.polymarket_signer_address: str | None = None` — optional
  operator-provided signer address (validated as an EVM address; when absent it
  may be derived from the private key). It is added to the existing address
  validator.
- `PolymarketAuthSettings` gained user-stream tuning knobs:
  `user_stream_freshness_seconds` (default 30, > 0),
  `user_stream_max_reconnects` (default 5, ≥ 0), and
  `user_stream_dedup_capacity` (default 4096, > 0). These are durations/counts,
  not monetary values.

No domain, persistence or execution protocols were modified. No previously
implemented interface changed behavior.

## Testing

Mocked unit tests (no network, no real orders) cover the models' Decimal safety
and invariants, credential loading/redaction, address/identity validation, all
documented signature types, readiness and freshness (including fail-closed),
the dedup cache, the user-stream reconnect/dedup/freshness/graceful-stop
behavior via a fake connection factory, the blocked live adapter contract, and
the diagnostics service against the stub reader (including that only read
methods are ever called).
