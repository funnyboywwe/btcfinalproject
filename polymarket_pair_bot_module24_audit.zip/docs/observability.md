# Module 20 — Observability (metrics, health, alerts)

Observability is the bot's **operator surface**: a private Prometheus metrics
feed, private health/readiness endpoints, an event-loop lag monitor, and a
catalog of alerting rules. It is read-only with respect to trading — it never
places, cancels, or mutates an order, and it never claims the strategy is
profitable.

> Metric values are a **lossy observability projection**. All monetary
> quantities (prices, P&L, fees, slippage, collateral) are computed elsewhere
> with `Decimal`; they are converted to `float` only at the Prometheus export
> boundary and are never read back into a financial calculation. A pair is only
> "matched" when equal Up/Down quantities are **confirmed filled** — the
> `matched_pairs_total` counter and `unmatched_*` gauges reflect that invariant
> and never count submitted / acknowledged / open / partially-filled orders.

## Components

| File | Responsibility |
| --- | --- |
| `observability/metric_names.py` | Declarative metric catalog (stdlib only): names, kinds, labels, help, buckets. |
| `observability/metrics.py` | `PrometheusMetricsSink` — never-raising sink implementing the `MetricsSink` protocol + typed helpers. |
| `observability/health.py` | Non-secret operator health/readiness response building (no FastAPI import). |
| `observability/api.py` | Private FastAPI app factory (`/health/live`, `/health/ready`, `/health/details`, `/metrics`). |
| `observability/server.py` | `OperatorApiService` — uvicorn lifecycle service bound to a private interface. |
| `observability/event_loop.py` | `EventLoopLagMonitor` — supervised task publishing `event_loop_lag_seconds`. |
| `observability/alerts.py` | Prometheus alert-rule catalog + YAML renderer. |
| `observability/factory.py` | Composition helpers wiring the above from `AppConfig`. |
| `observability/cli.py` | `render-alert-rules` command (read-only). |

Third-party dependencies (`prometheus_client`, `fastapi`, `uvicorn`, `PyYAML`)
are imported **lazily** inside the components, mirroring the existing
`observability/health_checks.py` pattern, so the package imports cheaply and the
catalog/health/alert logic is testable without the web/metrics stack.

## Metrics

Every metric is namespaced with `monitoring.prometheus_namespace` (default
`ppb`). Counters are declared without the `_total` suffix; `prometheus_client`
appends it on export.

| Requirement | Exported series | Kind | Labels |
| --- | --- | --- | --- |
| market websocket age | `ppb_market_websocket_age_seconds` | gauge | — |
| user websocket age | `ppb_user_websocket_age_seconds` | gauge | — |
| order book age | `ppb_order_book_age_seconds` | gauge | `outcome` |
| processing latency | `ppb_processing_latency_seconds` | histogram | — |
| REST latency | `ppb_rest_latency_seconds` | histogram | `operation` |
| RPC latency | `ppb_rpc_latency_seconds` | histogram | `method` |
| reconnect count | `ppb_reconnects_total` | counter | `stream` |
| opportunities detected | `ppb_opportunities_detected_total` | counter | — |
| expected pair edge | `ppb_expected_pair_edge_usd` | gauge | — |
| order submissions | `ppb_order_submissions_total` | counter | `outcome`, `mode` |
| order rejections | `ppb_order_rejections_total` | counter | `reason` |
| partial fills | `ppb_partial_fills_total` | counter | — |
| maker fills | `ppb_maker_fills_total` | counter | — |
| taker fills | `ppb_taker_fills_total` | counter | — |
| cancel latency | `ppb_cancel_latency_seconds` | histogram | — |
| unmatched shares | `ppb_unmatched_shares` | gauge | `outcome` |
| unmatched duration | `ppb_unmatched_duration_seconds` | gauge | — |
| matched pairs | `ppb_matched_pairs_total` | counter | — |
| merge transactions | `ppb_merge_transactions_total` | counter | `status` |
| gross P&L | `ppb_gross_pnl_usd` | gauge | — |
| fees | `ppb_fees_usd_total` | counter | — |
| slippage | `ppb_slippage_usd_total` | counter | — |
| realized net P&L | `ppb_realized_net_pnl_usd` | gauge | — |
| risk rejections | `ppb_risk_rejections_total` | counter | `rule` |
| kill-switch status | `ppb_kill_switch_active` | gauge (0/1) | — |
| reconciliation differences | `ppb_reconciliation_differences_total` | counter | `kind` |
| event-loop lag | `ppb_event_loop_lag_seconds` | gauge | — |

`market_id` is deliberately **never** a label: the BTC 5-minute market rotates
every five minutes and would explode series cardinality. Standard process
metrics (including `process_start_time_seconds`, used by the process-restart
alert) are also registered.

The sink is a drop-in replacement for `NullMetricsSink`. It also accepts the
generic `incr` / `gauge` / `observe` calls the orchestrator already emits (e.g.
`orchestrator_degraded_total`), auto-registering unknown names on first use.
**No sink method ever raises** — a metrics backend failure can never take down a
trading task.

## Health / operator API

The private operator API (served by `OperatorApiService` via uvicorn) exposes:

| Endpoint | Meaning | Status |
| --- | --- | --- |
| `GET /health/live` | Liveness — the process can respond. | `200` while running (any state). |
| `GET /health/ready` | Readiness — safe to trade. | `200` ready / `503` not ready. |
| `GET /health/details` | Combined non-secret diagnostics. | `200`. |
| `GET /metrics` | Prometheus exposition. | `200`. |

* **No secrets in responses.** Health bodies use `AppConfig.health_public_view()`
  (coarse operational flags only) and the details body is additionally passed
  through the redaction filter as defence in depth.
* **Readiness fails closed.** With the full orchestrator `ReadinessProbe`
  injected, readiness is true only when health is READY, the kill switch is
  inactive (unreadable ⇒ treated active), execution is unblocked, dependency
  probes pass, and a validated market session is restored. Any probe error ⇒
  `503`. When no full probe is injected the fail-closed liveness-only fallback is
  used (ready only when READY).
* **Private by default.** The server binds to `application.operator_api_host`
  (default `127.0.0.1`) and `application.operator_api_port` (default `8081`), so
  `/metrics` and health are not reachable off-host unless you deliberately change
  the bind address (put a TLS/auth reverse proxy in front if you do).

Observability is wired into the application lifecycle only when
`MONITORING_ENABLED=true`; it is OFF by default, so the default service set is
unchanged. A failure to start the diagnostics HTTP server is logged and
swallowed (fail-open for diagnostics) — readiness still fails closed
independently.

## Alerts

`observability/alerts.py` defines the required alert rules with thresholds
sourced from the validated config:

| Alert | Trigger |
| --- | --- |
| `StaleOrderBooks` | `ppb_order_book_age_seconds > stale_after_seconds` |
| `StaleUserStream` | `ppb_user_websocket_age_seconds > user_stream_freshness_seconds` |
| `UnmatchedDurationBreach` | `ppb_unmatched_duration_seconds > max_unmatched_duration_seconds` |
| `UnknownOrderDetected` | `increase(ppb_reconciliation_differences_total{kind="unknown_order"}[5m]) > 0` |
| `BalanceMismatch` | `increase(ppb_reconciliation_differences_total{kind="balance_mismatch"}[5m]) > 0` |
| `FailedMerge` | `increase(ppb_merge_transactions_total{status="failed"}[10m]) > 0` |
| `ProcessRestart` | `changes(process_start_time_seconds[15m]) > 0` |
| `DailyLossLimit` | `ppb_realized_net_pnl_usd < -daily_loss_limit_usd` |
| `KillSwitchActive` | `ppb_kill_switch_active == 1` |
| `RpcDisagreement` | `increase(ppb_reconciliation_differences_total{kind="rpc_disagreement"}[5m]) > 0` |

Render them to a Prometheus rules file (read-only, no network):

```bash
uv run polymarket-pair-bot render-alert-rules -o deploy/prometheus/ppb_alerts.yml
```

## Emitting metrics from other modules

Inject the sink where a `MetricsSink` is accepted and call the typed helpers,
for example:

```python
metrics.set_order_book_age("up", age_seconds)
metrics.observe_rest_latency("post_order", elapsed_seconds)
metrics.incr_order_rejection("risk_blocked")
metrics.set_kill_switch(is_active)
metrics.add_fees(Decimal("0.01"))  # Decimal in, float only at export
```

## Configuration (additive, Module 20)

New, backward-compatible fields on `MonitoringSettings` (all have defaults):
`metrics_path`, `health_path_prefix`, `expose_details_endpoint`,
`event_loop_lag_poll_seconds`, `readiness_timeout_seconds`. Existing fields
(`monitoring_enabled`, `metrics_host`, `metrics_port`, `prometheus_namespace`)
are unchanged. The operator API bind host/port continue to come from
`ApplicationSettings` (`operator_api_host` / `operator_api_port`).

## Tests

* `tests/unit/test_observability_health.py` — health-state transitions and the
  fail-closed readiness contract (stdlib only).
* `tests/unit/test_observability_metrics.py` — catalog coverage (stdlib) and
  sink behaviour (skipped without `prometheus_client`).
* `tests/unit/test_observability_alerts.py` — alert catalog + rendering.
* `tests/unit/test_observability_event_loop.py` — lag monitor.
* `tests/integration/test_observability_api.py` — FastAPI endpoints via
  `TestClient` (skipped without `fastapi`).
