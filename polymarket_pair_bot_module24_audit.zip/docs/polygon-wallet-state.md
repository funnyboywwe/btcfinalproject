# Polygon RPC and wallet-state service (Module 16)

Read-only, fail-closed access to Polygon chain state for the trading wallet.
This module answers questions like *"how much gas, collateral and Up/Down
inventory does the wallet actually hold on-chain, what are its allowances, what
is its nonce, and what happened to a transaction hash?"* It is the concrete
`ChainStateProvider` that the reconciliation service (Module 19) previously had
to stub out with a blocked provider.

> **No trading, no signing, no writes.** This module never builds, signs or
> submits a transaction, never requests or displays the private key, and never
> logs an RPC URL. Conditional-token split/merge/redeem is explicitly deferred
> to Module 21. The only state-changing entry point, `submit_ctf_operation`, is
> a **blocked** method that raises `UnsupportedChainOperationError`.

## Package layout

```
src/polymarket_pair_bot/blockchain/
  errors.py                  # typed chain errors (config, unavailable, disagreement, ...)
  units.py                   # exact base-unit <-> Decimal conversions (no floats)
  abi.py                     # hand-encoded READ-ONLY calldata + uint256 decode
  models.py                  # frozen dataclasses: snapshots, outcomes, estimates
  ports.py                   # EthereumRpc Protocol (dependency inversion boundary)
  resilience.py              # RetryPolicy, CircuitBreaker, guarded_read
  dual_rpc.py                # primary/secondary comparison + tolerances
  tx_status.py               # pure transaction classifier
  web3_rpc.py                # web3.py adapter (lazily imported, blocked if absent)
  service.py                 # WalletStateService (public API)
  reconciliation_provider.py # adapts the service to reconciliation.ChainStateProvider
  factory.py                 # build_wallet_state_service(config)
  cli.py                     # read-only `wallet-diagnostics` command
```

## Design

### Dependency inversion

The service depends only on the `EthereumRpc` Protocol (`ports.py`), never on
web3.py directly. The web3 adapter (`web3_rpc.py`) is the *only* place that
imports web3, and it imports lazily inside `__init__` so the whole package
remains importable (and unit-testable) in an environment without web3.py
installed. If web3 is missing, constructing the adapter raises
`ChainConfigurationError` with a clear message rather than failing at import
time. Tests inject an in-memory fake implementing the same Protocol.

### Exact arithmetic

All money/quantity values move through integer **base units** and are converted
to `Decimal` only via `units.py` (`base_units_to_decimal`, `wei_to_native`).
`decimal_to_base_units` floors (`ROUND_FLOOR`) so a conversion never rounds a
balance *up*. No binary float is used for balances, allowances, gas or nonce.

### Primary/secondary RPC comparison (`dual_rpc.py`)

- **Chain id** is read with `read_exact`: the two endpoints must return the
  **identical** value or `RpcDisagreementError` is raised.
- **Balances / allowances / nonce** are read with `read_int` under a configured
  `tolerance_base_units`. If the two endpoints differ by more than the
  tolerance, `RpcDisagreementError` is raised (fail closed).
- Within tolerance, a **conservative** value is chosen:
  - balances & allowances -> `MIN` (never over-report spendable funds),
  - nonce -> `MAX` (never reuse a nonce that one endpoint already advanced).
- With only one endpoint configured, or when the secondary is transiently
  unavailable, the read still returns the primary value but is flagged
  `degraded` (and, when `polygon_require_secondary_rpc=true`, a single/failed
  secondary is treated as a hard `RpcDisagreementError` instead).

### Bounded retries + circuit breaker (`resilience.py`)

`guarded_read` wraps every RPC read with:

- a bounded `RetryPolicy` (max retries, exponential backoff with jitter, capped
  delay) that only retries *transient* errors (`OSError`, `asyncio.TimeoutError`),
- a per-endpoint `CircuitBreaker` (`CLOSED -> OPEN -> HALF_OPEN`). After
  `fail_threshold` consecutive failures the breaker opens and fast-fails with
  `CircuitOpenError`; after `reset_seconds` it allows a single half-open trial.

Non-transient errors (e.g. a revert / malformed response) are **not** retried.

### Transaction classification (`tx_status.py`)

`classify_transaction` is a pure function producing a `TransactionOutcome` with
status `SUCCESS | REVERTED | PENDING | REPLACED | DROPPED | UNKNOWN`:

- receipt `status == 1` -> `SUCCESS` (with confirmation count; flagged in
  `detail` when shallower than the required confirmations),
- receipt `status == 0` -> `REVERTED`,
- no receipt but tx present in mempool -> `PENDING`,
- no receipt, tx absent, wallet nonce advanced past the tx's expected nonce ->
  `REPLACED` (a different tx took the slot),
- no receipt, tx absent, nonce not advanced -> `DROPPED`,
- insufficient information (unknown nonces) -> `UNKNOWN` (caller must reconcile).

### Simulation, gas estimation, receipt waiting (`service.py`)

- `simulate(...)` performs a read-only `eth_call` and decodes an
  `Error(string)` (`0x08c379a0`) revert reason when present, returning a
  `SimulationResult` rather than raising.
- `estimate_gas(...)` applies `polygon_gas_estimate_buffer` (default `1.25`,
  exact `Decimal`) to the raw estimate and floors to an integer gas limit;
  optional gas price yields a conservative max-cost estimate.
- `wait_for_receipt(...)` polls with a bounded timeout and poll interval,
  raising `ReceiptTimeoutError` when the deadline passes with no terminal
  status. The clock and sleep are injected so tests are deterministic.

### Reconciliation integration

`WalletServiceChainStateProvider` adapts `WalletStateService` to the existing
`reconciliation.ports.ChainStateProvider` (`async load(tokens)`), mapping the
snapshot to `reconciliation.models.ChainState`. Any `ChainError` is converted
to `ChainState(available=False, note=...)` so reconciliation fails closed and
never fabricates balances. A single-RPC (uncross-checked) read is surfaced via
the snapshot `degraded` flag and copied into the `ChainState.note`.

> This adapter is provided but is **not yet wired** into the reconciliation CLI
> in place of `BlockedChainStateProvider`; that wiring is intentionally left for
> a later integration step so this module stays self-contained.

## Configuration

New grouped settings live under `AppConfig.chain` (`ChainReadSettings`), read
from the environment with the shared prefix. Chain id and RPC URLs continue to
come from the existing `AppConfig.polygon` group (`PolygonSettings`); the RPC
URLs are `SecretStr` and are only read via `.get_secret_value()` at adapter
construction, never logged.

| Setting | Default | Meaning |
| --- | --- | --- |
| `polygon_rpc_timeout_seconds` | `10.0` | Per-request HTTP timeout |
| `polygon_rpc_max_retries` | `3` | Bounded retries per read |
| `polygon_rpc_backoff_base_seconds` | `0.5` | Backoff base |
| `polygon_rpc_backoff_max_seconds` | `8.0` | Backoff cap |
| `polygon_rpc_circuit_fail_threshold` | `5` | Failures before the breaker opens |
| `polygon_rpc_circuit_reset_seconds` | `30.0` | Half-open cooldown |
| `polygon_balance_tolerance_base_units` | `0` | Allowed primary/secondary drift |
| `polygon_require_secondary_rpc` | `false` | Treat missing/failed secondary as hard error |
| `polygon_receipt_timeout_seconds` | `120.0` | `wait_for_receipt` deadline |
| `polygon_receipt_poll_interval_seconds` | `2.0` | Receipt poll cadence |
| `polygon_required_confirmations` | `1` | Confirmations for terminal success |
| `polygon_gas_estimate_buffer` | `1.25` | Multiplier on raw gas estimate |
| `polygon_usdc_address` | `None` | Collateral (USDC) contract |
| `polygon_usdc_decimals` | `6` | Collateral decimals |
| `polygon_conditional_tokens_address` | `None` | CTF (ERC-1155) contract |
| `polygon_outcome_token_decimals` | `6` | Outcome-token decimals |

Contract addresses default to `None` and are validated as EVM addresses when
set. When a required contract address is unset, the corresponding read **fails
closed** (`ChainConfigurationError`) rather than guessing an address.

## `wallet-diagnostics` command

A read-only operator command that prints the on-chain wallet snapshot (native
gas, collateral, Up/Down token balances, allowances, nonce, degraded flag). It
never prints the private key or RPC URLs.

```bash
uv run polymarket-pair-bot wallet-diagnostics \
    --up-token <UP_TOKEN_ID> --down-token <DOWN_TOKEN_ID> \
    --allowance-spender <SPENDER_ADDRESS> [--json]
```

Exit code `0` on a clean read, `1` on any `ChainError` (fail closed).

## Testing

- Unit tests use an in-memory `FakeEthereumRpc` (see `tests/fixtures/blockchain.py`)
  and a deterministic fake clock/sleep. They cover unit conversions, ABI
  encode/decode, retry + circuit-breaker behaviour, dual-RPC agreement /
  tolerance / disagreement / degraded / conservative min-max, the transaction
  classifier, and the full service surface (chain-id verify + mismatch,
  balances, allowance, nonce, simulate success/revert, gas buffer, receipt
  success + timeout, replaced/dropped/reverted, blocked `submit_ctf_operation`,
  snapshot aggregation, and the reconciliation adapter).
- `tests/integration/test_blockchain_fork.py` is an **optional** read-only test
  that is skipped unless `POLYGON_FORK_RPC` is set and web3.py is installed. It
  verifies chain id and reads the nonce/native balance against a local fork
  (e.g. `anvil --fork-url ...`); it never submits a transaction.

## Assumptions & unresolved issues

- The exact async surface of `web3.py`'s `AsyncWeb3` is **not verifiable in this
  offline environment**; all networked code paths are isolated in `web3_rpc.py`
  behind the `EthereumRpc` Protocol and are excluded from coverage. If a method
  name/shape differs in the installed web3 version, only that adapter needs to
  change.
- Collateral / CTF contract addresses and token decimals are configuration and
  default to fail-closed values; they are intentionally not hard-coded.
- Split/merge/redeem (Module 21) is deferred; `submit_ctf_operation` is blocked.
- The reconciliation CLI still uses `BlockedChainStateProvider`; swapping in
  `WalletServiceChainStateProvider` is a later integration step.

## Security posture

- Read-only: no signing, no submission, no private-key access.
- RPC URLs are `SecretStr` and never logged or included in errors.
- Balances are reported conservatively (min across endpoints) and the service
  fails closed on disagreement, circuit-open, timeout or missing configuration.
