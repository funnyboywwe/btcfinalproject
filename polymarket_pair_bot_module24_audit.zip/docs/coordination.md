# Coordination and leader election (Module 4)

This module provides Redis-backed coordination so multiple bot processes can run
safely while **at most one** controls a wallet's live execution. It implements
no order submission; it only decides *who* may submit and exposes the fast,
shared state the rest of the system needs.

> No profitability is claimed or implied. This module is infrastructure only.

## Dependency inversion

All ports live in the domain layer at
`polymarket_pair_bot.domain.coordination` as `Protocol`s and pure value objects
(no I/O, no redis-py import):

- `LeaderElector`, `LeadershipObserver`, `ExecutionGateView`
- `KillSwitchStore`, `MarketMetadataCache`, `RiskCounterStore`,
  `IdempotencyStore`, `HeartbeatStore`
- value objects `ProcessIdentity`, `LeaseStatus`, `KillSwitchState`,
  `MarketMetadata`; errors `CoordinationError` / `RedisUnavailableError`

The concrete Redis implementations live in `polymarket_pair_bot.coordination`
and are the only place redis-py is used.

## Execution-leader lease

- **Single owner:** the lease is one Redis key per *scope* (one wallet = one
  scope) set with `SET key token NX PX <ttl>`. Only one process can hold it.
- **Short TTL, periodic renewal:** default TTL 10s, renewed every 3s
  (`leader_renew_interval_seconds` must be `< leader_lease_ttl_seconds`).
- **Ownership-verified renew/release:** atomic Lua compare-and-extend /
  compare-and-delete, so a process can never renew or delete a lease it no
  longer owns (e.g. after expiry and takeover).
- **Losing leadership** (renew returns false, or Redis error):
  1. the execution gate is disabled **immediately** (new orders off);
  2. `LeadershipObserver.on_demoted(reason)` is invoked so later modules can
     safely cancel resting orders and trigger reconciliation.
- **Standby stays read-only:** a non-leader never enables the gate.
- **Redis failure disables live trading:** any redis-py/timeout error is
  translated to `RedisUnavailableError`, the coordinator demotes and keeps the
  gate disabled, and health goes `DEGRADED` (fail closed).
- **Paper/recorder modes** do not require leadership
  (`requires_execution_leader()` returns true only for live trading).

The `LeadershipCoordinator` runs exactly one tracked background task and cleans
it up on `stop()` (cancellation-safe, no untracked tasks); it implements the
app `Service` protocol.

## Execution gate

`ExecutionGate` starts **disabled** (fail closed). Only the confirmed leader
enables it. Every future live order path must check `is_enabled` and refuse when
disabled. Cancellation paths are intentionally *not* gated (existing orders can
still be cancelled when trading is disabled).

## Kill-switch cache

`RedisKillSwitchCache` stores the kill-switch as a persistent (no-TTL) Redis
hash for instant, cross-process visibility. **Redis is not the audit store:**
the operator CLI dual-writes, journaling the authoritative append-only event to
PostgreSQL (`kill_switch_events`, Module 3) first, then updating the cache.

## Other coordination primitives

- **Market metadata cache:** short TTL (default 30s); cached JSON is validated
  with a Pydantic v2 model on read and a corrupt entry is treated as a miss.
  Tick sizes are `Decimal`. Never the source of truth.
- **Risk counters:** atomic `INCRBY` with optional rolling-window TTL. Monetary
  counters must use **integer base units** (e.g. USDC micro-units); floats are
  rejected.
- **Idempotency keys:** first-writer-wins `SET NX EX`. The permanent dedupe
  record remains in PostgreSQL (e.g. unique fill IDs).
- **Heartbeats:** TTL-expiring liveness keys per component.

## Operator CLI

```bash
# Inspect the current execution leader for this process's scope
uv run python -m polymarket_pair_bot.coordination.cli leader

# Inspect the kill-switch state
uv run python -m polymarket_pair_bot.coordination.cli kill-switch status

# Activate / deactivate the kill switch (dual-writes Postgres journal + Redis)
uv run python -m polymarket_pair_bot.coordination.cli kill-switch activate \
    --reason "manual halt" --actor ops
uv run python -m polymarket_pair_bot.coordination.cli kill-switch deactivate \
    --actor ops
```

Make shortcuts: `make coord-leader`, `make coord-kill-status`,
`make coord-kill-activate REASON="..." ACTOR=ops`.

Output never includes secrets, DSNs or connection URLs; the owner token is
`host:pid:uuid` (non-secret).

## Configuration

`CoordinationSettings` (env-prefixed, see `.env.example`): lease TTL / renew
interval, heartbeat TTL / interval, market-metadata TTL, idempotency TTL, risk
counter TTL, and the Redis operation timeout. Validation enforces
renew-interval < lease-TTL and heartbeat-interval < heartbeat-TTL.

## Tests

- **Unit (no Redis):** config validation, execution gate, and the leadership
  coordinator (promotion, lease-loss demotion, Redis-failure demotion) via an
  in-memory fake elector.
- **Integration (real Redis 7, `RUN_INFRA_TESTS=1`):** single-leader
  concurrency, lease expiration + takeover, ownership-verified renew, kill
  switch, idempotency, counters, heartbeat expiry, and metadata cache incl.
  corrupt-entry-as-miss.
