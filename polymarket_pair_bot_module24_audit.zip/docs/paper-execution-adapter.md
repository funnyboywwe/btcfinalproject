# Paper execution adapter (Module 11)

The paper execution adapter is a **deterministic, offline simulator** of order
execution on the Polymarket CLOB. It exists so the strategy, inventory, and
risk layers can be exercised end-to-end — including realistic microstructure
friction — without ever touching the network or placing a real order.

## Common interface

Paper and live execution share a single protocol, `ExecutionAdapter`
(`execution/ports.py`), so higher layers can swap implementations with no code
change. The live adapter (a later module) will implement the same interface.

```text
submit_order(intent)          -> SubmitAck(outcome, reason, order)
cancel_order(order_id)        -> CancelAck(outcome, reason)
cancel_market_orders(market)  -> CancelBatchAck(acks, scheduled_count)
cancel_all_orders()           -> CancelBatchAck(acks, scheduled_count)
get_order(order_id)           -> ExchangeOrder | None
get_open_orders()             -> tuple[ExchangeOrder, ...]
get_fills(order_id=None)      -> tuple[Fill, ...]
```

Only `PaperExecutionAdapter` (`execution/paper.py`) is implemented today.
Simulated intents, orders, and fills are persisted through the existing
repository protocols (`ExecutionPersistence`), exactly like the live adapter
will persist real activity.

## Simulated microstructure

The adapter is driven by an out-of-band clock (`advance_to`, `now_ms`) and by
recorded/synthetic `MarketEvent`s (book snapshots + trade prints). It models:

1. **Post-only rejection** — a maker order that would cross the book is rejected.
2. **Maker queue position** — a resting order joins behind the size already at
   its price; that queue must be consumed by trades before it can fill.
3. **Partial fills** — trades fill the remaining size incrementally.
4. **Acknowledgement latency** — orders stay `PENDING_SUBMIT` until ack elapses.
5. **Cancellation latency** — cancels are scheduled and take effect after a delay.
6. **Fill-before-cancel races** — a fill landing before the cancel is effective wins.
7. **Taker execution through multiple levels** — marketable orders walk the book.
8. **FOK all-or-none** — filled completely or killed with zero fill.
9. **FAK / IOC partial** — fills what is available, cancels the remainder.
10. **Tick-size rejection** — prices off the token tick are rejected.
11. **Minimum-size rejection** — sub-minimum sizes are rejected.
12. **Fees** — per-fill taker fees via the shared `taker_fee` arithmetic.
13. **Slippage** — configured expected slippage worsens taker fill prices
    (rounded away from the taker, to tick).
14. **Stale-book rejection** — submitting against an out-of-date book fails closed.
15. **WebSocket outage** — a non-live feed marks the book stale; no matching occurs.
16. **Missed fills during fast movement** — `maker_fill_probability < 1` can miss
    qualifying trades.
17. **Duplicate event delivery** — events are de-duplicated by id; no double fills.
18. **Unknown submission outcome** — a submission can resolve `UNKNOWN`, is not
    cancelable, and requires reconciliation.
19. **Configurable latency distribution** — constant or uniform latencies drawn
    from a seeded RNG.

### Do not fill on touch

A passive order is **never** filled merely because the displayed price touched
its limit. Maker fills require actual trade prints that reach the order's price
*after* its queue-ahead has been consumed. This is the single most important
realism guarantee and is covered by dedicated tests.

## Determinism

All randomness flows through a single `random.Random(config.seed)`. Given the
same configuration and the same sequence of market events, fills are bit-for-bit
reproducible. Replay tests drive the adapter with a recorded book/trade session
and assert identical, reproducible outcomes.

## Money and safety

- All prices, sizes, and fees are `Decimal`-based domain value objects; no
  `float` arithmetic touches money or probabilities.
- No networking, no blockchain, and no real-order code paths exist in this
  module. It makes **no profitability claim**.

## Configuration

`PaperExecutionConfig` (`execution/types.py`) carries the seed, fee/slippage
basis points, ack/cancel latency distributions, minimum size, stale threshold,
GTD TTL, and the unknown-submission / maker-fill probabilities. It can be built
from `PaperExecutionSettings` via `PaperExecutionConfig.from_settings(...)`.

## Tests

- `tests/unit/test_paper_execution.py` — one or more tests per modeled behavior.
- `tests/replay/test_paper_execution_replay.py` — recorded-book replay + determinism.
- `tests/fixtures/execution.py` — in-memory repository fakes and builders.

Run the full suite with `pytest`.
