# Module 15 — Authoritative Reconciliation

Reconciliation is the bot's **source-of-truth repair pass**. It compares what
the bot believes locally against authoritative remote/on-chain state, classifies
any divergence, takes only the safe automatic actions, and **fails closed** by
stopping new trading whenever it cannot prove the account is consistent.

> This module never claims the strategy is profitable and never treats a
> submitted / acknowledged / open / partially-filled order as a matched pair.
> A pair is only "locked" when equal Up and Down quantities are confirmed
> filled — reconciliation is one of the mechanisms that keeps that invariant
> honest after a crash, reconnect, or unknown submission.

## What is compared

| Dimension | Local source | Authoritative source |
| --- | --- | --- |
| Open orders | `orders.list_open_all()` | user API `get_open_orders()` |
| Fills | `fills.list_for_order()` | user API `get_trades()` |
| Inventory / matched pairs | `inventory.get_latest()` | derived from fills + balances |
| Outcome-token balances | expected net shares | wallet `get_balances()` |
| Collateral (USDC) balance | expected reserve | wallet `get_balances()` |
| Allowances | expected spender/amount | wallet `get_allowances()` |
| Pending Polygon transactions | `LocalState.pending_chain_txs` | chain provider (Modules 20-21) |
| Completed merge/redeem txs | `LocalState.completed_ctf_ops` | chain provider (Modules 20-21) |

The on-chain comparisons are wired through a **blocked provider** today
(`BlockedChainStateProvider`) because balance/allowance RPC and CTF operations
are owned by Modules 20-21. The comparator already supports chain data; it is
simply reported as unavailable until those modules land. This satisfies the
"if package behavior cannot be verified, add a blocked adapter method with a
clear explanation instead of guessing" safety rule.

## Classifications (increasing severity)

| Class | Halts new trading? | Meaning |
| --- | --- | --- |
| `CONSISTENT` | no | Local and authoritative state agree. |
| `AUTOMATICALLY_RECOVERABLE` | no | Safe to self-heal (e.g. import a confirmed missing fill idempotently). |
| `LOCAL_REPAIR_REQUIRED` | yes | Local records must be repaired from authoritative data before trading resumes. |
| `CANCELLATION_REQUIRED` | yes | An unknown/unwanted remote order must be cancelled. |
| `MANUAL_REVIEW` | yes | A human must inspect (e.g. local-only fill, in-flight merge). Data is never deleted. |
| `CRITICAL_STOP` | yes | Balance/collateral mismatch or unreadable authoritative state. Fail closed. |

The overall report classification is the **maximum severity** across all
discrepancies. `halts_new_trading` is true for every class except `CONSISTENT`
and `AUTOMATICALLY_RECOVERABLE`.

## Triggers (requirements 1-6)

`ReconciliationService` exposes one wrapper per required trigger:

| Trigger | Method | Requirement |
| --- | --- | --- |
| Startup | `on_startup()` | 1 |
| User WS reconnect | `on_user_stream_reconnect()` | 2 |
| Unknown submission | `on_unknown_submission(order_id)` | 3 |
| Before merge | `before_merge()` | 4 |
| After merge | `after_merge()` | 4 |
| Periodic | `periodic()` / `run_periodic(...)` | 5 |
| Graceful shutdown | `on_shutdown()` | 6 |

`run_periodic(interval_seconds=..., stop_event=...)` is bounded and
cancellation-safe: it awaits the stop event with a timeout, runs one pass per
tick, swallows/loggs per-pass failures so the loop is not torn down by a single
error, and exits promptly when the event is set or the task is cancelled. It
rejects a non-positive interval.

## Safety behaviours

- **Import missing confirmed fills idempotently (7).** Confirmed remote fills
  absent locally are queued and imported through `ConfirmedFillImporter`, which
  is idempotent by fill id. Fill messages are *not* assumed unique — duplicates
  are dropped, never double-counted.
- **Never silently delete unexplained data (8).** A fill or order that exists
  locally but not remotely is raised as `MANUAL_REVIEW`/`LOCAL_REPAIR_REQUIRED`,
  never deleted automatically.
- **Unknown remote orders (9).** An order the bot does not recognise triggers
  cancellation when a canceller is available, otherwise it escalates to a
  critical review. Cancellation stays possible even when the kill switch /
  trading halt is already engaged.
- **Balance mismatches stop new trading (10).** Any outcome-token or collateral
  balance disagreement (when balances are actually reported) is `CRITICAL_STOP`.
  When balances are not reported at all, the pass records an informational note
  and skips balance verification rather than fabricating a mismatch — real
  divergences still stop trading whenever balance data exists.
- **Persist complete reports (11).** Every pass is converted to a domain
  `ReconciliationResult` (status, discrepancies, recommended actions) and
  persisted through `ReconciliationReportSink` before effects are applied.
- **Fail closed.** If the remote account state cannot be loaded, the pass is
  `CRITICAL_STOP` and new trading halts.

## Module boundaries

- `comparator.py` is a **pure function** (`reconcile_states`) over plain value
  objects. It imports no SQLAlchemy, HTTP, WS, or blockchain client.
- All external systems are behind `typing.Protocol` ports in `ports.py`
  (`LocalStateProvider`, `RemoteAccountProvider`, `ChainStateProvider`,
  `ConfirmedFillImporter`, `RemoteOrderCanceller`, `TradingHalt`,
  `ReconciliationReportSink`, `MarketScope`).
- Concrete adapters in `adapters.py` bind those ports to the unit of work, the
  authenticated account reader (Module 15 auth), the execution adapter
  (Module 17), and the kill switch (Module 14).
- Monetary values are `Decimal`-backed domain value objects throughout.

## CLI (requirement 12)

```
uv run polymarket-pair-bot reconcile              # run a full pass, persist report
uv run polymarket-pair-bot reconcile --market <id> # scope to one or more markets
uv run polymarket-pair-bot reconcile --report-only # read-only: no halt side effects
uv run polymarket-pair-bot reconcile --json        # machine-readable report
```

Exit code is `0` when the pass does not halt new trading and `1` when it does,
so operators and systemd can gate restart/resume on it. From the CLI no
canceller is wired, so an unknown remote order is surfaced as a critical review
for a human rather than being auto-cancelled by an operator command.

## Files

| File | Responsibility |
| --- | --- |
| `reconciliation/triggers.py` | `ReconciliationTrigger` enum + merge-boundary helper. |
| `reconciliation/classification.py` | `ReconciliationClass`, severity, `escalate`/`combine`, status mapping. |
| `reconciliation/models.py` | `DiscrepancyKind`, `LocalState`, `RemoteAccountState`, `ChainState`, `Discrepancy`, `ReconciliationReport`. |
| `reconciliation/ports.py` | Typed Protocol ports for every external dependency. |
| `reconciliation/comparator.py` | Pure `reconcile_states(...)` comparison + classification. |
| `reconciliation/service.py` | `ReconciliationService`, `ReconciliationTuning`, triggers, effects, periodic loop. |
| `reconciliation/blocked_chain.py` | Blocked/empty chain providers pending Modules 20-21. |
| `reconciliation/adapters.py` | Concrete port bindings to uow / auth reader / execution / kill switch. |
| `reconciliation/cli.py` | `reconcile` subcommand. |
| `reconciliation/errors.py` | Reconciliation error types. |

See `docs/runbooks/` for operator recovery procedures.
