# Configuration reference (Module 1)

All configuration is loaded from environment variables (and an optional `.env`
file) with [pydantic-settings](https://docs.pydantic.dev/latest/concepts/pydantic_settings/).
Configuration is split into 14 grouped settings models composed by
`AppConfig` (`src/polymarket_pair_bot/config/settings.py`).

## Loading

```python
from polymarket_pair_bot.config import load_config

config = load_config()          # validates everything, fails closed
config.redacted_summary()        # log-safe dict (all secrets scrubbed)
config.health_public_view()      # minimal, secret-free view for health APIs
```

## Safety rules enforced at load time

- `PAPER_TRADING` defaults `true`, `LIVE_TRADING` defaults `false`.
- Setting both `true` is rejected. To go live: `PAPER_TRADING=false` **and**
  `LIVE_TRADING=true`.
- `LIVE_TRADING=true` fails unless every authenticated value is present:
  private key, funder address, all three API credentials, and both RPC URLs.
- Recorder mode (`PAPER_TRADING=false`, `LIVE_TRADING=false`) and paper mode
  need **no** wallet credentials.
- Unsupported `POLYGON_CHAIN_ID` and malformed wallet addresses / private keys
  are rejected.
- Sensitive values use `SecretStr` and never appear in `repr`, logs, summaries,
  or health endpoints.

## Secret handling

Secrets (`SecretStr`): `DATABASE_URL`, `REDIS_URL`, `POLYGON_RPC_PRIMARY`,
`POLYGON_RPC_SECONDARY`, `POLYMARKET_API_KEY`, `POLYMARKET_API_SECRET`,
`POLYMARKET_API_PASSPHRASE`, `POLYMARKET_PRIVATE_KEY`, `ALERTS_WEBHOOK_URL`.
Redaction is recursive and also scrubs any object exposing `get_secret_value`,
long hex/opaque tokens, and known-sensitive field names.

## Production startup gates

`config.gates.run_production_gates(config, postgres_check=..., redis_check=...)`
evaluates: dedicated wallet acknowledgement, positive risk limits, configured
kill switch, primary+secondary RPC, PostgreSQL available, Redis available,
monitoring enabled. Infrastructure probes are injected as `HealthCheck`
protocols (dependency inversion); results never contain secrets.

## Environment variables

### Application
| Variable | Type | Default | Notes |
|---|---|---|---|
| `APP_ENV` | development \| staging \| production | `development` | Deployment environment |
| `PAPER_TRADING` | bool | `true` | Simulated execution |
| `LIVE_TRADING` | bool | `false` | Real execution; requires full auth |
| `SHUTDOWN_TIMEOUT_SECONDS` | float | `30.0` | Graceful shutdown budget (non-monetary) |
| `OPERATOR_API_HOST` | str | `127.0.0.1` | Private operator/health API host |
| `OPERATOR_API_PORT` | int | `8081` | Private operator/health API port |

### Logging
| Variable | Type | Default | Notes |
|---|---|---|---|
| `LOG_LEVEL` | DEBUG..CRITICAL | `INFO` | |
| `LOG_JSON` | bool | `true` | JSON structured logs |
| `LOG_REDACTION_ENABLED` | bool | `true` | Enable log redaction |

### PostgreSQL
| Variable | Type | Default | Notes |
|---|---|---|---|
| `DATABASE_URL` | secret | `postgresql+asyncpg://bot:bot@localhost:5432/pair_bot` | Local default has no real creds |
| `DB_POOL_SIZE` | int | `5` | |
| `DB_ECHO` | bool | `false` | SQLAlchemy echo |

### Redis
| Variable | Type | Default | Notes |
|---|---|---|---|
| `REDIS_URL` | secret | `redis://localhost:6379/0` | |
| `REDIS_NAMESPACE` | str | `ppb` | Key prefix |

### Polymarket public APIs
| Variable | Type | Default | Notes |
|---|---|---|---|
| `POLYMARKET_GAMMA_URL` | http url | `https://gamma-api.polymarket.com` | Operator-overridable |
| `POLYMARKET_CLOB_URL` | http url | `https://clob.polymarket.com` | Operator-overridable |
| `POLYMARKET_MARKET_WS_URL` | ws url | `wss://ws-subscriptions-clob.polymarket.com/ws/market` | Operator-overridable |
| `POLYMARKET_USER_WS_URL` | ws url | `wss://ws-subscriptions-clob.polymarket.com/ws/user` | Operator-overridable |
| `POLYMARKET_RTDS_URL` | ws url \| empty | _none_ | Optional; supply when required |

### Polymarket authenticated APIs (secrets)
| Variable | Type | Default | Notes |
|---|---|---|---|
| `POLYMARKET_API_KEY` | secret | _none_ | Required for live |
| `POLYMARKET_API_SECRET` | secret | _none_ | Required for live |
| `POLYMARKET_API_PASSPHRASE` | secret | _none_ | Required for live |

### Polygon RPC
| Variable | Type | Default | Notes |
|---|---|---|---|
| `POLYGON_CHAIN_ID` | int | `137` | 137 mainnet / 80002 Amoy only |
| `POLYGON_RPC_PRIMARY` | secret | _none_ | May embed API key; required for live |
| `POLYGON_RPC_SECONDARY` | secret | _none_ | Required for live |

### Wallet
| Variable | Type | Default | Notes |
|---|---|---|---|
| `POLYMARKET_PRIVATE_KEY` | secret | _none_ | 32-byte hex; dedicated wallet only |
| `POLYMARKET_FUNDER_ADDRESS` | address | _none_ | 0x + 40 hex |
| `POLYMARKET_SIGNATURE_TYPE` | 0\|1\|2 | `0` | EOA / POLY_PROXY / POLY_GNOSIS_SAFE |
| `WALLET_IS_DEDICATED_ACK` | bool | `false` | Production gate: must be true |

### Paper execution
| Variable | Type | Default |
|---|---|---|
| `PAPER_STARTING_BANKROLL_USD` | Decimal | `1000` |
| `PAPER_TAKER_FEE_BPS` | Decimal | `0` |
| `PAPER_EXPECTED_SLIPPAGE_BPS` | Decimal | `0` |
| `PAPER_FILL_PROBABILITY` | Decimal 0..1 | `1` |
| `PAPER_LATENCY_MS` | int | `50` |

### Live execution
| Variable | Type | Default | Notes |
|---|---|---|---|
| `LIVE_MAX_ORDER_NOTIONAL_USD` | Decimal | `50` | |
| `LIVE_SUBMIT_TIMEOUT_SECONDS` | float | `10.0` | |
| `LIVE_ORDER_POLL_INTERVAL_SECONDS` | float | `1.0` | |
| `LIVE_MAX_SUBMIT_RETRIES` | int | `0` | Blind retries forbidden |
| `LIVE_RECONCILE_ON_TIMEOUT` | bool | `true` | Unknown status → reconcile |

### Pair strategy (USD; not a profitability claim)
| Variable | Type | Default | Notes |
|---|---|---|---|
| `MAX_EFFECTIVE_PAIR_COST_USD` | Decimal | `0.99` | Must be > 0 and < 1 |
| `SAFETY_RESERVE_USD` | Decimal | `0.005` | |
| `ASSUMED_TAKER_FEE_BPS` | Decimal | `0` | |
| `ASSUMED_SLIPPAGE_BPS` | Decimal | `0` | |
| `MERGE_GAS_OVERHEAD_USD` | Decimal | `0.01` | |
| `MIN_PAIR_SIZE_TOKENS` | Decimal | `1` | |
| `MAX_PAIR_SIZE_TOKENS` | Decimal | `100` | Must be >= min |

### Risk
| Variable | Type | Default |
|---|---|---|
| `MAX_UNMATCHED_NOTIONAL_USD` | Decimal | `25` |
| `MAX_UNMATCHED_DURATION_SECONDS` | int | `120` |
| `MAX_TOTAL_POSITION_NOTIONAL_USD` | Decimal | `100` |
| `MAX_OPEN_ORDERS` | int | `10` |
| `DAILY_LOSS_LIMIT_USD` | Decimal | `50` |
| `KILL_SWITCH_ENABLED` | bool | `true` |
| `KILL_SWITCH_KEY` | str | `ppb:kill_switch` |

### Monitoring
| Variable | Type | Default |
|---|---|---|
| `MONITORING_ENABLED` | bool | `false` |
| `METRICS_HOST` | str | `127.0.0.1` |
| `METRICS_PORT` | int | `9090` |
| `PROMETHEUS_NAMESPACE` | str | `ppb` |

### Alerts
| Variable | Type | Default | Notes |
|---|---|---|---|
| `ALERTS_ENABLED` | bool | `false` | |
| `ALERTS_WEBHOOK_URL` | secret | _none_ | May embed a token |
| `ALERTS_MIN_SEVERITY` | info\|warning\|error\|critical | `warning` | |
