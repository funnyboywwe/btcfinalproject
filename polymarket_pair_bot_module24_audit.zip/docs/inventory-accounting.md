# Inventory and matched-pair accounting (Module 12)

The inventory layer is the authoritative, in-memory model of **what the bot
owns** for a single binary market. It is pure, deterministic and
side-effect-free: positions are derived *exclusively* from confirmed fills, and
nothing in `polymarket_pair_bot.inventory.{accounting,marking,audit}` performs
I/O, reads environment variables, or imports SQLAlchemy / HTTP / WebSocket /
blockchain clients. Persistence and rebuild orchestration live in
`inventory.service` behind the domain repository protocols; the SQLAlchemy fill
journal lives in `persistence.inventory_journal`.

It makes **no profitability claim**. Every figure is a modeled accounting
quantity computed with the project's conservative `Decimal` rounding policy.

## What is tracked per market

| Quantity | Source |
| --- | --- |
| Confirmed Up/Down quantity | sum of confirmed buy fills per side |
| Up/Down acquisition cost | `sum(price * size)` (excludes fees) |
| Up/Down average cost | weighted-average = acquisition cost / quantity |
| Matched quantity | `min(up, down)` complete pairs |
| Residual Up/Down | `quantity - matched` (unmatched, directional) |
| Locked pair value | `matched * $1` recoverable by CTF merge |
| Locked net profit | `locked value - matched cost basis` |
| Marked residual value | residual valued at executable bid prices |
| Realized P&L | from any confirmed sells (defensive path) |
| Fees | cumulative taker fees per side |
| Rebates | only when supplied as authoritative; never inferred |
| Pending orders / reserved collateral | from non-terminal exchange orders |

## Lot-allocation method: weighted-average cost (WAC)

We use **weighted-average cost** per outcome side
(`LotAllocationMethod.WEIGHTED_AVERAGE_COST`). Rationale:

* the accumulation strategy only ever *buys* to acquire, so acquisition order
  never changes the reported average — the rebuild from the fill journal is
  therefore order-independent, deterministic and idempotent;
* it matches the single `average_price` field already carried by the persisted
  `Position`, so no per-lot storage is required;
* it keeps matched and unmatched cost bases consistent (both priced at the same
  average), which is what the CTF-merge economics assume.

## Matched vs unmatched (kept strictly separate)

* **Matched** accounting concerns complete Up+Down pairs. A matched pair can be
  merged back into $1 of collateral, so its locked value is `pairs * $1` and its
  cost basis is `matched * (up_avg + down_avg)` plus a pro-rata share of fees.
* **Unmatched (residual)** accounting concerns directional exposure not yet
  paired (`|up - down|` on one side). It carries directional risk and is valued
  by marking, not by the $1 merge identity.

`matched_cost_basis + residual_cost_basis` always reconstructs the total cost
basis (asserted by property tests).

## Residual marking: executable bid prices only

Residual exposure is marked **conservatively** at the price it could actually be
sold — the executable-bid VWAP obtained by walking the *bid* side of the book
(`inventory.mark_residual`). The module never uses midpoint, last-trade or
best-ask prices for liquidation value: those overstate what could be recovered
in an emergency exit. Residual beyond available bid depth is reported as a
`shortfall` and marked at **zero**, so `emergency_liquidation_value` is a floor,
never an optimistic estimate. A missing book marks the whole residual as
shortfall.

## Fills, idempotency and never-negative inventory

* Only confirmed fills mutate inventory; callers pass confirmed fills.
* `apply_fill` is idempotent by `fill_id` (a repeated fill message is ignored),
  and the persistence unit of work independently rejects duplicate `fill_id`s
  so a duplicate never advances inventory twice.
* A sell larger than the held quantity raises `NegativeInventoryError`; the
  layer fails closed rather than representing a negative holding.

## Persistence, rebuild and verification

`InventoryService.record_fill` seeds from the latest stored snapshot, applies
one confirmed fill, and persists the resulting snapshot **in the same
transaction as the fill** (`record_fill_and_update_inventory`), committing
atomically. It returns whether the fill was newly recorded.

`InventoryService.rebuild_and_verify` rebuilds inventory entirely from the fill
journal (`rebuild_from_fills`) and compares it to the stored snapshot
(`compare_inventories`), reporting any discrepancies. It never mutates state and
is used for restart-time verification and the audit command.

## Audit command

```
python -m polymarket_pair_bot.inventory.cli audit --market <market_id>
python -m polymarket_pair_bot.inventory.cli audit --market <market_id> --json
```

The audit rebuilds from the journal, compares against storage, summarizes
reserved collateral from pending orders, and prints a complete, **secret-free**
report (accounting figures only; no DSN, keys or signatures). It exits non-zero
when the rebuilt inventory does not match the stored snapshot. Residual bid
marking is available in the accounting API and is applied by the live
market-data path; it is intentionally omitted from this offline audit, which has
no fresh order book.

## Tests

* `tests/unit/test_inventory.py` — one test per modeled requirement, plus the
  async service (persist / idempotency / rebuild) tests.
* `tests/unit/test_inventory_properties.py` — Hypothesis invariants: quantity =
  sum of buys, matched + residual reconstruction, cost-basis decomposition,
  order-independent rebuild, the locked-net-profit identity, and that marked
  residual value never exceeds the best-bid notional.
