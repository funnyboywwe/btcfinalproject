# Architecture Overview (Module 0)

## Goal

Establish a production-grade engineering foundation for the Polymarket BTC
5-minute two-sided pair-accumulation bot **before** any trading logic exists.
Module 0 delivers configuration, logging, lifecycle management, health state,
local infrastructure, and the quality toolchain — nothing that talks to
Polymarket or places orders.

> No profitability claim is made anywhere in this project.

## Why a modular monolith

The bot is latency-sensitive and safety-critical, and a matched pair spans
tightly-coupled concerns (market data, execution, on-chain merge, accounting).
A **single deployable process** avoids inter-service network hops on the hot
path and keeps one authoritative view of state, which is essential for correct
matched-pair accounting and fail-closed behavior.

To avoid the usual downside of a monolith (tangled coupling), the codebase is
organized into **clear internal modules with dependency inversion**:

- **Domain and strategy code is pure.** It must not import SQLAlchemy models,
  HTTP clients, WebSocket clients, blockchain clients, environment variables,
  or concrete live-execution classes.
- **External systems sit behind typed protocols / abstract interfaces.** The
  `Service` protocol (`app/services.py`) and the `HealthCheck` protocol
  (`shared/health.py`) are the first two examples. Paper and live execution
  adapters will later share one interface so the strategy cannot tell them
  apart.

## Layering

```
shared/         pure primitives (health state, common types) — imports nothing heavy
security/       secret redaction (stdlib only)
observability/  JSON logging (stdlib), infra health checks (lazy driver imports)
config/         pydantic-settings typed configuration + secrets
app/            lifecycle manager, service protocol, composition root
domain/ ...     future business modules (pure), infra modules (adapters)
```

Dependencies point **inward**: `app` may depend on `config`, `observability`,
`shared`; `shared` depends on nothing in the project. Infrastructure modules
(`persistence`, `blockchain`, `observability.health_checks`) import their heavy
third-party drivers **lazily inside functions** so importing a module never
forces an optional driver to be installed and keeps import graphs clean.

## Runtime lifecycle

`LifecycleManager` (`app/lifecycle.py`) owns the process lifecycle:

1. Install SIGTERM/SIGINT handlers that request **one** graceful shutdown.
2. Transition health `starting -> ready` after services start in order.
3. Wait for a shutdown signal.
4. Transition `ready -> stopping`, stop services in **reverse** order, each
   bounded by a configurable timeout (fail closed on hang).

Background tasks (none required in Module 0) must be created through
`TaskSupervisor`, guaranteeing **no untracked tasks** and cancellation-safe
shutdown. Module 0 registers **zero services**, so the app starts and stops
cleanly with no external dependencies and no secrets.

## Health model

`HealthState` is a four-value machine: `starting`, `ready`, `degraded`,
`stopping`. `HealthTracker` holds the current state behind an async lock. A
later module will expose it via a private FastAPI operator/health API.
Dependency probes implement the `HealthCheck` protocol; `PostgresHealthCheck`
and `RedisHealthCheck` are provided for local infrastructure.

## Observability and secrets

Logging uses the standard library with a custom `JsonFormatter` and a
`RedactionFilter`. Redaction (`security/redaction.py`) scrubs both
sensitive **field names** (secret, password, token, private_key, dsn, ...) and
secret-looking **values** (32-byte hex blobs, long opaque tokens). Secrets in
configuration are typed as `SecretStr` and never rendered.

## Numeric policy (enforced from the domain module onward)

Prices, probabilities, token quantities, collateral, fees, P&L, slippage, and
gas conversions must use `Decimal` or explicitly documented integer base units
— never binary floating point. Module 0 uses `float` only for non-monetary
durations (e.g. the shutdown timeout in seconds).

## Module roadmap

The eventual system has 27 modules. Module 0 (this scaffold) is complete. The
next steps in order: (1) typed configuration is partly seeded here and will be
expanded, (2) domain models and fixed-point arithmetic, (3) PostgreSQL
persistence, (4) Redis coordination and leader election, and so on through the
paper simulator, risk engine, kill switches, authenticated adapters,
reconciliation, on-chain split/merge/redeem, the pair-accumulation state
machine, monitoring, the operator dashboard, deployment, crash-recovery tests,
and finally a manually gated tiny live pilot.

## Safety principles baked into the foundation

- `LIVE_TRADING` defaults false, `PAPER_TRADING` defaults true, and they are
  mutually exclusive.
- Fail closed; graceful, bounded shutdown; no untracked tasks.
- Never log secrets; never place real orders in tests or dev commands (there is
  no order path yet, and integration tests self-skip without opt-in).
- Unverified external behavior will be isolated behind adapters; when a
  package's behavior cannot be verified, a **blocked** adapter method with a
  clear explanation is added rather than guessing.
