# Module 10 — Pair-Opportunity Detector

> The user-facing plan numbers this "Module 9 (Pair-opportunity detector)". In
> the architecture list it is item **10**, sitting directly on top of the
> Module 8 VWAP/fee engine (item 9 in that same list). Internal code and tests
> label it Module 10 for consistency with the engine.

## Overview

The pair-opportunity detector is a **pure, synchronous, side-effect-free**
component that turns a Module 8 `PairCostResult` into an explicit, fully
described set of trade *candidates* — or a documented no-trade decision. It
**does not submit orders**, touch the network, read the clock, or mutate its
inputs. It only *describes* what could be done and whether risk has approved
it.

The detector makes **no profitability claim**. It surfaces an expected net edge
for information only; whether to act is decided downstream by the execution
state machine (Module 22) after the risk engine (Module 13) has spoken.

## Entry point

```python
from polymarket_pair_bot.strategy import PairDetector, DetectorConfig, RiskInput

detector = PairDetector(
    DetectorConfig(
        engine_parameters=engine_parameters,   # Module 8 EngineParameters
        passive_order_ttl_seconds=30,           # maker resting time budget
        taker_order_ttl_seconds=5,              # taker fill/cancel budget
    )
)

result = detector.evaluate(
    market=binary_market,          # domain.entities.BinaryMarket
    up_book=up_book,               # OrderBookSnapshot | None
    down_book=down_book,           # OrderBookSnapshot | None
    inventory=inventory_summary,   # confirmed-fill inventory only
    target_quantity=Shares(Decimal("10")),
    now=UnixTimestamp(...),        # caller-supplied clock (purity)
    up_is_fresh=True,              # freshness verdict from the feed layer
    down_is_fresh=True,
    risk_input=risk_input,         # RiskInput | None (see risk gate)
)
```

`evaluate` returns an immutable `DetectionResult`.

## What the detector evaluates

The detector delegates all cost/depth/freshness math to
`evaluate_pair_cost` and then maps the engine's `PairOpportunityResult` onto one
of five **actions**:

| Engine result | `DetectorAction` | Candidates produced |
|---|---|---|
| `IMMEDIATE_TWO_LEG` | `IMMEDIATE_TWO_LEG` | two taker legs (UP + DOWN) |
| `PASSIVE_FIRST_LEG` | `PASSIVE_FIRST_LEG` | one maker leg (cheaper resting side) |
| `PASSIVE_SECOND_LEG` | `PASSIVE_SECOND_LEG` | one leg completing the held side |
| `MATCHED_PAIR` | `MATCHED_INVENTORY` | none (already balanced) |
| `OBSERVATION_ONLY` / `REJECTED` | `NO_TRADE` | none |

1. **Passive first-leg accumulation** — taker is too expensive but the maker
   pair cost is within budget. The detector proposes resting a maker order on
   the *cheaper* side (deterministic UP tie-break), priced at the best bid but
   never above the engine's `max_first_leg_price` ceiling.
2. **Passive second-leg completion** — one side is already held as confirmed
   inventory. The detector proposes the missing side, choosing a taker
   completion when the best ask sits at/under `max_second_leg_price` and depth
   is sufficient, otherwise a maker completion.
3. **Immediate dual-leg capture** — both taker legs are affordable and the net
   edge clears the required threshold; two taker candidates are proposed at the
   executable VWAP price and clamped to the executable quantity.
4. **Existing matched inventory** — both sides already ≥ target; nothing to do.
5. **No-trade conditions** — any rejection (stale/unavailable feed, thin book,
   window too close) or observation-only cost. Candidates are empty and every
   rejection reason from the engine is preserved verbatim.

## Candidate fields

Every `PairCandidate` carries the complete description the spec requires:

| Field | Meaning |
|---|---|
| `market_id`, `window` | market and its five-minute window |
| `side` | `OutcomeSide.UP` / `DOWN` |
| `proposed_price` | `ProbabilityPrice` for the leg |
| `proposed_quantity` | `Shares`, already clamped to the risk-approved size |
| `role` | `ExecutionRole.MAKER` / `TAKER` |
| `matched_inventory` | current confirmed matched pairs |
| `unmatched_up`, `unmatched_down` | current directional exposure |
| `effective_pair_cost` | all-in per-pair cost for the chosen role |
| `expected_net_edge` | `$1 − effective_pair_cost` (per pair, informational) |
| `required_hedge_depth` | shares still needed on the opposite side to balance |
| `book_age_seconds` | `now − snapshot.as_of` (None if no book) |
| `seconds_to_close` | time remaining in the window |
| `cancel_deadline` | `now + ttl`, **capped at window close** |
| `approved` / `approval_reason` | risk-gate outcome for this candidate |
| `rejection_reasons` | complete engine rejection reasons (tuple) |

`DetectionResult` adds `action`, `risk_input_available`, `approved`,
`up_book_age_seconds`, `down_book_age_seconds`, `effective_pair_cost`,
`effective_pair_cost_maker`, `expected_net_edge`, `rejection_reasons`, the full
`cost_result`, and the `has_candidates` / `approved_candidates` helpers.

## Risk gate (cannot approve without risk input)

The detector **always describes** candidates so operators and observers can see
what *would* have been proposed, but it can only mark a candidate `approved`
when a `RiskInput` is present **and** its verdict is `APPROVE`:

| Condition | `approved` | `approval_reason` |
|---|---|---|
| `risk_input is None` | `False` | `risk_input_unavailable` |
| verdict `REJECT` | `False` | `risk_rejected: <reason>` |
| verdict `APPROVE` | `True` | `risk_approved` |

When approved, `proposed_quantity` is clamped to `risk_input.max_pair_size`.
`RiskInput` validates that a `REJECT` carries a zero `max_pair_size` and that a
reason string is always present. This is the dependency-inversion seam: the
detector depends on the abstract `RiskInput`, never on a concrete risk engine.

## Purity & determinism

- No I/O, no clock reads (the caller passes `now`), no randomness.
- Inputs are never mutated (verified by test).
- Same inputs ⇒ identical `DetectionResult` (verified by equality test).
- Imports only `polymarket_pair_bot.domain.*`,
  `polymarket_pair_bot.strategy.engine`, and the standard library. No
  SQLAlchemy, HTTP, WebSocket, blockchain, or settings imports.

## Asynchronous observation persistence

Persisting what the detector saw must never block or contaminate the pure
evaluation path, so it is done by a **separate consumer** in
`strategy/observations.py`:

- `observation_from_result(result, evaluated_at=?)` projects a `DetectionResult`
  into an immutable `DetectionObservation` whose monetary fields are **exact
  decimal strings** (`str(value_object)`), never floats, and which is
  JSON-serialisable via `as_dict()`.
- `ObservationSink` is a runtime-checkable `Protocol`
  (`write_batch` / `flush` / `aclose`) — the storage backend (Module 3
  Postgres, Parquet, etc.) is injected, keeping the strategy layer free of
  persistence imports.
- `ObservationConsumer` owns a **bounded** `asyncio.Queue` with a configurable
  overflow policy (`DROP_OLDEST`, `DROP_NEWEST`, `BLOCK`), drains in bounded
  batches, is cancellation-safe, is best-effort on sink errors (a failing sink
  never crashes the writer loop), and always flushes + closes on graceful
  shutdown. Counters are exposed via `ObservationConsumerMetrics` for Module 23
  monitoring. `run()` is intended to be launched as **one supervised task** —
  there are no untracked background tasks.

The consumer is single-use: construct one per `run()`. `request_stop()` makes
`run()` drain the remaining queue, then flush and close.

## Configuration

`DetectorConfig` wraps the Module 8 `EngineParameters` and adds two positive
TTL budgets used only to compute `cancel_deadline`:

```python
DetectorConfig(
    engine_parameters=EngineParameters.from_strategy_settings(settings, tick),
    passive_order_ttl_seconds=30,
    taker_order_ttl_seconds=5,
)
```

Both TTLs must be `> 0` (validated at construction). Deadlines are always
capped at the window close time so the bot never plans to rest an order past
expiry.

## Files

| File | Role |
|---|---|
| `src/polymarket_pair_bot/strategy/detector.py` | Pure detector implementation |
| `src/polymarket_pair_bot/strategy/observations.py` | Async observation consumer + projection |
| `src/polymarket_pair_bot/strategy/__init__.py` | Public re-exports (updated) |
| `tests/fixtures/detector.py` | Market / risk / in-memory-sink fixtures |
| `tests/unit/test_detector.py` | Scenario + purity + risk-gate tests |
| `tests/unit/test_observations.py` | Async consumer + overflow-policy tests |
| `docs/pair-opportunity-detector.md` | This document |

## Scope boundary

The detector proposes; it never executes. Order submission, paper simulation
(Module 11), inventory accounting (Module 12), the risk engine itself
(Module 13), and the accumulation state machine (Module 22) are out of scope
and are reached only through the abstract `RiskInput` and `ObservationSink`
seams defined here.
