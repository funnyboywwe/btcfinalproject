# Human go-live checklist (Module 24)

This checklist is **mandatory and human-only**. The release gate never marks any
item as confirmed on its own. `live_ready` cannot be reported until every item
below is explicitly confirmed by a person who has actually completed it, in
addition to every automated gate passing.

Confirm items with the release-gate CLI only after they are genuinely done:

```bash
uv run polymarket-pair-bot release-gate \
  --confirm legal_eligibility \
  --confirm dedicated_wallet \
  --confirm limited_capital \
  --confirm working_backups \
  --confirm working_alerts \
  --confirm reviewed_risk_limits \
  --confirm tested_kill_switch \
  --confirm successful_reconciliation \
  --confirm sufficient_paper_sample \
  --confirm reviewed_tx_config \
  --confirm reviewed_market_api
```

| Key | What it means |
|-----|---------------|
| `legal_eligibility` | Legal and account eligibility confirmed for this jurisdiction and venue. |
| `dedicated_wallet` | A dedicated, isolated trading wallet is in use (not a personal wallet). |
| `limited_capital` | Only limited, loss-tolerant capital is funded on the wallet. |
| `working_backups` | Database and configuration backups are taken and a restore was tested. |
| `working_alerts` | Alerting is wired end-to-end and a test alert was received. |
| `reviewed_risk_limits` | Risk-engine limits (order size, notional, unmatched size/duration) reviewed. |
| `tested_kill_switch` | Kill switch engaged and verified to stop new trading while still allowing cancellation. |
| `successful_reconciliation` | A full authoritative reconciliation pass completed consistently. |
| `sufficient_paper_sample` | A sufficient paper-trading sample was collected and reviewed. |
| `reviewed_tx_config` | On-chain transaction configuration (gas, allowances, RPC endpoints) reviewed. |
| `reviewed_market_api` | Market and API behavior (5-minute windows, fills, rate limits) reviewed. |

## Important

- Completing this checklist and passing every gate is a **necessary but not
  sufficient** condition for a human to *consider* a tiny, manually gated live
  pilot (Module 27). It is not an endorsement of the strategy and makes **no
  profitability claim**.
- This build ships with `LIVE_TRADING=false` and `PAPER_TRADING=true`. Module 24
  does not change those defaults and does not enable live trading.
