# Market data: public CLOB WebSocket + local order books (Module 6)

This module maintains **independent, level-two order books** for the BTC
five-minute **Up** and **Down** outcome tokens by consuming Polymarket's
documented **public** market-data WebSocket. It is strictly read-only: it
subscribes, validates, and maintains local books. It performs **no**
authentication and **no** order submission, and makes **no** claim of
profitability.

## Scope

In scope (this module):

- Asynchronous connection to the documented public market WebSocket.
- Runtime validation of every inbound frame with Pydantic v2.
- Full book snapshots, incremental price changes, trade prints, tick-size
  changes, heartbeats, and reconnects.
- Two independent `Decimal`-priced L2 books (Up and Down), with zero-size
  levels removed.
- Fault detection: stale books, crossed books, malformed messages,
  updates-before-snapshot, and impossible negative sizes.
- Freshness / lifecycle tracking and a read-only `OrderBookProvider` protocol.
- A `market-data-monitor` console command.

Explicitly **out of scope** (later modules): strategy, opportunity detection,
fee/VWAP math, order submission, persistence of the feed ("market-data
recorder" is Module 8).

## Architecture

Dependency inversion is preserved: the **domain** only defines read-only types
and a protocol; all I/O lives in the `market_data` infrastructure package.

```
domain/market_data.py         FeedStatus, BookQuote, OrderBookProvider (protocol)
                              -- pure types, no I/O imports

market_data/
  errors.py                   MarketDataError hierarchy
  ports.py                    WebSocketConnection / WebSocketConnector protocols,
                              clock + sleep type aliases (injected for tests)
  messages.py                 Pydantic wire models + parse_frame() dispatch
  book.py                     LocalOrderBook (one side): Decimal price->size map
  manager.py                  OrderBookManager: routes frames to Up/Down books,
                              tracks lifecycle/freshness, implements the protocol
  feed.py                     MarketDataFeed: async supervisor, bounded queue,
                              reader/processor tasks, reconnect + resync
  ws_client.py                websockets-backed connector adapter (lazy import)
  factory.py                  build_market_data_feed() wiring from AppConfig
  cli.py                      `market-data-monitor` console command
```

The **domain never imports** SQLAlchemy, HTTP, WebSocket, blockchain, or
environment modules. `OrderBookManager` implements the domain
`OrderBookProvider` protocol, so downstream modules depend only on the domain
type, never on the concrete feed.

## Data flow and concurrency

```
WebSocket --recv--> [reader task] --put_nowait--> [bounded asyncio.Queue]
                                                        |
                                              [processor task] --get--> parse_frame
                                                        |                     |
                                                        v                     v
                                             OrderBookManager.apply_message  heartbeat (ignored)
```

- The **reader** only reads the socket and enqueues raw frames. It never parses
  or mutates books, so a slow consumer can never block socket reading
  (requirement 12).
- The **queue is bounded** (`MAX_QUEUE_SIZE`). If it is full, the reader does
  **not** block or silently drop deltas: it records a `queue_overflows` metric
  and raises, which **fails closed** by tearing down the session and forcing a
  reconnect + fresh snapshot (requirements 9, 11, and "fail closed").
- A small set of **supervised tasks** (reader, processor, and two control
  watchers for resync/stop) is awaited with `FIRST_COMPLETED`; on any exit all
  tasks are cancelled and awaited, and the connection is closed. There are no
  untracked background tasks.

## Lifecycle and freshness

`FeedStatus` transitions per side:

```
UNAVAILABLE  -- connect -->  AWAITING_SNAPSHOT  -- snapshot -->  LIVE
     ^                              ^                              |
     |                              |                     age > STALE_AFTER
  disconnect                        |                              v
     |                              +----------------------------  STALE
     +----------------------------- (a reconnect resets both books and
                                     requires a fresh authoritative snapshot)
```

- On **disconnect**, the feed is marked `UNAVAILABLE` immediately
  (requirement 8) and both books are reset.
- After a **reconnect**, each side independently returns to
  `AWAITING_SNAPSHOT` and stays there until a fresh full snapshot arrives
  (requirement 9). Incremental changes received before a snapshot are rejected
  (`UpdateBeforeSnapshotError`).
- A book becomes `STALE` once its age exceeds `STALE_AFTER_SECONDS`.
- `OrderBookProvider.is_fresh(side)` is true only when the side is `LIVE`.

### Timestamps tracked (requirement 10)

Per side the manager/quote expose: **exchange timestamp** (from the frame, in
ms, when present), **local receipt timestamp** (epoch seconds when the frame
was dequeued), **processing timestamp** (epoch seconds after the book was
updated), **current book age** (seconds, from a monotonic clock), and the
feed-wide **reconnect count**.

> Age is derived from an injected **monotonic** clock so it cannot go negative
> if the wall clock is adjusted. Wall-clock epoch seconds are used only for the
> human-facing receipt/processing timestamps.

## Fault detection (requirement 7)

| Fault | Trigger | Handling |
| ----- | ------- | -------- |
| Malformed message | Unknown/absent `event_type`, non-object frame, wrong types, or a **float** where a decimal string is required | `MalformedMessageError`; counted, frame skipped |
| Update before snapshot | Incremental change before a full snapshot | `UpdateBeforeSnapshotError` |
| Negative size | Any level/delta size `< 0` | `NegativeSizeError` |
| Crossed book | best bid ≥ best ask after applying | `CrossedBookError`; the offending update is rolled back (book left intact) and a **resync** is forced |
| Stale book | age > `STALE_AFTER_SECONDS` | status → `STALE`, `is_fresh` false |

Monetary/quantity fields are parsed as `Decimal` from **strings**; JSON is
decoded with `parse_float=Decimal`, and the models explicitly reject binary
`float` inputs so precision is never silently lost.

## Configuration

`MarketDataSettings` (grouped under `AppConfig.market_data`, loaded from the
environment / `.env` with bare, case-insensitive field names):

| Env var | Default | Meaning |
| ------- | ------- | ------- |
| `STALE_AFTER_SECONDS` | `5.0` | Age beyond which a book is `STALE`. |
| `MAX_QUEUE_SIZE` | `1000` | Bounded reader→processor queue size. |
| `RECONNECT_BASE_SECONDS` | `0.5` | Full-jitter backoff base. |
| `RECONNECT_MAX_SECONDS` | `30.0` | Backoff ceiling. |
| `MAX_RECONNECT_ATTEMPTS` | unset | Blank = retry forever; integer caps attempts. |
| `CONNECT_TIMEOUT_SECONDS` | `10.0` | WebSocket open timeout. |
| `PING_INTERVAL_SECONDS` | `20.0` | Keepalive ping interval. |
| `PING_TIMEOUT_SECONDS` | `20.0` | Keepalive ping timeout. |
| `SUBSCRIBE_TYPE` | `market` | Subscription channel type. |

The socket URL comes from the existing `PolymarketPublicSettings`
(`polymarket_market_ws_url`, default
`wss://ws-subscriptions-clob.polymarket.com/ws/market`).

## Console command

```bash
# Auto-resolve the current BTC 5-minute market's Up/Down token ids via the
# Module 5 discovery service, then stream live books:
uv run polymarket-pair-bot market-data-monitor

# Or pass token ids explicitly (skips discovery / network metadata calls):
uv run polymarket-pair-bot market-data-monitor \
  --up-token-id 111... --down-token-id 222... \
  --refresh-seconds 1 --duration-seconds 30
```

It prints, for each refresh: Up bid/ask, Down bid/ask, spread, top-of-book
depth, per-side status and book age, and the reconnect count. It is read-only
and never submits orders.

## Assumptions about the public market feed

The exact public market-channel schema is **not verifiable offline** in this
sandbox, so wire parsing is centralized in `messages.py` behind an adapter and
documented here for easy correction:

- Frames carry an `event_type` discriminator: `book` (full snapshot),
  `price_change` (incremental), `tick_size_change`, and `last_trade_price`
  (trade print).
- Each frame identifies its token via `asset_id`.
- Snapshots contain `bids`/`asks` arrays of `{price, size}` string pairs;
  incremental frames contain `changes` of `{price, side, size}` where `side`
  is `BUY`/`SELL` (mapped to bid/ask).
- Heartbeats arrive as `PING`/`PONG` (string or `{type: ...}`), empty frames,
  or `{}`.
- Subscription is a single JSON frame `{"type": "market", "assets_ids":
  [<up>, <down>]}`.

Unknown `event_type` values and unexpected extra fields are ignored (extra
fields) or treated as malformed (unknown discriminator) rather than guessed.
If the real schema differs, only `messages.py` and `build_subscribe_message`
need updating.

## Testing

- **Deterministic replay** (`tests/replay/test_market_data_replay.py`): a fixed
  scripted frame sequence is replayed through the manager and exact final book
  state / quotes are asserted; a repeatability test proves determinism.
- **Unit** (`tests/unit/test_market_data_*.py`): message parsing (incl. float
  rejection and side mapping), book invariants (zero-size removal, negative
  size, crossed rollback, update-before-snapshot, snapshot sorting), and
  manager lifecycle/freshness/quote math.
- **Fault tests** (`tests/unit/test_market_data_feed_faults.py`): async runner
  behaviour with an in-memory fake connector — subscription content,
  bounded-queue overflow (fail closed), disconnect → unavailable, reconnect →
  incremented count + fresh snapshot required **per token**, malformed frames
  not crashing the processor, and crossed-book forcing a resync.

Tests never open a real socket and never place orders.
