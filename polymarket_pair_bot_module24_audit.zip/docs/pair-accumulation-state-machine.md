# Pair-accumulation state machine (Module 18)

The restartable, event-driven orchestrator for **one** BTC 5-minute two-sided
pair-accumulation session. It turns validated markets, fresh order books,
confirmed fills and operational events into risk-gated acquisition, hedging and
CTF-merge decisions. It makes **no** profitability claim: `locked_net_profit`
is an accounting figure that may be negative.

## Where it lives

| File | Responsibility |
|------|----------------|
| `strategy/session_states.py` | The 14 states + legal transition graph (pure, stdlib only). |
| `strategy/session_events.py` | Immutable event types (the only inputs). |
| `strategy/session_models.py` | `PairSessionSnapshot` (authoritative restorable state), `SessionLimits`, `SessionTransition`, `TransitionOutcome`. |
| `strategy/session_ports.py` | Typed `Protocol` ports (store, risk, merge, reconciliation, kill switch). |
| `strategy/session_machine.py` | `PairAccumulationStateMachine` — the orchestration brain. |
| `strategy/session_factory.py` | Builders that translate config into `SessionLimits` and assemble the machine. |
| `config/models.py` | `StateMachineSettings` (limits, cutoffs, history). |

The strategy package imports **no** SQLAlchemy models, HTTP/WS/blockchain
clients, environment variables or concrete live execution classes. Every
external system is reached through a `Protocol` (dependency inversion).

## States

```
DISCOVERED -> BOOK_SYNCING -> READY -> WAITING_FOR_EDGE
                                    -> FIRST_LEG_OPEN -> UNMATCHED_INVENTORY
UNMATCHED_INVENTORY -> SECOND_LEG_OPEN -> MATCHED_PAIR
UNMATCHED_INVENTORY / SECOND_LEG_OPEN -> UNWIND_REQUIRED   (hedge failed / no safe price)
MATCHED_PAIR -> MERGE_PENDING -> MERGING -> CLOSED
<any active state> -> HALTED                    (kill switch / illegal transition)
<any active state> -> RECONCILIATION_REQUIRED   (uncertain event / stale feed / unknown submit)
RECONCILIATION_REQUIRED -> (resume) BOOK_SYNCING | UNMATCHED_INVENTORY | MATCHED_PAIR
CLOSED = terminal
```

Every move is validated against `ALLOWED_TRANSITIONS`; an unexpected move fails
closed to `HALTED` rather than corrupting state. A self-loop (e.g. a partial
fill that does not yet complete a pair) is always legal.

## Events

`MarketValidatedEvent`, `BooksUpdatedEvent`, `FillConfirmedEvent`,
`LimitCheckEvent`, `MergeEvaluateEvent`, `MergeResultEvent`,
`WindowClosingEvent`, `KillSwitchEvent`, `UncertainEvent`, `ReconciledEvent`.
Every event carries an `event_id`; every fill an `fill_id`.

## Restart & restore (requirements 1 & 4)

- `save(snapshot, transition)` MUST persist the snapshot **and** its transition
  audit row atomically. Every transition is persisted before it is observable.
- On restart, `restore(market_id)` reloads the authoritative snapshot and the
  machine continues from it. A reconnect always re-enters `BOOK_SYNCING` for a
  flat session (a fresh authoritative sync is required before trading resumes).
- Directional inventory and per-side cost basis are rebuilt from the snapshot,
  so the bot is restartable after a partial fill.

## Idempotency (requirement 3)

- Re-delivered events are detected via `processed_event_ids` and return an
  idempotent no-op.
- Fills are additionally de-duplicated via `processed_fill_ids`, because a fill
  message is not guaranteed unique. An acknowledgement is never treated as a
  fill; matched pairs are counted only from confirmed fills.

## Safety mapping (requirements 1–15)

| # | Requirement | How |
|---|-------------|-----|
| 1 | Persist every transition | `SessionStore.save` writes snapshot + `SessionTransition`. |
| 2 | Event-driven | Sole entry point `process(event)`; no background tasks. |
| 3 | Idempotent | Event-id and fill-id de-duplication. |
| 4 | Restore after restart | `restore()` + snapshot rebuild. |
| 5 | Wait for validated market + fresh books | `MarketValidatedEvent` then fresh `BooksUpdatedEvent`; stale feed -> `BOOK_SYNCING` / reconcile. |
| 6 | Evaluate passive first leg | Detector `PASSIVE_FIRST_LEG` while flat and before cutoff. |
| 7 | Risk approval before execution | Every submit is gated by `RiskApprovalPort` + detector `risk_input`. |
| 8 | On first-leg fill | Update inventory, compute `max_second_leg_price`, attempt passive completion, monitor size/age. |
| 9 | As limits approach | Cancel passive, risk-approved FOK hedge, else `UNWIND_REQUIRED` / `HALTED`. |
| 10 | When matched | Compute `locked_net_profit`, schedule merge when economical. |
| 11 | Stop new first legs after cutoff | `first_leg_cutoff_seconds` -> `WAITING_FOR_EDGE`. |
| 12 | Cancel passive before close | `WindowClosingEvent` / mandatory-cancel window cancels first. |
| 13 | Reconcile on uncertain events | `UncertainEvent`, unknown submit, stale feed -> reconcile + `RECONCILIATION_REQUIRED`. |
| 14 | Same machine for paper & live | Depends only on `ExecutionAdapter` + ports; both adapters implement them. |
| 15 | Scenario tests | `tests/unit/test_strategy_state_machine.py`. |

## Cost & profit accounting

- Per-fill cost = `price * size + fee` (fees included, conservative).
- `max_second_leg_price = max_effective_pair_cost - overhead - first_leg_avg_price`.
- `locked_net_profit = matched_pairs * $1 - matched_cost - overhead * matched_pairs`.
  All values are `Decimal`; no binary floats are used for money/quantities.

## Paper vs live

The machine holds no adapter-specific logic. Wiring the paper simulator or the
live order adapter to the same `ExecutionAdapter` protocol (and the CTF /
risk / reconciliation / persistence ports to their production adapters) drives
identical behavior. The production `SessionStore` (SQLAlchemy), `MergePort`
(CTF service) and risk/reconciliation adapters are bound at the composition
layer — deliberately out of scope for this module.
