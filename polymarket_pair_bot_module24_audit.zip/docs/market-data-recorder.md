# Market-data recorder (Module 7)

A **research-grade, read-only** recorder that captures the local Up/Down order
books produced by Module 6 and persists them for offline research. It records
market data only: it derives no order, asserts no profitability, and contains
no order-execution code.

## What it records

Each capture is a **pair snapshot** covering both the Up and Down books at one
point in time:

1. **One-second periodic snapshots** — a guaranteed cadence (configurable).
2. **Event-driven snapshots** when any of these change:
   - best bid;
   - best ask;
   - spread (either side);
   - the **executable pair cost** crosses a configured level (either
     direction);
   - a feed becomes **stale** or **recovers** (leaves / re-enters LIVE).
3. **Configurable top-N depth** per side (`RECORDER_TOP_DEPTH_LEVELS`). The
   full book's level counts and depth totals are also recorded so you can tell
   when the stored depth was truncated.
4. **Three timestamps** per side: exchange (`exchange_timestamp_ms`), local
   receipt (`local_receipt_epoch`) and processing (`processed_epoch`), plus a
   freshness `age_seconds`.
5. **Data-quality flags** per side: `has_snapshot`, `is_live`, `is_stale`,
   `is_unavailable`, `is_crossed`, `is_empty`, `missing_best_bid`,
   `missing_best_ask`, `missing_exchange_timestamp` (with an `is_clean`
   roll-up).
6. **Window and token identifiers**: `window_id`, `market_slug`, and each
   side's `token_id`.

> **`executable_pair_cost` is a research proxy.** It is the top-of-book cost to
> take both best asks (`up.best_ask + down.best_ask`). It deliberately excludes
> fees, slippage, and merge/gas overhead, so it is **not** the strategy's
> `effective_pair_cost` and implies nothing about profitability.

All prices, sizes, spreads and costs are `Decimal` (serialized as exact decimal
strings) — never binary floats. `age_seconds` is a duration and is the only
`float`.

## Persistence

- **Bulk research data → compressed Parquet** (`pyarrow`). Files live under
  `RECORDER_OUTPUT_DIR/<window_id>/<window_id>__NNNNNN.parquet`. The schema is
  flat and queryable; depth is stored as JSON-array columns
  (`up_bids_json`, `up_asks_json`, …).
- **Queryable summaries → PostgreSQL** (`market_data_snapshots` table). One
  compact row per snapshot for filtering/aggregation. Inserts are idempotent
  (`ON CONFLICT (window_id, sequence) DO NOTHING`), so re-processing a Parquet
  file never duplicates rows. Set `RECORDER_PERSIST_SUMMARIES=false` for
  Parquet-only recording.

### Rotation and durability

Files rotate when the **market window changes** or after
`RECORDER_FILE_ROTATION_SECONDS` of wall-clock time, whichever comes first. A
Parquet footer is only written when a file closes, so graceful shutdown
(`aclose`) is what finalizes the current file; rotation bounds the data at risk
from a hard kill to a single interval, and `market-data-validate` detects a
file left without a footer.

## Concurrency & safety

- The recorder **only reads** the already-parsed in-memory books via the
  domain `OrderBookProvider` protocol — no network calls, no shared lock with
  the feed reader. It therefore **can never block the WebSocket reader**.
- A **bounded buffer** decouples the sampler (producer) from the writer
  (consumer). Overflow policy is configurable (`RECORDER_OVERFLOW_POLICY`):
  - `drop_oldest` (default) — evict the oldest queued snapshot;
  - `drop_newest` — discard the incoming snapshot;
  - `block` — back-pressure the recorder poll loop only (never the reader).
  Every overflow increments `buffer_overflows`; every discarded record
  increments `dropped_records`.
- Blocking Parquet writes run via `asyncio.to_thread`, never on the event loop.
- Structured shutdown: the writer task is always awaited (buffered snapshots
  are flushed) and both sinks are always closed, even if the poll loop raises.
- Best-effort writes: a failed batch increments `write_errors` and is logged;
  it never crashes the recorder or the feed.

## Commands

| Command | Purpose |
| --- | --- |
| `record-market-data` | Discover (or accept explicit tokens for) the current BTC 5-minute window, run the Module 6 feed, and record snapshots until stopped. |
| `market-data-export` | Export all snapshots whose `capture_epoch` is within `[--start, --end]` (ISO-8601, UTC) to Parquet or CSV. |
| `market-data-validate` | Structurally validate every Parquet file under a directory (readable footer, expected columns, monotonic epochs, non-empty triggers). Exits non-zero on any error. |
| `market-data-replay` | Replay a recorded window's snapshots in deterministic `(capture_epoch, sequence)` order. |

Examples:

```bash
# Start recording (uses env config; discovers the current window)
uv run polymarket-pair-bot record-market-data

# Export a UTC time range to CSV
uv run polymarket-pair-bot market-data-export \
  --input data/market_data --start 2026-07-17T00:00:00Z \
  --end 2026-07-17T01:00:00Z --out export/window.csv --format csv

# Validate recorded files
uv run polymarket-pair-bot market-data-validate --input data/market_data

# Replay a window
uv run polymarket-pair-bot market-data-replay \
  --input data/market_data --window-id <window_id>
```

`make record-market-data`, `make market-data-export`,
`make market-data-validate` and `make market-data-replay` wrap these with an
`ARGS="..."` passthrough.

## Configuration

All knobs are `RecorderSettings` (env prefix-free, bare uppercased names; see
`.env.example`), translated into an immutable `RecorderRuntimeConfig` by
`recorder.factory`. `RECORDER_POLL_INTERVAL_SECONDS` must be `<=`
`RECORDER_SNAPSHOT_INTERVAL_SECONDS` so periodic snapshots are never missed.

## Module boundaries

- Pure types (`domain/recording.py`), the sampler, serialization and runtime
  config import no SQLAlchemy / HTTP / WebSocket / blockchain / pyarrow / env.
- `pyarrow` and SQLAlchemy are imported **lazily** inside the sinks, so the
  package remains importable (and most tests run) without them installed.
- The recorder does **not** extend the domain `UnitOfWork`. It owns a
  standalone `MarketDataSnapshotRepositoryImpl` driven through its own
  `SummarySink` port via a plain async session factory. This keeps the trading
  unit-of-work interface unchanged.

## Schema / migration

The additive `market_data_snapshots` table is created by Alembic migration
`0002_market_data_snapshots` (down-revision `0001_initial`). Retention is
optional: with `RETENTION_ENABLED=true`, rows older than
`MARKET_DATA_SNAPSHOT_RETENTION_DAYS` (0 = keep forever) are pruned by
`make db-retention`.
