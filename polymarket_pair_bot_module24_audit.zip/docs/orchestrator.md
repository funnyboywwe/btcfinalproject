# Application orchestrator (Module 19)

The orchestrator is the top-level coordinator that wires the whole trading
pipeline together and owns its lifecycle. It lives in
`src/polymarket_pair_bot/orchestrator/` and depends only on **abstract ports**,
so the paper and live builds run through exactly one code path (a core safety
rule: paper and live share the strategy and risk interfaces).

It does **not** create infrastructure, hold secrets, read the environment, or
enable live trading. The composition layer injects concrete adapters (paper or,
only when explicitly configured, live) that satisfy the ports.

## What it coordinates

| Concern              | Port                    | Notes                                        |
| -------------------- | ----------------------- | -------------------------------------------- |
| Market discovery     | `MarketDiscoveryPort`   | Bounded by `startup_timeout_seconds`.        |
| WebSocket market data| `EventProducer`         | Emits `BooksUpdatedEvent` etc. onto the queue.|
| Opportunity detector | (inside `SessionMachine`)| Driven by the machine as events are processed.|
| Risk engine          | (inside `SessionMachine`)| All order actions flow through risk.          |
| Execution adapter    | `ExecutionControl`      | Local block gate + kill-switch-safe cancel.   |
| Inventory            | (inside `SessionMachine`)| Authoritative snapshot restored on startup.   |
| Reconciliation       | `ReconcilerPort`        | Startup / degraded / shutdown triggers.       |
| CTF operations       | `EventProducer` + machine| Merge evaluation flows as session events.     |
| Persistence          | `PersistenceControl`    | Flushed during graceful shutdown.             |
| Metrics              | `MetricsSink`           | Null sink by default; Prometheus in prod.     |

## Task graph and supervision (requirements 1, 2, 4)

Every background coroutine is owned by a `TaskSupervisor`. There are **no
untracked `asyncio.create_task` calls**: starting a task always goes through the
supervisor, which keeps a handle, logs terminal outcomes, and classifies tasks:

- **Critical** — the event consumer (drives the state machine) and any producer
  a build marks critical (e.g. the market-data feed). A critical task failing
  triggers degraded mode.
- **Noncritical** — the freshness watchdog and best-effort producers. These fail
  in isolation without tearing down the process; the watchdog instead *enters*
  degraded mode deliberately.

All events flow through a single **bounded** `asyncio.Queue`
(`event_queue_maxsize`, requirement 3). When full, producers block
(backpressure) instead of growing memory without limit.

## Startup order

1. Health -> `STARTING`; log `run_mode` (never mutate it — requirement 9).
2. Discover a validated market (bounded). No market => fail closed (health
   `DEGRADED`, request stop).
3. `machine.restore(market_id)` rebuilds authoritative session state so the
   process is restartable.
4. Seed the pipeline with a single idempotent `MarketValidatedEvent`.
5. Start the critical consumer, then producers (each with its own criticality),
   then the noncritical freshness watchdog.
6. Health -> `READY`.

## Degraded mode (requirement 5)

Entered on a critical-task failure, a machine `HALTED` transition, or a stale
feed. The procedure (idempotent) is:

1. block new orders (local execution block);
2. mark health `DEGRADED`;
3. cancel resting orders where safe (cancellation stays possible even under the
   kill switch);
4. reconcile authoritatively;
5. **stop if any uncertainty remains** — a discrepancy *or* a reconcile error is
   treated as uncertainty (fail closed).

Machine lockdown states (`UNWIND_REQUIRED`, `RECONCILIATION_REQUIRED`,
`HALTED`) always block new order flow; only `HALTED` escalates to full degraded
mode.

## Graceful shutdown ordering (requirement 6)

Each step is bounded and fail-closed (a failing step is logged, never raised):

1. disable new strategy actions (block new orders + emit `WindowClosingEvent` so
   the machine stops opening first legs and cancels passives);
2. activate the local execution block;
3. cancel open orders;
4. wait for authoritative updates (`authoritative_wait_seconds`) while the
   consumer keeps draining fills/acks;
5. reconcile (`ReconciliationTrigger.SHUTDOWN`);
6. flush persistence;
7. close WebSockets (producers + ws resources);
8. close the database, then Redis.

Finally the supervisor cancels any remaining tasks within
`cancel_grace_seconds`.

## Readiness checks (requirement 7)

`readiness()` returns a `ReadinessReport` aggregating: health is `READY`, the
kill switch is inactive (unreadable => treated as active, fail closed),
execution is unblocked, the session has been restored, and every injected
dependency health check (Postgres, Redis, ...) is healthy.

## Paper vs live, and never auto-enabling live (requirements 8, 9)

The orchestrator only reads `run_mode` and drives whatever adapters were
injected; it never flips a build into live trading. Deterministic paper-mode
integration tests (`tests/integration/test_orchestrator_paper.py`) run the real
orchestrator against in-memory fakes with
`run_until_producers_complete=True`, so a run terminates deterministically once
scripted producers drain and the queue is empty — no wall-clock sleeps, no
network, no orders.

## Requirement-to-implementation map

| Req | Where |
| --- | ----- |
| 1 structured asyncio supervision | `supervisor.py` (`TaskSupervisor`) |
| 2 no untracked tasks | all tasks via `TaskSupervisor.start` |
| 3 bounded queues | `asyncio.Queue(maxsize=event_queue_maxsize)` |
| 4 critical vs noncritical | `start(..., critical=...)` classification |
| 5 critical failure handling | `degraded.py` (`DegradedModeController`) |
| 6 graceful shutdown order | `orchestrator._graceful_shutdown` |
| 7 readiness checks | `readiness.py` (`ReadinessProbe`) |
| 8 deterministic paper tests | `tests/integration/test_orchestrator_paper.py` |
| 9 no auto live | `start()` reads `run_mode`, never mutates it |

## Composition status

`ApplicationOrchestrator` implements the app `Service` protocol
(`name`/`start`/`stop`), so it can be registered in `build_lifecycle` once a
composition module provides the concrete port adapters. It is intentionally
**not** auto-registered yet: doing so would require constructing the full live
adapter graph and would break the Module 0 guarantee that the app starts with
zero services and no secrets.
