# Live-capable execution adapter and order lifecycle (Module 14)

This module implements the **guarded** path to a real exchange. It shares the
single `ExecutionAdapter` interface with the paper adapter (Module 11), so
higher layers swap paper for live without any code change. It performs no
networking or signing itself: the official Polymarket CLOB client is injected
behind the `LiveOrderClient` port.

> No profitability is claimed or implied. Nothing here decides *whether* to
> trade; it only executes an already-approved intent under strict guards.

## Important: the concrete CLOB client is a blocked adapter

The official `py_clob_client` package could not be installed or inspected in
this environment (the sandbox has no network access). Per the project's safety
rules — *"if package behavior cannot be verified, add a blocked adapter method
with a clear explanation instead of guessing"* — the concrete client does
**not** guess method names or response shapes:

- `execution/clob_order_client.py` implements the `LiveOrderClient` interface,
  but every method raises a typed `UnsupportedLiveOperationError(operation,
  detail)` naming the exact operation and the wiring step required once the
  installed package API has been inspected;
- `load_clob_package()` lazily imports `py_clob_client` and raises the same
  typed error on `ImportError`;
- `BlockedAllowanceProvider` returns `None` for collateral and allowance, which
  the adapter treats as **fail-closed** (an order that cannot be validated is
  rejected).

The adapter, submission gate, order-lifecycle manager, dry-run interceptor and
error classification are all fully implemented and unit-tested against fakes.
Only the final CLOB request/response mapping is intentionally deferred.

## Components

| File | Responsibility |
| --- | --- |
| `execution/errors.py` | Provider-independent error classes and `classify_exchange_error`. |
| `execution/live_models.py` | Validated, frozen response models (`OrderPlacement`, `OrderStateView`, `OpenOrderRecord`, `FillRecord`, `CancelResult`). |
| `execution/live_ports.py` | `LiveOrderClient` and the read-only signal ports (collateral/allowance, risk, feed health, reconciliation, kill switch). |
| `execution/submission_gate.py` | `LiveSubmissionGate`: every precondition for a live submission (fail-closed). |
| `execution/lifecycle.py` | `OrderLifecycleManager`: authoritative order/fill state transitions. |
| `execution/dry_run.py` | `DryRunOrderClient`: intercepts all writes; guarantees no real endpoint is reached. |
| `execution/clob_order_client.py` | Blocked concrete client + blocked allowance provider. |
| `execution/live.py` | `LiveExecutionAdapter`: orchestrates gate -> validate -> persist -> claim -> submit -> reconcile. |

## Submission sequence

`submit_order(intent)` performs, in order:

1. **Resolve token** — unknown token is rejected before any side effect.
2. **Risk decision** — fetched from the centralized risk engine port.
3. **Submission gate** — `LIVE_TRADING` on, `PAPER_TRADING` off, execution
   leadership held, feeds healthy, a recent consistent reconciliation exists,
   kill switch clear, and the risk engine approved *this* intent. Any missing
   or unreadable signal blocks (fail closed).
4. **Validation** — tick alignment, positive size, `live_max_order_notional_usd`
   ceiling, and (for BUY) collateral + allowance. Unverifiable collateral or
   allowance fails closed.
5. **Persist intent** — before any submission attempt.
6. **Idempotency claim** — `submit:<intent_id>` is claimed first-writer-wins. An
   already-claimed key is **never** blindly resubmitted; it reconciles and
   returns `UNKNOWN`.
7. **Submit through the client** — post-only for maker (GTC/GTD) TIFs, taker for
   IOC/FOK. Wrapped in `asyncio.wait_for(live_submit_timeout_seconds)`.
8. **Persist response** — via the lifecycle manager. An acknowledgement is
   recorded as `ACKNOWLEDGED`, **never** as a fill.
9. **Taker finalize** — for IOC/FOK, authoritative fills are queried and applied,
   then the order is finalized `FILLED` (fully) or `CANCELED` (killed remainder).

## Failure handling

| Situation | Outcome |
| --- | --- |
| Submission timeout | `SubmissionTimeoutError` -> mark order `UNKNOWN`, query open orders + fills, reconcile, **never** blindly resubmit. Ack outcome `UNKNOWN`. |
| Clean rejection (invalid / insufficient funds / auth / post-only-would-cross / not-found) | Persist a `REJECTED` order; no retry. |
| Uncertain rejection (`UNKNOWN` class) | Reconcile; ack outcome `UNKNOWN` (never assume rejected or accepted). |
| Transient rejection (retryable / rate-limited) | Bounded idempotent retries (`live_max_submit_retries`, default **0**), reusing the same idempotency key; otherwise `REJECTED`. |
| Blocked/unsupported operation | Caught and returned as `REJECTED` (fail closed); nothing placed. |

## Fill accounting (safety-critical)

- An acknowledgement is **never** a fill.
- Fill records are **not** assumed unique; they are de-duplicated by `fill_id`.
- `filled_size` is always recomputed from the authoritative fills table and
  **clamped to `original_size`** — the conservative direction is to understate,
  never overstate, matched quantity (pair matching must never think a leg is
  fuller than it is).
- A fill arriving before its order (fill-before-ack) is still recorded and
  produces a conservative `UNKNOWN` placeholder order.
- Terminal states are never downgraded.

## Cancellation is never gated by the kill switch

`cancel_order`, `cancel_market_orders` and `cancel_all_orders` bypass the
submission gate so resting orders remain cancellable while the kill switch is
on. `cancel_and_replace` is **reserve-aware**: the replacement is submitted only
after the existing order is confirmed terminal with zero fills (reserve freed);
if it (partially) filled or its terminal state cannot be confirmed, the
replacement is withheld and reconciliation resolves the state. This prevents
double-reserving collateral.

## Dry-run guarantee

Wrap the client with `DryRunOrderClient` to run the entire live code path in
development or tests while intercepting every write (synthetic `dryrun-<key>`
acknowledgements, never fills). This is the mechanism guaranteeing no real write
endpoint is reached (safety requirements 17 and 19).

## Live enablement checklist

A real order is submitted only when **all** hold: `LIVE_TRADING=true`,
`PAPER_TRADING=false`, execution leadership held, feeds healthy, a recent
consistent reconciliation exists, kill switch clear, and the risk engine
approved the intent. Additionally, the concrete `ClobOrderClient` must be wired
to the installed, inspected `py_clob_client` (it is a blocked adapter until
then).

## Relevant settings (existing `LiveExecutionSettings`; no new settings added)

- `live_max_order_notional_usd` (default `50`)
- `live_submit_timeout_seconds` (default `10.0`)
- `live_order_poll_interval_seconds` (default `1.0`)
- `live_max_submit_retries` (default `0`)
- `live_reconcile_on_timeout` (default `true`)
