# Module 17 — Conditional Token Framework operations

This module implements the on-chain **split / merge / redeem** write path for
Polymarket's Gnosis Conditional Token Framework (CTF), the operation that lets a
confirmed complete Up/Down pair be merged back into `$1` of collateral. It is
the write counterpart to the read-only Polygon wallet-state service (Module 16).

> This document describes mechanics only. It makes **no** profitability claim.
> A merge recovers `$1` of collateral per *confirmed complete pair*; it never
> implies the pair was acquired below `$1`.

## Package layout (`src/polymarket_pair_bot/ctf/`)

| File | Responsibility |
|------|----------------|
| `errors.py` | Typed CTF error hierarchy (all secret-free). |
| `models.py` | Immutable dataclasses: contracts, outcome mapping, request, unsigned tx, results, mergeable quantity. |
| `encoding.py` | Pure, keccak-free ABI **argument-region** encoding + binary index-set validation. |
| `validation.py` | Pure validation: condition id, outcome mapping, merge-cap `min(up, down)`, risk-decision binding. |
| `ports.py` | Typed protocols: `ChainStateReader`, `CtfTransactionPreparer`, `CtfChainWriter`, `GaslessRelayer`. |
| `preparer.py` | `BlockedCtfTransactionPreparer` — fail-closed calldata builder (see "blocked adapters"). |
| `chain_writer.py` | `BlockedCtfChainWriter` — fail-closed signer/broadcaster (never touches the key). |
| `relayer.py` | `NullGaslessRelayer` — optional gasless adapter, disabled, assumes no credentials. |
| `service.py` | `CtfOperationService` — the real, fully tested orchestration. |
| `factory.py` | Composition root; resolves trusted addresses from config. |
| `cli.py` | Read-only `ctf-mergeable` command. |

## Safety ordering of a state-changing operation

`CtfOperationService.execute()` performs, in order:

1. **Manual write gate** (`ctf_enable_writes`, requirement 18) and **kill
   switch** check — both fail closed.
2. Validate **condition id** (4) and **binary outcome mapping** (5); require a
   non-empty **idempotency key** (8).
3. Require an **approving `RiskDecision`** whose id is bound to the idempotency
   key (7).
4. **Verify chain id** (3).
5. **Duplicate guard** by idempotency key (12) — refuses to re-broadcast after a
   timeout or restart.
6. **Reconcile balances before** (13); for a merge, **cap** the quantity to
   `min(confirmed_up, confirmed_down)` (11).
7. Build unsigned calldata; **simulate before signing** (6); estimate gas
   (self-funded, 14).
8. **Persist a PENDING operation before broadcasting** (9). The insert is
   idempotent; a losing race returns "already recorded" and stops.
9. **Broadcast** — self-funded gas by default, or the optional gasless relayer.
10. **Persist the transaction hash immediately** (10) via an insert-only,
    hash-keyed row.
11. **Monitor the receipt.** A revert marks the operation FAILED; a timeout or
    ambiguous status marks it UNKNOWN and records a note to reconcile — it never
    blindly retries.
12. **Reconcile balances after** (13) and persist the terminal status.

The read-only `mergeable_quantity()` needs no writes and consults neither the
kill switch nor the write gate (requirement 17). It reads only *confirmed*
on-chain balances and returns `min(up, down)` — it never treats an open or
partially filled order as a pair.

## Blocked adapters — why signing/calldata are not implemented here

Two pieces cannot be verified in this offline environment, and the project's
safety rules forbid guessing:

- **Function selectors / full calldata.** A CTF calldata payload begins with the
  4-byte selector = first four bytes of the Ethereum **keccak-256** hash of the
  function signature. Keccak-256 is **not** in the Python standard library
  (`hashlib.sha3_256` is NIST SHA3 and produces *different* digests), and no
  verified keccak/ABI dependency (eth-hash, eth-abi, web3) is importable here.
  `BlockedCtfTransactionPreparer` therefore raises a clear blocked-operation
  error. The verifiable, tested part — the ABI **argument region** encoding and
  the binary index-set partition `[1, 2]` — lives in `encoding.py` for the day a
  verified library is installed.
- **Signing and broadcasting.** Signing needs `eth-account` and broadcasting
  needs a verified web3 client; neither is available offline.
  `BlockedCtfChainWriter` raises a clear blocked-operation error and **never**
  reads, stores, returns or logs a private key or a complete signed transaction.

This mirrors the established pattern in Modules 14 and 16. Because pending state
is persisted **before** the (blocked) broadcast, a real deployment fails closed:
the operation is durably recorded as PENDING and the duplicate guard prevents a
second attempt from re-broadcasting.

## Configuration (`CtfSettings`)

Contract addresses are **not** duplicated here — they are read from
`ChainReadSettings` (`polygon_conditional_tokens_address`, `polygon_usdc_address`)
so there is a single trusted source (requirements 1/2). `CtfSettings` holds only
gates and the standard Gnosis binary parameters:

| Setting | Default | Meaning |
|---------|---------|---------|
| `ctf_enable_writes` | `false` | Manual gate for state-changing writes (18). |
| `ctf_up_index_set` / `ctf_down_index_set` | `1` / `2` | Binary partition; validated as `{1, 2}`. |
| `ctf_parent_collection_id` | zero bytes32 | Root collateral collection. |
| `ctf_receipt_timeout_seconds` / `..._poll_interval_seconds` | unset | Receipt monitoring overrides. |
| `ctf_gasless_enabled` | `false` | Optional gasless relayer (15/16); no credentials assumed. |

## Commands

```bash
# Read-only: how many complete Up/Down pairs could be merged right now.
uv run polymarket-pair-bot ctf-mergeable \
    --condition-id 0x<64hex> --up-token <TOKEN_ID> --down-token <TOKEN_ID> [--json]
```

There is intentionally **no** CLI for split/merge/redeem: state-changing
operations stay manually gated behind configuration and the risk engine
(requirement 18).

## Tests

- `tests/unit/test_ctf_encoding.py` — pure ABI argument encoding + index sets.
- `tests/unit/test_ctf_validation.py` — condition id, mapping, merge cap, risk.
- `tests/unit/test_ctf_adapters.py` — blocked preparer/writer + null relayer.
- `tests/unit/test_ctf_service.py` — mocked RPC + transaction orchestration
  covering every branch (happy path, merge cap, duplicate prevention, revert,
  timeout→UNKNOWN, kill switch, write gate, gasless available/unavailable).

No test signs or broadcasts anything; the fake chain writer returns a
deterministic fake hash.
