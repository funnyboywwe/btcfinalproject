# Persistence (Module 3)

Asynchronous PostgreSQL persistence built on **SQLAlchemy 2 async**, **asyncpg**
and **Alembic**. This layer holds the *authoritative records* the bot rebuilds
its position from after a crash or partial fill.

> This document describes storage mechanics only. It makes no claim that the
> strategy is profitable.

## Layering and dependency inversion

- **Ports (domain):** `polymarket_pair_bot.domain.repositories` defines
  `Protocol` interfaces (repositories + `UnitOfWork`). It imports only the
  standard library and the pure domain package.
- **Adapters (persistence):** `polymarket_pair_bot.persistence` provides the
  SQLAlchemy implementations, ORM models, engine/session factory, the
  transactional unit of work, and operator admin tools.

Domain and strategy code depend on the ports, never on this package, so no
SQLAlchemy / asyncpg / Alembic import leaks into domain or strategy code.

## Tables

15 tables are created by the initial migration:

| Table | Purpose | Idempotency / notes |
| --- | --- | --- |
| `markets` | Binary Up/Down market definition | PK `market_id`; unique `condition_id` |
| `market_windows` | 5-minute window (1:1 with market) | PK `market_id` → `markets` (CASCADE) |
| `order_intents` | Desired order pre-risk/submit | PK `intent_id` (client idempotency key) |
| `exchange_orders` | Order as known on the exchange | PK `order_id` (exchange order id) |
| `fills` | Confirmed executions | PK `fill_id` → idempotent insert; FK `order_id` (RESTRICT) |
| `inventory_snapshots` | Append-only per-market inventory | high-volume; retained |
| `pair_opportunities` | Append-only detected opportunities | high-volume; retained |
| `matched_pairs` | Confirmed matched Up/Down pairs | built only from confirmed fills |
| `ctf_operations` | CTF split/merge/redeem | PK `operation_id` |
| `blockchain_transactions` | On-chain tx references | unique `operation_key`; public data only |
| `reconciliation_runs` | Reconciliation pass headers | |
| `reconciliation_discrepancies` | Discrepancies per run | FK `run_id` (CASCADE) |
| `risk_events` | Centralized risk decisions | PK `decision_id` |
| `kill_switch_events` | Append-only kill-switch journal | |
| `system_events` | Append-only audit event journal | JSONB `payload`, secret-free |

## Numeric types (no binary floats)

All money / price / quantity columns are `NUMERIC` (fixed-point) and round-trip
as `Decimal`. No `Float`/`Double` column exists anywhere (enforced by
`tests/unit/test_persistence_models.py`).

| Kind | SQL type |
| --- | --- |
| Price / probability / tick | `NUMERIC(12, 6)` |
| Token quantity (shares) | `NUMERIC(30, 6)` |
| USD collateral / fees | `NUMERIC(30, 6)` |
| Profit / P&L (signed) | `NUMERIC(30, 6)` |

Domain timestamps are stored as `BIGINT` seconds (UTC). Each table also has a
server-side `recorded_at TIMESTAMPTZ DEFAULT now()` used for retention.

## Idempotency and transactional integrity

- **Idempotent fill insertion:** `FillRepository.insert_idempotent` uses
  `INSERT ... ON CONFLICT (fill_id) DO NOTHING` and reports whether a row was
  actually inserted. Fill messages are *not* assumed unique.
- **Atomic order + fill + inventory:**
  `UnitOfWork.record_fill_and_update_inventory(fill, resulting_inventory, order=None)`
  inserts the fill and, **only when the fill is newly inserted**, appends the
  inventory snapshot and optionally updates the order — all inside one
  transaction. A duplicate fill returns `False` and leaves inventory untouched.
- **Unit of work:** leaving the `async with` block without calling `commit()`
  (including on exception) rolls back, so partial writes never persist.

## Append-only audit journal

`system_events` is an append-only journal written via `AuditJournal.append_event`
(`event_type`, `severity`, `created_at`, secret-free JSONB `payload`). It must
never receive secrets.

## Admin commands

`python -m polymarket_pair_bot.persistence.cli <command>`:

| Command | Action |
| --- | --- |
| `migrate` | Apply all migrations up to `head` |
| `health` | Check connectivity + report current revision (never prints the DSN) |
| `reset` | Drop & recreate all tables (refuses when `LIVE_TRADING` is on) |
| `retention` | Delete rows older than configured windows (no-op unless enabled) |
| `counts` | Print row counts per table |

Makefile shortcuts: `make db-migrate`, `make db-health`, `make db-reset`,
`make db-retention`.

## Retention configuration

`RetentionSettings` (env-prefixed, part of `AppConfig.retention`):

| Env var | Default | Meaning |
| --- | --- | --- |
| `RETENTION_ENABLED` | `false` | Master switch; nothing is deleted unless true |
| `PAIR_OPPORTUNITY_RETENTION_DAYS` | `30` | `pair_opportunities` window |
| `INVENTORY_SNAPSHOT_RETENTION_DAYS` | `90` | `inventory_snapshots` window |
| `RECONCILIATION_RETENTION_DAYS` | `90` | `reconciliation_runs` window |
| `SYSTEM_EVENT_RETENTION_DAYS` | `180` | `system_events` window |

A per-table value of `0` means retain forever. Retention deletes by
`recorded_at` and is never run implicitly.

## Secrets

No table stores a private key, API secret, passphrase, HMAC signature or a full
signed transaction. `blockchain_transactions` stores only public references
(operation key, chain id, status, optional tx hash). The DSN comes from the
`SecretStr` in `PostgresSettings` and is injected into Alembic programmatically —
it is never written to `alembic.ini` or echoed by the health check.

## Migrations

The database URL is not stored in `alembic.ini`. Prefer
`python -m polymarket_pair_bot.persistence.cli migrate`; or run
`alembic upgrade head` with `DATABASE_URL` exported (async engine, `NullPool`).

## Integration tests

`tests/integration/test_persistence_postgres.py` runs against a real PostgreSQL
16 container (`make infra-up`). They self-skip unless `RUN_INFRA_TESTS=1` and
assert the acceptance criteria: schema applies to an empty DB, duplicate fills
don't alter inventory twice, and fill + inventory changes commit/rollback
atomically.
