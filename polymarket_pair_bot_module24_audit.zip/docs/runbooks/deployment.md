# Runbook: VPS Deployment

Manual, step-by-step deployment to a single VPS. Nothing here runs
automatically. Trading stays in **paper** mode until you deliberately go live.

## 0. Host prerequisites

- Ubuntu/Debian or Amazon Linux VPS, 2 vCPU / 4 GB RAM minimum.
- Docker Engine + Docker Compose v2 (`docker compose version`).
- A non-root deploy user in the `docker` group.
- Time synchronization enabled (see step 3).

## 1. Harden the host

### SSH: key-only

```bash
# /etc/ssh/sshd_config.d/10-ppb.conf
PasswordAuthentication no
PermitRootLogin no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
```

```bash
sudo systemctl reload ssh   # or sshd
```

### Firewall: default deny, SSH only inbound

The operator/metrics/dashboard ports are published on loopback only, so they are
never exposed even if the firewall allows a port. Keep inbound minimal anyway.

```bash
# ufw (Debian/Ubuntu)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow OpenSSH
sudo ufw enable
```

```bash
# firewalld (RHEL/Amazon Linux)
sudo firewall-cmd --set-default-zone=drop
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --reload
```

Reach the private ports through an SSH tunnel from your workstation:

```bash
ssh -L 8081:127.0.0.1:8081 -L 8082:127.0.0.1:8082 -L 9090:127.0.0.1:9090 deploy@vps
```

## 2. Fetch the code

Copy the project to `/opt/polymarket-pair-bot` (scp/rsync/tarball — no remote
code hosting required).

## 3. Clock synchronization

```bash
sudo timedatectl set-ntp true
timedatectl show -p NTPSynchronized --value   # expect: yes
```

## 4. Configure

```bash
cd /opt/polymarket-pair-bot/docker
cp .env.prod.example .env
cp env/app.env.example env/app.env
cp secrets/secrets.env.example secrets/secrets.env
chmod 600 .env secrets/secrets.env
```

- Set `POSTGRES_PASSWORD` (strong) in `.env` and pin `IMAGE_TAG`.
- Review `env/app.env`; keep `PAPER_TRADING=true`, `LIVE_TRADING=false`.
- Put secrets ONLY in `secrets/secrets.env` (or a secret manager). Leave live
  wallet/RPC/API values blank until you go live.

## 5. Reproducible image (recommended)

```bash
cd /opt/polymarket-pair-bot
uv lock                     # commit uv.lock for byte-stable builds
# then build with the frozen flag:
docker build --build-arg UV_SYNC_FLAGS="--no-dev --no-editable --frozen" \
  -t polymarket-pair-bot:$(date -u +%Y%m%d) .
```

Set the resulting tag as `IMAGE_TAG` in `docker/.env`.

## 6. Migrate + start (gated helper)

```bash
cd /opt/polymarket-pair-bot
deploy/scripts/preflight.sh          # safety checks; must pass
deploy/scripts/deploy.sh --build     # preflight + migrate + up -d + health
```

Or manually:

```bash
cd docker
docker compose -f docker-compose.prod.yml run --rm migrate   # migration startup procedure
docker compose -f docker-compose.prod.yml up -d
```

## 7. Supervise with systemd

```bash
sudo cp deploy/systemd/polymarket-pair-bot.service /etc/systemd/system/
sudo sed -i 's#/opt/polymarket-pair-bot/docker#'"$(pwd)"'/docker#' \
  /etc/systemd/system/polymarket-pair-bot.service   # or edit WorkingDirectory
sudo systemctl daemon-reload
sudo systemctl enable --now polymarket-pair-bot.service
```

Enable scheduled encrypted backups:

```bash
sudo install -d -m 0750 /etc/polymarket-pair-bot
# create /etc/polymarket-pair-bot/backup.env with BACKUP_DIR + AGE_RECIPIENT (chmod 600)
sudo cp deploy/systemd/polymarket-pair-bot-backup.* /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now polymarket-pair-bot-backup.timer
```

## 8. Verify

```bash
deploy/scripts/healthcheck.sh
# via tunnel from your workstation:
#   curl -s 127.0.0.1:8081/health/ready
#   open 127.0.0.1:8082  (dashboard)
```

## 9. High availability (primary / standby)

- Provision a second host identically, pointing `DATABASE_URL`/`REDIS_URL` at
  the **same** managed PostgreSQL and Redis.
- Both run the bot; Redis leader election ensures only one controls the wallet.
- Start the standby with the same config; it stays ready and takes over on lease
  expiry. **Never** point the standby at a different Redis for the same wallet.
- Confirm exactly one leader: `deploy/scripts/preflight.sh` reports leader keys.

## 10. Going live (separate, deliberate step)

Do this only after a green backtest/pilot review and with a dedicated,
limited-capital wallet.

1. Fund the dedicated wallet; fill wallet/RPC/API values in `secrets.env`.
2. Set `WALLET_IS_DEDICATED_ACK=true`, `POLYGON_RPC_PRIMARY`+`SECONDARY`.
3. Set `PAPER_TRADING=false` and `LIVE_TRADING=true` in `env/app.env`.
4. `deploy/scripts/preflight.sh` must pass (it enforces the above).
5. `sudo systemctl restart polymarket-pair-bot.service`; watch metrics/logs and
   keep the kill switch within reach (see incident-response runbook).
