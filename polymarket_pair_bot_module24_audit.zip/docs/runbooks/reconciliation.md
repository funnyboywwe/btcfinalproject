# Runbook: Authoritative Reconciliation (Module 15)

This runbook covers routine operation of the reconciliation service and the
crash-recovery scenarios it is designed to repair. Reconciliation **fails
closed**: when in doubt it stops new trading and asks for a human. Cancellation
of existing remote orders remains possible even while trading is halted.

## Golden rules

1. Never manually delete orders, fills, or inventory rows to "make it green".
   Reconciliation deliberately keeps unexplained data and asks for review.
2. A pair is only real when equal Up and Down quantities are **confirmed
   filled**. Submitted / acknowledged / open / partially-filled never counts.
3. Confirmed fills are imported idempotently — re-running reconciliation is safe.
4. If balances or the remote account cannot be read, expect `CRITICAL_STOP`.
   Do not force-resume; investigate first.

## Run a pass manually

```
uv run polymarket-pair-bot reconcile              # full pass, persists a report
uv run polymarket-pair-bot reconcile --report-only # read-only, no halt effects
uv run polymarket-pair-bot reconcile --json        # machine-readable
uv run polymarket-pair-bot reconcile --market <id>  # scope to specific markets
```

Exit `0` = safe to trade, exit `1` = new trading is halted. The full report
(status, discrepancies, recommended actions) is persisted to the
`reconciliation_runs` / `reconciliation_discrepancies` tables every pass.

## Interpreting classifications

| Class | Operator action |
| --- | --- |
| `CONSISTENT` | None. Trading may proceed. |
| `AUTOMATICALLY_RECOVERABLE` | None required; confirmed fills were imported. Verify the imported fills look correct. |
| `LOCAL_REPAIR_REQUIRED` | Let reconciliation refresh local records from authoritative data, then re-run until consistent. |
| `CANCELLATION_REQUIRED` | Confirm the unknown order was cancelled; investigate why it existed (leader conflict?). |
| `MANUAL_REVIEW` | Inspect the flagged data by hand. Do not delete. Resolve, then re-run. |
| `CRITICAL_STOP` | Do not resume. Investigate balances / connectivity. Escalate. |

---

## Crash-recovery scenarios

Each scenario maps to an automated test in
`tests/unit/test_reconciliation_recovery.py`.

### 1. Crash **before acknowledgement**
- **Symptom:** A local order is `SUBMITTED` but the exchange never acknowledged
  it; it is absent from remote open orders and has no remote fill.
- **Classification:** `LOCAL_REPAIR_REQUIRED` (`LOCAL_OPEN_NOT_ON_REMOTE`).
- **Recovery:** Reconciliation refreshes the order's authoritative status. If
  the exchange truly never accepted it, mark it terminal locally. Never assume
  it filled. Re-run until consistent.

### 2. Crash **after a partial fill**
- **Symptom:** Local order shows `OPEN`/0 filled, but the exchange reports it
  `PARTIALLY_FILLED` and a fill exists remotely that is missing locally.
- **Classification:** `LOCAL_REPAIR_REQUIRED` (combines `MISSING_LOCAL_FILL`
  auto-import + `ORDER_STATE_MISMATCH`).
- **Recovery:** The missing confirmed fill is imported idempotently and the
  local order state is repaired to match authority. New trading stays halted
  until the position is proven (no unmatched pair is invented).

### 3. Crash **during cancellation**
- **Symptom:** We were cancelling an order; the kill switch is already engaged.
  The order is gone locally but the exchange still shows it open.
- **Classification:** `CANCELLATION_REQUIRED`.
- **Recovery:** Reconciliation re-issues the cancel. **Cancellation works even
  with the kill switch on.** Confirm the order is gone remotely afterward.

### 4. Crash **after fill, before database write**
- **Symptom:** The exchange confirmed a fill but the process died before the
  local DB write.
- **Classification:** `AUTOMATICALLY_RECOVERABLE`.
- **Recovery:** The confirmed fill is imported idempotently on the next pass
  (startup or WS-reconnect). No operator action required; verify inventory.

### 5. Crash **during merge**
- **Symptom:** A CTF merge transaction was in flight; a pending Polygon tx is
  recorded locally.
- **Classification:** `MANUAL_REVIEW` (`PENDING_CHAIN_TX`).
- **Recovery:** Do not start a second merge. Confirm the transaction's final
  status on-chain (Modules 20-21 will automate this). Once confirmed, record it
  and re-run reconciliation. New trading stays halted until resolved.

### 6. **Duplicate fill**
- **Symptom:** The same fill id is delivered more than once, and/or already
  exists locally.
- **Classification:** `CONSISTENT` (no re-import).
- **Recovery:** None. Fills are de-duplicated by id; duplicates are dropped and
  never double-counted. Fill messages are explicitly not assumed unique.

### 7. **Missing local order**
- **Symptom:** An order exists on the exchange that the bot has no local record
  of at all ("ghost" order).
- **Classification:** `CANCELLATION_REQUIRED` when a canceller is available,
  otherwise `CRITICAL_STOP`/manual review (e.g. from the `reconcile` CLI).
- **Recovery:** Cancel the unknown order and stop new trading. Investigate
  whether another process/leader is controlling the wallet — only one execution
  leader may control a wallet.

---

## Balance / collateral mismatch
- **Symptom:** Wallet outcome-token or USDC balance disagrees with expected
  holdings (when balances are reported).
- **Classification:** `CRITICAL_STOP`. New trading halts (requirement 10).
- **Recovery:** Do not resume. Reconcile the wallet against authoritative fill
  and CTF history. Escalate. If balances are simply not reported this pass, the
  report records a note and skips verification rather than fabricating a stop —
  wire in the Module 20 balance provider to enable full verification.

## Remote state unreadable
- **Symptom:** The authenticated account API cannot be reached/validated.
- **Classification:** `CRITICAL_STOP` (fail closed).
- **Recovery:** Treat as an outage. Keep trading halted, fix connectivity/auth,
  then re-run `reconcile` before resuming.
