# Runbook: Incident Response

Principle: **fail closed**. When state is uncertain — cancel where safe,
reconcile, and stop. Cancellation and reconciliation remain possible while the
kill switch is on.

## 0. First action for any trading incident: STOP NEW ORDERS

Activate the persistent kill switch (blocks new orders immediately; never blocks
cancellation/reconciliation):

```bash
cd /opt/polymarket-pair-bot
docker compose -f docker/docker-compose.prod.yml run --rm bot \
  python -m polymarket_pair_bot.risk.cli kill-switch activate \
  --reason "<incident>" --actor "<you>"
```

The switch is multi-source (process/env/Redis/Postgres) and survives restarts.
It is active if ANY source is active or unreadable.

## 1. Triage

```bash
deploy/scripts/healthcheck.sh
docker compose -f docker/docker-compose.prod.yml logs --tail=200 bot
# via SSH tunnel: metrics 127.0.0.1:9090/metrics, dashboard 127.0.0.1:8082
```

Check: feed freshness, unmatched exposure size/age, open orders, leader owner,
RPC health (primary/secondary), DB/Redis health.

## 2. Common scenarios

### Unknown order status / submission timeout
- Do NOT blindly retry. Run reconciliation:
  ```bash
  docker compose -f docker/docker-compose.prod.yml run --rm bot reconcile
  ```
- Unknown state after reconcile → keep kill switch on, cancel where safe, stop.

### Stale market data / WebSocket disconnect
- The bot fails closed on staleness and requires a fresh authoritative resync on
  reconnect. If it is not recovering, restart the bot; it rebuilds from records.

### Unmatched exposure over limit
- The risk engine should block further orders. Verify limits
  (`MAX_UNMATCHED_NOTIONAL_USD`, `MAX_UNMATCHED_DURATION_SECONDS`). Cancel the
  offending open orders; let reconciliation confirm inventory.

### RPC provider degraded
- Confirm `POLYGON_RPC_SECONDARY` is set; the blockchain adapter uses dual RPC.
  Rotate the primary URL in `secrets.env` and restart if needed.

### Two leaders suspected
- There must be exactly one leader per wallet. Stop the extra host. Verify via
  the preflight leader check. Never run two Redis instances for one wallet.

### Database or Redis down
- The system fails closed (kill switch unreadable → active). Restore the
  dependency, run `db-health`, then clear the kill switch (requires a recent
  consistent reconciliation and healthy feeds).

## 3. Recovery / clearing the kill switch

```bash
docker compose -f docker/docker-compose.prod.yml run --rm bot reconcile
docker compose -f docker/docker-compose.prod.yml run --rm bot \
  python -m polymarket_pair_bot.risk.cli kill-switch clear \
  --reason "resolved: <summary>" --actor "<you>"
deploy/scripts/healthcheck.sh
```

Clearing requires an explicit reason, a recent consistent reconciliation, and
healthy feeds. Critical reconciliation differences re-trip it automatically.

## 4. Emergency full stop

```bash
sudo systemctl stop polymarket-pair-bot.service
# kill switch stays latched in Postgres, so a later restart will NOT trade until
# it is deliberately cleared.
```

## 5. After the incident

- Take + verify a backup.
- Record timeline, root cause, and any config/limit changes.
- Confirm position rebuilt correctly from authoritative records before resuming.
