# Runbook: Backup & Restore Verification

PostgreSQL is the authoritative store (inventory, fills, kill-switch state,
audit). Back it up encrypted and regularly PROVE the backups are restorable.

## Encryption key setup (pick one)

### age (recommended)

```bash
age-keygen -o /etc/polymarket-pair-bot/age-identity.txt   # chmod 600, keep OFFLINE copy
grep 'public key' /etc/polymarket-pair-bot/age-identity.txt  # -> AGE_RECIPIENT
```

### gpg

```bash
gpg --gen-key                         # or import an ops public key
# use the recipient email/id as BACKUP_GPG_RECIPIENT
```

Store the DECRYPTION key/identity OFF the VPS (an operator who can restore must
hold it). The VPS only needs the public recipient to WRITE backups.

## Backup config

`/etc/polymarket-pair-bot/backup.env` (chmod 600):

```bash
BACKUP_DIR=/var/backups/polymarket-pair-bot
RETENTION_DAYS=14
AGE_RECIPIENT=age1xxxxxxxx...        # or BACKUP_GPG_RECIPIENT=ops@example.com
```

## Take a backup

```bash
cd /opt/polymarket-pair-bot
set -a; . /etc/polymarket-pair-bot/backup.env; set +a
deploy/scripts/backup_postgres.sh
```

- Writes `pair_bot_<UTC>.dump.age` (or `.gpg`) + a `.sha256`.
- REFUSES to write a plaintext backup (fails closed without a recipient).
- Enforces the retention window.
- The systemd timer runs this daily.

## Verify a backup is restorable (does NOT touch production)

```bash
# age: point AGE_IDENTITY at your private identity file
AGE_IDENTITY=/secure/age-identity.txt deploy/scripts/restore_verify.sh
# gpg: uses your local keyring
deploy/scripts/restore_verify.sh /var/backups/polymarket-pair-bot/pair_bot_XXddump.gpg
```

The script spins up a throwaway, network-isolated PostgreSQL 16, restores into
it, runs the app image's `db-health` (connectivity + migration revision) and row
counts against it, then tears everything down. Run it regularly (e.g. weekly)
and after any schema change.

## Real restore (disaster recovery)

1. Provision a fresh host + empty PostgreSQL (via the compose file).
2. Decrypt the chosen backup with your private key/identity.
3. `pg_restore --clean --if-exists --no-owner --no-privileges` into the DB.
4. Run migrations to head (idempotent): `deploy/scripts/migrate.sh`.
5. Start the bot; it rebuilds position from the restored authoritative records.
6. Confirm the kill switch state before allowing any trading.
