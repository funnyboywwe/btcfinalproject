# Runbook: Local Development

## Prerequisites

- Python 3.12+
- `uv` (https://docs.astral.sh/uv/)
- Docker + Docker Compose

## First-time setup

```bash
uv sync                 # create venv and install runtime + dev dependencies
cp .env.example .env    # placeholders only; never add real secrets
```

## Quality gates (run before considering work done)

```bash
uv run ruff format --check .
uv run ruff check .
uv run mypy src
uv run pytest
# or all at once:
make check
```

## Running the app

```bash
uv run polymarket-pair-bot
```

Expected behavior:
- Emits a JSON `application_configuring` log line, then `application_ready`.
- Health transitions `starting -> ready`.
- Waits. On SIGINT (Ctrl-C) or SIGTERM it logs `shutdown_requested`,
  transitions `ready -> stopping`, stops services in reverse order, and exits
  cleanly (`application_stopped`).

## Local infrastructure

```bash
make infra-up      # PostgreSQL 16 + Redis 7 via docker/docker-compose.yml
make infra-logs    # tail logs
make infra-down    # stop and remove
```

### Verify infra health

```bash
uv run python scripts/healthcheck.py
RUN_INFRA_TESTS=1 uv run pytest tests/integration
```

## Troubleshooting

- **`uv` not found:** install per the uv docs, then re-run `uv sync`.
- **Ports 5432 / 6379 already in use:** stop the conflicting local service or
  edit the published ports in `docker/docker-compose.yml`.
- **Integration tests skipped:** that is expected unless `RUN_INFRA_TESTS=1` is
  set and infrastructure is running.
- **Signals not handled (rare/restricted environments):** the lifecycle logs
  `signal_handler_unavailable` and can still be shut down via
  `LifecycleManager.request_shutdown(...)`.
