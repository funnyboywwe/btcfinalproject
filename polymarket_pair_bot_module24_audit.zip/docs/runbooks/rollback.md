# Runbook: Rollback

Application rollback (swap image tag) is safe and fast. Database rollback is
dangerous and manual — only forward migrations are routine.

## Before you start

- Identify a known-good image tag: `docker image ls polymarket-pair-bot`.
- Take and verify a backup (see backup-restore runbook) BEFORE any schema change.

## 1. Application-only rollback (preferred)

```bash
cd /opt/polymarket-pair-bot
deploy/scripts/rollback.sh --to-tag <known-good-tag>
deploy/scripts/healthcheck.sh
```

This re-creates the services on the previous image. The one-shot `migrate`
service is idempotent; a previous image that expects an OLDER schema is the only
reason you would consider a database downgrade.

## 2. If the new release added an incompatible migration

Prefer rolling FORWARD with a fix. Only if you must downgrade:

```bash
# take + verify a fresh backup first
deploy/scripts/backup_postgres.sh
deploy/scripts/restore_verify.sh

# stop the bot, downgrade to a specific revision, then roll the app back
deploy/scripts/rollback.sh --to-tag <known-good-tag> --db-downgrade <revision>
```

The script requires a typed confirmation and stops the bot before touching the
schema. Downgrades that drop columns/tables are irreversible — rely on the
verified backup.

## 3. Post-rollback checklist

- `deploy/scripts/healthcheck.sh` is green.
- Bot rebuilt its position from authoritative records (check inventory audit:
  `docker compose -f docker/docker-compose.prod.yml run --rm bot \
    python -m polymarket_pair_bot.inventory.cli audit --market <id>`).
- Exactly one execution leader (preflight leader check).
- Kill switch state is as intended.
