# Module 5 — BTC five-minute market discovery

Discovers, validates, persists and caches the Polymarket BTC five-minute
Up/Down market for the current (and, best-effort, next) five-minute UTC window,
using only the documented public Gamma market-metadata API over asynchronous
HTTP.

This module **never submits orders**. It performs only safe, idempotent `GET`
requests.

## Responsibilities

1. Compute the previous / current / next five-minute UTC windows (pure math).
2. Fetch candidate markets for a window's slug from the Gamma `/markets` API.
3. Validate every response with Pydantic before any other code trusts it.
4. Extract: slug, market id, condition id, Up token id, Down token id, open
   timestamp, close timestamp, active/closed state, order-book-enabled status,
   tick size, minimum order size, negative-risk setting, and resolution-source
   metadata when available.
5. Resolve the Up/Down → token-id mapping **by outcome name**, never by
   position. The first token is never assumed to be Up.
6. Reject contradictory or incomplete metadata (fail closed).
7. Preload the next window (best-effort; a not-yet-listed next market is not a
   fatal error).
8. Persist validated markets to PostgreSQL (authoritative) and cache validated
   metadata in Redis (short TTL, never authoritative).

## Components

| File | Responsibility |
| --- | --- |
| `windows.py` | Pure five-minute UTC window arithmetic (stdlib only). |
| `errors.py` | Discovery error hierarchy. |
| `ports.py` | `MarketMetadataSource` / `SlugStrategy` typed protocols. |
| `schemas.py` | Pydantic `GammaMarket` + validated `DiscoveredMarket` and cross-checks. |
| `gamma_client.py` | httpx adapter: bounded retries, backoff+jitter, 429 handling. |
| `slugs.py` | Slug strategies (template / fixed / blocked). |
| `service.py` | Orchestration: discover → validate → window-match → persist → cache. |
| `factory.py` | Composition helpers wiring config → service. |
| `cli.py` | The `discover-market` command. |

## Dependency inversion

The domain-facing service depends only on typed protocols (`MarketMetadataSource`,
`MarketMetadataCache`, `UnitOfWork`). Only the adapter (`gamma_client.py`) and
the wiring layer (`factory.py`, `cli.py`) import httpx, SQLAlchemy or redis.
Importing the `market_discovery` package does not import any of those drivers.

## Slug format is operator-configured (not guessed)

The exact BTC five-minute slug format is **not** hard-coded, because guessing an
undocumented slug shape would violate the "do not invent API fields" rule. You
must either:

- set `MARKET_DISCOVERY_BTC_5M_SLUG_TEMPLATE` to a `str.format` template using
  placeholders such as `{date}`, `{year}`, `{month}`, `{day}`, `{hour}`,
  `{minute}`, `{hhmm}`, `{open_epoch}`, `{close_epoch}`, `{open_iso}`,
  `{close_iso}`; or
- pass an explicit `--slug` to the command (which disables window matching and
  expects the API to return exactly one market).

With neither configured, discovery fails closed with a clear operator message.

## Window matching

When a slug template is used, several candidate markets may come back. The
service keeps only markets whose open/close timestamps match the requested
window within `MARKET_DISCOVERY_DISCOVERY_WINDOW_MATCH_TOLERANCE_SECONDS`
(default 90s). Zero matches → `MarketNotFoundError`; more than one distinct
market id → `InvalidMarketMetadataError` (ambiguous, fail closed).

## Persistence & cache

- **PostgreSQL** (authoritative): the core identity + window subset is upserted
  idempotently (`markets` + `market_windows`) in a single transaction, reusing
  the Module 3 unit of work. Re-discovery of the same market is a no-op upsert.
- **Redis** (cache): the validated `MarketMetadata` is cached with a short TTL
  via the Module 4 `RedisMarketMetadataCache`. Only validated `DiscoveredMarket`
  values ever reach the cache.

The richer descriptor fields (slug, minimum order size, neg-risk, active,
order-book-enabled, resolution source) are surfaced on `DiscoveredMarket` and
in the CLI output; the durable relational schema persists the identity+window
subset, so **no database migration is required** for this module.

## Retries, backoff and rate limits

`GammaMarketSource` retries transient failures (connection/timeout errors and
HTTP 500/502/503/504) with full-jitter exponential backoff capped at
`discovery_backoff_max_seconds`. HTTP 429 is handled explicitly: the
`Retry-After` header is honored when present, otherwise capped backoff is used;
exhausting retries raises `RateLimitedError`. Non-retryable 4xx client errors
fail fast. Retry counts are bounded by `discovery_max_retries`.

## Command

```bash
uv run polymarket-pair-bot discover-market            # discover, persist, cache
uv run polymarket-pair-bot discover-market --dry-run  # validate + print only
uv run polymarket-pair-bot discover-market --slug <slug> --json
uv run polymarket-pair-bot discover-market --no-preload-next
```

`--dry-run` touches no infrastructure (no Postgres, no Redis). Output is
secret-free.

## Tests

- `tests/unit/test_market_discovery_windows.py` — window arithmetic.
- `tests/unit/test_market_discovery_schemas.py` — required fixture cases: valid,
  closed, missing token, reversed outcome order, invalid timestamps, missing
  condition id (plus extra rejection cases).
- `tests/unit/test_market_discovery_service.py` — orchestration with in-memory
  fakes (persist/cache wiring, window match, ambiguity, preload).
- `tests/unit/test_market_discovery_config.py` — settings (gated on
  pydantic-settings).
- `tests/integration/test_gamma_client.py` — httpx `MockTransport` retry /
  backoff / rate-limit behavior (gated on httpx; no real network).

Fixtures live in `tests/fixtures/gamma.py` and contain only synthetic data.
