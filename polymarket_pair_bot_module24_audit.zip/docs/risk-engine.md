# Centralized risk engine and persistent kill switches (Modules 13-14)

This module is the single mandatory gate that every order intent, hedge and
blockchain operation must pass through before it may proceed. It also owns the
persistent, multi-level kill switch. It implements **no** order submission and
**no** live execution; it only produces a `RiskDecision` and controls whether
new activity is allowed at all.

> No profitability is claimed or implied. This module is a safety control only.

## Design goals

- **Default DENY.** A verdict becomes `APPROVE` only when *every* applicable
  rule passes. An empty rule set, an unknown operation kind, or any missing
  required input all fail closed to `REJECT`.
- **Fully explainable.** Every decision carries a `RuleOutcome` for each rule
  it evaluated, including the observed value and the configured limit, so the
  reason for any denial (or approval) is auditable.
- **Infrastructure-free core.** The engine and the kill-switch aggregation are
  pure and synchronous; they perform no I/O and import no SQLAlchemy, redis-py,
  HTTP or blockchain client. Persistence and reads happen in the async service
  and adapter layers behind typed ports.

## Dependency inversion

The pure surface (`polymarket_pair_bot.risk`) depends only on the standard
library, domain value objects, and abstract ports declared in
`polymarket_pair_bot.risk.ports`:

- `KillSwitchLatestReader` — read the latest durable kill-switch state.
- `ReconciliationStatusProvider` / `ReconciliationHealth` — latest
  reconciliation status and its timestamp.
- `FeedHealthProvider` — whether market-data feeds are healthy.

The SQLAlchemy/redis-backed implementations live in
`polymarket_pair_bot.risk.adapters` and are assembled in
`polymarket_pair_bot.risk.factory`. Importing the `risk` package therefore never
requires SQLAlchemy or redis to be installed — only the composition layer and
the CLI pull those in.

## Evaluation model

`RiskEngine.evaluate(context: RiskContext) -> RiskEvaluation` is pure and
deterministic. The `RiskContext` is an immutable snapshot of everything a
decision needs (quantities, collateral, unmatched exposure, counts, timing,
feed liveness, gas balance, leadership, and the injected kill-switch state).

Rules always evaluated (all operation kinds):

- **kill switch** — denies while active.
- **leader-election requirement** — when `require_execution_leader` is set, the
  process must be the confirmed execution leader; unknown leadership fails
  closed.

Order / hedge operations additionally check every configured limit:

| Limit | Rule |
| --- | --- |
| maximum order quantity | `max_order_quantity` |
| maximum collateral per order | `max_order_collateral` |
| maximum position per market | `max_position_per_market` |
| maximum unmatched shares | `max_unmatched_shares` |
| maximum unmatched collateral | `max_unmatched_collateral` |
| maximum unmatched duration | `max_unmatched_duration` |
| maximum deployed capital | `max_deployed_capital` |
| maximum reserved collateral | `max_reserved_collateral` |
| maximum open orders | `max_open_orders` |
| maximum loss per window | `max_loss_per_window` |
| maximum daily loss | `max_daily_loss` |
| minimum expected pair edge | `min_expected_pair_edge` |
| minimum hedge depth | `min_hedge_depth` |
| maximum book age | `max_book_age` |
| market-data feed liveness | `feed_live` |
| mandatory cancellation time | `mandatory_cancel_window` |
| latest first-leg entry | `latest_first_leg_entry` (only when opening a first leg) |
| maximum API failures | `max_api_failures` |
| maximum WebSocket reconnects | `max_ws_reconnects` |
| minimum wallet collateral | `min_wallet_collateral` |
| minimum Polygon gas balance | `min_polygon_gas` |

Blockchain operations (e.g. split / merge / redeem, in a later module) only
check the kill switch, leadership, minimum Polygon gas and maximum API
failures, and never approve a share size.

`latest_first_leg_entry` is only enforced when `opening_first_leg` is true: the
engine refuses to open a *new* directional first leg too close to market close
(when there would not be enough time to complete and merge the pair), while
still allowing the second leg that completes an already-open pair.

All monetary and quantity comparisons use `Decimal` (via the domain value
objects and `coerce_decimal`); no binary floating point is used anywhere.

## Approved size

`RiskEvaluation.approved_size` is the order quantity only when the verdict is
`APPROVE` for an order/hedge; it is `Shares(0)` for any rejection and for every
blockchain operation. This preserves the domain invariant that a rejected
`RiskDecision` has a zero approved size.

## Persistence (requirement 3)

`RiskEngineService.evaluate` reads the composite kill switch, injects its state
into the context, runs the engine, and then, in a single unit of work:

- records the `RiskDecision` via `risk_events.record(...)`, and
- appends a `risk.decision` audit event (severity `info` on approve, `warning`
  on reject) whose payload contains every rule outcome and its observed/limit
  values.

## Kill switch (Module 14)

Four independent sources are combined by `CompositeKillSwitch`. The switch is
active if **any** source is active, and — critically — if any source cannot be
read, that source is treated as active (fail closed):

1. **process** — an in-memory flag for the running process.
2. **environment** — an operator-set environment variable
   (`PPB_KILL_SWITCH` by default). It survives restarts and cannot be cleared
   by the running process, so it is also a hard block on clearing.
3. **redis** — the fast shared cache for cross-process propagation; a Redis
   outage fails closed.
4. **postgres** — the durable authoritative record; it survives restarts
   (requirement 7).

### Activation (requirements 5, 9)

`KillSwitchService.activate(reason, actor)` writes the durable PostgreSQL
record first, then the Redis cache, then trips the in-process flag, so new
orders are blocked immediately and the state survives a restart.
`trip_on_reconciliation(result)` activates automatically on any
non-`CONSISTENT` reconciliation result (requirement 9).

### What stays allowed (requirement 6)

Cancellation and reconciliation are **not** routed through the risk engine and
are intentionally never blocked by the kill switch. Later modules (order
lifecycle, reconciliation) must keep calling cancel/reconcile paths directly
while the switch is on.

### Clearing (requirement 8)

`KillSwitchService.clear(reason, actor)` only succeeds when `evaluate_clearance`
is satisfied:

- an explicit, non-empty operator reason;
- a most-recent reconciliation that is `CONSISTENT` and not older than
  `reconciliation_max_age_seconds`;
- healthy data feeds;
- the environment kill switch is not set.

Otherwise `clear` returns `cleared=False` with the exact blocking reasons and
changes nothing.

## CLI (requirement 11)

```bash
python -m polymarket_pair_bot.risk.cli status
python -m polymarket_pair_bot.risk.cli activate --reason "manual halt" --actor ops
python -m polymarket_pair_bot.risk.cli clear --reason "incident resolved" --actor ops
```

`clear` exits non-zero and prints the unresolved preconditions when clearing is
denied. The CLI never prints secrets, DSNs or connection URLs.

## Interface change

The only change to a previously implemented interface is **additive**:
`RiskSettings` in `polymarket_pair_bot.config.models` gained the limit fields
listed above plus `kill_switch_env_var` and `reconciliation_max_age_seconds`,
all with conservative defaults, and a validator ensuring the mandatory-cancel
window is not later than the latest-first-leg-entry window. No domain or
persistence repository protocols were modified; the durable kill-switch and
latest-reconciliation reads are performed directly in `risk/adapters.py` via
the existing SQLAlchemy models.
