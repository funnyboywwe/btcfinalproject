# Release gate and end-to-end verification (Module 24)

This module adds two things:

1. **End-to-end crash and recovery tests** (`tests/e2e/`) that stitch the
   already-implemented modules together and exercise the full pair-accumulation
   lifecycle plus failure/recovery paths — offline and deterministic.
2. A **release-gate command** (`polymarket-pair-bot release-gate`) that runs
   every automated quality gate, an in-process secret scan, and prints paper
   statistics, unresolved risks, and a human go-live checklist.

The release gate is a *reporting and gating* tool. **It never enables live
trading and never places an order.** `LIVE_TRADING` stays `false` and
`PAPER_TRADING` stays `true`.

## End-to-end scenarios

The E2E suite covers all 23 required scenarios, grouped into three files:

| # | Scenario | File |
|---|----------|------|
| 1 | Market discovery | `tests/e2e/test_e2e_lifecycle.py` |
| 2 | WebSocket snapshot | `tests/e2e/test_e2e_lifecycle.py` |
| 3 | Incremental updates | `tests/e2e/test_e2e_lifecycle.py` |
| 4 | Opportunity detection | `tests/e2e/test_e2e_lifecycle.py` |
| 5 | Passive first-leg paper order | `tests/e2e/test_e2e_lifecycle.py` |
| 6 | Partial fill | `tests/e2e/test_e2e_lifecycle.py` |
| 7 | Second-leg completion | `tests/e2e/test_e2e_lifecycle.py` |
| 8 | Inventory match | `tests/e2e/test_e2e_lifecycle.py` |
| 9 | Simulated merge | `tests/e2e/test_e2e_lifecycle.py` |
| 10 | P&L accounting | `tests/e2e/test_e2e_lifecycle.py` |
| 11 | Crash before acknowledgement | `tests/e2e/test_e2e_recovery.py` |
| 12 | Crash after partial fill | `tests/e2e/test_e2e_recovery.py` |
| 13 | Reconnect | `tests/e2e/test_e2e_recovery.py` |
| 14 | Unknown order status | `tests/e2e/test_e2e_recovery.py` |
| 15 | PostgreSQL outage | `tests/e2e/test_e2e_infra_faults.py` |
| 16 | Redis outage | `tests/e2e/test_e2e_infra_faults.py` |
| 17 | Primary RPC outage | `tests/e2e/test_e2e_infra_faults.py` |
| 18 | RPC disagreement | `tests/e2e/test_e2e_infra_faults.py` |
| 19 | Duplicate fill | `tests/e2e/test_e2e_lifecycle.py` |
| 20 | Stale data | `tests/e2e/test_e2e_lifecycle.py` |
| 21 | Kill switch | `tests/e2e/test_e2e_recovery.py` |
| 22 | Market close while unmatched | `tests/e2e/test_e2e_recovery.py` |
| 23 | Graceful shutdown | `tests/e2e/test_e2e_recovery.py` |

Every scenario asserts a safety-relevant invariant, e.g. a submitted/acked/
partially-filled order is never counted as a matched pair; unknown status leads
to reconciliation; infra faults fail closed; and the kill switch still allows
cancellation.

## Gates

The gate runs these mandatory checks. Each is reported as
`passed` / `failed` / `error` (a missing tool or crash is `error`, which fails
closed and blocks readiness):

| Gate | Command |
|------|---------|
| formatting | `ruff format --check .` |
| lint | `ruff check .` |
| type-check | `mypy src` |
| unit-test | `pytest -q -m "not integration" tests/unit` |
| integration-test | `pytest -q -m integration` |
| replay-test | `pytest -q tests/replay` |
| e2e-test | `pytest -q tests/e2e` |
| reconciliation | `polymarket-pair-bot reconcile --report-only --json` |
| dependency-audit | `uv pip check` |
| secret-scan | in-process (see below) |

All commands are read-only or test-only. The reconciliation gate uses
`--report-only`, so it never mutates state or places an order.

### Secret scan

`polymarket_pair_bot.release.secret_scan.SecretScanner` is a dependency-free,
pattern-based scanner. It flags PEM private keys, hex private keys assigned to a
key-like name, AWS access-key IDs, quoted secret assignments and bearer tokens.
It **never prints the matched value** — only `path:line: rule [REDACTED]`.
Code files that legitimately contain detection patterns are allow-listed.

### Paper statistics and unresolved risks

Paper statistics (sessions, confirmed pairs, unmatched incidents) are
**descriptive only and are not a profitability claim**. Unresolved risks
aggregate every failing/errored mandatory gate, an insufficient paper sample and
any unconfirmed checklist item.

## Live readiness

`live_ready` is `true` only when **every mandatory gate passes AND every human
checklist item is confirmed**. Because the checklist defaults to unconfirmed, an
automated run alone can never report readiness. See `docs/go-live-checklist.md`.

## Usage

```bash
# Human-readable report (exit 0 iff all mandatory gates pass)
uv run polymarket-pair-bot release-gate

# JSON report for CI
uv run polymarket-pair-bot release-gate --json

# Record operator confirmations after actually completing each checklist item
uv run polymarket-pair-bot release-gate \
  --confirm dedicated_wallet --confirm tested_kill_switch

# Provide observed paper-sample counts (descriptive only)
uv run polymarket-pair-bot release-gate --paper-sessions 250 --confirmed-pairs 40
```

Exit code is `0` when every mandatory gate passes and `1` otherwise. A `0` exit
still does **not** authorise going live — the human checklist must be completed
and reviewed by a person.
