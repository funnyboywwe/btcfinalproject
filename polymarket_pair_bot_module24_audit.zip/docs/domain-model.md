# Domain model & fixed-point arithmetic (Module 2)

Pure domain layer under `src/polymarket_pair_bot/domain/`. It imports **no**
SQLAlchemy models, HTTP/WebSocket clients, blockchain clients, environment
variables, or execution classes (only the Python standard library). No
networking or persistence lives here.

> This module computes modeled costs and mark-to-executable values only. It
> makes **no claim that the strategy is profitable**.

## Decimal precision policy (`precision.py`)

Money, prices, probabilities, quantities, fees, slippage and P&L are always
`Decimal` (never binary floats). `coerce_decimal` accepts only `str`, `int`, or
`Decimal` and **raises on `float` and `bool`**, so a `Decimal` can never be
built from a binary float. Non-finite values (`NaN`, `Infinity`) are rejected.

Intermediate math runs in a 50-significant-digit context
(`DECIMAL_COMPUTATION_PRECISION`); the result is quantized exactly once.

| Quantity kind | Quantum | Rounding default | Notes |
|---|---|---|---|
| Price / probability | `1e-6` (`PRICE_QUANTUM`) | half-even | range `[0, 1]` |
| Shares | `1e-6` (`SHARES_QUANTUM`) | down | outcome-token shares |
| USD (collateral/fee/P&L) | `1e-6` (`USD_QUANTUM`) | see below | `1e-6 USD == 1 micro-USDC` |
| Basis points | `1e-2` (`BPS_QUANTUM`) | n/a | `1 bp == 1e-4` fraction |

Conservative rounding:

* **Fees round UP** (`round_fee_up`, `ROUND_CEILING`) — never under-charge.
* **Expected/locked profit rounds DOWN** (`round_profit_down`, `ROUND_FLOOR`)
  — never over-state.
* **Tick rounding** is deterministic: `round_to_tick(value, tick, mode)` returns
  `round(value/tick)*tick` re-aligned to the tick exponent, with
  `round_down_to_tick`, `round_up_to_tick`, and `nearest_tick` helpers.

USDC is 6-decimal; `CollateralAmount.base_units` yields floored integer
micro-USDC for later on-chain base-unit math.

## Value objects (`value_objects.py`)

All are frozen (immutable) dataclasses. Unit/precision per field:

| Type | Field | Unit / precision | Constraint |
|---|---|---|---|
| `ProbabilityPrice` | `value: Decimal` | USD/share (probability), 1e-6 | `0 <= v <= 1` |
| `Shares` | `value: Decimal` | shares, 1e-6 | `v >= 0` (`require_positive()` for `> 0`) |
| `CollateralAmount` | `value: Decimal` | USD, 1e-6 (`.base_units` = micro-USDC) | `v >= 0` |
| `FeeAmount` | `value: Decimal` | USD, 1e-6 | `v >= 0` |
| `ProfitAmount` | `value: Decimal` | USD, 1e-6 | may be negative |
| `BasisPoints` | `value: Decimal` | bps, 1e-2 (`.as_fraction()`) | `v >= 0` |
| `TickSize` | `value: Decimal` | price increment | `0 < v <= 1` |
| `UnixTimestamp` | `value: int` | seconds since epoch (UTC) | `v >= 0` |
| `TokenId` | `value: str` | base-10 uint256 string | non-empty, digits |
| `MarketId` | `value: str` | opaque id | non-empty |
| `ConditionId` | `value: str` | bytes32 hex | `0x` + 64 hex |
| `OrderId` | `value: str` | opaque id | non-empty |
| `FillId` | `value: str` | opaque id | non-empty (not assumed unique) |
| `WalletAddress` | `value: str` | EVM address (lower-cased) | `0x` + 40 hex |

## Entities (`entities.py`)

Frozen dataclasses validated in `__post_init__`:

* `MarketWindow` — market/condition ids + open/close `UnixTimestamp`
  (`close > open`); `duration_seconds`.
* `OutcomeToken` — token id, `OutcomeSide`, market id, `TickSize`.
* `BinaryMarket` — window + up/down tokens (side-checked, must differ);
  `token_for(side)`.
* `PriceLevel` — price + positive size.
* `OrderBookSnapshot` — token id, bids (desc) / asks (asc) enforced, `as_of`,
  optional `sequence`; `best_bid` / `best_ask`. Freshness/resync handled by
  later market-data modules.
* `OrderIntent` — idempotency `intent_id`, side, limit price, positive size,
  `TimeInForce`, `created_at` (pre-risk).
* `ExchangeOrder` — status lifecycle; `is_confirmed_complete` is **only** true
  when `status == FILLED` and `filled == original`. `remaining_size` derived.
* `Fill` — confirmed execution; `notional` = price*size. Not assumed unique.
* `Position` — net long per token; `cost_basis` = qty*avg + fees.
* `InventorySnapshot` — per-market up/down positions + matched pairs;
  `unmatched_up` / `unmatched_down` derive directional exposure.
* `PairOpportunity` — measured `effective_pair_cost` vs `max_pair_cost`;
  `is_within_threshold` (no profitability claim).
* `MatchedPair` — built only from confirmed fills; `locked_value` (=qty*$1),
  `net_profit` (may be negative).
* `RiskDecision` — `RiskVerdict`, reason, idempotency `decision_id`; a REJECT
  must have zero approved size.
* `CtfOperation` — split/merge/redeem record with idempotency id; a MERGE of a
  complete pair recovers $1/pair.
* `ReconciliationResult` — status + discrepancies/actions (secret-free).

Enums (`enums.py`, string-valued for stable serialization): `OutcomeSide`,
`OrderSide`, `TimeInForce`, `OrderStatus` (with `is_terminal` /
`is_confirmed_complete`), `RiskVerdict`, `CtfOperationType`,
`CtfOperationStatus`, `ReconciliationStatus`.

## Pure arithmetic (`arithmetic.py`)

All deterministic and side-effect free:

| Function | Meaning | Rounding |
|---|---|---|
| `executable_vwap(levels, qty)` | VWAP walking a book to `qty` → `ExecutableVwap(average_price, filled, requested, is_complete)` | price half-even |
| `average_acquisition_price(fills)` | size-weighted avg price of fills | price half-even |
| `taker_fee(notional, bps)` | fee on notional | **UP** |
| `matched_quantity(up, down)` | `min(up, down)` | exact |
| `residual_quantity(up, down)` | `|up - down|` | exact |
| `effective_pair_cost(...)` | sum of the 6 documented cost components | **UP** |
| `locked_pair_value(pairs)` | `pairs * $1` | exact |
| `locked_net_profit(locked, cost)` | `locked - cost` | **DOWN** |
| `mark_to_executable_bid_pnl(qty, avg, bid)` | `qty*(bid-avg)` at executable bid | **DOWN** |

## Serialization (`serialization.py`)

`to_jsonable` renders any value object/entity to JSON-safe primitives with
**Decimals as strings** (no float), enums as their `.value`, dataclasses as
dicts, and tuples/sets as lists. `dumps` emits deterministic sorted JSON.
Explicit `*_from_str` constructors round-trip the Decimal-backed value objects.

## Tests

* `tests/unit/test_precision.py` — float rejection, conservative rounding,
  deterministic tick alignment.
* `tests/unit/test_value_objects.py` — range/positivity/format boundaries,
  immutability, float rejection.
* `tests/unit/test_entities.py` — invariants incl. non-`FILLED` never complete.
* `tests/unit/test_arithmetic.py` — worked numeric examples for every function.
* `tests/unit/test_serialization.py` — Decimal-as-string, enum values, JSON.
* `tests/unit/test_domain_properties.py` — Hypothesis invariants (fees never
  understate, profit never overstates, matched+residual==max, VWAP bounds).
