"""Unit tests for the zero-config auto-discovery path.

Exercise the slug-free ``fetch_markets_for_window`` route through the service
and factory, plus the Gamma window-query builder and keyword filter. All fakes
are in-memory; no HTTP, Postgres or Redis is touched.
"""

from __future__ import annotations

from collections.abc import Sequence

import pytest

from polymarket_pair_bot.market_discovery.errors import (
    MarketDiscoveryConfigurationError,
    MarketNotFoundError,
)
from polymarket_pair_bot.market_discovery.gamma_client import (
    GammaMarketSource,
    _keyword_matches,
)
from polymarket_pair_bot.market_discovery.ports import RawMarket
from polymarket_pair_bot.market_discovery.service import MarketDiscoveryService
from polymarket_pair_bot.market_discovery.windows import FiveMinuteWindow
from tests.fixtures import gamma

NOW_EPOCH = gamma.WINDOW_OPEN_EPOCH + 150
WINDOW = FiveMinuteWindow(gamma.WINDOW_OPEN_EPOCH, gamma.WINDOW_CLOSE_EPOCH)


class FakeWindowSource:
    """Auto-capable source recording calls and returning canned candidates."""

    def __init__(self, markets: list[RawMarket]) -> None:
        self._markets = markets
        self.calls: list[dict[str, object]] = []

    async def fetch_markets_by_slug(self, slug: str) -> Sequence[RawMarket]:
        raise AssertionError("slug path must not run in auto mode")

    async def fetch_markets_for_window(
        self,
        window: FiveMinuteWindow,
        *,
        keyword: str | None = None,
        limit: int = 100,
        tag_id: str | None = None,
        use_date_filter: bool = True,
    ) -> Sequence[RawMarket]:
        self.calls.append(
            {
                "open": window.open_epoch,
                "keyword": keyword,
                "limit": limit,
                "tag_id": tag_id,
                "use_date_filter": use_date_filter,
            }
        )
        return list(self._markets)


class SlugOnlySource:
    async def fetch_markets_by_slug(self, slug: str) -> Sequence[RawMarket]:
        return []


def _unrelated_market() -> dict[str, object]:
    other = gamma.clone(gamma.valid_market())
    other["id"] = "999999"
    other["startDate"] = "2025-02-02T09:00:00Z"
    other["endDate"] = "2025-02-02T09:05:00Z"
    return other


@pytest.mark.asyncio
async def test_auto_discovery_selects_window_market_without_slug() -> None:
    source = FakeWindowSource([_unrelated_market(), gamma.valid_market()])
    service = MarketDiscoveryService(
        source,
        None,
        auto_discovery=True,
        auto_keyword="bitcoin",
        auto_max_candidates=50,
        clock=lambda: NOW_EPOCH,
    )

    market = await service.discover_window(WINDOW)

    assert market.market_id == "512345"
    assert market.up_token_id == gamma.UP_TOKEN_ID
    assert market.down_token_id == gamma.DOWN_TOKEN_ID
    assert source.calls == [
        {
            "open": gamma.WINDOW_OPEN_EPOCH,
            "keyword": "bitcoin",
            "limit": 50,
            "tag_id": None,
            "use_date_filter": True,
        }
    ]


@pytest.mark.asyncio
async def test_auto_discovery_run_once_preloads_next_window() -> None:
    source = FakeWindowSource([gamma.valid_market(), gamma.next_window_market()])
    service = MarketDiscoveryService(
        source, None, auto_discovery=True, clock=lambda: NOW_EPOCH
    )

    result = await service.run_once(preload_next=True)

    assert result.current.market_id == "512345"
    assert result.next is not None
    assert result.next.market_id == "512346"


@pytest.mark.asyncio
async def test_auto_discovery_fails_closed_when_no_window_match() -> None:
    source = FakeWindowSource([_unrelated_market()])
    service = MarketDiscoveryService(
        source, None, auto_discovery=True, clock=lambda: NOW_EPOCH
    )

    with pytest.raises(MarketNotFoundError):
        await service.discover_window(WINDOW)


def test_auto_discovery_requires_window_capable_source() -> None:
    with pytest.raises(MarketDiscoveryConfigurationError):
        MarketDiscoveryService(SlugOnlySource(), None, auto_discovery=True)


def test_non_auto_requires_slug_strategy() -> None:
    with pytest.raises(MarketDiscoveryConfigurationError):
        MarketDiscoveryService(SlugOnlySource(), None, auto_discovery=False)


@pytest.mark.parametrize(
    ("item", "keyword", "expected"),
    [
        ({"slug": "btc-bitcoin-updown"}, "bitcoin", True),
        ({"question": "Will Bitcoin go up?"}, "bitcoin", True),
        ({"title": "BITCOIN 5m"}, "bitcoin", True),
        ({"slug": "eth-updown"}, "bitcoin", False),
        ({"slug": "eth"}, "", True),
        ({"slug": "eth"}, None, True),
    ],
)
def test_keyword_matches(item: dict[str, object], keyword: str | None, expected: bool) -> None:
    assert _keyword_matches(item, keyword) is expected


def test_window_params_band_around_close() -> None:
    params = GammaMarketSource._build_window_params(
        WINDOW, limit=100, tag_id=None, use_date_filter=True
    )
    assert params["active"] == "true"
    assert params["closed"] == "false"
    assert params["order"] == "endDate"
    assert params["ascending"] == "true"
    assert params["limit"] == "100"
    # Window close 00:05:00Z banded +/- one 5-minute window.
    assert params["end_date_min"] == "2025-01-01T00:00:00Z"
    assert params["end_date_max"] == "2025-01-01T00:10:00Z"


def test_window_params_without_date_filter_and_with_tag() -> None:
    params = GammaMarketSource._build_window_params(
        WINDOW, limit=10, tag_id="42", use_date_filter=False
    )
    assert "end_date_min" not in params
    assert "end_date_max" not in params
    assert params["tag_id"] == "42"
    assert params["limit"] == "10"
