# Consolidated Safety Audit + Applied Fixes (v2)

This document folds new runtime evidence (from a networked build session) into the
original sandbox safety audit, and records the four fixes now merged into this copy.
Sandbox limits are stated explicitly so nothing is over-claimed.

---

## 1. What changed in this copy

Four fixes are now present together in this single tree (previously they lived in two
separate copies):

| # | Area | File(s) | Nature |
|---|------|---------|--------|
| 1 | ORM startup blocker | persistence/models.py | SQLAlchemy 2.0 positional Annotated alias rejected at class definition |
| 2 | Config startup blocker | config/models.py | blank .env value not coercible to typed field |
| 3 | Config startup blocker | config/models.py, config/settings.py | AppConfig missing dashboard settings referenced by Module 21 |
| 4 | Concurrency hardening (mine) | strategy/session_machine.py (+ tests/unit/test_session_machine_locking.py) | per-market asyncio.Lock serializing the cache read-modify-write |

Fixes 1-3 are identical in intent to the fixes an independent networked session made and
validated by booting the app and running the suite (904 passed / 12 failed / 15 skipped).
Fix 4 is my own hardening, verified offline.

---

## 2. Deep verification of the three adopted fixes

### Fix 1 - ORM money columns (precision is the safety-critical concern)

persistence/base.py defines the shared fixed-point column objects:

- PRICE_NUMERIC  = Numeric(precision=12, scale=6)
- SHARES_NUMERIC = Numeric(precision=30, scale=6)
- USD_NUMERIC    = Numeric(precision=30, scale=6)
- PROFIT_NUMERIC = Numeric(precision=30, scale=6)

The broken pattern passed the Annotated aliases (DecimalPrice, ...) positionally to
mapped_column, which SQLAlchemy 2.0 rejects. The fix replaces each positional alias with
the exact same underlying Numeric(...) object the alias wrapped, keeping the
Mapped[Decimal] annotation. Because the object is identical, precision and scale are
provably unchanged on every money column.

Mechanical proof:

- 38 positional columns rewritten: PRICE_NUMERIC x15, SHARES_NUMERIC x11,
  USD_NUMERIC x11, PROFIT_NUMERIC x1 (matches the original alias distribution 1:1).
- No Decimal* alias remains used positionally.
- The suite own test_persistence_models.py::test_money_columns_are_numeric asserts the
  key money columns are sa.Numeric (not binary Float) - this fix makes that test able
  to run and pass, corroborating the Decimal/base-units invariant.

### Fix 2 - blank .env handling (env safety)

env_ignore_empty=True added to the shared settings config (and the backtest config).
Blank entries such as MAX_RECONNECT_ATTEMPTS= now fall back to the field default
(max_reconnect_attempts: int | None = Field(default=None, ge=1)), matching the
documented "blank = unset / retry forever" semantics.

Safety check - does this let a required secret silently default? No:

- Trading is off by default; live mode is gated by an explicit AppConfig validator that
  fails closed and lists every missing credential (private key, funder address, auth
  fields, both RPC endpoints). A blank secret still resolves to None and is still caught
  by that validator before any live action.
- No test sets an env var to an empty string expecting a validation error, so the change
  introduces no behavioral regression (verified by scanning every setenv(..., "")).

### Fix 3 - DashboardSettings (secret handling)

DashboardSettings added and wired into AppConfig as dashboard, covering exactly the
six fields the code reads (dashboard_enabled/host/port/auth_token/refresh_seconds/title)
plus the documented dashboard_recent_fills. The bearer token is typed SecretStr | None
(not str):

- The factory already expects a secret: it calls .get_secret_value() only to compare the
  token and never logs it.
- SecretStr + the field name fragment token are both covered by the redaction utility,
  so redacted_summary() masks it in config dumps and logs.
- Defaults are safe: dashboard disabled, bound to loopback, blank token (VPN-only).

---

## 3. The 12 pre-existing test failures (characterized)

These are stale-snapshot / environment drift, independent of the four fixes. None touch a
safety invariant. Representative, source-confirmed instances:

1. Stale flat Settings API (Module 0 -> Module 1 split). test_settings.py reads
   Settings().live_trading, .paper_trading, .trading_mode, .postgres_dsn,
   .log_level - all now live on nested models (application.*, postgres, logging.*).
   These raise AttributeError. (~3 failing cases.)
2. Expected table-set drift. test_persistence_models.py::test_all_expected_tables_present
   hard-codes 15 tables, but the schema now has 16 (market_data_snapshots added later).
   set(metadata.tables) == _EXPECTED_TABLES and the length assertion both fail.
3. Python 3.13 event loop. test_observability_api.py calls
   asyncio.get_event_loop().run_until_complete(...) with no running loop, which errors on
   3.13.
4. Engine / market-data semantic drift. A small number of engine and market-data book
   tests assert on older semantics.

Recommendation: fix by realigning the tests to the current API (nested config access, add
market_data_snapshots to the expected set, use asyncio.run(...)), not by changing
production code - production behavior is correct; the tests lag it.

---

## 4. Offline verification performed here

- Full-tree byte-compile of src + tests: OK.
- No stray positional Decimal* alias remains.
- Invariant harness (risk fail-closed, kill switch, leadership, idempotent fills, matched
  pair math, merge cap, secret redaction incl. bytes, live/paper defaults): 18/18 pass.
- Per-market lock tests: 3/3 pass (identity, cross-market non-blocking, same-market
  serialization with single authoritative load).

### What could NOT be run here (must run on a networked host)

This sandbox has no network and no runtime deps (sqlalchemy, pydantic-settings, httpx,
etc.), so these remain external blockers:

- uv run pytest for the full suite (expected 907 passed / 12 failed / 15 skipped: the
  externally measured 904 plus the 3 new lock tests). Confirm on a networked host.
- ruff / mypy gates.
- Applying migrations to a staging DB and confirming the ORM boots against a real engine.
- Verifying the real live CLOB / user-stream / on-chain adapters (cannot be exercised or
  guessed offline).

---

## 5. Verdict (updated)

- Paper mode: the app boots and runs cleanly in paper mode once fixes 1-3 are applied
  (externally demonstrated). Before these fixes the app could not start at all - which is
  why the sandbox-only audit could not observe them and correctly defaulted to NOT READY.
- Paper-ready? Yes for local/offline paper use with these fixes, once the full gate suite
  is run green on a networked host.
- Live-pilot-ready? NO. Live adapters remain unverified, gates/migrations have not been
  run in this environment, and 12 test failures (though non-blocking) should be closed
  first. Fail-closed defaults (live off, per-market serialization, kill-switch cancel-only)
  hold, but that is necessary, not sufficient, for a live pilot.
