"""Database maintenance operations: migrate, health-check, reset, retention.

These are operator tools. They are safe to import without a live database (the
drivers are only touched when a function runs). Retention deletion is guarded by
configuration and never runs implicitly.
"""

from __future__ import annotations

import asyncio
import os
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

from sqlalchemy import delete, func, select, text
from sqlalchemy.ext.asyncio import AsyncEngine

from polymarket_pair_bot.config import AppConfig, load_config
from polymarket_pair_bot.config.models import RetentionSettings
from polymarket_pair_bot.persistence.base import Base
from polymarket_pair_bot.persistence.engine import create_engine_from_dsn
from polymarket_pair_bot.persistence.models import (
    InventorySnapshotRow,
    MarketDataSnapshotRow,
    PairOpportunityRow,
    ReconciliationRunRow,
    SystemEventRow,
)

def _project_root() -> Path:
    """Locate the directory that contains ``alembic/`` and ``alembic.ini``.

    Works for both an editable/source checkout
    (``<root>/src/polymarket_pair_bot/persistence/admin.py``) and a
    non-editable install, where the package lives in ``site-packages`` while the
    migration scripts are copied next to the runtime working directory (e.g.
    ``/app`` in the production image). An explicit ``PPB_PROJECT_ROOT`` override
    wins for unusual layouts.
    """
    override = os.environ.get("PPB_PROJECT_ROOT")
    if override:
        return Path(override)
    here = Path(__file__).resolve()
    # Editable/source layout: <root>/src/polymarket_pair_bot/persistence/admin.py
    source_root = here.parents[3]
    if (source_root / "alembic").is_dir():
        return source_root
    # Non-editable install: migration scripts copied next to the working dir.
    cwd = Path.cwd()
    if (cwd / "alembic").is_dir():
        return cwd
    return source_root


@dataclass(frozen=True)
class HealthReport:
    """Result of a database health check (never contains the DSN)."""

    ok: bool
    detail: str
    current_revision: str | None = None


def _alembic_config(dsn: str):
    """Build an Alembic ``Config`` pointed at our migration directory.

    Import is local so importing this module never requires Alembic.
    """
    from alembic.config import Config

    root = _project_root()
    ini = root / "alembic.ini"
    cfg = Config(str(ini) if ini.is_file() else None)
    cfg.set_main_option("script_location", str(root / "alembic"))
    # sqlalchemy.url is set programmatically so the DSN never lives in the ini.
    cfg.set_main_option("sqlalchemy.url", dsn)
    return cfg


def migrate_to_head(config: AppConfig | None = None) -> None:
    """Apply all migrations up to ``head`` (synchronous Alembic runner)."""
    from alembic import command

    cfg = config or load_config()
    command.upgrade(_alembic_config(cfg.postgres.dsn), "head")


def downgrade_to_base(config: AppConfig | None = None) -> None:
    """Downgrade all the way back to an empty schema."""
    from alembic import command

    cfg = config or load_config()
    command.downgrade(_alembic_config(cfg.postgres.dsn), "base")


async def _current_revision(engine: AsyncEngine) -> str | None:
    async with engine.connect() as conn:
        try:
            result = await conn.execute(
                text("SELECT version_num FROM alembic_version")
            )
        except Exception:  # noqa: BLE001 - table may not exist yet
            return None
        row = result.first()
        return None if row is None else str(row[0])


async def health_check(config: AppConfig | None = None) -> HealthReport:
    """Verify connectivity and report the current migration revision.

    Never raises and never echoes the DSN or any credential.
    """
    cfg = config or load_config()
    engine = create_engine_from_dsn(
        cfg.postgres.dsn, echo=False, pool_size=cfg.postgres.db_pool_size
    )
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        revision = await _current_revision(engine)
        return HealthReport(
            ok=True, detail="connectivity ok", current_revision=revision
        )
    except Exception as exc:  # noqa: BLE001 - report, never leak
        return HealthReport(ok=False, detail=type(exc).__name__)
    finally:
        await engine.dispose()


async def reset_schema(config: AppConfig | None = None) -> None:
    """Drop and recreate every table (DESTRUCTIVE; dev/test only).

    Refuses to run when live trading is enabled to avoid destroying production
    records.
    """
    cfg = config or load_config()
    if cfg.application.live_trading:
        raise RuntimeError("refusing to reset schema while LIVE_TRADING is enabled")
    engine = create_engine_from_dsn(cfg.postgres.dsn, echo=False)
    try:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
            await conn.run_sync(Base.metadata.create_all)
    finally:
        await engine.dispose()


def _cutoff(now: datetime, days: int) -> datetime:
    return now - timedelta(days=days)


async def apply_retention(
    config: AppConfig | None = None,
    *,
    now: datetime | None = None,
) -> Mapping[str, int]:
    """Delete rows older than the configured retention windows.

    Returns a mapping of table name -> rows deleted. A no-op (all zeros) when
    ``retention_enabled`` is false. A per-table window of ``0`` means retain
    forever (that table is skipped).
    """
    cfg = config or load_config()
    settings: RetentionSettings = cfg.retention
    deleted: dict[str, int] = {
        "pair_opportunities": 0,
        "inventory_snapshots": 0,
        "reconciliation_runs": 0,
        "system_events": 0,
        "market_data_snapshots": 0,
    }
    if not settings.retention_enabled:
        return deleted

    moment = now or datetime.now(tz=UTC)
    engine = create_engine_from_dsn(cfg.postgres.dsn, echo=False)
    # Explicit per-table deletes (fully typed; a day-window of 0 = keep forever).
    try:
        async with engine.begin() as conn:
            if settings.pair_opportunity_retention_days > 0:
                result = await conn.execute(
                    delete(PairOpportunityRow).where(
                        PairOpportunityRow.recorded_at
                        < _cutoff(moment, settings.pair_opportunity_retention_days)
                    )
                )
                deleted["pair_opportunities"] = int(result.rowcount or 0)
            if settings.inventory_snapshot_retention_days > 0:
                result = await conn.execute(
                    delete(InventorySnapshotRow).where(
                        InventorySnapshotRow.recorded_at
                        < _cutoff(moment, settings.inventory_snapshot_retention_days)
                    )
                )
                deleted["inventory_snapshots"] = int(result.rowcount or 0)
            if settings.reconciliation_retention_days > 0:
                result = await conn.execute(
                    delete(ReconciliationRunRow).where(
                        ReconciliationRunRow.recorded_at
                        < _cutoff(moment, settings.reconciliation_retention_days)
                    )
                )
                deleted["reconciliation_runs"] = int(result.rowcount or 0)
            if settings.system_event_retention_days > 0:
                result = await conn.execute(
                    delete(SystemEventRow).where(
                        SystemEventRow.recorded_at
                        < _cutoff(moment, settings.system_event_retention_days)
                    )
                )
                deleted["system_events"] = int(result.rowcount or 0)
            if settings.market_data_snapshot_retention_days > 0:
                result = await conn.execute(
                    delete(MarketDataSnapshotRow).where(
                        MarketDataSnapshotRow.recorded_at
                        < _cutoff(
                            moment, settings.market_data_snapshot_retention_days
                        )
                    )
                )
                deleted["market_data_snapshots"] = int(result.rowcount or 0)
    finally:
        await engine.dispose()
    return deleted


async def table_counts(config: AppConfig | None = None) -> Mapping[str, int]:
    """Return row counts per table (diagnostics helper)."""
    cfg = config or load_config()
    engine = create_engine_from_dsn(cfg.postgres.dsn, echo=False)
    counts: dict[str, int] = {}
    try:
        async with engine.connect() as conn:
            for table in Base.metadata.sorted_tables:
                stmt = select(func.count()).select_from(table)
                counts[table.name] = int((await conn.execute(stmt)).scalar_one())
    finally:
        await engine.dispose()
    return counts


__all__ = [
    "HealthReport",
    "apply_retention",
    "downgrade_to_base",
    "health_check",
    "migrate_to_head",
    "reset_schema",
    "table_counts",
]
