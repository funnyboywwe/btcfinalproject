"""SQLAlchemy ORM table definitions (Module 3).

One class per persisted table. Design notes:

* Money/price/quantity columns are ``NUMERIC`` (see :mod:`.base`) so they
  round-trip as :class:`decimal.Decimal`; no binary floats are ever stored.
* Domain timestamps are ``BIGINT`` seconds (UTC); ``recorded_at`` is a
  server-side ``TIMESTAMPTZ`` used for retention.
* Unique constraints enforce idempotency for exchange order ids, fill ids,
  client idempotency keys (intent / risk decision / CTF operation) and the
  blockchain operation key.
* No column ever stores a private key, API secret, passphrase, signature or a
  full signed transaction.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    BigInteger,
    Boolean,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from polymarket_pair_bot.persistence.base import (
    Base,
    PRICE_NUMERIC,
    PROFIT_NUMERIC,
    SHARES_NUMERIC,
    USD_NUMERIC,
    UnixSeconds,
    recorded_at_column,
)

_ID_LEN = 128
_HASH_LEN = 128
_ENUM_LEN = 32


class MarketRow(Base):
    """A binary Up/Down BTC 5-minute market definition."""

    __tablename__ = "markets"

    market_id: Mapped[str] = mapped_column(String(_ID_LEN), primary_key=True)
    condition_id: Mapped[str] = mapped_column(String(_HASH_LEN), nullable=False)
    up_token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    down_token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    up_tick_size: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    down_tick_size: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    recorded_at: Mapped[datetime] = recorded_at_column()

    __table_args__ = (
        UniqueConstraint("condition_id", name="uq_markets_condition_id"),
    )


class MarketWindowRow(Base):
    """A single BTC 5-minute market window (1:1 with a market)."""

    __tablename__ = "market_windows"

    market_id: Mapped[str] = mapped_column(
        String(_ID_LEN),
        ForeignKey("markets.market_id", ondelete="CASCADE"),
        primary_key=True,
    )
    condition_id: Mapped[str] = mapped_column(String(_HASH_LEN), nullable=False)
    open_time: Mapped[int] = mapped_column(BigInteger, nullable=False)
    close_time: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recorded_at: Mapped[datetime] = recorded_at_column()


class OrderIntentRow(Base):
    """A desired order prior to risk approval/submission (idempotency key = PK)."""

    __tablename__ = "order_intents"

    intent_id: Mapped[str] = mapped_column(String(_ID_LEN), primary_key=True)
    market_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    side: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    limit_price: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    size: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    time_in_force: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    created_at: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recorded_at: Mapped[datetime] = recorded_at_column()


class ExchangeOrderRow(Base):
    """An order as known on the exchange (unique exchange order id)."""

    __tablename__ = "exchange_orders"

    order_id: Mapped[str] = mapped_column(String(_ID_LEN), primary_key=True)
    intent_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    market_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    side: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    limit_price: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    original_size: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    filled_size: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    status: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False, index=True)
    created_at: Mapped[int] = mapped_column(BigInteger, nullable=False)
    updated_at: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recorded_at: Mapped[datetime] = recorded_at_column()

    fills: Mapped[list[FillRow]] = relationship(back_populates="order")


class FillRow(Base):
    """A confirmed execution against an order (unique fill id => idempotent)."""

    __tablename__ = "fills"

    fill_id: Mapped[str] = mapped_column(String(_ID_LEN), primary_key=True)
    order_id: Mapped[str] = mapped_column(
        String(_ID_LEN),
        ForeignKey("exchange_orders.order_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    side: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    price: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    size: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    fee: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    filled_at: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recorded_at: Mapped[datetime] = recorded_at_column()

    order: Mapped[ExchangeOrderRow] = relationship(back_populates="fills")


class InventorySnapshotRow(Base):
    """Append-only per-market inventory snapshot (high volume; retained)."""

    __tablename__ = "inventory_snapshots"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    up_token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    up_quantity: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    up_average_price: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    up_fees_paid: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    down_token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    down_quantity: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    down_average_price: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    down_fees_paid: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    matched_pairs: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    as_of: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    recorded_at: Mapped[datetime] = recorded_at_column()

    __table_args__ = (
        Index("ix_inventory_snapshots_market_as_of", "market_id", "as_of"),
    )


class PairOpportunityRow(Base):
    """Append-only detected pair opportunity (high volume; retained)."""

    __tablename__ = "pair_opportunities"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    size: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    up_price: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    down_price: Mapped[Decimal] = mapped_column(PRICE_NUMERIC, nullable=False)
    effective_pair_cost: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    max_pair_cost: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    within_threshold: Mapped[bool] = mapped_column(Boolean, nullable=False)
    as_of: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    recorded_at: Mapped[datetime] = recorded_at_column()


class MatchedPairRow(Base):
    """A confirmed matched Up/Down pair built only from confirmed fills."""

    __tablename__ = "matched_pairs"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    market_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    condition_id: Mapped[str] = mapped_column(String(_HASH_LEN), nullable=False)
    quantity: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    up_cost: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    down_cost: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    fees: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    locked_value: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    net_profit: Mapped[Decimal] = mapped_column(PROFIT_NUMERIC, nullable=False)
    created_at: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recorded_at: Mapped[datetime] = recorded_at_column()


class CtfOperationRow(Base):
    """A CTF split/merge/redeem operation (unique operation id => idempotent)."""

    __tablename__ = "ctf_operations"

    operation_id: Mapped[str] = mapped_column(String(_ID_LEN), primary_key=True)
    operation_type: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    condition_id: Mapped[str] = mapped_column(String(_HASH_LEN), nullable=False, index=True)
    quantity: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    collateral: Mapped[Decimal] = mapped_column(USD_NUMERIC, nullable=False)
    status: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    created_at: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recorded_at: Mapped[datetime] = recorded_at_column()


class BlockchainTransactionRow(Base):
    """A blockchain transaction (unique blockchain operation key => idempotent).

    Stores only public references (operation key, chain id, status, optional
    tx hash). Never stores private keys, signatures or full signed transactions.
    """

    __tablename__ = "blockchain_transactions"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    operation_key: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    chain_id: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    operation_id: Mapped[str | None] = mapped_column(
        String(_ID_LEN),
        ForeignKey("ctf_operations.operation_id", ondelete="SET NULL"),
        nullable=True,
    )
    tx_hash: Mapped[str | None] = mapped_column(String(_HASH_LEN), nullable=True)
    created_at: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recorded_at: Mapped[datetime] = recorded_at_column()

    __table_args__ = (
        UniqueConstraint(
            "operation_key", name="uq_blockchain_transactions_operation_key"
        ),
    )


class ReconciliationRunRow(Base):
    """A reconciliation pass result header."""

    __tablename__ = "reconciliation_runs"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    status: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False, index=True)
    as_of: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    recorded_at: Mapped[datetime] = recorded_at_column()

    discrepancies: Mapped[list[ReconciliationDiscrepancyRow]] = relationship(
        back_populates="run", cascade="all, delete-orphan"
    )


class ReconciliationDiscrepancyRow(Base):
    """A single discrepancy discovered during a reconciliation run."""

    __tablename__ = "reconciliation_discrepancies"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    run_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("reconciliation_runs.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    description: Mapped[str] = mapped_column(Text, nullable=False)
    recommended_action: Mapped[str | None] = mapped_column(Text, nullable=True)
    recorded_at: Mapped[datetime] = recorded_at_column()

    run: Mapped[ReconciliationRunRow] = relationship(back_populates="discrepancies")


class RiskEventRow(Base):
    """A centralized risk-engine decision (unique decision id => idempotent)."""

    __tablename__ = "risk_events"

    decision_id: Mapped[str] = mapped_column(String(_ID_LEN), primary_key=True)
    verdict: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    approved_size: Mapped[Decimal] = mapped_column(SHARES_NUMERIC, nullable=False)
    decided_at: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    recorded_at: Mapped[datetime] = recorded_at_column()


class KillSwitchEventRow(Base):
    """Append-only journal of kill-switch state transitions."""

    __tablename__ = "kill_switch_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    active: Mapped[bool] = mapped_column(Boolean, nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    actor: Mapped[str | None] = mapped_column(String(_ID_LEN), nullable=True)
    created_at: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    recorded_at: Mapped[datetime] = recorded_at_column()


class SystemEventRow(Base):
    """Append-only, secret-free audit event journal.

    ``payload`` is validated to be secret-free by the caller/mapper; this table
    must never receive private keys, API secrets, passphrases or signatures.
    """

    __tablename__ = "system_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    event_type: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    severity: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False, index=True)
    payload: Mapped[dict[str, object]] = mapped_column(
        JSONB, nullable=False, server_default="{}"
    )
    created_at: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    recorded_at: Mapped[datetime] = recorded_at_column()


class MarketDataSnapshotRow(Base):
    """Queryable summary of a recorded Up/Down pair snapshot (Module 7).

    Full-fidelity depth lives in compressed Parquet; this row keeps only the
    columns useful for filtering/aggregation. Prices/costs are ``NUMERIC``
    (Decimal). ``(window_id, sequence)`` is unique so re-processing a Parquet
    file is idempotent. This table records market data only; it never stores
    an order, fill or any trading decision.
    """

    __tablename__ = "market_data_snapshots"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    window_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False, index=True)
    market_slug: Mapped[str | None] = mapped_column(String(_ID_LEN), nullable=True)
    sequence: Mapped[int] = mapped_column(BigInteger, nullable=False)
    capture_epoch: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    trigger_reasons: Mapped[str] = mapped_column(Text, nullable=False)
    up_token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    down_token_id: Mapped[str] = mapped_column(String(_ID_LEN), nullable=False)
    up_status: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    down_status: Mapped[str] = mapped_column(String(_ENUM_LEN), nullable=False)
    up_best_bid: Mapped[Decimal | None] = mapped_column(PRICE_NUMERIC, nullable=True)
    up_best_ask: Mapped[Decimal | None] = mapped_column(PRICE_NUMERIC, nullable=True)
    up_spread: Mapped[Decimal | None] = mapped_column(PRICE_NUMERIC, nullable=True)
    down_best_bid: Mapped[Decimal | None] = mapped_column(PRICE_NUMERIC, nullable=True)
    down_best_ask: Mapped[Decimal | None] = mapped_column(PRICE_NUMERIC, nullable=True)
    down_spread: Mapped[Decimal | None] = mapped_column(PRICE_NUMERIC, nullable=True)
    executable_pair_cost: Mapped[Decimal | None] = mapped_column(
        USD_NUMERIC, nullable=True
    )
    pair_cost_level: Mapped[Decimal | None] = mapped_column(USD_NUMERIC, nullable=True)
    up_is_live: Mapped[bool] = mapped_column(Boolean, nullable=False)
    down_is_live: Mapped[bool] = mapped_column(Boolean, nullable=False)
    any_stale: Mapped[bool] = mapped_column(Boolean, nullable=False)
    any_crossed: Mapped[bool] = mapped_column(Boolean, nullable=False)
    up_exchange_timestamp_ms: Mapped[int | None] = mapped_column(
        BigInteger, nullable=True
    )
    down_exchange_timestamp_ms: Mapped[int | None] = mapped_column(
        BigInteger, nullable=True
    )
    recorded_at: Mapped[datetime] = recorded_at_column()

    __table_args__ = (
        UniqueConstraint(
            "window_id",
            "sequence",
            name="uq_market_data_snapshots_window_sequence",
        ),
        Index(
            "ix_market_data_snapshots_window_epoch",
            "window_id",
            "capture_epoch",
        ),
    )


#: Every mapped table, in dependency order (useful for tests and reset).
ALL_TABLES = (
    MarketRow,
    MarketWindowRow,
    OrderIntentRow,
    ExchangeOrderRow,
    FillRow,
    InventorySnapshotRow,
    PairOpportunityRow,
    MatchedPairRow,
    CtfOperationRow,
    BlockchainTransactionRow,
    ReconciliationRunRow,
    ReconciliationDiscrepancyRow,
    RiskEventRow,
    KillSwitchEventRow,
    SystemEventRow,
    MarketDataSnapshotRow,
)


__all__ = [
    "ALL_TABLES",
    "Base",
    "BlockchainTransactionRow",
    "CtfOperationRow",
    "ExchangeOrderRow",
    "FillRow",
    "InventorySnapshotRow",
    "KillSwitchEventRow",
    "MarketDataSnapshotRow",
    "MarketRow",
    "MarketWindowRow",
    "MatchedPairRow",
    "OrderIntentRow",
    "PairOpportunityRow",
    "ReconciliationDiscrepancyRow",
    "ReconciliationRunRow",
    "RiskEventRow",
    "SystemEventRow",
]
