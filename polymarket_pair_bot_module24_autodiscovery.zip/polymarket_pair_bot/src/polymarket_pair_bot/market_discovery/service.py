"""BTC five-minute market discovery service.

Orchestrates window computation, metadata retrieval (via the injected source
port), Pydantic validation + semantic cross-checks, outcome-to-token mapping by
name, optional persistence (authoritative) and optional caching (validated data
only). No I/O client is imported directly here -- only ports and pure helpers
(dependency inversion).

The service fails closed: contradictory, incomplete, ambiguous or
window-mismatched metadata is rejected and never persisted or cached.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass

from polymarket_pair_bot.domain.coordination import MarketMetadataCache
from polymarket_pair_bot.domain.repositories import UnitOfWork
from polymarket_pair_bot.market_discovery.errors import (
    InvalidMarketMetadataError,
    MarketDiscoveryConfigurationError,
    MarketNotFoundError,
)
from polymarket_pair_bot.market_discovery.ports import (
    MarketMetadataSource,
    MarketWindowSource,
    SlugStrategy,
)
from polymarket_pair_bot.market_discovery.schemas import (
    DiscoveredMarket,
    discovered_from_raw,
)
from polymarket_pair_bot.market_discovery.windows import (
    FiveMinuteWindow,
    WindowSet,
    window_set,
)
from polymarket_pair_bot.observability.logging import get_logger

_LOGGER = get_logger("market_discovery.service")

UnitOfWorkFactory = Callable[[], UnitOfWork]
Clock = Callable[[], int]


def _default_clock() -> int:
    return int(time.time())


@dataclass(frozen=True, slots=True)
class DiscoveryResult:
    """Outcome of a discovery cycle for the current window (+ optional next)."""

    windows: WindowSet
    current: DiscoveredMarket
    next: DiscoveredMarket | None
    persisted: bool
    cached: bool


class MarketDiscoveryService:
    """Discovers, validates, persists and caches BTC 5-minute markets."""

    def __init__(
        self,
        source: MarketMetadataSource,
        slug_strategy: SlugStrategy | None = None,
        *,
        expected_up: str = "Up",
        expected_down: str = "Down",
        window_match_tolerance_seconds: int = 90,
        require_window_match: bool = True,
        auto_discovery: bool = False,
        auto_keyword: str | None = None,
        auto_max_candidates: int = 100,
        auto_tag_id: str | None = None,
        auto_use_date_filter: bool = True,
        clock: Clock | None = None,
        uow_factory: UnitOfWorkFactory | None = None,
        metadata_cache: MarketMetadataCache | None = None,
        cache_ttl_seconds: int | None = None,
    ) -> None:
        if window_match_tolerance_seconds < 0:
            raise ValueError("window_match_tolerance_seconds must be non-negative")
        if auto_discovery and not isinstance(source, MarketWindowSource):
            raise MarketDiscoveryConfigurationError(
                "auto discovery is enabled but the metadata source does not "
                "support slug-free window lookups (fetch_markets_for_window)"
            )
        if not auto_discovery and slug_strategy is None:
            raise MarketDiscoveryConfigurationError(
                "a slug strategy is required when auto discovery is disabled"
            )
        self._source = source
        self._slug_strategy = slug_strategy
        self._expected_up = expected_up
        self._expected_down = expected_down
        self._tolerance = window_match_tolerance_seconds
        self._require_window_match = require_window_match
        self._auto_discovery = auto_discovery
        self._auto_keyword = auto_keyword
        self._auto_max_candidates = auto_max_candidates
        self._auto_tag_id = auto_tag_id
        self._auto_use_date_filter = auto_use_date_filter
        self._clock = clock or _default_clock
        self._uow_factory = uow_factory
        self._metadata_cache = metadata_cache
        self._cache_ttl_seconds = cache_ttl_seconds

    # -- window helpers ---------------------------------------------------- #
    def windows(self, now_epoch: int | None = None) -> WindowSet:
        """Return previous/current/next windows for now (or a fixed instant)."""
        return window_set(self._clock() if now_epoch is None else now_epoch)

    # -- discovery --------------------------------------------------------- #
    async def discover_window(
        self, window: FiveMinuteWindow, *, require_window_match: bool | None = None
    ) -> DiscoveredMarket:
        """Discover and validate the market for a single window."""
        match = (
            self._require_window_match
            if require_window_match is None
            else require_window_match
        )
        if self._auto_discovery:
            # Slug-free path: ask the API for candidates aligned to this window
            # and always re-check the window (auto discovery must window-match).
            match = True
            raw_markets = await self._source.fetch_markets_for_window(
                window,
                keyword=self._auto_keyword,
                limit=self._auto_max_candidates,
                tag_id=self._auto_tag_id,
                use_date_filter=self._auto_use_date_filter,
            )
        else:
            assert self._slug_strategy is not None  # guaranteed by __init__
            slug = self._slug_strategy.build(window)
            raw_markets = await self._source.fetch_markets_by_slug(slug)
        fetched_at = self._clock()
        candidates = self._validate_candidates(raw_markets, fetched_at=fetched_at)
        selected = self._select_for_window(candidates, window, require_match=match)
        _LOGGER.info(
            "discovered market",
            extra={
                "slug": selected.slug,
                "market_id": selected.market_id,
                "open_time": selected.open_time,
                "close_time": selected.close_time,
                "active": selected.active,
                "closed": selected.closed,
                "order_book_enabled": selected.order_book_enabled,
            },
        )
        return selected

    def _validate_candidates(
        self, raw_markets: Sequence[object], *, fetched_at: int
    ) -> list[DiscoveredMarket]:
        if not raw_markets:
            raise MarketNotFoundError("metadata API returned no markets for slug")
        discovered: list[DiscoveredMarket] = []
        errors: list[str] = []
        for raw in raw_markets:
            try:
                discovered.append(
                    discovered_from_raw(
                        raw,
                        expected_up=self._expected_up,
                        expected_down=self._expected_down,
                        fetched_at=fetched_at,
                    )
                )
            except InvalidMarketMetadataError as exc:
                errors.append(str(exc))
        if not discovered:
            raise InvalidMarketMetadataError(
                "no market passed validation: " + "; ".join(errors)
            )
        return discovered

    def _select_for_window(
        self,
        candidates: list[DiscoveredMarket],
        window: FiveMinuteWindow,
        *,
        require_match: bool,
    ) -> DiscoveredMarket:
        if not require_match:
            if len(candidates) != 1:
                raise InvalidMarketMetadataError(
                    "expected exactly one market when window matching is disabled, "
                    f"got {len(candidates)}"
                )
            return candidates[0]

        matching = [c for c in candidates if self._matches_window(c, window)]
        if not matching:
            raise MarketNotFoundError(
                f"no market matched window [{window.open_epoch}, "
                f"{window.close_epoch}) within {self._tolerance}s tolerance"
            )
        distinct_ids = {c.market_id for c in matching}
        if len(distinct_ids) > 1:
            raise InvalidMarketMetadataError(
                f"ambiguous window match: {sorted(distinct_ids)}"
            )
        return matching[0]

    def _matches_window(
        self, market: DiscoveredMarket, window: FiveMinuteWindow
    ) -> bool:
        return (
            abs(market.open_time - window.open_epoch) <= self._tolerance
            and abs(market.close_time - window.close_epoch) <= self._tolerance
        )

    # -- persistence / cache ---------------------------------------------- #
    async def persist(self, market: DiscoveredMarket) -> bool:
        """Persist a validated market (authoritative). Returns False if no store.

        The market row and its window row are upserted in one transaction so a
        re-discovery of the same market is idempotent.
        """
        if self._uow_factory is None:
            return False
        binary_market = market.to_binary_market()
        window = market.to_market_window()
        async with self._uow_factory() as uow:
            await uow.markets.upsert_market(binary_market)
            await uow.windows.upsert_window(window)
            await uow.commit()
        return True

    async def cache(self, market: DiscoveredMarket) -> bool:
        """Cache validated market metadata. Returns False if no cache configured.

        Only validated markets ever reach this method (callers pass
        DiscoveredMarket instances), so the cache never holds unvalidated data.
        """
        if self._metadata_cache is None:
            return False
        await self._metadata_cache.put(
            market.to_market_metadata(), ttl_seconds=self._cache_ttl_seconds
        )
        return True

    # -- top-level cycle --------------------------------------------------- #
    async def run_once(
        self, *, now_epoch: int | None = None, preload_next: bool = True
    ) -> DiscoveryResult:
        """Discover the current window, optionally preload next, persist + cache.

        Persistence and caching only occur for stores that were configured. The
        current window is always discovered; a failure to discover the next
        window is logged but not fatal (preloading is best-effort).
        """
        windows = self.windows(now_epoch)
        current = await self.discover_window(windows.current)
        persisted = await self.persist(current)
        cached = await self.cache(current)

        next_market: DiscoveredMarket | None = None
        if preload_next:
            try:
                next_market = await self.discover_window(windows.next)
            except (MarketNotFoundError, InvalidMarketMetadataError) as exc:
                _LOGGER.info(
                    "next window not yet discoverable",
                    extra={"reason": str(exc)},
                )
            if next_market is not None:
                await self.persist(next_market)
                await self.cache(next_market)

        return DiscoveryResult(
            windows=windows,
            current=current,
            next=next_market,
            persisted=persisted,
            cached=cached,
        )


__all__ = [
    "Clock",
    "DiscoveryResult",
    "MarketDiscoveryService",
    "UnitOfWorkFactory",
]
