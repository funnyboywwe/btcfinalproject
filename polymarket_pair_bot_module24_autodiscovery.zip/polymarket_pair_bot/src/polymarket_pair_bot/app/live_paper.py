"""Live PAPER-mode composition: wire the real strategy pipeline into the app.

This is the composition/orchestration layer that was previously only a
placeholder in :mod:`app.application` (``service_count == 1``). It assembles the
*existing, tested* production strategy components -- the pair opportunity
detector, the centralized risk engine, the pair-accumulation state machine, the
inventory accounting and the paper execution simulator -- and drives them from a
LIVE market-data WebSocket feed plus the BTC 5-minute discovery service, using
exactly the same event ordering the deterministic backtest engine uses
(:class:`polymarket_pair_bot.backtest.harness.BacktestEngine`).

HARD SAFETY BOUNDARIES (do not relax):

* PAPER ONLY. This service is registered by :func:`app.application.build_lifecycle`
  only when ``config.run_mode is RunMode.PAPER`` and the opt-in environment flag
  ``PPB_PAPER_AUTOTRADE`` is set. It constructs a :class:`PaperExecutionAdapter`
  and never a live execution adapter, so it can never place a real order.
* NO CORE-STRATEGY CHANGE. Nothing here re-implements or edits strategy logic;
  it only wires already-built components to live inputs. The detector, the state
  machine, the risk engine and the paper adapter are imported and used as-is.
* FAIL CLOSED. Discovery / feed failures are logged and retried; a stale or
  absent book yields a not-fresh :class:`BooksUpdatedEvent` so the machine never
  acts on stale data. On shutdown every resting paper order is cancelled.

UNVERIFIED LIVE INTEGRATION: the live WebSocket + Gamma discovery paths cannot
be exercised offline. The per-window event loop is a direct port of the tested
backtest loop, but the live wiring itself must be validated on the deployment
host. Session state here uses the in-process stores (no Postgres), so paper
sessions are intentionally not durable across a restart.
"""

from __future__ import annotations

import asyncio
import os
import time

from polymarket_pair_bot.backtest.memory import (
    BacktestKillSwitchPort,
    BacktestMergePort,
    BacktestReconciliationPort,
    InMemoryExecutionPersistence,
    InMemorySessionStore,
)
from polymarket_pair_bot.backtest.risk_adapter import BacktestRiskApprovalAdapter
from polymarket_pair_bot.config.settings import AppConfig
from polymarket_pair_bot.domain.entities import BinaryMarket, OrderBookSnapshot
from polymarket_pair_bot.domain.enums import OrderSide, OutcomeSide
from polymarket_pair_bot.domain.value_objects import (
    ProbabilityPrice,
    Shares,
    TokenId,
    UnixTimestamp,
)
from polymarket_pair_bot.execution import (
    MarketEvent,
    PaperExecutionAdapter,
    PaperExecutionConfig,
)
from polymarket_pair_bot.execution.types import TradeTick
from polymarket_pair_bot.inventory.accounting import build_inventory
from polymarket_pair_bot.market_data.factory import build_market_data_feed
from polymarket_pair_bot.market_discovery.factory import (
    build_market_discovery_service,
)
from polymarket_pair_bot.observability.logging import get_logger
from polymarket_pair_bot.risk.engine import RiskEngine
from polymarket_pair_bot.risk.limits import RiskLimits
from polymarket_pair_bot.strategy.session_events import (
    BooksUpdatedEvent,
    FillConfirmedEvent,
    LimitCheckEvent,
    MarketValidatedEvent,
    MergeEvaluateEvent,
    WindowClosingEvent,
)
from polymarket_pair_bot.strategy.session_factory import (
    build_pair_detector,
    build_state_machine,
)

_LOG = get_logger("app.live_paper")

_MAX_MERGE_DRAIN_STEPS = 8
_AUTOTRADE_TRUE = {"1", "true", "yes", "on"}


def paper_autotrade_enabled() -> bool:
    """Opt-in gate: the live paper pipeline is OFF unless explicitly enabled."""
    return os.getenv("PPB_PAPER_AUTOTRADE", "").strip().lower() in _AUTOTRADE_TRUE


def _poll_seconds() -> float:
    raw = os.getenv("PPB_PAPER_POLL_SECONDS", "").strip()
    try:
        value = float(raw) if raw else 1.0
    except ValueError:
        return 1.0
    return value if value > 0 else 1.0


def _best_level(levels: tuple, *, highest: bool):
    """Return the best usable price level (highest bid / lowest ask), or None."""
    usable = [lvl for lvl in levels if lvl.size.value > 0]
    if not usable:
        return None
    return (
        max(usable, key=lambda lvl: lvl.price.value)
        if highest
        else min(usable, key=lambda lvl: lvl.price.value)
    )


def _synthesize_trades(
    prev: OrderBookSnapshot | None,
    curr: OrderBookSnapshot | None,
    token_id: TokenId,
    *,
    prefix: str,
) -> tuple[TradeTick, ...]:
    """Conservative trade-print proxy from two consecutive live snapshots.

    This mirrors the documented backtest proxy
    (:func:`polymarket_pair_bot.backtest.events.synthesize_trades`) applied to
    the live :class:`OrderBookSnapshot` shape: a reduction in size at an
    unchanged best bid is modeled as a SELL-aggressor print; a reduction at an
    unchanged best ask as a BUY-aggressor print. Volume is capped at the
    observed reduction (never invented). It asserts nothing about profitability.
    """
    if prev is None or curr is None:
        return ()
    trades: list[TradeTick] = []
    pairs = (
        (prev.bids, curr.bids, True, OrderSide.SELL, "bid"),
        (prev.asks, curr.asks, False, OrderSide.BUY, "ask"),
    )
    for prev_levels, curr_levels, highest, aggressor, tag in pairs:
        prev_best = _best_level(prev_levels, highest=highest)
        curr_best = _best_level(curr_levels, highest=highest)
        if prev_best is None or curr_best is None:
            continue
        if prev_best.price.value != curr_best.price.value:
            continue
        delta = prev_best.size.value - curr_best.size.value
        if delta <= 0:
            continue
        try:
            trades.append(
                TradeTick(
                    trade_id=f"{prefix}:{tag}",
                    token_id=token_id,
                    price=curr_best.price,
                    size=Shares(delta),
                    aggressor=aggressor,
                )
            )
        except (ValueError, TypeError):
            continue
    return tuple(trades)


class LivePaperTradingService:
    """Long-lived service that runs the paper pipeline window-by-window.

    Implements the structural ``app.services.Service`` protocol (name/start/stop).
    ``start`` spawns a single supervised background task; ``stop`` is idempotent
    and cancels resting paper orders.
    """

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._stop = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._counter = 0
        self._poll = _poll_seconds()

    @property
    def name(self) -> str:
        return "live-paper-trading"

    async def start(self) -> None:
        if self._task is not None:
            return
        self._stop.clear()
        self._task = asyncio.create_task(self._run(), name="live-paper-trading")
        _LOG.info("live_paper_started", extra={"poll_seconds": self._poll})

    async def stop(self) -> None:
        self._stop.set()
        task = self._task
        self._task = None
        if task is not None:
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        _LOG.info("live_paper_stopped")

    # -- supervisor ------------------------------------------------------- #
    async def _run(self) -> None:
        discovery = build_market_discovery_service(self._config)
        while not self._stop.is_set():
            market: BinaryMarket | None = None
            try:
                result = await discovery.run_once(preload_next=False)
                current = result.current
                if not current.is_open_for_trading:
                    _LOG.info(
                        "live_paper_market_not_open",
                        extra={"market_id": current.market_id},
                    )
                elif current.close_time <= int(time.time()):
                    _LOG.info(
                        "live_paper_window_already_closed",
                        extra={"market_id": current.market_id},
                    )
                else:
                    market = current.to_binary_market()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - supervisor must not die
                _LOG.warning(
                    "live_paper_discovery_failed",
                    extra={"error": type(exc).__name__, "reason": str(exc)},
                )
            if market is None:
                await self._sleep_or_stop(5.0)
                continue
            try:
                await self._trade_window(market)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 - one bad window must not kill loop
                _LOG.exception("live_paper_window_error")
                await self._sleep_or_stop(5.0)

    async def _sleep_or_stop(self, seconds: float) -> None:
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    def _paper_config(self) -> PaperExecutionConfig:
        return PaperExecutionConfig.from_settings(self._config.paper_execution)

    def _next_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter}"

    # -- one market window ------------------------------------------------ #
    async def _trade_window(self, market: BinaryMarket) -> None:
        up_token = market.up_token.token_id
        down_token = market.down_token.token_id
        market_id = market.market_id
        open_epoch = market.window.open_time.value
        close_epoch = market.window.close_time.value

        feed, manager = build_market_data_feed(self._config, up_token, down_token)
        feed_task = asyncio.create_task(feed.run(), name="live-paper-feed")

        persistence = InMemoryExecutionPersistence()
        start_ms = int(time.time() * 1000)
        adapter = PaperExecutionAdapter(
            config=self._paper_config(),
            persistence=persistence,
            start_ms=start_ms,
        )
        adapter.register_market(market)
        detector = build_pair_detector(
            strategy=self._config.pair_strategy,
            tick_size=market.up_token.tick_size,
            min_seconds_to_close=self._config.state_machine.first_leg_cutoff_seconds,
        )
        risk = BacktestRiskApprovalAdapter(
            RiskEngine(RiskLimits.from_settings(self._config.risk))
        )
        store = InMemorySessionStore()
        merge = BacktestMergePort()
        machine = build_state_machine(
            state_machine_settings=self._config.state_machine,
            strategy=self._config.pair_strategy,
            tick_size=market.up_token.tick_size,
            store=store,
            execution=adapter,
            risk=risk,
            merge=merge,
            reconciliation=BacktestReconciliationPort(),
            kill_switch=BacktestKillSwitchPort(),
            detector=detector,
        )

        _LOG.info(
            "live_paper_window_open",
            extra={
                "market_id": market_id.value,
                "open_time": open_epoch,
                "close_time": close_epoch,
            },
        )
        await machine.process(
            MarketValidatedEvent(
                event_id=self._next_id("validated"),
                market_id=market_id,
                occurred_at=UnixTimestamp(open_epoch),
                market=market,
            )
        )

        prev_up: OrderBookSnapshot | None = None
        prev_down: OrderBookSnapshot | None = None
        clock_ms = start_ms
        fill_cursor = 0
        ticks = 0
        try:
            while not self._stop.is_set():
                now_s = int(time.time())
                seconds_to_close = max(0, close_epoch - now_s)
                clock_ms = max(clock_ms + 1, int(time.time() * 1000))
                as_of = UnixTimestamp(now_s)
                ticks += 1

                up_fresh = manager.is_fresh(OutcomeSide.UP)
                down_fresh = manager.is_fresh(OutcomeSide.DOWN)
                up_book = manager.snapshot(OutcomeSide.UP)
                down_book = manager.snapshot(OutcomeSide.DOWN)
                up_trades = (
                    _synthesize_trades(
                        prev_up, up_book, up_token, prefix=f"{market_id.value}:{ticks}:up"
                    )
                    if up_fresh
                    else ()
                )
                down_trades = (
                    _synthesize_trades(
                        prev_down,
                        down_book,
                        down_token,
                        prefix=f"{market_id.value}:{ticks}:down",
                    )
                    if down_fresh
                    else ()
                )

                await adapter.apply_market_event(
                    MarketEvent(
                        event_id=self._next_id("mev-up"),
                        token_id=up_token,
                        timestamp_ms=clock_ms,
                        snapshot=up_book if up_fresh else None,
                        trades=up_trades,
                        feed_live=up_fresh,
                    )
                )
                clock_ms += 1
                await adapter.apply_market_event(
                    MarketEvent(
                        event_id=self._next_id("mev-down"),
                        token_id=down_token,
                        timestamp_ms=clock_ms,
                        snapshot=down_book if down_fresh else None,
                        trades=down_trades,
                        feed_live=down_fresh,
                    )
                )

                fill_cursor = await self._drain_fills(
                    machine, market, persistence, fill_cursor
                )
                await machine.process(
                    BooksUpdatedEvent(
                        event_id=self._next_id("books"),
                        market_id=market_id,
                        occurred_at=as_of,
                        market=market,
                        up_book=up_book,
                        down_book=down_book,
                        up_is_fresh=up_fresh,
                        down_is_fresh=down_fresh,
                        feed_live=up_fresh or down_fresh,
                        seconds_to_close=seconds_to_close,
                    )
                )
                fill_cursor = await self._drain_fills(
                    machine, market, persistence, fill_cursor
                )

                snapshot = store.snapshots.get(market_id.value)
                if snapshot is not None and snapshot.has_unmatched:
                    await machine.process(
                        LimitCheckEvent(
                            event_id=self._next_id("limit"),
                            market_id=market_id,
                            occurred_at=as_of,
                            market=market,
                        )
                    )
                snapshot = store.snapshots.get(market_id.value)
                if snapshot is not None and snapshot.matched_pairs.value > 0:
                    merge.set_mergeable(snapshot.matched_pairs)
                    await machine.process(
                        MergeEvaluateEvent(
                            event_id=self._next_id("merge"),
                            market_id=market_id,
                            occurred_at=as_of,
                            market=market,
                        )
                    )

                prev_up = up_book
                prev_down = down_book
                if seconds_to_close <= 0:
                    break
                await self._sleep_or_stop(self._poll)

            # Close cutoff: advance past close, settle, run the closing event.
            close_ms = max(
                clock_ms + 1,
                close_epoch * 1000 + self._config.backtest.settle_buffer_ms,
            )
            await adapter.advance_to(close_ms)
            fill_cursor = await self._drain_fills(
                machine, market, persistence, fill_cursor
            )
            await machine.process(
                WindowClosingEvent(
                    event_id=self._next_id("closing"),
                    market_id=market_id,
                    occurred_at=UnixTimestamp(close_epoch),
                    market=market,
                    seconds_to_close=0,
                )
            )
            fill_cursor = await self._drain_fills(
                machine, market, persistence, fill_cursor
            )
            for _ in range(_MAX_MERGE_DRAIN_STEPS):
                snapshot = store.snapshots.get(market_id.value)
                if snapshot is None or snapshot.matched_pairs.value <= 0:
                    break
                merge.set_mergeable(snapshot.matched_pairs)
                await machine.process(
                    MergeEvaluateEvent(
                        event_id=self._next_id("merge-close"),
                        market_id=market_id,
                        occurred_at=UnixTimestamp(close_epoch),
                        market=market,
                    )
                )
        finally:
            feed.request_stop()
            feed_task.cancel()
            await asyncio.gather(feed_task, return_exceptions=True)
            try:
                await adapter.cancel_all_orders()
            except Exception:  # noqa: BLE001 - best-effort cleanup
                _LOG.warning("live_paper_cancel_all_failed")

        fills = tuple(persistence.fills.ordered)
        inventory = build_inventory(market, fills)
        final_snapshot = store.snapshots.get(market_id.value)
        _LOG.info(
            "live_paper_window_complete",
            extra={
                "market_id": market_id.value,
                "ticks": ticks,
                "attempted_orders": len(persistence.intents.items),
                "fills": len(fills),
                "merged_pairs": str(merge.merged_pairs.value),
                "matched_pairs": (
                    str(final_snapshot.matched_pairs.value)
                    if final_snapshot is not None
                    else "0"
                ),
                "final_state": (
                    final_snapshot.state.value
                    if final_snapshot is not None
                    else "unknown"
                ),
                "realized_pnl_usd": str(getattr(inventory, "realized_pnl", "")),
            },
        )

    async def _drain_fills(
        self,
        machine: object,
        market: BinaryMarket,
        persistence: InMemoryExecutionPersistence,
        cursor: int,
    ) -> int:
        ordered = persistence.fills.ordered
        while cursor < len(ordered):
            fill = ordered[cursor]
            cursor += 1
            await machine.process(  # type: ignore[attr-defined]
                FillConfirmedEvent(
                    event_id=f"fill-{fill.fill_id.value}",
                    market_id=market.market_id,
                    occurred_at=fill.filled_at,
                    market=market,
                    fill=fill,
                )
            )
        return cursor


__all__ = ["LivePaperTradingService", "paper_autotrade_enabled"]
