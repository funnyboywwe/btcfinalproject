"""Grouped, typed settings models loaded from environment variables and .env.

Each concern is its own ``BaseSettings`` model so ownership is explicit and the
models can be reused independently. Sensitive values use ``SecretStr`` so they
never leak through ``repr`` or logging. Monetary values use ``Decimal`` (never
binary floats); only durations/counts use ``float``/``int``.
"""

from __future__ import annotations

from decimal import Decimal

from pydantic import Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from polymarket_pair_bot.config.enums import (
    AlertSeverity,
    AppEnv,
    LogLevel,
    RecorderOverflowPolicy,
    SignatureType,
)
from polymarket_pair_bot.config.validators import (
    ensure_supported_chain_id,
    ensure_valid_evm_address,
    normalize_http_url,
    normalize_private_key,
    normalize_ws_url,
)

_ENV = SettingsConfigDict(
    env_file=".env",
    env_file_encoding="utf-8",
    extra="ignore",
    case_sensitive=False,
    # Treat blank .env entries (e.g. `MAX_RECONNECT_ATTEMPTS=`) as unset so the
    # field default applies, matching the documented "blank = unset" semantics
    # instead of failing to coerce an empty string into a typed value.
    env_ignore_empty=True,
)


class ApplicationSettings(BaseSettings):
    """Top-level application and trading safety switches."""

    model_config = _ENV

    app_env: AppEnv = AppEnv.DEVELOPMENT
    # Live trading OFF and paper trading ON unless explicitly changed.
    paper_trading: bool = True
    live_trading: bool = False
    shutdown_timeout_seconds: float = Field(default=30.0, gt=0)
    operator_api_host: str = "127.0.0.1"
    operator_api_port: int = Field(default=8081, ge=1, le=65535)

    @model_validator(mode="after")
    def _reject_paper_and_live(self) -> "ApplicationSettings":
        if self.paper_trading and self.live_trading:
            raise ValueError(
                "PAPER_TRADING and LIVE_TRADING cannot both be true; disable "
                "PAPER_TRADING explicitly before enabling live trading."
            )
        return self


class LoggingSettings(BaseSettings):
    """Structured logging configuration."""

    model_config = _ENV

    log_level: LogLevel = "INFO"
    log_json: bool = True
    log_redaction_enabled: bool = True


class PostgresSettings(BaseSettings):
    """PostgreSQL connection configuration."""

    model_config = _ENV

    database_url: SecretStr = Field(
        default=SecretStr("postgresql+asyncpg://bot:bot@localhost:5432/pair_bot"),
    )
    db_pool_size: int = Field(default=5, ge=1)
    db_echo: bool = False

    @field_validator("database_url")
    @classmethod
    def _check_dsn(cls, value: SecretStr) -> SecretStr:
        dsn = value.get_secret_value()
        if not dsn.startswith(("postgresql://", "postgresql+asyncpg://")):
            raise ValueError(
                "DATABASE_URL must be a postgresql:// or postgresql+asyncpg:// DSN"
            )
        return value

    @property
    def dsn(self) -> str:
        """Return the raw DSN for driver use (never log this)."""
        return self.database_url.get_secret_value()


class RedisSettings(BaseSettings):
    """Redis connection configuration."""

    model_config = _ENV

    redis_url: SecretStr = Field(default=SecretStr("redis://localhost:6379/0"))
    redis_namespace: str = "ppb"

    @field_validator("redis_url")
    @classmethod
    def _check_url(cls, value: SecretStr) -> SecretStr:
        url = value.get_secret_value()
        if not url.startswith(("redis://", "rediss://")):
            raise ValueError("REDIS_URL must be a redis:// or rediss:// URL")
        return value

    @property
    def url(self) -> str:
        """Return the raw URL for driver use (never log this)."""
        return self.redis_url.get_secret_value()


class PolymarketPublicSettings(BaseSettings):
    """Public (unauthenticated) Polymarket endpoints.

    Defaults point at Polymarket's documented public hosts and are operator
    overridable. RTDS is optional until a later module requires it.
    """

    model_config = _ENV

    polymarket_gamma_url: str = "https://gamma-api.polymarket.com"
    polymarket_clob_url: str = "https://clob.polymarket.com"
    polymarket_market_ws_url: str = (
        "wss://ws-subscriptions-clob.polymarket.com/ws/market"
    )
    polymarket_user_ws_url: str = (
        "wss://ws-subscriptions-clob.polymarket.com/ws/user"
    )
    polymarket_rtds_url: str | None = None

    @field_validator("polymarket_gamma_url", "polymarket_clob_url")
    @classmethod
    def _check_http(cls, value: str) -> str:
        return normalize_http_url(value)

    @field_validator("polymarket_market_ws_url", "polymarket_user_ws_url")
    @classmethod
    def _check_ws(cls, value: str) -> str:
        return normalize_ws_url(value)

    @field_validator("polymarket_rtds_url")
    @classmethod
    def _check_rtds(cls, value: str | None) -> str | None:
        return None if value is None else normalize_ws_url(value)


class PolymarketAuthSettings(BaseSettings):
    """Authenticated Polymarket API credentials (CLOB L2 headers)."""

    model_config = _ENV

    polymarket_api_key: SecretStr | None = None
    polymarket_api_secret: SecretStr | None = None
    polymarket_api_passphrase: SecretStr | None = None
    # Authenticated user-stream tuning (Module 15). Durations are seconds and
    # counts are ints (these are not monetary values, so int/float is fine).
    user_stream_freshness_seconds: float = Field(default=30.0, gt=0)
    user_stream_max_reconnects: int = Field(default=5, ge=0)
    user_stream_dedup_capacity: int = Field(default=4096, gt=0)

    @property
    def has_full_auth(self) -> bool:
        """True only when every authenticated credential is present."""
        return all(
            v is not None
            for v in (
                self.polymarket_api_key,
                self.polymarket_api_secret,
                self.polymarket_api_passphrase,
            )
        )

    def missing_fields(self) -> list[str]:
        """Return the env-var names of any missing credentials."""
        missing: list[str] = []
        if self.polymarket_api_key is None:
            missing.append("POLYMARKET_API_KEY")
        if self.polymarket_api_secret is None:
            missing.append("POLYMARKET_API_SECRET")
        if self.polymarket_api_passphrase is None:
            missing.append("POLYMARKET_API_PASSPHRASE")
        return missing


class PolygonSettings(BaseSettings):
    """Polygon chain and RPC configuration.

    RPC URLs are secrets because they frequently embed provider API keys.
    """

    model_config = _ENV

    polygon_chain_id: int = 137
    polygon_rpc_primary: SecretStr | None = None
    polygon_rpc_secondary: SecretStr | None = None

    @field_validator("polygon_chain_id")
    @classmethod
    def _check_chain(cls, value: int) -> int:
        return ensure_supported_chain_id(value)

    @field_validator("polygon_rpc_primary", "polygon_rpc_secondary")
    @classmethod
    def _check_rpc(cls, value: SecretStr | None) -> SecretStr | None:
        if value is None:
            return None
        # normalize_http_url never echoes the (possibly key-bearing) URL.
        return SecretStr(normalize_http_url(value.get_secret_value()))


class ChainReadSettings(BaseSettings):
    """Polygon RPC read/resilience tunables for the wallet-state service (Module 16).

    All monetary conversions downstream use Decimal / documented integer base
    units; nothing here is a binary float used for money. Contract addresses are
    left unset by default and must be operator-configured: the service fails
    closed (raises a typed error) rather than guessing Polymarket's on-chain
    contract addresses.
    """

    model_config = _ENV

    # Per-request/read resilience.
    polygon_rpc_timeout_seconds: float = Field(default=10.0, gt=0)
    polygon_rpc_max_retries: int = Field(default=3, ge=0)
    polygon_rpc_backoff_base_seconds: float = Field(default=0.5, gt=0)
    polygon_rpc_backoff_max_seconds: float = Field(default=8.0, gt=0)
    polygon_rpc_circuit_fail_threshold: int = Field(default=5, gt=0)
    polygon_rpc_circuit_reset_seconds: float = Field(default=30.0, gt=0)

    # Dual-RPC agreement. Balances/nonces are integer base units; differences
    # at/under this tolerance are treated as agreement (conservative value is
    # then chosen). chain id must always match exactly.
    polygon_balance_tolerance_base_units: int = Field(default=0, ge=0)
    polygon_require_secondary_rpc: bool = False

    # Receipt waiting / confirmations.
    polygon_receipt_timeout_seconds: float = Field(default=120.0, gt=0)
    polygon_receipt_poll_interval_seconds: float = Field(default=2.0, gt=0)
    polygon_required_confirmations: int = Field(default=1, ge=0)

    # Conservative gas buffer applied to estimated gas (Decimal multiplier >= 1).
    polygon_gas_estimate_buffer: Decimal = Field(default=Decimal("1.25"), ge=1)

    # On-chain contracts. Unset => the corresponding read is blocked/fail-closed.
    polygon_usdc_address: str | None = None
    polygon_usdc_decimals: int = Field(default=6, ge=0, le=36)
    polygon_conditional_tokens_address: str | None = None
    polygon_outcome_token_decimals: int = Field(default=6, ge=0, le=36)

    @field_validator(
        "polygon_usdc_address", "polygon_conditional_tokens_address"
    )
    @classmethod
    def _check_contract(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return ensure_valid_evm_address(value)


class WalletSettings(BaseSettings):
    """Trading wallet configuration. Never required for recorder/paper modes."""

    model_config = _ENV

    polymarket_private_key: SecretStr | None = None
    polymarket_funder_address: str | None = None
    # Optional operator-provided signer (EOA) address. When absent it may be
    # derived from the private key by an Ethereum library at runtime; deriving
    # it is never required for paper/recorder modes.
    polymarket_signer_address: str | None = None
    polymarket_signature_type: SignatureType = SignatureType.EOA
    # Operator acknowledgement that this is a dedicated limited-capital wallet.
    wallet_is_dedicated_ack: bool = False

    @field_validator("polymarket_private_key")
    @classmethod
    def _check_key(cls, value: SecretStr | None) -> SecretStr | None:
        if value is None:
            return None
        # Error messages never include the key material.
        return SecretStr(normalize_private_key(value.get_secret_value()))

    @field_validator("polymarket_funder_address", "polymarket_signer_address")
    @classmethod
    def _check_address(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return ensure_valid_evm_address(value)


class CtfSettings(BaseSettings):
    """Conditional Token Framework (split/merge/redeem) write-path settings (Module 17).

    Contract addresses are NOT stored here: they are read from
    :class:`ChainReadSettings` (``polygon_conditional_tokens_address``,
    ``polygon_usdc_address``) so there is a single trusted source and nothing is
    hard-coded in strategy code. Everything here is a safety gate or the
    standard Gnosis CTF binary-condition parameters (index sets / parent
    collection id), which are validated before use. No monetary value here is a
    binary float.

    Writes are OFF by default: ``ctf_enable_writes`` must be explicitly turned on
    (and LIVE_TRADING enabled) before any on-chain state-changing CTF operation
    is attempted. Gasless relaying is a separate optional adapter and is
    disabled by default; no gasless credentials are ever assumed.
    """

    model_config = _ENV

    # Manual gate for state-changing CTF writes (requirement 18). Read-only
    # mergeable-quantity queries never consult this flag.
    ctf_enable_writes: bool = False

    # Standard Gnosis CTF binary-condition partition. For a binary market the
    # two complementary index sets are 1 (0b01) and 2 (0b10); together they form
    # the full partition [1, 2] used by split/merge. These are documented Gnosis
    # conventions, not Polymarket-specific guesses, and are validated.
    ctf_up_index_set: int = Field(default=1, ge=1)
    ctf_down_index_set: int = Field(default=2, ge=1)
    # Parent collection id (bytes32). The root collateral collection is the
    # zero hash; operator-overridable for nested/neg-risk collections.
    ctf_parent_collection_id: str = "0x" + "00" * 32

    # Receipt monitoring for CTF transactions. Falls back to the shared
    # ChainReadSettings receipt timeout when these are unset.
    ctf_receipt_timeout_seconds: float | None = Field(default=None, gt=0)
    ctf_receipt_poll_interval_seconds: float | None = Field(default=None, gt=0)

    # Optional gasless relayer (requirements 15/16). Disabled by default; the
    # concrete relayer is a separate adapter and no credentials are assumed.
    ctf_gasless_enabled: bool = False

    @field_validator("ctf_parent_collection_id")
    @classmethod
    def _check_parent_collection(cls, value: str) -> str:
        text = value.strip().lower()
        candidate = text[2:] if text.startswith("0x") else text
        if len(candidate) != 64 or any(c not in "0123456789abcdef" for c in candidate):
            raise ValueError(
                "ctf_parent_collection_id must be 0x + 64 hex characters (bytes32)"
            )
        return "0x" + candidate

    @model_validator(mode="after")
    def _check_index_sets(self) -> "CtfSettings":
        if self.ctf_up_index_set == self.ctf_down_index_set:
            raise ValueError("ctf_up_index_set and ctf_down_index_set must differ")
        return self


class PaperExecutionSettings(BaseSettings):
    """Paper-execution simulator knobs (monetary values are Decimal)."""

    model_config = _ENV

    paper_starting_bankroll_usd: Decimal = Field(default=Decimal("1000"), gt=0)
    paper_taker_fee_bps: Decimal = Field(default=Decimal("0"), ge=0)
    paper_expected_slippage_bps: Decimal = Field(default=Decimal("0"), ge=0)
    paper_fill_probability: Decimal = Field(default=Decimal("1"), ge=0, le=1)
    paper_latency_ms: int = Field(default=50, ge=0)


class LiveExecutionSettings(BaseSettings):
    """Live-execution guard rails (monetary values are Decimal)."""

    model_config = _ENV

    live_max_order_notional_usd: Decimal = Field(default=Decimal("50"), gt=0)
    live_submit_timeout_seconds: float = Field(default=10.0, gt=0)
    live_order_poll_interval_seconds: float = Field(default=1.0, gt=0)
    # Blind retries of timed-out submissions are forbidden: default is 0.
    live_max_submit_retries: int = Field(default=0, ge=0)
    live_reconcile_on_timeout: bool = True


class PairStrategySettings(BaseSettings):
    """Pair-accumulation strategy parameters (all monetary values Decimal).

    These are conservative configuration knobs only. This module does not
    implement or assert any profitability of the strategy.
    """

    model_config = _ENV

    # Combined all-in target must be strictly below $1.
    max_effective_pair_cost_usd: Decimal = Field(
        default=Decimal("0.99"), gt=0, lt=1
    )
    safety_reserve_usd: Decimal = Field(default=Decimal("0.005"), ge=0)
    assumed_taker_fee_bps: Decimal = Field(default=Decimal("0"), ge=0)
    assumed_slippage_bps: Decimal = Field(default=Decimal("0"), ge=0)
    merge_gas_overhead_usd: Decimal = Field(default=Decimal("0.01"), ge=0)
    min_pair_size_tokens: Decimal = Field(default=Decimal("1"), gt=0)
    max_pair_size_tokens: Decimal = Field(default=Decimal("100"), gt=0)

    @model_validator(mode="after")
    def _check_sizes(self) -> "PairStrategySettings":
        if self.max_pair_size_tokens < self.min_pair_size_tokens:
            raise ValueError(
                "max_pair_size_tokens must be >= min_pair_size_tokens"
            )
        return self


class StateMachineSettings(BaseSettings):
    """Pair-accumulation state-machine limits and cutoffs (Module 18).

    Durations/counts are ints; monetary values are ``Decimal`` (never binary
    floats). These are conservative safety knobs only; nothing here implies the
    strategy is profitable.
    """

    model_config = _ENV

    # Default target size for a new first-leg proposal (outcome-token shares).
    target_pair_size_tokens: Decimal = Field(default=Decimal("5"), gt=0)
    # Stop opening NEW first legs once the window is within this many seconds of
    # close, so a pair can still plausibly be completed (requirement 11).
    first_leg_cutoff_seconds: int = Field(default=90, gt=0)
    # Cancel all resting passive orders once within this many seconds of close
    # (requirement 12).
    mandatory_cancel_seconds: int = Field(default=20, ge=0)
    # Hard ceilings on directional unmatched exposure (requirements 8/9).
    max_unmatched_shares: Decimal = Field(default=Decimal("50"), gt=0)
    max_unmatched_seconds: int = Field(default=120, gt=0)
    # Fraction of a hard limit at which the machine begins de-risking (cancel
    # passive orders, attempt a hedge) before the ceiling is breached. (0, 1].
    unmatched_warning_ratio: Decimal = Field(default=Decimal("0.8"), gt=0, le=1)
    # Schedule a CTF merge only when the locked net value of the matched pairs,
    # net of merge/gas overhead, is at least this many USD (requirement 10).
    merge_min_net_value_usd: Decimal = Field(default=Decimal("0"), ge=0)
    # Always reconcile on an uncertain / unknown event before proceeding
    # (requirement 13). Fail closed.
    reconcile_on_uncertain: bool = True
    # Bounded history of processed event / fill ids kept on a persisted session
    # snapshot for idempotency (requirement 3). Older ids age out.
    processed_id_history: int = Field(default=512, gt=0)

    @model_validator(mode="after")
    def _check(self) -> "StateMachineSettings":
        if self.mandatory_cancel_seconds >= self.first_leg_cutoff_seconds:
            raise ValueError(
                "first_leg_cutoff_seconds must be greater than "
                "mandatory_cancel_seconds"
            )
        return self


class RiskSettings(BaseSettings):
    """Centralized risk-engine limits (all monetary values Decimal)."""

    model_config = _ENV

    max_unmatched_notional_usd: Decimal = Field(default=Decimal("25"), gt=0)
    max_unmatched_duration_seconds: int = Field(default=120, gt=0)
    max_total_position_notional_usd: Decimal = Field(default=Decimal("100"), gt=0)
    max_open_orders: int = Field(default=10, gt=0)
    daily_loss_limit_usd: Decimal = Field(default=Decimal("50"), gt=0)
    kill_switch_enabled: bool = True
    kill_switch_key: str = "ppb:kill_switch"

    # -- Additional centralized risk-engine limits (Module 13) ----------
    # All monetary values are Decimal USD; counts/durations are ints. The
    # minimum Polygon gas balance is expressed in the chain's NATIVE token
    # units (POL/MATIC) as a Decimal (documented), never a binary float.
    max_order_quantity_shares: Decimal = Field(default=Decimal("50"), gt=0)
    max_order_collateral_usd: Decimal = Field(default=Decimal("25"), gt=0)
    max_unmatched_shares: Decimal = Field(default=Decimal("50"), gt=0)
    max_deployed_capital_usd: Decimal = Field(default=Decimal("200"), gt=0)
    max_reserved_collateral_usd: Decimal = Field(default=Decimal("100"), gt=0)
    max_loss_per_window_usd: Decimal = Field(default=Decimal("10"), gt=0)
    min_expected_pair_edge_usd: Decimal = Field(default=Decimal("0.005"), ge=0)
    min_hedge_depth_shares: Decimal = Field(default=Decimal("1"), gt=0)
    max_book_age_seconds: int = Field(default=5, gt=0)
    # Minimum seconds remaining before window close to open a NEW first leg.
    entry_min_seconds_before_close: int = Field(default=60, ge=0)
    # Resting orders must be cancelled by this many seconds before close; no
    # new orders are permitted inside this window.
    mandatory_cancel_seconds_before_close: int = Field(default=20, ge=0)
    max_api_failures: int = Field(default=5, gt=0)
    max_ws_reconnects: int = Field(default=10, gt=0)
    min_wallet_collateral_usd: Decimal = Field(default=Decimal("5"), ge=0)
    min_polygon_gas_native: Decimal = Field(default=Decimal("0.5"), ge=0)
    require_execution_leader: bool = True
    # Break-glass environment kill switch variable (read live by the risk
    # kill-switch composite). Presence of a truthy value forces fail-closed.
    kill_switch_env_var: str = "PPB_KILL_SWITCH"
    # Max age (seconds) of the most recent successful reconciliation that will
    # still satisfy the kill-switch clearing precondition.
    reconciliation_max_age_seconds: int = Field(default=300, gt=0)

    @model_validator(mode="after")
    def _check_close_windows(self) -> "RiskSettings":
        if (
            self.mandatory_cancel_seconds_before_close
            > self.entry_min_seconds_before_close
        ):
            raise ValueError(
                "mandatory_cancel_seconds_before_close must be <= "
                "entry_min_seconds_before_close"
            )
        return self


class MonitoringSettings(BaseSettings):
    """Metrics/monitoring configuration.

    Interface addition (Module 20): the fields below ``prometheus_namespace``
    are new, additive and backward compatible (all have safe defaults). They
    tune the private operator API's endpoint paths and the event-loop lag
    monitor. Existing fields are unchanged. Durations are plain ``float``
    seconds (never monetary), so binary floats are acceptable here.
    """

    model_config = _ENV

    monitoring_enabled: bool = False
    metrics_host: str = "127.0.0.1"
    metrics_port: int = Field(default=9090, ge=1, le=65535)
    prometheus_namespace: str = "ppb"
    # -- Module 20 additive fields --------------------------------------
    # Path of the Prometheus exposition endpoint on the private operator API.
    metrics_path: str = "/metrics"
    # Path prefix for the health endpoints (live/ready/details).
    health_path_prefix: str = "/health"
    # Whether to serve the verbose /health/details diagnostics endpoint.
    expose_details_endpoint: bool = True
    # How often the event-loop lag monitor samples scheduling drift (seconds).
    event_loop_lag_poll_seconds: float = Field(default=0.25, gt=0)
    # Timeout for a single readiness evaluation before failing closed (seconds).
    readiness_timeout_seconds: float = Field(default=5.0, gt=0)


class AlertsSettings(BaseSettings):
    """Operator alerting configuration. Webhook URL is treated as a secret."""

    model_config = _ENV

    alerts_enabled: bool = False
    alerts_webhook_url: SecretStr | None = None
    alerts_min_severity: AlertSeverity = "warning"


class DashboardSettings(BaseSettings):
    """Private read-only operator dashboard (Module 21).

    Bind to loopback (``dashboard_host``) and reach it over SSH/VPN. The bearer
    token is a secret; blank means VPN-only access. Cadence/counts are plain
    ints (never monetary), so they are not Decimals.
    """

    model_config = _ENV

    dashboard_enabled: bool = False
    dashboard_host: str = "127.0.0.1"
    dashboard_port: int = Field(default=8082, ge=1, le=65535)
    dashboard_auth_token: SecretStr | None = None
    dashboard_refresh_seconds: int = Field(default=5, gt=0)
    dashboard_recent_fills: int = Field(default=20, ge=1)
    dashboard_title: str = "Operator dashboard"


class CoordinationSettings(BaseSettings):
    """Redis coordination / leader-election timings.

    Durations are plain ``float``/``int`` seconds (not monetary), so binary
    floats are acceptable here. The lease TTL is intentionally short and must be
    strictly greater than the renewal interval so a healthy leader renews well
    before expiry; likewise for heartbeats.
    """

    model_config = _ENV

    leader_lease_ttl_seconds: float = Field(default=10.0, gt=0)
    leader_renew_interval_seconds: float = Field(default=3.0, gt=0)
    heartbeat_ttl_seconds: float = Field(default=15.0, gt=0)
    heartbeat_interval_seconds: float = Field(default=5.0, gt=0)
    market_metadata_ttl_seconds: int = Field(default=30, gt=0)
    idempotency_ttl_seconds: int = Field(default=86_400, gt=0)
    risk_counter_ttl_seconds: int = Field(default=86_400, gt=0)
    redis_operation_timeout_seconds: float = Field(default=2.0, gt=0)

    @model_validator(mode="after")
    def _check_intervals(self) -> "CoordinationSettings":
        if self.leader_renew_interval_seconds >= self.leader_lease_ttl_seconds:
            raise ValueError(
                "leader_renew_interval_seconds must be < leader_lease_ttl_seconds "
                "so the lease is renewed before it expires"
            )
        if self.heartbeat_interval_seconds >= self.heartbeat_ttl_seconds:
            raise ValueError(
                "heartbeat_interval_seconds must be < heartbeat_ttl_seconds"
            )
        return self


class MarketDiscoverySettings(BaseSettings):
    """BTC five-minute market discovery configuration (Module 5).

    Durations/counts are plain ``float``/``int`` (not monetary) so binary
    floats are acceptable here; no price/quantity value lives in this group.

    The BTC 5-minute slug format is intentionally NOT hard-coded. Operators
    must set ``MARKET_DISCOVERY_BTC_5M_SLUG_TEMPLATE`` (a ``str.format`` string
    using placeholders such as ``{date}``/``{hour}``/``{minute}``/``{hhmm}``/
    ``{open_epoch}``) after verifying the exact slug format against live
    Polymarket data, or pass an explicit ``--slug`` override. When neither is
    set, discovery fails closed with a clear message instead of guessing.
    """

    model_config = _ENV

    btc_5m_slug_template: str | None = None
    # Zero-config automatic discovery. When enabled AND no slug template / --slug
    # override is supplied, the service resolves the current (and next) BTC
    # 5-minute market straight from the Gamma /markets API by matching the
    # computed UTC window, so no operator-supplied slug is required. A slug
    # template or an explicit --slug still takes precedence when provided.
    discovery_auto_enabled: bool = True
    # Case-insensitive keyword the auto path uses to keep only Bitcoin markets
    # (matched against each candidate's slug / question / title). Set blank to
    # disable keyword filtering and rely purely on window + outcome matching.
    discovery_auto_keyword: str = "bitcoin"
    # Upper bound on candidate markets fetched per auto-discovery request.
    discovery_auto_max_candidates: int = Field(default=100, ge=1, le=1000)
    # Narrow the Gamma query to markets whose close time is near the requested
    # window using the documented endDate range filters. Disable to fall back to
    # a broad active-market scan filtered entirely client-side.
    discovery_auto_use_date_filter: bool = True
    # Optional Gamma tag id to further constrain the auto candidate set.
    discovery_auto_tag_id: str | None = None
    discovery_expected_up_outcome: str = "Up"
    discovery_expected_down_outcome: str = "Down"
    # Tolerance (seconds) when matching a discovered market to a computed
    # window; absorbs minor metadata skew without accepting the wrong market.
    discovery_window_match_tolerance_seconds: int = Field(default=90, ge=0)
    discovery_require_window_match: bool = True
    discovery_request_timeout_seconds: float = Field(default=10.0, gt=0)
    discovery_max_retries: int = Field(default=4, ge=0)
    discovery_backoff_base_seconds: float = Field(default=0.5, gt=0)
    discovery_backoff_max_seconds: float = Field(default=8.0, gt=0)
    discovery_preload_next_window: bool = True
    # Overrides the coordination market-metadata cache TTL when set (> 0).
    discovery_cache_ttl_seconds: int | None = Field(default=None, ge=1)

    @field_validator("discovery_expected_up_outcome", "discovery_expected_down_outcome")
    @classmethod
    def _non_empty(cls, value: str) -> str:
        text = value.strip()
        if not text:
            raise ValueError("expected outcome name must be non-empty")
        return text

    @model_validator(mode="after")
    def _check_backoff(self) -> "MarketDiscoverySettings":
        if self.discovery_backoff_max_seconds < self.discovery_backoff_base_seconds:
            raise ValueError(
                "discovery_backoff_max_seconds must be >= "
                "discovery_backoff_base_seconds"
            )
        if (
            self.discovery_expected_up_outcome.strip().casefold()
            == self.discovery_expected_down_outcome.strip().casefold()
        ):
            raise ValueError("expected Up and Down outcome names must differ")
        return self


class MarketDataSettings(BaseSettings):
    """Public CLOB market-data WebSocket / order-book configuration (Module 6).

    All values here are durations (seconds), counts or plain strings, never
    monetary values, so ``float``/``int`` are acceptable. The feed reads market
    data only; it never submits orders.
    """

    model_config = _ENV

    # A book older than this (seconds since its last applied update) is STALE
    # and must not be used for pricing (freshness check).
    stale_after_seconds: float = Field(default=5.0, gt=0)
    # Bounded queue between the socket reader and the book processor.
    max_queue_size: int = Field(default=1000, ge=1)
    reconnect_base_seconds: float = Field(default=0.5, gt=0)
    reconnect_max_seconds: float = Field(default=30.0, gt=0)
    # None => retry forever (default for a long-running feed).
    max_reconnect_attempts: int | None = Field(default=None, ge=1)
    connect_timeout_seconds: float = Field(default=10.0, gt=0)
    ping_interval_seconds: float = Field(default=20.0, gt=0)
    ping_timeout_seconds: float = Field(default=20.0, gt=0)
    # Subscription channel type on the documented market WebSocket.
    subscribe_type: str = "market"

    @model_validator(mode="after")
    def _check_backoff(self) -> "MarketDataSettings":
        if self.reconnect_max_seconds < self.reconnect_base_seconds:
            raise ValueError(
                "reconnect_max_seconds must be >= reconnect_base_seconds"
            )
        return self


class RetentionSettings(BaseSettings):
    """Retention windows (in whole days) for high-volume persisted data.

    Retention is applied only by an operator-invoked maintenance command
    (``persistence.admin`` / the ``db retention`` CLI); it never runs
    automatically during tests or normal development. A value of ``0`` disables
    pruning for that table (retain forever). ``retention_enabled`` is an
    additional master guard that must be true before any row is deleted.
    """

    model_config = _ENV

    retention_enabled: bool = False
    pair_opportunity_retention_days: int = Field(default=30, ge=0)
    inventory_snapshot_retention_days: int = Field(default=90, ge=0)
    reconciliation_retention_days: int = Field(default=90, ge=0)
    system_event_retention_days: int = Field(default=180, ge=0)
    market_data_snapshot_retention_days: int = Field(default=30, ge=0)


class RecorderSettings(BaseSettings):
    """Research-grade market-data recorder configuration (Module 7).

    The recorder is a read-only research tool; it captures the local Up/Down
    books and never derives or places an order. Monetary trigger levels are
    ``Decimal`` (parsed from a comma-separated string); intervals are plain
    ``float`` seconds (durations, never money).
    """

    model_config = _ENV

    recorder_enabled: bool = False
    recorder_output_dir: str = "data/market_data"
    # How often the in-memory books are sampled. Must be <= the periodic
    # snapshot interval so the one-second cadence is never missed.
    recorder_poll_interval_seconds: float = Field(default=0.25, gt=0)
    recorder_snapshot_interval_seconds: float = Field(default=1.0, gt=0)
    recorder_top_depth_levels: int = Field(default=10, ge=1, le=1000)
    # Comma-separated executable-pair-cost levels whose crossing triggers an
    # event snapshot, e.g. "0.98,0.99,1.00". Empty disables the trigger.
    recorder_pair_cost_levels: str = ""
    recorder_buffer_max_size: int = Field(default=10000, ge=1)
    recorder_overflow_policy: RecorderOverflowPolicy = RecorderOverflowPolicy.DROP_OLDEST
    recorder_write_batch_size: int = Field(default=500, ge=1)
    recorder_flush_interval_seconds: float = Field(default=2.0, gt=0)
    recorder_file_rotation_seconds: float = Field(default=300.0, gt=0)
    recorder_parquet_compression: str = "zstd"
    recorder_persist_summaries: bool = True

    @field_validator("recorder_pair_cost_levels")
    @classmethod
    def _check_levels(cls, value: str) -> str:
        for part in value.split(","):
            token = part.strip()
            if not token:
                continue
            try:
                level = Decimal(token)
            except (ArithmeticError, ValueError) as exc:
                raise ValueError(
                    f"invalid RECORDER_PAIR_COST_LEVELS entry: {token!r}"
                ) from exc
            if level <= 0:
                raise ValueError("RECORDER_PAIR_COST_LEVELS entries must be > 0")
        return value

    @model_validator(mode="after")
    def _check_intervals(self) -> "RecorderSettings":
        if self.recorder_poll_interval_seconds > self.recorder_snapshot_interval_seconds:
            raise ValueError(
                "RECORDER_POLL_INTERVAL_SECONDS must be <= "
                "RECORDER_SNAPSHOT_INTERVAL_SECONDS so periodic snapshots are "
                "not missed"
            )
        return self

    @property
    def pair_cost_levels(self) -> tuple[Decimal, ...]:
        """Parsed, sorted, de-duplicated pair-cost trigger levels."""
        levels = {
            Decimal(part.strip())
            for part in self.recorder_pair_cost_levels.split(",")
            if part.strip()
        }
        return tuple(sorted(levels))


class ReconciliationSettings(BaseSettings):
    """Authoritative reconciliation tunables (Module 15).

    All monetary/quantity tolerances are :class:`~decimal.Decimal`; never floats.
    Trading-relevant defaults fail closed: unknown remote orders are cancelled,
    balance mismatches stop new trading.
    """

    model_config = _ENV

    reconciliation_enabled: bool = True
    reconciliation_interval_seconds: float = Field(default=60.0, gt=0)
    reconciliation_auto_cancel_unknown_orders: bool = True
    reconciliation_halt_on_balance_mismatch: bool = True
    # Comparisons treat differences at/under these tolerances as equal.
    reconciliation_share_tolerance: Decimal = Field(
        default=Decimal("0.000001"), ge=0
    )
    reconciliation_price_tolerance: Decimal = Field(
        default=Decimal("0.000001"), ge=0
    )
    reconciliation_collateral_tolerance_usd: Decimal = Field(
        default=Decimal("0.01"), ge=0
    )
    # When True, an unavailable on-chain source degrades the run to
    # manual_review instead of an informational note (Modules 20-21 pending).
    reconciliation_require_chain_verification: bool = False
    # Optional spender address whose allowance must be positive before live
    # buying. Empty disables the allowance-shortfall check (never guessed).
    reconciliation_expected_allowance_spender: str = ""


_BACKTEST_ENV = SettingsConfigDict(
    env_file=".env",
    env_file_encoding="utf-8",
    extra="ignore",
    case_sensitive=False,
    env_prefix="BACKTEST_",
    # Blank .env entries fall back to defaults (see `_ENV`).
    env_ignore_empty=True,
)


class BacktestSettings(BaseSettings):
    """Deterministic replay / backtest knobs (Module 22).

    All monetary rates are ``Decimal`` (never binary floats); probabilities are
    ``Decimal`` in ``[0, 1]``; latencies/durations are integer milliseconds.
    These knobs drive the paper execution model used during replay and the
    reporting buckets; they never affect live trading. Environment variables are
    prefixed ``BACKTEST_`` (e.g. ``BACKTEST_SEED``).
    """

    model_config = _BACKTEST_ENV

    seed: int = 0
    ack_latency_ms: int = Field(default=50, ge=0)
    latency_jitter_ms: int = Field(default=0, ge=0)
    cancel_latency_ms: int = Field(default=50, ge=0)
    taker_fee_bps: Decimal = Field(default=Decimal("0"), ge=0)
    maker_fee_bps: Decimal = Field(default=Decimal("0"), ge=0)
    expected_slippage_bps: Decimal = Field(default=Decimal("0"), ge=0)
    maker_fill_probability: Decimal = Field(default=Decimal("1"), ge=0, le=1)
    unknown_submission_probability: Decimal = Field(default=Decimal("0"), ge=0, le=1)
    stale_after_ms: int = Field(default=5_000, gt=0)
    gtd_ttl_ms: int = Field(default=60_000, gt=0)
    settle_buffer_ms: int = Field(default=250, ge=0)
    time_to_close_buckets: str = "60,120,180,240"
    size_buckets: str = "5,25,100"

    @field_validator("time_to_close_buckets")
    @classmethod
    def _check_ttc(cls, value: str) -> str:
        edges = [part.strip() for part in value.split(",") if part.strip()]
        if not edges:
            raise ValueError("BACKTEST_TIME_TO_CLOSE_BUCKETS must not be empty")
        for token in edges:
            try:
                seconds = int(token)
            except ValueError as exc:
                raise ValueError(
                    f"invalid BACKTEST_TIME_TO_CLOSE_BUCKETS entry: {token!r}"
                ) from exc
            if seconds <= 0:
                raise ValueError("time-to-close bucket edges must be > 0")
        return value

    @field_validator("size_buckets")
    @classmethod
    def _check_size(cls, value: str) -> str:
        edges = [part.strip() for part in value.split(",") if part.strip()]
        if not edges:
            raise ValueError("BACKTEST_SIZE_BUCKETS must not be empty")
        for token in edges:
            try:
                size = Decimal(token)
            except (ArithmeticError, ValueError) as exc:
                raise ValueError(
                    f"invalid BACKTEST_SIZE_BUCKETS entry: {token!r}"
                ) from exc
            if size <= 0:
                raise ValueError("size bucket edges must be > 0")
        return value

    @property
    def time_to_close_edges(self) -> tuple[int, ...]:
        """Parsed, sorted, de-duplicated time-to-close bucket edges (seconds)."""
        edges = {
            int(part.strip())
            for part in self.time_to_close_buckets.split(",")
            if part.strip()
        }
        return tuple(sorted(edges))

    @property
    def size_edges(self) -> tuple[Decimal, ...]:
        """Parsed, sorted, de-duplicated target-size bucket edges (shares)."""
        edges = {
            Decimal(part.strip())
            for part in self.size_buckets.split(",")
            if part.strip()
        }
        return tuple(sorted(edges))
