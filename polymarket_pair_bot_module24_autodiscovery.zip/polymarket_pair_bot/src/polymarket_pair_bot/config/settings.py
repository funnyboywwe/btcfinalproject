"""Root application configuration composed from grouped settings models.

Interface change (Module 1): Module 0 exposed a single flat ``Settings`` model.
Module 1 replaces it with ``AppConfig``, a composition of 14 grouped settings
models (Application, Logging, PostgreSQL, Redis, Polymarket public / auth,
Polygon, Wallet, Paper/Live execution, Pair strategy, Risk, Monitoring,
Alerts). ``Settings`` remains available as a backward-compatible alias for
``AppConfig`` and ``load_config()`` is the preferred constructor.

Secrets use ``SecretStr`` everywhere. Trading is OFF by default. Cross-cutting
invariants (paper/live exclusivity lives on ApplicationSettings; live requires
complete authenticated configuration) are enforced here.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from polymarket_pair_bot.config.enums import RunMode
from polymarket_pair_bot.config.models import (
    AlertsSettings,
    ApplicationSettings,
    BacktestSettings,
    ChainReadSettings,
    CtfSettings,
    CoordinationSettings,
    DashboardSettings,
    LiveExecutionSettings,
    LoggingSettings,
    MarketDataSettings,
    MarketDiscoverySettings,
    MonitoringSettings,
    PaperExecutionSettings,
    PairStrategySettings,
    PolygonSettings,
    PolymarketAuthSettings,
    PolymarketPublicSettings,
    PostgresSettings,
    RecorderSettings,
    ReconciliationSettings,
    RedisSettings,
    RetentionSettings,
    RiskSettings,
    StateMachineSettings,
    WalletSettings,
)
from polymarket_pair_bot.security.redaction import redact_mapping


class AppConfig(BaseModel):
    """Fully-typed, validated application configuration."""

    model_config = ConfigDict(frozen=True)

    application: ApplicationSettings = Field(default_factory=ApplicationSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    postgres: PostgresSettings = Field(default_factory=PostgresSettings)
    redis: RedisSettings = Field(default_factory=RedisSettings)
    coordination: CoordinationSettings = Field(default_factory=CoordinationSettings)
    market_discovery: MarketDiscoverySettings = Field(
        default_factory=MarketDiscoverySettings
    )
    market_data: MarketDataSettings = Field(default_factory=MarketDataSettings)
    recorder: RecorderSettings = Field(default_factory=RecorderSettings)
    reconciliation: ReconciliationSettings = Field(
        default_factory=ReconciliationSettings
    )
    retention: RetentionSettings = Field(default_factory=RetentionSettings)
    polymarket_public: PolymarketPublicSettings = Field(
        default_factory=PolymarketPublicSettings
    )
    polymarket_auth: PolymarketAuthSettings = Field(
        default_factory=PolymarketAuthSettings
    )
    polygon: PolygonSettings = Field(default_factory=PolygonSettings)
    chain: ChainReadSettings = Field(default_factory=ChainReadSettings)
    wallet: WalletSettings = Field(default_factory=WalletSettings)
    ctf: CtfSettings = Field(default_factory=CtfSettings)
    paper_execution: PaperExecutionSettings = Field(
        default_factory=PaperExecutionSettings
    )
    live_execution: LiveExecutionSettings = Field(
        default_factory=LiveExecutionSettings
    )
    pair_strategy: PairStrategySettings = Field(
        default_factory=PairStrategySettings
    )
    state_machine: StateMachineSettings = Field(
        default_factory=StateMachineSettings
    )
    risk: RiskSettings = Field(default_factory=RiskSettings)
    # Additive (Module 22): deterministic replay / backtest knobs. Defaults keep
    # existing configs valid; no live-trading behavior is affected.
    backtest: BacktestSettings = Field(default_factory=BacktestSettings)
    monitoring: MonitoringSettings = Field(default_factory=MonitoringSettings)
    alerts: AlertsSettings = Field(default_factory=AlertsSettings)
    dashboard: DashboardSettings = Field(default_factory=DashboardSettings)

    @property
    def run_mode(self) -> RunMode:
        """Operating mode derived from the trading safety switches."""
        if self.application.live_trading:
            return RunMode.LIVE
        if self.application.paper_trading:
            return RunMode.PAPER
        return RunMode.RECORDER

    @model_validator(mode="after")
    def _enforce_live_requirements(self) -> "AppConfig":
        """Live mode fails closed without complete authenticated configuration."""
        if not self.application.live_trading:
            return self
        missing: list[str] = []
        if self.wallet.polymarket_private_key is None:
            missing.append("POLYMARKET_PRIVATE_KEY")
        if self.wallet.polymarket_funder_address is None:
            missing.append("POLYMARKET_FUNDER_ADDRESS")
        missing.extend(self.polymarket_auth.missing_fields())
        if self.polygon.polygon_rpc_primary is None:
            missing.append("POLYGON_RPC_PRIMARY")
        if self.polygon.polygon_rpc_secondary is None:
            missing.append("POLYGON_RPC_SECONDARY")
        if missing:
            raise ValueError(
                "LIVE_TRADING=true requires complete authenticated configuration; "
                "missing: " + ", ".join(missing)
            )
        return self

    def redacted_summary(self) -> dict[str, Any]:
        """Return a fully-redacted, log-safe dump of the entire configuration."""
        return redact_mapping(self.model_dump())

    def health_public_view(self) -> dict[str, Any]:
        """Return a minimal, non-secret view safe for private health endpoints.

        Contains only coarse operational flags — never any secret, DSN, URL,
        address or credential.
        """
        return {
            "app_env": self.application.app_env.value,
            "run_mode": self.run_mode.value,
            "paper_trading": self.application.paper_trading,
            "live_trading": self.application.live_trading,
            "chain_id": self.polygon.polygon_chain_id,
            "signature_type": int(self.wallet.polymarket_signature_type),
            "monitoring_enabled": self.monitoring.monitoring_enabled,
            "alerts_enabled": self.alerts.alerts_enabled,
            "log_level": self.logging.log_level,
        }


def load_config() -> AppConfig:
    """Construct :class:`AppConfig` from the environment and ``.env``."""
    return AppConfig()


# Backward-compatible alias for code written against the Module 0 name.
Settings = AppConfig
