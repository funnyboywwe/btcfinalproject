# Polymarket Pair Bot — VPS Requirements & From-Scratch Deployment Guide

> **Safety first.** This build ships with `PAPER_TRADING=true` and `LIVE_TRADING=false`.
> Nothing in this guide enables live trading. Going live is a **separate, manually
> gated step** (see the last section). No profitability is claimed anywhere.

This guide takes you from a **blank VPS** to a **running bot in paper mode**, using the
project's own production Docker Compose stack (`docker/docker-compose.prod.yml`) and
deploy scripts (`deploy/scripts/*`). A native (no-Docker) path is included as an
appendix.

---

## 1. VPS requirements

### 1.1 Sizing

The production stack runs four containers: the **bot**, **PostgreSQL 16**, **Redis 7**,
and a one-shot **migrate** job. The compose file caps resources at: bot `1.0 CPU / 512 MB`,
postgres `512 MB`, redis `256 MB`.

| Tier | vCPU | RAM | Disk | Use |
|------|------|-----|------|-----|
| Minimum | 2 | 2 GB | 20 GB SSD | Paper mode, recorder OFF |
| **Recommended** | **2** | **4 GB** | **40 GB NVMe SSD** | Paper + headroom, small live pilot |
| With recorder ON | 2–4 | 4–8 GB | 80+ GB NVMe SSD | Parquet market-data recording is high-volume |

- **CPU:** 2 vCPU is enough (the workload is I/O- and latency-bound, not CPU-bound).
- **RAM:** container limits total ~1.3 GB; 4 GB leaves room for the OS, backups, and Postgres cache.
- **Disk:** the base DB stays small. **Only** grows large if you enable the market-data
  recorder (`RECORDER_ENABLED=true`), which writes compressed Parquet. Use SSD/NVMe.

### 1.2 Operating system

- **Ubuntu 22.04 / 24.04 LTS** or **Debian 12** (recommended — Docker-friendly, well documented).
- 64-bit x86_64. Amazon Linux 2023 / RHEL-family also work.
- **NTP time sync is mandatory** — the preflight check *fails hard* if the clock is not
  NTP-synchronized (order timing and 5-minute windows depend on it).

### 1.3 Network

- Stable, low-latency egress to **Polymarket** (`clob.polymarket.com`,
  `gamma-api.polymarket.com`, `ws-subscriptions-clob.polymarket.com`) and your
  **Polygon RPC** provider. The strategy trades 5-minute windows, so latency and
  connection stability matter.
- A provider/region with good connectivity to Polymarket infrastructure (typically
  US-based) is preferable. A static IP is helpful if your RPC provider allowlists IPs.
- **No public inbound ports are required.** The operator API (8081), metrics (9090),
  and dashboard (8082) publish **only on `127.0.0.1`** and are reached via an **SSH tunnel**.

### 1.4 Accounts & secrets you must have BEFORE going live (not needed for paper)

- **Polymarket authenticated API**: `POLYMARKET_API_KEY`, `POLYMARKET_API_SECRET`, `POLYMARKET_API_PASSPHRASE`.
- **Two Polygon RPC URLs** (primary + secondary; both required for live).
- A **dedicated, limited-capital wallet**: `POLYMARKET_PRIVATE_KEY`, `POLYMARKET_FUNDER_ADDRESS`.
- Optional: alert webhook URL, dashboard bearer token.

---

## 2. Prerequisites on the VPS

You need: Docker Engine + Compose plugin, Git, a non-root sudo user, a firewall, and NTP.

---

## 3. Step-by-step: from a blank VPS to paper mode

### Step 1 — Create a non-root user and harden SSH

```bash
# As root on the fresh VPS:
adduser deploy
usermod -aG sudo deploy
# Copy your SSH key for the new user, then log in as 'deploy' from now on.
rsync --archive --chown=deploy:deploy ~/.ssh /home/deploy
```

Disable password/root SSH login in `/etc/ssh/sshd_config` (`PermitRootLogin no`,
`PasswordAuthentication no`), then `sudo systemctl restart ssh`.

### Step 2 — Update the OS and enable NTP time sync

```bash
sudo apt update && sudo apt -y upgrade
sudo timedatectl set-ntp true
timedatectl show -p NTPSynchronized --value   # must print: yes
```

### Step 3 — Enable a firewall (preflight requires one active)

```bash
sudo apt -y install ufw
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow OpenSSH            # keep SSH reachable
sudo ufw enable
sudo ufw status                  # must show: Status: active
```

Do **not** open 8081/8082/9090 to the world — they stay on loopback and are tunneled.

### Step 4 — Install Docker Engine + Compose plugin

```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker deploy
newgrp docker                    # or log out/in
docker --version && docker compose version
```

### Step 5 — Get the code onto the VPS

Either clone your private repo or upload the release zip:

```bash
# Option A: git
git clone <your-private-repo-url> polymarket_pair_bot

# Option B: upload the zip from your machine, then:
unzip polymarket_pair_bot_module24_consolidated.zip
cd polymarket_pair_bot
```

### Step 6 — Create the three configuration files

All production config lives under `docker/`. Copy the templates:

```bash
cd docker
cp .env.prod.example .env                    # compose variables (DB creds, image tag, bind addr)
cp env/app.env.example env/app.env           # NON-secret runtime config
cp secrets/secrets.env.example secrets/secrets.env   # SECRETS (blank for paper)
chmod 600 .env secrets/secrets.env           # preflight FAILS if these are group/world readable
cd ..
```

**Edit `docker/.env`** — set a strong Postgres password (the only required change for paper):

```ini
IMAGE_NAME=polymarket-pair-bot
IMAGE_TAG=latest            # pin an immutable tag in real production, not "latest"
BIND_ADDR=127.0.0.1         # keep on loopback; reach ports via SSH tunnel
POSTGRES_USER=bot
POSTGRES_PASSWORD=<set-a-strong-password>
POSTGRES_DB=pair_bot
```

**`docker/env/app.env`** is already safe for paper: `APP_ENV=production`,
`PAPER_TRADING=true`, `LIVE_TRADING=false`, monitoring + dashboard enabled on loopback.
Leave it as-is for the first run.

**`docker/secrets/secrets.env`** — leave **all values blank** for paper mode. Fill it in
only when going live (Section 6). `DATABASE_URL` and `REDIS_URL` are injected automatically
by compose; do not set them yourself.

### Step 7 — Preflight safety check

```bash
make prod-preflight
# or: deploy/scripts/preflight.sh
```

This verifies: config files exist with `600` perms, `PAPER_TRADING`/`LIVE_TRADING` are not
both true, a firewall is active, and the clock is NTP-synced. Fix any **FAIL** before continuing.

### Step 8 — Build the image and apply database migrations

```bash
make prod-build       # docker compose -f docker/docker-compose.prod.yml build
make prod-migrate     # one-shot Alembic upgrade to head, then exits
```

The `migrate` service runs `alembic upgrade head` (migrations `0001_initial_schema`,
`0002_market_data_snapshots`) against Postgres and exits 0. The bot will not start until
this has completed successfully.

### Step 9 — Start the stack (paper mode)

Use the gated helper (runs preflight → build/pull → migrate → up → waits for health):

```bash
make prod-deploy         # asks for confirmation; add --yes to skip the prompt
# equivalent manual path:
#   make prod-up
#   make prod-ps
```

### Step 10 — Verify it is healthy

```bash
make prod-ps             # bot should show "healthy"
make prod-logs           # expect application_configuring -> application_ready
make prod-health         # operator health probe
```

You should see the lifecycle reach `application_ready` and the container report `healthy`.

---

## 4. Accessing the private operator surfaces (SSH tunnel)

The operator API, metrics, and dashboard bind only to `127.0.0.1` on the VPS. From your
laptop, open an SSH tunnel:

```bash
ssh -N -L 8081:127.0.0.1:8081 \
       -L 8082:127.0.0.1:8082 \
       -L 9090:127.0.0.1:9090  deploy@<vps-ip>
```

Then browse locally:

- **http://localhost:8081** — private operator/health API
- **http://localhost:8082** — read-only operator dashboard
- **http://localhost:9090** — Prometheus metrics

If you set `DASHBOARD_AUTH_TOKEN` in `secrets.env`, the dashboard requires that bearer token;
if blank, you rely on network isolation (firewall + tunnel) only.

---

## 5. Ongoing operations

| Task | Command |
|------|---------|
| Tail bot logs | `make prod-logs` |
| Service status | `make prod-ps` |
| Health probe | `make prod-health` |
| DB revision/health | container role `db-health` |
| Encrypted DB backup | `make prod-backup` |
| Verify a backup restores | `make prod-restore-verify` |
| Kill-switch status | `make coord-kill-status` |
| **Activate kill switch** | `make coord-kill-activate REASON="..." ACTOR="you"` |
| Stop the stack | `make prod-down` |

**Supervision & restarts:** the bot container uses `restart: "no"` on purpose — **systemd**
is the single supervisor so a crash-looping trader cannot keep retrying. Install the unit
for auto-start on boot + bounded restarts:

```bash
sudo cp deploy/systemd/polymarket-pair-bot.service /etc/systemd/system/
# For encrypted scheduled backups:
sudo cp deploy/systemd/polymarket-pair-bot-backup.service /etc/systemd/system/
sudo cp deploy/systemd/polymarket-pair-bot-backup.timer   /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now polymarket-pair-bot.service
sudo systemctl enable --now polymarket-pair-bot-backup.timer
```

**Security posture (already enforced by the compose file):** postgres + redis are on an
`internal` network (no host ports, no internet egress); only the bot has outbound egress;
the bot runs non-root, read-only rootfs, `no-new-privileges`, all Linux caps dropped; logs
are size-rotated.

---

## 6. Going live (mandatory, human-gated — do NOT skip)

> Completing this is **necessary but not sufficient**, and is **not** an endorsement of the
> strategy. Only ever fund a **dedicated, limited-capital** wallet.

1. **Collect a sufficient paper-trading sample** and review it.
2. **Fill `docker/secrets/secrets.env`** (kept `chmod 600`): Polymarket API key/secret/passphrase,
   **both** `POLYGON_RPC_PRIMARY` and `POLYGON_RPC_SECONDARY`, and the dedicated wallet
   `POLYMARKET_PRIVATE_KEY` + `POLYMARKET_FUNDER_ADDRESS`. Prefer a real secret manager over a flat file.
3. **In `docker/env/app.env`** set `WALLET_IS_DEDICATED_ACK=true` and confirm `POLYGON_CHAIN_ID=137`.
4. **Test the kill switch** (engage → verify new trading stops, cancellation still works) and run a
   full **reconciliation** pass. Confirm **backups** restore and **alerts** fire end-to-end.
5. **Run the release gate** with every human confirmation (all automated gates must also pass):

   ```bash
   uv run polymarket-pair-bot release-gate \
     --confirm legal_eligibility --confirm dedicated_wallet --confirm limited_capital \
     --confirm working_backups --confirm working_alerts --confirm reviewed_risk_limits \
     --confirm tested_kill_switch --confirm successful_reconciliation \
     --confirm sufficient_paper_sample --confirm reviewed_tx_config --confirm reviewed_market_api
   ```

6. **Only then**, flip the switches in `docker/env/app.env`: `PAPER_TRADING=false` **and**
   `LIVE_TRADING=true` (they must never both be true), re-run `make prod-preflight` (it hard-fails
   if live prerequisites are missing), then `make prod-deploy`. Start with tiny size
   (`LIVE_MAX_ORDER_NOTIONAL_USD`, `MAX_TOTAL_POSITION_NOTIONAL_USD`) and watch closely.

See `docs/go-live-checklist.md`, `docs/runbooks/deployment.md`, and `docs/runbooks/reconciliation.md`.

---

## 7. Appendix A — Native (no-Docker) install

For a single-process install supervised directly by systemd:

```bash
# System deps
sudo apt -y install python3.12 python3.12-venv postgresql-16 redis-server git curl
curl -LsSf https://astral.sh/uv/install.sh | sh    # install 'uv'

# App deps (from repo root)
uv sync                                            # creates .venv from uv.lock (Python >=3.12)

# Configure: copy the root template and edit
cp .env.example .env && chmod 600 .env
# Point DATABASE_URL / REDIS_URL at your local Postgres/Redis; keep PAPER_TRADING=true.

# Migrate + run
make db-migrate            # uv run python -m polymarket_pair_bot.persistence.cli migrate
make db-health
make run                   # uv run polymarket-pair-bot   (paper mode)

# Supervise with the provided native unit
sudo cp deploy/systemd/polymarket-pair-bot-native.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now polymarket-pair-bot-native.service
```

---

## 8. Appendix B — Quick reference

**Stack:** Python >= 3.12 (managed by `uv`), FastAPI/uvicorn, SQLAlchemy 2 + Alembic +
asyncpg (PostgreSQL 16), Redis 7 (leader election / coordination / kill switch),
websockets/httpx/aiohttp (Polymarket feeds), web3/eth-account (Polygon/CTF),
prometheus-client, pyarrow (recorder).

**Config layering:** `docker/.env` (compose vars) -> `docker/env/app.env` (non-secret) ->
`docker/secrets/secrets.env` (secrets). `DATABASE_URL`/`REDIS_URL` are injected by compose.

**Ports (loopback only):** 8081 operator API, 8082 dashboard, 9090 metrics.

**Golden safety rules:** `PAPER_TRADING` and `LIVE_TRADING` are never both true; live requires
dual RPC + dedicated wallet + `WALLET_IS_DEDICATED_ACK=true` + the full release gate; the
kill switch always allows cancellation; keep secret files `chmod 600`.
